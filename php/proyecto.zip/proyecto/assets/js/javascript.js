function Saludo() {
  alert("Hola humano!");
}