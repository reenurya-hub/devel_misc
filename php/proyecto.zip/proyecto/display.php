<?php
function display()
{
    echo "<p>hola ".$_POST["name"]."</p>";
}
if(isset($_POST['submit']))
{
   display();
} 
?>
