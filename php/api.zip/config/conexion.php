<?php
class Conectar {
    protected $dbh;
    protected function Conexion() {
        try {
            $conectar = $this->dbh = new PDO(
                "mysql:local=localhost;dbname=seminario",
                "root",
                ""
            );
            return $conectar;
        } catch (Exception $e) {
            print "Tenemos error en la conexion " .
            $e->getMessage() . " <br>";
            die();
        }
    }
    
    public function set_names(){
        return $this->dbh->query("SET NAMES 'utf8'");
    }
}