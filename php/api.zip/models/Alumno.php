<?php

class Alumno extends Conectar {
    public function getAlumnos(){
        $conectar = parent::Conexion();
        parent::set_names();
        $sql = "select * from alumnos";
        $sql = $conectar->prepare($sql);
        $sql->execute();
        $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    }

    public function getAlumnoId($id){
        $conectar = parent::Conexion();
        parent::set_names();
        $sql = "select * from alumnos where id = ? ";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $id);
        $sql->execute();
        return $sql->fetch(PDO::FETCH_ASSOC);
    }

    public function nuevoAlumno($nombre, $apellido, $fecha, $telefono){
        $conectar = parent::Conexion();
        parent::set_names();
        $sql = " insert into alumnos
            (id, nombre, apellido, fecha_nacimiento, telefono)
            values
            (NULL, ?, ?, ?, ?) ";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombre);
        $sql->bindValue(2, $apellido);
        $sql->bindValue(3, $fecha);
        $sql->bindValue(4, $telefono);
        $sql->execute();
    }

    public function actualizarAlumno($id, $nombre, $apellido, $fecha, $telefono){
        $conectar = parent::Conexion();
        parent::set_names();
        $sql = " update alumnos set 
            nombre = ?, apellido = ?, fecha_nacimiento = ?, telefono = ?
            where id = ? ";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombre);
        $sql->bindValue(2, $apellido);
        $sql->bindValue(3, $fecha);
        $sql->bindValue(4, $telefono);
        $sql->bindValue(5, $id);
        $sql->execute();
    }
}