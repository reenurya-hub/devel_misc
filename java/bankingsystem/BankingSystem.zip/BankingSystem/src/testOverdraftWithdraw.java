/*
 * Project: Banking System
 * Class  :	testOverdraftWithDraw.java
 * Date:	February 27, 2023
 * Author:	Reinaldo Urquijo
 * Description:	Unit test for generate Overdraw with a withdraw
 * in the balance of the user
 * Version:	1.0 - 27/02/2023
 * Iteration_4
 */
import static org.junit.Assert.*;

import org.junit.Test;

public class testOverdraftWithdraw {

	@Test
	public void test() {
		// instance of main class
		bankingSystem bs = new bankingSystem();
		// calling method 'withdrawMoney' to get result
		bs.withdrawMoney("francisco", 1000);	
	}

}
