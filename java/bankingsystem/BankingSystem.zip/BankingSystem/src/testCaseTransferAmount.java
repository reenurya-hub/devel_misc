/*
 * Project: Banking System
 * Class  :	testCaseTransferAmount.java
 * Date:	February 27, 2023
 * Author:	Reinaldo Urquijo
 * Description:	Unit test for User History No. 003 - Scenario 1
 * in the balance of the user
 * Version:	1.0  - Iteration_6 - 27/02/2023: User History 003 Scenario 1 =  An existing client transfer
 ***************************************************************
 * 							C H A N G E S
 * *************************************************************
 * Version 1.0 - Iteration_2 - 27/02/2023: created class 'bankingSystem' and method 'depositMoney'
 */
import static org.junit.Assert.*;

import org.junit.Test;

public class testCaseTransferAmount {

	@Test
	public void test() {
		// instance of main class
		bankingSystem bs = new bankingSystem();
		// calling method 'testCaseTransferAmount' to get result
		bs.transferMoneyAnotherUser("francisco", "martha", 50);
	}

}
