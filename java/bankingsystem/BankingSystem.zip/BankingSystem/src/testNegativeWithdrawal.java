/*
 * Project: Banking System
 * Class  :	testCaseTransferAmount.java
 * Date:	February 27, 2023
 * Author:	Reinaldo Urquijo
 * Description:	Unit test for test case 
 * in the balance of the user
 * Version:	1.0  - Iteration_6 - 27/02/2023: User History 003 Scenario 1 =  An existing client transfer
 * Iteration_2
 ***************************************************************
 * 							C H A N G E S
 * *************************************************************
 * Version 1.0 - Iteration_2 - 27/02/2023: created class 'bankingSystem' and method 'depositMoney'
 */
import static org.junit.Assert.*;
import org.junit.Test;
//
public class testNegativeWithdrawal {
	@Test
	public void test() {
		// instance of main class
		bankingSystem bs = new bankingSystem();
		// calling method 'withdrawMoney' to get result
		bs.withdrawMoney("francisco", -55);		
	}
}
