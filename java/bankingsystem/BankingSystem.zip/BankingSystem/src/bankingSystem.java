import java.util.Scanner;

/*
 * Project: Banking System
 * Date:	February 27, 2023
 * Author:	Reinaldo Urquijo
 * Description:	A simple program that simulates a banking System
 * Version:	3.0
 ***************************************************************
 * 							C H A N G E S
 * *************************************************************
 * Version 1.0 - Iteration_1 - 27/02/2023: created class 'bankingSystem' and method 'depositMoney'
 * Version 2.0 - Iteration_2 - 27/02/2023: Fixed issue 'negative amount'
 * Version 3.0 - Iteration_3 - 27/02/2023: created method 'withdrawMoney'
 * Version 4.0 - Iteration_4 - 27/02/2023: Fixed issue 'overdraft withdrawal'
 * Version 5.0 - Iteration_5 - 27/02/2023: Check whether it is possible to withdraw a negative value.
 * Version 6.0 - Iteration_6 - 27/02/2023: User History 003 Scenario 1 =  An existing client transfer
 * an amount of money from his account to another client account.
 * Version 7.0 - Iteration_6 - 27/02/2023: User History 003 Scenario 2 =  An existing client transfer
 * with zero value in balance  
 */
// v1.0 {
public class bankingSystem {
	/*
	 * Stablish variables as datas of entry
	 */
	public static String id1 = "francisco";
	public static String id2 = "martha"; // v 6.0
	//public static float balance = 100 ; // v 1.0  
	public static float balance1 = 100; // v 6.0
	public static float balance2 = 100; // v 6.0
	//
	public static void main(String[] args) {
		// defines a variable to simulate deposit amount
		float amount = 10;
		// call method to deposit some money
		depositMoney(id1, amount); // v 6.0
	}
	/*
	 * Name:	depositMoney
	 * Type: 	Method
	 * Description:	Allow deposit an amount of money in the
	 * user account
	 * Affects:	value of balance attribute of user
	 * Returns:	Nothing (message in output terminal)
	 * Iteration_1
	 */
	public static void depositMoney(String p_id, float p_amount) {
		// Validate id of user and adds deposit to balance
		
		if(p_id.equals("francisco")) {
            //  { v 2.0  - Iteration_2 - 27/02/2023: Fixed issue 'negative amount'
			//  { v 4.0 - Iteration_4 - 27/02/2023: Fixed issue 'overdraft withdrawal'
			if((p_amount <=0) || (p_amount > balance1)) {  // v 6.0
		    //  } v 4.0
				System.out.println("Amount not allowed. " + p_amount );
			}
			else {
			// } v2.0
				balance1 = balance1 + p_amount;	// v 6.0
			}  // v 2.0
		}
		System.out.println("the balance of his account is = " + balance1 ); // v 6.0
	}
	// } v1.0
	// { v3.0
		/* Name:		withdrawMoney
		 * Type: 		Method
		 * Description:	Allow withdraw of some amount of money
		 * Affects:		value of balance attribute of user
		 * Returns:		Nothing (message in output terminal) 
		 * Iteration_3
		 */
		public static void withdrawMoney(String p_id, float p_amount) {
			if(p_id.equals("francisco")) {
				// { v 5.0 - Iteration_5 - 27/02/2023: Check whether it is possible to withdraw a negative value.
				if(p_amount < 0) {
				// } v 5.0 
					System.out.println("You withdraw = " + p_amount + " this value is not allowed! " );
     			// { v 5.0
				}else {
				// } v 5.0
					balance1 = balance1 - p_amount; // v 6.0
					System.out.println("You withdraw = " + p_amount + " your new balance is = " + balance1 ); // v 6.0
	     		// { v 5.0
				}
				// } v 5.0
			}
			// { v 5.0 - change from line 81 to line 77
			//System.out.println("You withdraw = " + p_amount + " your new balance is = " + balance );		
			// } v 5.0
		}
		// } v3.0
		// { v6.0
		/* Name:		transferMoneyAnotherUser
		 * Type: 		Method
		 * Description:	Allows to transfer amount of money from an user to another
		 * Affects:		value of balance attribute of user who transfer and value of balance attribute of user
		 * who receipts
		 * Returns:		Nothing (message in output terminal) 
		 * Iteration_6
		 */
		public static void transferMoneyAnotherUser(String p_idfrom, String p_idto, float p_amount) {
				// v 6.0 Scenario 1: An existing client transfer an amount of money from his account to another client account.
			    // Version 7.0 - Iteration_6 - 27/02/2023: User History 003 Scenario 2 =  An existing client transfer
				// { v 7.0
				if(balance1 == 0) {
				    System.out.println("Balance of = " + p_idfrom   + " is zero and without funds!!!" );
				} else {
				// } v 7.0
					balance1 = balance1 - p_amount;
					balance2 = balance2 + p_amount;
					System.out.println("You transfer = " + p_amount + " from account = " + p_idfrom + " to account = " + p_idto );
					System.out.println("New Balance of = " + p_idfrom + " = " + balance1 );
					System.out.println("New Balance of = " + p_idto   + " = " + balance2 );
				} // v 7.0
		}
		// } v6.0


}
