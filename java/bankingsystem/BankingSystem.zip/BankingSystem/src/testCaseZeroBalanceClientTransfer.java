/*
 * Project: Banking System
 * Class  :	testCaseTransferAmount.java
 * Date:	February 27, 2023
 * Author:	Reinaldo Urquijo
 * Description:	Unit test for User History No. 003 - Scenario 1
 * in the balance of the user
 * Version:	1.0  - Iteration_6 - 27/02/2023: User History 003 Scenario 2 =  An existing client transfer
 ***************************************************************
 * 							C H A N G E S
 * *************************************************************
 * Version 1.0 - Iteration_6 - 27/02/2023: create test case to User History 003 Scenario 2
 */
import static org.junit.Assert.*;

import org.junit.Test;

public class testCaseZeroBalanceClientTransfer {

	@Test
	public void test() {
		// instance of main class
		bankingSystem bs = new bankingSystem();
		// calling method 'transferMoneyAnotherUser' to get result
		bs.balance1 = 0;
		bs.transferMoneyAnotherUser("francisco", "martha", 50);
	}

}
