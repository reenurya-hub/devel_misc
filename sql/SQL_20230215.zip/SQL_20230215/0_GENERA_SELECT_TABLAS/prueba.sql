SELECT * FROM ALL_TAB_COLS 
WHERE OWNER = 'TRON2000' 
AND TABLE_NAME = 'A2000030'
AND DATA_TYPE <> 'RAW'
ORDER BY COLUMN_ID ASC;

DECLARE
l_nom_tabla varchar2(100) := 'A2000030';
l_select    varchar2(2000) := 'SELECT ';
l_where    varchar2(2000) := ' WHERE ';
i all_tab_cols%rowtype;
BEGIN
   FOR i in (SELECT * 
               FROM ALL_TAB_COLS 
              WHERE OWNER = 'TRON2000' 
                AND TABLE_NAME = l_nom_tabla
                AND DATA_TYPE <> 'RAW'
              ORDER BY COLUMN_ID ASC)
   LOOP
     l_select := l_select || 'a.' || i.column_name || ', ';
     l_where := l_where || i.column_name || ' = ';
   END LOOP;
DBMS_OUTPUT.PUT_LINE(l_select);
DBMS_OUTPUT.PUT_LINE( l_where);
END;
