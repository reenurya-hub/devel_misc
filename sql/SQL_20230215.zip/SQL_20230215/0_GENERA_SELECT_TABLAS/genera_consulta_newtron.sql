DECLARE
   --
   CURSOR c_all_tab_cols
   IS
      SELECT * 
        FROM all_tab_comments 
       WHERE TABLE_NAME IN (SELECT TABLE_NAME 
                              FROM all_tables 
                             WHERE table_name LIKE UPPER('%NWT%')
                            )
       ORDER BY owner,table_name; 
   --
BEGIN
   --
   FOR lreg in c_all_tab_cols
      LOOP
         --
         --l_select := l_select || 'a.' || lreg.column_name || ', ';
         --
         DBMS_OUTPUT.PUT_LINE('SELECT * FROM ' || lreg.owner || '.' || lreg.table_name || '; -- ' || lreg.comments );
         --
      END LOOP;
   --

END;
