-- NOTA: PONER EL BUFFER DEL OUTPUT EN 1000000
DECLARE
   --
   CURSOR c_all_tab_cols
   IS
   SELECT a.owner,a.table_name,b.comments, a.DATA_TYPE 
  FROM ALL_TAB_COLS a, all_tab_comments b
 WHERE 1=1
   --AND a.OWNER = 'TRON2000' 
   --AND a.TABLE_NAME = 'A2000030'
   --AND a.DATA_TYPE <> 'RAW'
   AND UPPER(a.COLUMN_NAME) = 'COD_FRACC_PAGO'
   AND a.table_name = b.table_name;
   --
BEGIN
   --
   FOR lreg in c_all_tab_cols
      LOOP
         --
         --l_select := l_select || 'a.' || lreg.column_name || ', ';
         --
         DBMS_OUTPUT.PUT_LINE('SELECT * FROM ' || lreg.owner || '.' || lreg.table_name || '; -- ' || lreg.comments );
         --
      END LOOP;
   --

END;
