DECLARE
   --
   l_nom_tabla VARCHAR2(100)   := 'A7001000';
   l_owner     VARCHAR2(100)   := 'TRON2000';
   l_select    VARCHAR2(2000)  := 'SELECT a.*';
   l_where     VARCHAR2(32000) := ' WHERE 1=1' || chr(13);
   l_reg       all_tab_cols%ROWTYPE;
   firstr      BOOLEAN        := TRUE;
   --
   CURSOR c_all_tab_cols(lc_owner all_tab_cols.owner%TYPE,
                         lc_tabla all_tab_cols.table_name%TYPE)
   IS
      SELECT  * 
        FROM ALL_TAB_COLS 
       WHERE OWNER        = lc_owner 
         AND TABLE_NAME   = lc_tabla
         AND DATA_TYPE    <> 'RAW'
       ORDER BY COLUMN_ID ASC;
   --
BEGIN
   --
   FOR lreg in c_all_tab_cols(l_owner,l_nom_tabla)
      LOOP
         --
         --l_select := l_select || 'a.' || lreg.column_name || ', ';
         l_where  := l_where  || '   -- AND ' || 'a.' || LOWER(lreg.column_name) || ' = a.' || LOWER(lreg.column_name) || chr(13);
         --
      END LOOP;
   --
   DBMS_OUTPUT.PUT_LINE(l_select);
   DBMS_OUTPUT.PUT_LINE('  FROM ' || LOWER(l_nom_tabla) || ' a' || CHR(13) || l_where || CHR(59));
   --
END;
