
select * from tron2000.g2109999_vcr where cod_mensagem = '20098003';

select * from tron2000.g2109999_vcr where lower(txt_mensagem) like '%ermo%'

;ss_k_g2109999
ss_k_g2109999.p_lee_vigente


20098003

tron2000.em_k_gen_ws_vcr;

tron2000.EM_K_GEN_WS_VCR;
