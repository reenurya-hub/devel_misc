-- DESBLOQUEAR SINIESTROS
select mca_exclusivo from a7000900 where num_sini = 200121022000508
update a7000900 set mca_exclusivo = 'N' where num_sini = 200121022000508;
COMMIT;
