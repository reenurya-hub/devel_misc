-- CAUSAS DEL  SINIESTRO
-- NUM_SINI, TIP_CAUSA  pk
SELECT a.*
  FROM A7000930 a
 WHERE 1=1 
   -- AND a.COD_CIA = a.COD_CIA
   AND a.NUM_SINI = 413598522000319                                  -- PK
   AND a.TIP_CAUSA = 1                                               -- PK
   -- AND a.COD_CAUSA = 42
   -- AND a.COD_CONSECUENCIA = 295
   -- AND TRUNC(a.FEC_MVTO) = TO_DATE('12/07/2022','DD/MM/YYYY')
   -- AND TRUNC(a.FEC_ACTU) = TO_DATE('12/07/2022','DD/MM/YYYY')
   -- AND a.COD_USR = a.COD_USR
   -- AND a.MCA_OPER_NWT = a.MCA_OPER_NWT
;
