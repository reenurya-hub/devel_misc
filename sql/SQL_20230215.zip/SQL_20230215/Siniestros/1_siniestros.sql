
select * from 

--DATOS FIJOS DEL EXPEDIENTE
SELECT * FROM a7001000 where cod_ramo = 985;
select num_sini from a7000900 where num_poliza in (
   select num_poliza from a2000030 
   where cod_cia = 7 and cod_ramo = 301
   and mca_provisional = 'N' 
   AND MCA_POLIZA_ANULADA = 'N' 
   AND MCA_SPTO_ANULADO = 'N'
   AND MCA_EXCLUSIVO = 'N'
   AND TRUNC(FEC_EFEC_SPTO) >= TO_DATE('01/01/2021','DD/MM/YYYY') 
   and num_poliza not in (select NUM_POLIZA from a2000030 where mca_poliza_anulada = 'S'))
and tip_est_sini not in ('T','P');


ts_p_final_inspecciones_msv;

-- procedimientos sugerido por laura
tron2000.ts_k_peritaciones;
ts_k_peritaciones.p_final_inspecciones;
ts_p_final_inspecciones;
/*
1.CREAR EL SINIESTRO
FECHA SINIESTRO = 05/07/2022

2. CREAR EL EXPEDIENTE
   1 DPA PENDIENTE
   2 RC BIENES TERMINADO 18/07/2022
DUI 023205328


3. CREAR LA INSPECCION
COD= 804
FECHA = 13/07/2022
   ORDENES=
   1  17 536.63
   2  17 278.85
   3  59 192.78
   4  59  65.00
   5  59 578.46

4. Validar la actualizacion de 
la reserva de siniestros
*/

ts_k_cabsini
ts_k_cabsini.p_v_num_sini

select * from a7000900 where num_sini = 301220000001345;

IF l_tip_est_sini = 'T' AND l_reapertura = 'N'
l_tip_est_sini = 'P'


3012201002038

-- POLIZAS SIN SINIESTRO
select num_poliza from a2000030 
   where cod_cia = 1 and cod_ramo = 985
   and mca_provisional = 'N' 
   AND MCA_POLIZA_ANULADA = 'N' 
   AND MCA_SPTO_ANULADO = 'N'
   AND MCA_EXCLUSIVO = 'N'
   AND TRUNC(FEC_EFEC_SPTO) >= TO_DATE('01/01/2021','DD/MM/YYYY') 
   and num_poliza not in (select NUM_POLIZA from a2000030 where mca_poliza_anulada = 'S')
   AND NUM_POLIZA NOT IN (select NUM_POLIZA from a7000900 );

--- POLIZAS VIGENTES NO BLOQUEADAS O ANULADAS
select num_sini from a7000900 where num_poliza in (
   select num_poliza from a2000030 
   where cod_cia = 1 and cod_ramo = 985
   and mca_provisional = 'N' 
   AND MCA_POLIZA_ANULADA = 'N' 
   AND MCA_SPTO_ANULADO = 'N'
   AND MCA_EXCLUSIVO = 'N'
   AND TRUNC(FEC_EFEC_SPTO) >= TO_DATE('01/01/2021','DD/MM/YYYY') 
   and num_poliza not in (select NUM_POLIZA from a2000030 where mca_poliza_anulada = 'S'))
and tip_est_sini not in ('T','P');

--ORDENES RETENIDAS
SELECT * FROM a3009001_MSV WHERE NUM_SINI = 301220000002021;

-- TRAZAS SALVADOR
-- recupera trazas
DELETE FROM  TRAZAS_MSV where cod_traza = 'reuy';
COMMIT;
select * from TRAZAS_MSV where cod_traza = 'reuy' ORDER BY ID_TRAZA;
-- ejemplo trazas
tron2000.dc_p_trazas_msv('reuy','em_k_ld_com_trn: '|| $$PLSQL_LINE || ' g_reg_p2000253.num_poliza : '|| g_reg_p2000253.num_poliza);


ts_k_ap700640.p_query_visitas

tron2000.TS_K_A7001005_TRN

 ts_k_ac700202.p_comp_per

ts_k_ac700003.p_query_movimientos(6)
(1): ts_k_ac700003.p_devuelve_movimientos(10)

(0): ts_k_ac700601.p_query_importes(5)
(1): ts_k_ac700601.p_devuelve_importes(14)
a7006010

1. LA VALORACION ESTA ERRADA A PARTIR DE LA ACTUALIZACION QUE SE HIZO DE LA ORDEN DE COBRO
DE LA REPARACION
2. EL EXPEDIENTE CON LA VALORACION ERRONEA ES EL DPA (DANIOS PROPIOS ASEGURADO)
3. EN EL DETALLE DE LA ORDEN DE REPARACION SE ENCUENTRAN LOS DIFERENTES CONCEPTOS
AL PARECER SOLO ESTA INCLUYENDO EL CONCEPTO DEL NUMERO DE ORDEN 1 POR VALOR DE
536.63 EN EL VALOR DE LA RESERVA.
(select SUM(IMP_CTO) from a7006010  where num_sini = 301220000002021
AND NUM_INSP=2022004213)

select num_sini from a7001000 where num_sini in 

--DATOS FIJOS DEL EXPEDIENTE
SELECT * FROM a7001000 WHERE num_sini = 301220000002021
AND NUM_EXP = 1;

-- HISTORICO DE LA VALORACION
SELECT * FROM h7001200 WHERE num_sini = 301220000002021 AND TIP_MVTO = 'E'
AND NUM_EXP = 1
AND NUM_MVTO = 4;


-- VALORACIONES DE INSPECCION/PERITACION
select * from a7006010  where num_sini = 301220000002021
AND NUM_INSP=2022004213 AND NUM_ORDEN = 1 ;

--DATOS DE LAS INSPECCIONES/PERITACIONES POR EXPEDIENTES
SELECT * FROM a7006040 where num_sini = 301220000002021;

--DATOS DE LAS VISITAS DE UNA INSPECCION/PERITACION
SELECT * FROM a7006050 where num_sini = 301220000002021;

/**********************************/
--CONTROL TECNICO DEL SINIESTRO
SELECT * FROM a2000220 WHERE num_sini = 301220000002021; -- NO HAY DATOS PARA SINIESTRO


--CONTROL TECNICO DEL SINIESTRO
select * from a2000220 where num_sini = 301220000002021;



 ts_k_ac700202.p_comp_per

-- HISTORICO DE MOVIMIENTOS ECONOMICO DEL EXPEDIENTE
select * from h7001200  where num_sini = 301220000002021;

-- VALORACIONES DE INSPECCION/PERITACION
select * from a7006010  where num_sini = 301220000002021;

-- MONTOS AUTORIZADOS EN ORDENES DE REPARACIO
select * from g3009430_msv;

---------------

-- DESBLOQUEAR SINIESTROS
select mca_exclusivo from a7000900 where num_sini = 3012201000298
update a7000900 set mca_exclusivo = 'N' where num_sini = 3012201000298;
COMMIT;
---
cod_cia = 7
cod_ramo = 301
num_poliza = 3012201000298

num_sini = 301220000002021

--datos fijos poliza
select * from a2000030 where num_poliza = 3012201000298;
select * from a2000030@tron_pro where num_poliza = 3012201000298;

-- datos variables
select * from a2000020 where num_poliza = 3012201000298;
select * from a2000020@tron_pro where num_poliza = 3012201000298;


-- general siniestro
SELECT * FROM a7000900 where num_sini = 301220000002021;
SELECT * FROM a7000900@tron_pro where num_sini = 301220000002021;

-- reservas por tipo de expediente
select * from A7000100 where cod_cia = 7 and cod_ramo = 301;
select * from A7000100@tron_pro where cod_cia = 7 and cod_ramo = 301;

-- causas de siniestros por ramo
select * from A7000200 where cod_cia = 7 and cod_ramo = 301;
select * from A7000200@tron_pro where cod_cia = 7 and cod_ramo = 301;

-- conceptos de reserva por compania
select * from A7000300

-- datos fijos de siniestros
select * from A7000900
select * from A7000900@tron_pro where num_poliza = 3012201000298;
select * from A7000900@tron_pro where num_sini = 301220000002021;

-- datos del asegurado de autos
select * from A7001080 where num_sini = 301220000002021;

--TABLA DE FIN DE MES , DONDE SE LLEVAN LAS RESERVAS Y RESERVA
select * from A7002200 where num_sini = 301220000002021;

-- terceros
select * from A1001338;

--TABLA DE VISITAS POR PERITACION
select * from A7006050;

-- TABLA DE RESULTADO DE PERITACIONES
select * from A7006060;

-- BUZON DE CAUSAS DE SINIESTROS
select * from B7000930;

-- BUZON DATOS FIJOS SINIESTRO AUTOS
select * from B7000950;

-- DATOS CONTRARIOS DEL SINIESTRO
select * from A7000973;

--BUZON DATOS CONTRARIO SINIESTRO
select * from B7000973;

-- NUMERACION SINIESTROS
select * from G7000130;

--BUZON DE LOS MOVIMIENTOS ECONOMICOS DEL EXPEDIENTE
select * from B7001200;

--DATOS GENERALES DEL SINIESTRO AUTOS
select * from A7000950;

--HISTORICO DE MOVIMIENTOS ECONOMICO DEL EXPEDIENTE
select * from H7001200;

--ORDENES DE REPARACION
select * from A7006001;

--DATOS DEL ASEGURADO SINIESTRO AUTOS
select * from A7000975;

--SINIESTROS/EXPEDIENTES CANDIDATOS SUPLEMENTOS DE BAJA CAPITAL
select * from A7001005;

--HISTORICO DE ASIGNACIONES DE TRAMITADORES /SUPERVISORES
select * from A7001020;

--DATOS DEL CONTRARIO DEL EXPEDIENTE
select * from A7001040;

--DATOS FIJOS DE LAS  LIQUIDACIONES DE EXPEDIENTES
select * from A3001700;

--BUZON RELATO SINIESTRO
select * from B7000971;

--DATOS FIJOS DEL SINIESTRO
select * from A7000900;

-- LIQUIDACIONES DE ORDENES INSPECCION/PERITACION
select * from A7009900;

--PLAN DE TRAMITACION
select * from A7500000;

-- DATOS FIJOS DEL EXPEDIENTE
select * from A7001000;

--HISTORICO DE CAUSAS DEL EXPEDIENTE
select * from A7001030;

--BUZON DATOS DEL CONTRARIO EXPEDIENTE
select * from B7001040;

-- VALORACIONES DE INSPECCION/PERITACION
select * from A7006010;


select * from A7006040;

---------------------------------

ts_k_peritaciones.p_final_inspecciones

cod_plan = 12 
fefecto = 18-08-2022
fvencim = 18-04-2023
cod_agt = 1801
cod_mon = 1 (dolares)

datos variables =
modalidad riesgo = 1
marca vehiculo = 6
modelo = 164
nombre = 164
tipo vehiculo= 2
anio vehiculo =2010
pasajeros = 5
puertas = 4
uso = 1
capacidad =1
clase= A
subclase = 0
vehic nuevo = N
version A
valor = 18000
color = 419
matricula = N
matricula no = P644825
numero moto = NT
numero chasis = 1GCJTDDE0A8123728
NUMERO VIN = NODETERMINADO
COBERTURAS
2001 = 18000
2002 = 10000
2003 = 10000
2005 = 35000
2006 = 5000
2010 = 18000
2011 = 18000
2012 = INCLUIDA
2016 = 1200
2025 = 18000
2029 = INCLUIDA
2019 = 10000
2018 = 1200
2024 =  500
2027 = 18000
2028 = INCLUIDA
9997 = 0

--------------------
SINIESTROS
F_SINIESTRO = 05-07-2022
VALORADO = 1436.63
LIQUIDADO = 965
PAGADO = 965
CAUSA = 105 COLISION

EXPEDIENTES
DPA DA�OS PROPIOS ASEGURADO = PENDIENTE 
   RESERVA POR INDEMNIZACION = 536.63 TOTAL LIQUIDADO = 65 PAGADO 65
RCB RC BIENES = TERMINADO
   RESERVA POR INDEMNIZCION = 900 TOTAL PAGAO = 900



200121022000503 -- con esta da el error
200121022000504
200121022000505
200121022000507
200121022000506
200121022000508

select * from a7001024 where cod_cia =2 and cod_ramo = 210;

-- background
SELECT * FROM xbackground
delete from xbackground where COD_CIA = 2 AND cod_marco = '228'; -- x2000040 cod_marco del producto
COMMIT;

--- POLIZAS VIGENTES NO BLOQUEADAS O ANULADAS
select num_sini from a7000900 where num_poliza in (
   select num_poliza from a2000030 where cod_cia = 2 and cod_ramo = 210
   and mca_provisional = 'N' AND MCA_POLIZA_ANULADA = 'N' AND MCA_SPTO_ANULADO = 'N'
   AND MCA_EXCLUSIVO = 'N' AND TRUNC(FEC_EFEC_SPTO) >= TO_DATE('01/01/2022','DD/MM/YYYY') 
   and num_poliza not in (
      select NUM_POLIZA from a2000030 where mca_poliza_anulada = 'S'
      ));


-- criterios de asignaci�n de tramitadores
select * from a7001024 where cod_cia =2 and cod_ramo = 210;

delete from a7001024 where cod_cia = 2 and  cod_ramo = 210 and cod_tramitador = 1;
commit;

delete from a7001024 where cod_cia = 2 and cod_ramo in (210, 260) and mca_perd_total is null;
commit;

consulta: 
ts_p_obtiene_tramitador_trn
tramitador por ramo (cursor)
c_a1001339_tramitador_ramo
p_query
TS_K_AP700043
TS_K_AP700043.p_v_mca_perd_total
TS_K_AP700043.p_query
TS_K_AP700043.p_devuelve

1 236297459 reuy  em_k_ld_com_trn: 1613 g_mca_perd_total : N  8/25/2022 8:53:16 AM  gtadmin 64054361
2 236297460 reuy  em_k_ld_com_trn: 1614 l_mca_perd_total :  8/25/2022 8:53:16 AM  gtadmin 64054361


-- DESBLOQUEAR SINIESTROS
select mca_exclusivo from a7000900 where num_sini = 200121022000508
update a7000900 set mca_exclusivo = 'N' where num_sini = 200121022000508;
COMMIT;

select * from TRAZAS_MPR where cod_traza = 'reuy' ORDER BY ID_TRAZA;
 DELETE FROM  TRAZAS_MPR where cod_traza = 'reuy';
COMMIT;

ts_k_cabexp;
 ts_k_cabexp.p_inicio
 linea 1222 pp_obtener_tramitador;
 dc_p_trazas_mpr('reuy','ts_k_cabexp_trn: '|| $$PLSQL_LINE || ' g_reg_p2000253.num_poliza : '|| g_reg_p2000253.num_poliza);

ts_p_obtiene_tramitador_trn

select * from a1001339 where cod_tramitador = 17;


/***************** consulta recupera tramitadores expediente *************************/
      SELECT a.tip_docum, a.cod_docum , a.cod_tramitador
        FROM a1001339 a
       WHERE a.cod_cia       = 2--p_cod_cia
         AND a.cod_tramitador IN (SELECT b.cod_tramitador
                                    FROM a7001024 b
                                   WHERE b.cod_cia        = a.cod_cia
                                     AND b.cod_tramitador = a.cod_tramitador
                                     AND b.cod_ramo       = 210)--p_cod_ramo)
         --AND a.cod_nivel3    = p_cod_nivel3
         AND NVL(a.num_siniestros,0)=(SELECT min(NVL(c.num_siniestros,0))
                                 FROM a1001339 c
                                WHERE c.cod_cia       = 2--p_cod_cia
                                  AND c.cod_tramitador IN
                                     (SELECT d.cod_tramitador
                                        FROM a7001024 d
                                       WHERE d.cod_cia       = c.cod_cia
                                         AND d.cod_tramitador= c.cod_tramitador
                                         AND d.cod_ramo      = 210--p_cod_ramo
                                     )
                                  --AND c.cod_nivel3     = p_cod_nivel3
                                  AND c.tip_estado     = 'A'
                                  AND NVL(c.num_siniestros,0) <  NVL(c.max_num_exp, 99999)
                               )
         AND a.tip_estado     = 'A'
         AND NVL(a.num_siniestros,0) <  NVL(a.max_num_exp, 99999) ;
/****************************************************************************/

SELECT rowid ,
              cod_cia        ,
              cod_sector     ,
              cod_ramo       ,
              num_poliza     ,
              tip_exp        ,
              mca_juicio     ,
              mca_perd_total ,
              cod_tramitador ,
              fec_actu       ,
              cod_usr        
         FROM a7001024
        WHERE cod_cia        = 2--g_cod_cia       
          AND cod_sector     = 2--NVL(g_cod_sector, cod_sector)    
          AND cod_ramo       = 210--NVL(g_cod_ramo  , cod_ramo)    
          AND num_poliza     = NVL(null, num_poliza)    
          AND tip_exp        = NVL(null   , tip_exp)    
          AND mca_juicio     = NVL(null, mca_juicio)    
            AND mca_perd_total = NVL(null, mca_perd_total)    
            --AND cod_tramitador = NVL(g_cod_tramitador,cod_tramitador)
        ORDER BY 
                 cod_cia       ,
                 cod_sector    ,
                 cod_ramo      ,
                 num_poliza    ,
                 tip_exp       ,
                 mca_juicio    ,
                 mca_perd_total,
                 cod_tramitador;





TS_K_AP700043


TS_K_A7001000_TRN
TS_K_AS700030_TRN
insert a7001000 num_sini : 200121022000508 tip_exp: PDB cod_tramitador: 17----- PL/SQL Call Stack -----
  object      line  object
  handle    number  name
0x71df8510         3  TRON2000.TMP_A7001000
0x7e567638      1081  package body TRON2000.TS_K_A7001000_TRN.P_INSERTA
0x76ec5390      1268  package body TRON2000.TS_K_AS700030_TRN.P_INSERTA_EXPEDIENTE.PI_INSERTA_A7001000
0x76ec5390      1449  package body TRON2000.TS_K_AS700030_TRN.P_INSERTA_EXPEDIENTE
0x7121e6d8         1  anonymous block





 
 ts_k_a7001000.f_cod_tramitador;
 ts_k_a7001000
 ts_k_a7001000
 
 select * from a7001000 where num_sini = 200121022000508;

drop trigger TMP_A7001000;

TS_K_A7001000_TRN

 CREATE OR REPLACE TRIGGER TMP_A7001000  BEFORE INSERT OR UPDATE ON A7001000 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      dc_p_trazas_mpr('reuy','insert a7001000 num_sini : '|| :new.num_sini || ' tip_exp: ' || :new.tip_exp || ' cod_tramitador: ' || :new.cod_tramitador || dbms_utility.format_call_stack );
    END IF;
    IF UPDATING THEN
      dc_p_trazas_mpr('reuy','update a7001000 num_sini : '|| :new.num_sini || ' tip_exp: ' || :new.tip_exp || ' cod_tramitador: ' || :new.cod_tramitador || ' old_cod_tramitador: ' || :old.cod_tramitador || dbms_utility.format_call_stack );
    END IF;
  END;


--- POLIZAS VIGENTES NO BLOQUEADAS O ANULADAS
select * from a2000030 where cod_cia = 2 and cod_ramo = 210
and mca_provisional = 'N' AND MCA_POLIZA_ANULADA = 'N' AND MCA_SPTO_ANULADO = 'N'
AND MCA_EXCLUSIVO = 'N'
AND TRUNC(FEC_EFEC_SPTO) >= TO_DATE('01/01/2022','DD/MM/YYYY') ORDER BY NUM_POLIZA ASC;



select * from a7001060 where num_sini = 200121022000508--no tiene observaciones el siniestro
select * from a7000900 where num_sini = 200121022000508;-- num_apli = 0

 ts_k_cabexp;
 ts_k_cabexp.p_inicio
 
 select * from a7001000 where num_sini = 200130022000538;
 
-- datos varios siniestro
ts_k_ap700112;
ts_k_ap700112.p_devuelve

-- apertura expediente
 ts_k_ap700112.p_devuelve
 
 TRON2000.TS_K_A7000900_TRN
TRON2000.TS_K_CABSINI_TRN


ts_k_ap700043

-- tabla de criterios de asignacion de  tramitadores.
select * from a7001024 where cod_cia = 2 and cod_ramo = 210 and cod_tramitador = 16;


-- criterios de asignaci�n de tramitadores
select * from a7001024 where cod_cia =2 and cod_ramo = 210 FOR UPDATE;

delete from a7001024 where cod_cia =2 and cod_ramo = 210;
commit;

insert into a7001024 (COD_CIA, COD_SECTOR, COD_RAMO, NUM_POLIZA, TIP_EXP, MCA_JUICIO, COD_TRAMITADOR, FEC_ACTU, COD_USR, MCA_PERD_TOTAL)
values (2, 2, 210, '999999999999', '999', 'N', 4, to_date('23-12-2019', 'dd-mm-yyyy'), 'TRON2000', 'N');

insert into a7001024 (COD_CIA, COD_SECTOR, COD_RAMO, NUM_POLIZA, TIP_EXP, MCA_JUICIO, COD_TRAMITADOR, FEC_ACTU, COD_USR, MCA_PERD_TOTAL)
values (2, 2, 210, '999999999999', '999', 'N', 13, to_date('23-12-2019', 'dd-mm-yyyy'), 'TRON2000', 'N');

insert into a7001024 (COD_CIA, COD_SECTOR, COD_RAMO, NUM_POLIZA, TIP_EXP, MCA_JUICIO, COD_TRAMITADOR, FEC_ACTU, COD_USR, MCA_PERD_TOTAL)
values (2, 2, 210, '999999999999', '999', 'N', 16, to_date('23-12-2019', 'dd-mm-yyyy'), 'TRON2000', 'N');

insert into a7001024 (COD_CIA, COD_SECTOR, COD_RAMO, NUM_POLIZA, TIP_EXP, MCA_JUICIO, COD_TRAMITADOR, FEC_ACTU, COD_USR, MCA_PERD_TOTAL)
values (2, 2, 210, '999999999999', '999', 'N', 17, to_date('23-12-2019', 'dd-mm-yyyy'), 'TRON2000', 'N');

insert into a7001024 (COD_CIA, COD_SECTOR, COD_RAMO, NUM_POLIZA, TIP_EXP, MCA_JUICIO, COD_TRAMITADOR, FEC_ACTU, COD_USR, MCA_PERD_TOTAL)
values (2, 2, 210, '9999999999999', 'PDB', 'N', 45, to_date('30-08-2022', 'dd-mm-yyyy'), 'TRON2000', 'N');

insert into a7001024 (COD_CIA, COD_SECTOR, COD_RAMO, NUM_POLIZA, TIP_EXP, MCA_JUICIO, COD_TRAMITADOR, FEC_ACTU, COD_USR, MCA_PERD_TOTAL)
values (2, 2, 210, '9999999999999', '999', 'N', 111, to_date('29-08-2022', 'dd-mm-yyyy'), 'TRON2000', 'N');
commit;

