-- causas siniestro
SELECT * 
  FROM a7000200 a
 WHERE a.cod_cia = 2
   AND a.cod_ramo = 228;