-- NUM_SINI, NUM_EXP, COD_CIA

-- DATOS FIJOS DEL EXPEDIENTE
SELECT a.*
  FROM a7001000 a
 WHERE a.cod_cia    = 2
   AND a.cod_sector = 3
   AND a.cod_ramo   = 300
   --AND a.num_sini   = 200130022000587
   -- AND a.num_exp = a.num_exp
   AND a.tip_exp    = 'RDS'
   -- AND a.tip_est_exp      = a.tip_est_exp
   -- AND a.mca_exp_recobro  = a.mca_exp_recobro
   -- AND a.mca_recobro      = a.mca_recobro
   -- AND a.tip_est_recobro  = a.tip_est_recobro
   -- AND a.num_exp_afec     = a.num_exp_afec
   -- AND a.tip_exp_afec     = a.tip_exp_afec
   -- AND a.tip_est_afec     = a.tip_est_afec
   -- AND a.mca_juicio       = a.mca_juicio
   -- AND a.tip_est_juicio   = a.tip_est_juicio
   -- AND a.fec_aper_exp     = a.fec_aper_exp
   -- AND a.fec_term_exp     = a.fec_term_exp
   -- AND a.fec_modi_exp     = a.fec_modi_exp
   -- AND a.fec_reap_exp     = a.fec_reap_exp
   -- AND a.fec_ult_liq      = a.fec_ult_liq
   -- AND a.mca_provisional  = a.mca_provisional
   -- AND a.fec_autorizacion = a.fec_autorizacion
   -- AND a.tip_docum        = a.tip_docum
   -- AND a.cod_docum        = a.cod_docum
   -- AND a.nombre           = a.nombre
   -- AND a.apellidos        = a.apellidos
   -- AND a.cod_mon          = a.cod_mon
   -- AND a.imp_val_inicial  = a.imp_val_inicial
   -- AND a.mca_rva_manual   = a.mca_rva_manual
   -- AND a.imp_val          = a.imp_val
   -- AND a.imp_liq          = a.imp_liq
   -- AND a.imp_pag          = a.imp_pag
   -- AND a.imp_val_neto     = a.imp_val_neto
   -- AND a.imp_liq_neto     = a.imp_liq_neto
   -- AND a.imp_pag_neto     = a.imp_pag_neto
   -- AND a.pct_coa          = a.pct_coa
   -- AND a.imp_rva_3112     = a.imp_rva_3112
   -- AND a.fec_rva_3112     = a.fec_rva_3112
   -- AND a.cod_supervisor   = a.cod_supervisor
   -- AND a.cod_tramitador   = a.cod_tramitador
   -- AND a.cod_usr          = a.cod_usr
   -- AND a.fec_actu         = a.fec_actu
   -- AND a.mca_calcula_rva  = a.mca_calcula_rva
   -- AND a.cod_nivel1       = a.cod_nivel1
   -- AND a.cod_nivel2       = a.cod_nivel2
   -- AND a.cod_nivel3       = a.cod_nivel3
   -- AND a.tip_apertura     = a.tip_apertura
   -- AND a.fec_denu_exp     = a.fec_denu_exp
   -- AND a.fec_aviso_exp    = a.fec_aviso_exp
   -- AND a.mca_aper_nwt     = a.mca_aper_nwt
;









--  DATOS FIJOS DEL EXPEDIENTE
/*
SELECT * 
  FROM a7001000 
 WHERE COD_CIA = 2 
   AND COD_RAMO = 101 
   AND num_sini LIKE '200%' 
   AND tip_exp = 'RDS' 
   ORDER BY FEC_ACTU DESC;
*/
