-- CONTROL TECNICO DEL SINIESTRO
-- COD_CIA, NUM_SINI, NUM_EXP, NUM_LIQ
-- COD_CIA, NUM_SINI, NUM_EXP, NUM_SECU                    -- PK
SELECT a.*
  FROM A2000220 a
 WHERE 1=1 
   AND a.COD_CIA = 1                                       -- PK            
   -- AND a.COD_SISTEMA = a.COD_SISTEMA
   AND a.NUM_SINI                = 1011710000003           -- PK
   AND a.NUM_EXP                 = 1                       -- PK
   -- AND a.NUM_LIQ                = 760011154940
   -- AND a.COD_NIVEL_SALTO        = '2'
   -- AND a.COD_EST                = '12'
   -- AND a.COD_ERROR              = a.COD_ERROR
   -- AND a.MCA_AUTORIZACION       = a.MCA_AUTORIZACION
   -- AND a.OBS_AUTORIZACION       = a.OBS_AUTORIZACION
   -- AND a.COD_USR_AUTORIZACION   = a.COD_USR_AUTORIZACION
   -- AND a.FEC_AUTORIZACION       = a.FEC_AUTORIZACION
   -- AND a.COD_USR                = a.COD_USR
   -- AND a.FEC_ACTU               = a.FEC_ACTU
   AND a.NUM_SECU                  = 1                     -- PK
   -- AND a.COD_SIST_AUT           = a.COD_SIST_AUT
   -- AND a.OBS_ERROR              = a.OBS_ERROR
;
