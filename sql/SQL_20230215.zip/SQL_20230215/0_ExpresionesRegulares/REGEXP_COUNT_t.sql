-- Result: 2
SELECT REGEXP_COUNT ('TechOnTheNet is a great resource', 't') FROM DUAL;