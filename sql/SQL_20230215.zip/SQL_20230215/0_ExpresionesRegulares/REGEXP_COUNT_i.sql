-- Result: 4
SELECT REGEXP_COUNT ('TechOnTheNet is a great resource', 't', 1, 'i') FROM dual;