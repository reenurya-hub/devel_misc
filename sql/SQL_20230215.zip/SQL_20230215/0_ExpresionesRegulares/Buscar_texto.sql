-- This REGEXP_LIKE example will return all contacts whose last_name starts with 'A'.
SELECT last_name
FROM contacts
WHERE REGEXP_LIKE (last_name, '^A(*)');