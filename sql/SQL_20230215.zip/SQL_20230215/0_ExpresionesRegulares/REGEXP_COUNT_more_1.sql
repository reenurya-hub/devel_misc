-- Result: 2
SELECT REGEXP_COUNT ('Anderson', 'a|e|i|o|u') FROM dual;