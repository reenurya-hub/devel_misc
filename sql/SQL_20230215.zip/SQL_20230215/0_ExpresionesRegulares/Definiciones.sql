--REGEXP_LIKE(source, regexp, modes) is probably the one you’ll use most. 
--You can use it in the WHERE and HAVING clauses of a SELECT statement. In a PL/SQL script, it returns a Boolean value. 
--You can also use it in a CHECK constraint. The source parameter is the string or column the regex should be matched against. 
--The regexp parameter is a string with your regular expression. The modes parameter is optional. It sets the matching modes.

SELECT * FROM mytable WHERE REGEXP_LIKE(mycolumn, 'regexp', 'i');
IF REGEXP_LIKE('subject', 'regexp') THEN /* Match */ ELSE /* No match */ END IF;
ALTER TABLE mytable ADD (CONSTRAINT mycolumn_regexp CHECK (REGEXP_LIKE(mycolumn, '^regexp$')));

--REGEXP_SUBSTR(source, regexp, position, occurrence, modes) returns a string with the part of source matched by the regular expression. 
--If the match attempt fails, NULL is returned. You can use REGEXP_SUBSTR with a single string or with a column. 
--You can use it in SELECT clauses to retrieve only a certain part of a column. 
--The position parameter specifies the character position in the source string at which the match attempt should start. 
--The first character has position 1. The occurrence parameter specifies which match to get. Set it to 1 to get the first match. 
--If you specify a higher number, Oracle will continue to attempt to match the regex starting at the end of the previous match, 
--until it found as many matches as you specified. The last match is then returned. If there are fewer matches, NULL is returned. 
--Do not confuse this parameter with backreferences. Oracle does not provide a function to return the part of the string matched by a capturing group. 
--The last three parameters are optional.

SELECT REGEXP_SUBSTR(mycolumn, 'regexp') FROM mytable;
match := REGEXP_SUBSTR('subject', 'regexp', 1, 1, 'i')

--REGEXP_REPLACE(source, regexp, replacement, position, occurrence, modes) returns the source string with one or all regex matches replaced. 
--If no matches can be found, the original string is replaced. If you specify a positive number for occurrence (see the above paragraph) 
--only that match is replaced. If you specify zero or omit the parameter, all matches are replaced. The last three parameters are optional. 
--The replacement parameter is a string that each regex match will be replaced with. You can use the backreferences \1 through \9 in 
--the replacement text to re-insert text matched by a capturing group. You can reference the same group more than once. 
--There’s no replacement text token to re-insert the whole regex match. To do that, put parentheses around the whole regexp, 
--and use \1 in the replacement. If you want to insert \1 literally, use the string '\\1'. Backslashes only need to be escaped 
--if they’re followed by a digit or another backslash. To insert \\ literally, use the string '\\\\'. 
--While SQL does not require backslashes to be escaped in strings, the REGEXP_REPLACE function does.

SELECT REGEXP_REPLACE(mycolumn, 'regexp', 'replacement') FROM mytable;
result := REGEXP_REPLACE('subject', 'regexp', 'replacement', 1, 0, 'i');

--REGEXP_INSTR(source, regexp, position, occurrence, return_option, modes) returns the beginning or ending position of a regex match 
--in the source string. This function takes the same parameters as REGEXP_SUBSTR, plus one more. Set return_option to zero or omit 
--the parameter to get the position of the first character in match. Set it to one to get the position of the first character after the match. 
--The first character in the string has position 1. REGEXP_INSTR returns zero if the match cannot be found. The last 4 parameters are optional.

SELECT REGEXP_INSTR(mycolumn, 'regexp', 1, 1, 0, 'i') FROM mytable;

--REGEXP_COUNT(source, regexp, position, modes) returns the number of times the regex can be matched in the source string. 
--It returns zero if the regex finds no matches at all. This function is only available in Oracle 11g and later.

SELECT REGEXP_COUNT(mycolumn, 'regexp', 1, 'i') FROM mytable;