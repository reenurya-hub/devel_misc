--This REGEXP_LIKE example will return all contacts whose last_name ends with 'n'.
SELECT last_name
FROM contacts
WHERE REGEXP_LIKE (last_name, '(*)n$');