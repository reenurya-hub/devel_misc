-- formatea el valor de cadena de caracteres ingresados
select regexp_replace('10023','([0-9]{2})([0-9]{6})([0-9]{1})','\1.\2-\3') from dual;