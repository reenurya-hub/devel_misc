TRP_XX_DL.EV_K_985_WELCOME_KIT_VCR

  SELECT a.*
    FROM corpp0.a2000030 a
   WHERE a.cod_cia          = 1--g_cod_cia
     AND a.cod_sector       = 77--g_cod_sector
     AND a.cod_ramo         = 985--g_cod_ramo
     AND a.mca_provisional  = 'N'--g_mca_provisional
     AND a.num_spto         = 0--trn.CERO
     AND a.cod_canal3       = 4--g_k_cuatro
     AND a.mca_impresion    = 'N'--trn.NO
     AND TRUNC(a.fec_emision_spto) BETWEEN TO_DATE('01/12/2022','DD/MM/YYYY') - 15 AND TO_DATE('01/12/2022','DD/MM/YYYY');

23/11/2022
