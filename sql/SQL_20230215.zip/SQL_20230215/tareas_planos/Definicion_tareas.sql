-- DEFINICION DE TAREA
SELECT * FROM g0200001;

-- PARAMETROS DE TAREAS
SELECT * FROM g0200002;

-- MCA_CONSULTA Y COD_ROL PARA TAREAS
SELECT * FROM g1010210;


SELECT * FROM g0200001 where nom_tar like '%INADIM%';

EV_K_END_CANCEL_INADIMPL_VCR

  INSERT INTO g0200001 (cod_cia,cod_tar,nom_tar,tip_tar,tip_prg,nom_prg,mca_directo,cod_est_parametros,cod_est_anexo,cod_usr,fec_actu,mca_visualiza)
VALUES (1,'VCREMT0024','GERA EVENTO SGO FORA','1','1','EV_K_985_BATCH.P_GERA_EVENTO_SGO','S',NULL,NULL,'DBATERO',TRUNC(SYSDATE),'N');

  INSERT INTO g0200002 (cod_cia,cod_tar,num_secu_campo,cod_campo,mca_visible,mca_obligatorio,nom_prg_pre_campo,val_defecto,nom_pgm_help,nom_tabla_valida,cod_version,nom_global_pgm_help,nom_prg_campo,cod_lista,cod_usr,fec_actu,mca_valida_si_null,mca_vld_online)
VALUES (1,'VCREMT0024',1,'JBCOD_CIA','S','S','JB_K_PARAMETROS.P_COD_CIA','1',NULL,NULL,NULL,NULL,'JB_K_PARAMETROS.P_VALIDA',NULL,'DBATERO',TRUNC(SYSDATE),'N','N');

  INSERT INTO g1010210 (cod_rol,cod_pgm,mca_consulta,fec_actu)
VALUES ('1','VCREMT0024',NULL,TRUNC(SYSDATE));


SELECT * FROM g0200002 where cod_tar in ( 'VCREMT0010', 'VCREMT0006');

SELECT * FROM g0200002 where cod_tar ='VCREMT0010';

SELECT * FROM g1010210 where cod_pgm = 'VCREMT0006';

SELECT * FROM g0200001 where cod_tar in ( 'VCREMT0010', 'VCREMT0006');


SELECT * FROM g0200001 where cod_tar in
('VCRCAP0001',
'VCRCAP0003',
'VCREML0050',
'VCREML0052',
'VCREML0048',
'VCREMT0009',
'VCREMT0011',
'VCRCAP0005',
'VCREMT0010',
'VCRGCL0001',
'VCRGCT7013',
'VCREMT0006',
'VCRGCT7014',
'VCRGCL0002',
'VCREML0046',
'VCREMT0024'

SELECT * FROM corpp0.g0200001 where cod_tar in ( 'VCREML0047','VCREML0049');
