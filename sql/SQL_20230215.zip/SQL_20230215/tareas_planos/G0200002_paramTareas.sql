--PARAMETROS DE TAREAS
--COD_CIA, COD_TAR, COD_CAMPO PK
SELECT * 
  FROM G0200002 a
 WHERE a.cod_cia   = 7
   AND a.cod_tar   = 'MSVTSINPOL'
   AND a.cod_campo = 'JBFEC_INI';
