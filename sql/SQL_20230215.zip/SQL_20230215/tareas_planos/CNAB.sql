
SELECT * FROM A5029491_VCR where num_proposta IN ('9851989771015','9851989771016','9851989771013') FOR UPDATE ;

Puede cambiarle el marca procesado a N�y esas le van a salir en el archivo

Si cuando ejecute la tarea le sale violaci�n de llave primaria, borra los registros que encuentre con esas p�lizas en esa tabla:

SELECT * FROM tron2000.A9999017_VCR where cod_cia = 1 and cod_ramo = 985 and num_poliza IN ('4135000058377','4135000058577','4135000058777') FOR UPDATE;


Y en esta confirma el valor de los recibos:
SELECT * FROM A2990700 where cod_cia = 1 and num_poliza IN ('4135000058377','4135000058577','4135000058777')

El c�digo de la tarea es VCRGCL0001

