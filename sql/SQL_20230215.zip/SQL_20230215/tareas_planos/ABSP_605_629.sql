/******************************* CAMBIOS A ENVIAR PROXIMA MUDANZA *****************************
delete e insert a1001331 ( where cod_docum = '3795072000160')
delete e insert a1001399 ( where cod_docum = '3795072000160')
dc_k_format_output_vcr
dc_k_ptd_thp_vcr
dc_k_ptd_vcr
ev_k_985_welcome_kit_vcr
TRP_XX_DL.EV_K_985_ACT_MONETARIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_CANCELAMENTO_VCR;
TRP_XX_DL.EV_K_985_CARTA_PRORROGACAO_VCR;
em_k_a2992131

orden:
los dml
em_k_a2992131
dc_k_ptd_vcr
dc_k_ptd_thp_vcr
dc_k_format_output_vcr
ev_k_985_welcome_kit_vcr
TRP_XX_DL.EV_K_985_ACT_MONETARIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_CANCELAMENTO_VCR;
TRP_XX_DL.EV_K_985_CARTA_PRORROGACAO_VCR;

*********************************************************************************************/
em_k_a2992131;
dc_k_a1009039_vcr
DC_K_PTD_VCR
tron2000.dc_k_format_output_vcr;
tron2000.dc_k_ptd_thp_vcr;
tron2000.dc_k_ptd_vcr;
trp_xx_dl.ev_k_985_welcome_kit_vcr;
TRP_XX_DL.EV_K_985_ACT_MONETARIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR;
EV_K_LIS_INAD_SICREDI_VCR
TRP_XX_DL.EV_K_985_CARTA_CANCELAMENTO_VCR;
TRP_XX_DL.EV_K_985_CARTA_PRORROGACAO_VCR;


tron2000.em_k_ptd_gni;

  -- inadimplencia VCREML0047 - 19/10/2022
  -- act monetaria VCREML0052 - 28/07/2022
  -- WELCOME KIT   VCREML0048 - 19/10/2022 - 18/10/2022
  -- cancelamento  VCREML0049 - 19/09/2022
  -- prorrogacion  VCREML0050 - 10/05/2022
  
-- segunda mudanza
tron2000.dc_k_ptd_thp_vcr; -- (se cambio fp_format_cpf_cgc por f_format_cpf_cgc)
--tron2000.dc_k_ptd_vcr; -- (se cambio dc_k_a1009039_vcr.p_lee5 por dc_k_a1009039_vcr.p_lee6)
trp_xx_dl.ev_k_985_welcome_kit_vcr;
TRP_XX_DL.EV_K_985_ACT_MONETARIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_CANCELAMENTO_VCR;
TRP_XX_DL.EV_K_985_CARTA_PRORROGACAO_VCR;

TRON2000.em_k_ptd_atr
select * from a2000030 where num_poliza = '4135000044377';
  SELECT *
    FROM a2000030 a
   WHERE a.cod_cia = 1--g_cod_cia
     AND a.cod_sector = 77--g_cod_sector
     AND a.cod_ramo = 985--g_cod_ramo
     AND a.mca_provisional = 'N'--g_mca_provisional
     AND a.fec_emision_spto = TO_DATE('19/10/2022','DD/MM/YYYY')--g_fec_emision_spto
     AND NOT EXISTS (SELECT 0 
                       FROM  a2000030 c
                      WHERE  a.cod_cia            = c.cod_cia
                        AND  a.cod_ramo           = c.cod_ramo
                        AND  a.num_poliza         = c.num_poliza
                        AND  c.tip_spto           = 'AT'
                        AND  c.mca_poliza_anulada = 'S');

select * from a2000020 where 
cod_campo = 'FEC_VCTO_POLIZA_TOTAL'
AND num_poliza = '4135900023477';

tron2000.em_k_ptd_atr;

   SELECT *
     FROM a2000030 a
    WHERE a.cod_cia    = 1--g_cod_cia
      AND a.cod_sector =  77-- g_cod_sector
      AND a.cod_ramo   =   985 --g_cod_ramo
      AND a.mca_provisional =   'N'--trn.NO
      AND cod_spto         = 505 --g_k_suplm_renov
      AND sub_cod_spto     = 10 --g_k_sbcd_supl_renov
      AND a.fec_emision_spto = TO_DATE('10/05/2022','DD/MM/YYYY') --g_fec_emision_spto
      AND NOT EXISTS (SELECT 0 
                     FROM a2000030 c
                     where a.cod_cia  = c.cod_cia
                      AND  a.cod_ramo = c.cod_ramo
                      AND  a.num_poliza = c.num_poliza
                      AND  c.tip_spto = 'AT'
                      AND  c.mca_poliza_anulada = 'S');


select * from a2000060 where num_poliza = '4135900023477';


tron2000.em_k_ptd_atr;
SELECT * FROM A2000020 WHERE NUM_POLIZA = '4135000044777';
SELECT * FROM A2000030 WHERE NUM_POLIZA = '4135000044777';
select * from a2000030 where num_poliza in (
'4135000043877',
'4135000043977',
'4135000044077',
'4135000044177',
'4135000044277',
'4135000044377',
'4135000044477',
'4135000044577',
'4135000044677',
'4135000044777',
'4135000044877',
'4135000044977',
'4135000045077',
'4135000045177',
'2945900000177',
'2945900002477',
'4135000045477',
'4135000045577',
'4135000045677',
'4135000045777',
'4135000045877',
'4135000045977',
'4135000046077');


tron2000.em_k_ptd_ine

 FUNCTION f_con_beneficiarios_riesgo(p_cod_cia    x2000060.cod_cia    %TYPE,
                                     p_num_poliza x2000060.num_poliza %TYPE,
                                     p_num_riesgo x2000060.num_riesgo %TYPE,
                                     p_tip_benef  x2000060.tip_benef  %TYPE)

     l_tb_docum_benef := tron2000.em_k_ptd_ine.f_con_beneficiarios_riesgo(g_cod_cia    ,
                                                                          g_num_poliza ,
                                                                          trn.UNO      ,
                                                                          2--g_k_asegurado);
 


   SELECT *
     FROM a2000030
    WHERE cod_cia          = 1--g_cod_cia
      AND cod_sector       = 77--g_cod_sector
      AND cod_ramo         = 985--g_cod_ramo
      AND mca_provisional  = 'N'--g_mca_provisional
      AND cod_spto         = 508--g_k_suplm_cancelamento
      AND sub_cod_spto     = 2--g_k_sbcd_supl_dec_aseg
      AND fec_emision_spto = to_date('19/09/2022','DD/MM/YYYY');


select * from a1001331  where cod_docum = '3795072000160';

tron2000_app.EA_K_231_COTI_VCR;

select * from a2000020 where num_poliza = '4135000043877';
dc_k_ptd_thp_vcr
f_format_cpf_cgc
VCREML0048 (GERA ARQ WELCOME KIT PRESTAMIS) -> Enviar ao CCM os dados Welcome Kit - RISCO ACEITO automaticamente
                                            -> Enviar ao CCM os dados Welcome Kit - RISCO ACEITO ap�s Subscri��o
              
VCREML0047 (GERA AVISO DE INADIMPLENCIA) -> Solicitar ao CCM o envio de email com a Comunica��o de Inadimplencia 30 dias
                                         -> Solicitar ao CCM o envio de email com a Comunica��o de Inadimplencia 60 dias
                                         
                                         
VCREML0050 (GERA AVISO DE PRORROGACAO) -> Solicitar ao CCM o envio de email com a Comunica��o de Prorrogacao de Vigencia            



VCREML0052 (GERA AVISO DE ACT. MONETARIA) -> Solicitar ao CCM o envio de email com a Comunica��o de Atualiza��o Monet�ria do Capital Fixo



VCREML0049 (GERA AVISO DE CANCELAMENTO) -> Solicitar ao CCM o envio de e-mail com a Comunica��o de Cancelamento a Pedido do Segurado  .

;

tron2000.dc_k_ptd_thp_vcr;
tron2000.dc_k_ptd_thp;

jb_k_AP020012
 jb_k_AP020012.p_lanza_tarea
 
select * from  g0200001 where cod_tar in ('VCREML0048', 'VCREML0047', 'VCREML0050', 'VCREML0052', 'VCREML0049' );

VCREML0052 GERA AVISO DE ACT. MONETARIA
EV_K_985_ACT_MONETARIA;
EV_K_985_ACT_MONETARIA.P_PROCESO;
tron2000.EM_K_LISTA_ASISTENCIA_VCR
;
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR.P_INICIO
;
TRP_XX_DL.EV_K_985_WELCOME_KIT_VCR;

dc_k_format_output

select * from a1001800 where cod_ramo = 985 and cod_cia = 1;
Tranquilidade Financeira MAPFRE

-- antes estaba PRESTAMISTA COLETIVO
UPDATE A1001800 SET NOM_RAMO = 'Tranquilidade Financeira MAPFRE'
WHERE COD_CIA = 1 AND COD_SECTOR = 77 AND COD_RAMO = 985;
COMMIT;

;
tron2000.dc_k_form
dc_k_format_output;

TRON2000.em_k_ptd_atr

select * from a2000040 where cod_ramo = 985;

select * from a2000020 where NUM_POLIZA = '4135000035977';
select * from a1009039_vcr where cod_grupo_susep_vcr in (9,13)and cod_sector_susep_vcr = 77 and cod_ramo = 985
select * from a1009039_vcr where cod_grupo_susep_vcr in (9,13) and cod_ramo = 985

select * from a1009039_vcr_susep;
;
ev_k_985_cob;

tron2000.dc_k_ptd_vcr;

f_con_a1009039_vcr;

TRON2000.dc_k_ptd_vcr;

trp_xx_dl.dc_k_thp_vcr
tron2000.dc_k_thp_vcr;
tron2000.DC_K_PTD_THP_VCR;

dc_k_ptd
trn_k_df_cmn_nwt_xx_cnn.f_vrb_nam_val

select * from df_cmn_nwt_xx_cnn where vrb_nam = 'NOME_PRODUTO' ;

insert into df_cmn_nwt_xx_cnn (CMP_VAL, LOB_VAL, MDT_VAL, CRN_VAL, CVR_VAL, FRS_LVL_VAL, SCN_LVL_VAL, THR_LVL_VAL, FRS_DST_HNL_VAL, SCN_DST_HNL_VAL, THR_DST_HNL_VAL, AGN_VAL, GPP_VAL, DEL_VAL, SBL_VAL, PLY_VAL, VRB_NAM, VRB_NAM_VAL, JMP_CHC, VLD_DAT, DSB_ROW, USR_VAL, MDF_DAT)
values (1, 985, 99999, 99, 9999, 99, 999, 9999, 'ZZZZ', 'ZZZZ', 'ZZZZ', 99999, 'ZZZZZZZZZZZZZ', 99999, 99999, 'ZZZZZZZZZZZZZ', 'NOME_PRODUTO', 'Tranquilidade Financeira MAPFRE', 'S', to_date('14-01-2022', 'dd-mm-yyyy'), 'N', 'DDELGADO', to_date('24-02-2022', 'dd-mm-yyyy'));

prompt Done.

SELECT * FROM A2000030 WHERE NUM_POLIZA = '4135000035977';
SELECT * FROM A2000020 WHERE NUM_POLIZA = '4135000035977';
select * from a1000802 WHERE NUM_POLIZA = '4135000035977';

select * from a1001999;

UPDATE A2000030 SET MCA_IMPRESION = 'N' WHERE  NUM_POLIZA = '4135000035977';

dc_k_a1009039_vcr.p_lee5(p_cod_cia  => p_cod_cia,
                         p_cod_ramo => p_cod_ramo,
                         
dc_k_a1009039_vcr;

select * from a1001399

tron2000.CA_K_CARGA_CARTA_SINI_CCED_VCR



ed_k_734_dv

select * from a2000030 where  NUM_POLIZA = '4135000035977';
select *from G2990000 WHERE num_contrato IN ('9003'); 
v1001390
A1001399 , A1001390, G1000900;
SELECT * FROM G1000900
 PROCEDURE p_lee(p_cod_cia      g2990000.cod_cia      %TYPE,
                 p_cod_ramo     g2990000.cod_ramo     %TYPE,
                 p_num_contrato g2990000.num_contrato %TYPE,
                 p_fec_validez  g2990000.fec_validez  %TYPE) IS
                 
           

tron2000.dc_k_ptd_vcr;
de la a2000030 obtengo el num_contrato
luego de la g2990000 obtengo con el num_contrato con el (cod_cia, cod_ramo, num_contrato, fec_validez)
el tip_docum y cod_docum del estipulante
;
tron2000.DC_K_PROCESO_BATCH_VCR

;
em_k_g2990000
        em_k_g2990000.p_lee (p_cod_cia      => gn_cod_cia      ,
                             p_cod_ramo     => gn_cod_ramo     ,
                             p_num_contrato => gn_num_contrato ,
                             p_fec_validez  => gl_fec_validez  );
        --

select * from corpp0.a2000030 where num_poliza in (
'4135900140777', '4135900140877', '4135900140977');

tron2000.em_k_g2990000.em_k_g2990000
select



dc_k_a1009039_vcr




tron2000.EM_K_PTD_BRW_VCR

tron2000.BUSCA_ESTIPULANTE;

dc_k_ptd;
trn_k_df_cmn_nwt_xx_cnn
SELECT * FROM a5020900 WHERE COD_ENTIDAD like '%748%';
TRON2000.dc_k_ptd_vcr;
dc_k_ptd_vcr.f_con_a5020900
;

UPDATE a5020900 SET

WHERE COD_ENTIDAD 

Nome: CONFEDERA��O DAS COOPERATIVAS DO SICREDI - CONFEDERA��O SICREDI

CNPJ: 03.795.072/0001-60

Endere�o: Avenida Assis Brasil, n� 3940, Andar 6

Bairro: S�o Sebasti�o

CEP 91060-900

Cidade: Porto Alegre

UF: RS

TELEFONE: (51) 3358-4700


SELECT * FROM a5023100_vcr;

--estipulante
select * from a1001331 where cod_docum = '3795072000160';
SELECT * FROM a1000102 WHERE cod_localidad = 71 AND cod_prov = 956; -- barrio


para formatear documentos CPF o CNPJ (CGC)
;
tron2000.em_k_jrp_231_emi_vcr


begin
  -- Call the function
  :result := tron2000.em_k_jrp_231_emi_vcr.fp_format_cpf_cgc(p_tip_docum => :p_tip_docum,
                                                             p_cod_docum => :p_cod_docum);
end;

;
TRON2000.dc_k_ptd_thp_vcr;
tron2000.EM_K_GEN_INT_VCR;
tron2000.EV_K_BACKOFFICE_VCR

TRON2000.dc_k_v1001390_vcr;
dc_k_ptd_thp_vcr.f_dev_v1001390_nom_completo

select * from A1001399 where cod_docum = '3795072000160' FOR UPDATE;
A1001390; 
G1000900;
  
   TRP_XX_DL.EV_K_985_WELCOME_KIT_VCR;



tron2000.dc_k_a1001331_trn;
tron2000



tron2000.dc_k_ptd_thp_vcr;


EV_K_985_WELCOME_KIT;
EV_K_985_WELCOME_KIT.P_INICIO;
EV_K_985_ACT_MONETARIA;
EV_K_985_ACT_MONETARIA.P_PROCESO;
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR;
TRP_XX_DL.EV_K_985_CARTA_INADIMPLENCIA_VCR.P_INICIO;
TRP_XX_DL.EV_K_985_CARTA_CANCELAMENTO_VCR;
TRP_XX_DL.EV_K_985_CARTA_CANCELAMENTO_VCR.P_INICIO;
EV_K_985_CARTA_PRORROGACAO;
EV_K_985_CARTA_PRORROGACAO.P_PROCESO

select * from a2000060 where num_poliza = '4135000044877';
select * from a2000060 where tip_relac is not null;
tip_relac

select * from a1001344

-- polizas para probar welcomekit
select * from a2000030 where num_poliza = '4135000044877';
4135000044777


tron2000.dc_k_ptd_vcr;
em_k_a2992131
em_k_a2992131.p_lee_max_num_mvto(

--CONSULTA PARA HML
  SELECT a.*
    FROM CORPP0.a2000030 a
   WHERE a.cod_cia          = 1   --g_cod_cia
     AND a.cod_sector       = 77  --g_cod_sector
     AND a.cod_ramo         = 985 --g_cod_ramo
     AND a.mca_provisional  = 'N' --g_mca_provisional
     AND a.num_spto         = 0   --trn.CERO
     AND a.cod_canal3       = 4   --g_k_cuatro
     AND a.mca_impresion    = 'N' --trn.NO
     AND a.fec_emision_spto BETWEEN TO_DATE('20/10/2022','DD/MM/YYYY') - 15 AND g_fec_emision_spto;
     
tron2000.dc_k_ptd_vcr;
TRON2000.em_k_a2992131_vcr.p_lee_max_num_mvto_fech

-- INADIMPLENCIA
   
  SELECT *
    FROM a2000030
   WHERE cod_cia = 1--g_cod_cia
     AND cod_sector = 77--g_cod_sector
     AND cod_ramo = 985 --g_cod_ramo
    AND mca_provisional = 'N' --g_mca_provisional
    AND num_spto = 0--trn.cero -- inicialmente nao teremos tratamento de endossos
     AND fec_emision_spto = TO_DATE('19/10/2022','DD/MM/YYYY')--g_fec_emision_spto;

select * from a2990700
select * from A5020500
-- actividad monetaria

  SELECT *
    FROM a2000030
   WHERE cod_cia          = 1--g_cod_cia
     AND cod_sector       = 77--g_cod_sector
     AND cod_ramo         = 985--g_cod_ramo
     AND mca_provisional  = 'N'--trn.NO
     AND cod_canal3       = 4--g_k_cuatro
     --AND fec_emision_spto = TO_DATE('19/10/2022','DD/MM/YYYY')--g_fec_emision_spto
     AND cod_spto         = 901--g_k_spto
     AND sub_cod_spto     = 7--g_k_siete;
     
-- cancelamiento
SELECT * FROM A2000030;

   SELECT *
     FROM a2000030
    WHERE cod_cia = 1--g_cod_cia
      AND cod_sector = 77--g_cod_sector
      AND cod_ramo = 985--g_cod_ramo
      AND mca_provisional = 'N'--g_mca_provisional
      AND num_spto = 0--trn.cero -- inicialmente nao teremos tratamento de endossos
      AND fec_emision_spto = to_date('17/10/2022','dd/mm/yyyy')--g_fec_emision_spto;
