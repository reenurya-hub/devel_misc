SELECT a.*
  FROM g2000211 a
 WHERE 1=1
   -- AND a.cod_cia = 2
   -- AND a.cod_error = 0 --= a.cod_error
   -- AND a.nom_error = a.nom_error
   -- AND a.cod_idioma = a.cod_idioma
   -- AND a.cod_usr = 'TRON2000'
   -- AND a.TRUNC(fec_actu) = TO_DATE('01/01/2023','DD/MM/YYYY')
;
