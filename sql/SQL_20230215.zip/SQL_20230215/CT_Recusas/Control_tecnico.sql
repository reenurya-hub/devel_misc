-- parametrizacion del error de Control Tecnico
SELECT * FROM G2000210 where cod_error = 9856;

