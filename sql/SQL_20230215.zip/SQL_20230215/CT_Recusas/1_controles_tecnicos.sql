-- tablas ct homologacion
select * from corpp0.g2000211 where cod_cia = 1 AND cod_error = 9856; -- definicion nombre error ct
select * from corpp0.g2000210 where cod_cia = 1 and cod_error = 9856; -- parametrizacion control tecnico 
select * from corpp0.g2000220 where cod_cia = 1 ORDER BY cod_sistema, cod_nivel_salto;


-- tablas ct dev
-- G2000211 DESCRIPCIONES DE ERRORES DE CONTROL TECNICO
SELECT * 
  FROM g2000211 a 
 WHERE a.cod_cia = 1 -- PK
   AND a.cod_error = 9856 -- PK
   AND a.cod_idioma = 'PT' -- PK
   AND a.cod_usr = 'TRON2000'
-- AND TRUNC(FEC_ACTU) = TO_DATE('24/03/2022','DD/MM/YYYY')
   ; -- definicion nombre error ct

--ERRORES DE CONTROL TECNICO
--COD_CIA, COD_ERROR
SELECT a.* 
  FROM g2000210 a 
 WHERE a.cod_cia   = 1  --PK
   AND a.cod_error = 9856 -- PK
   ; 
   
-- NIVELES DE SALTO DEL CONTROL TECNICO
--COD_CIA, COD_SISTEMA, COD_NIVEL_SALTO
SELECT a.* 
  FROM g2000220 a 
 WHERE a.cod_cia     = 1 -- PK
   --AND a.cod_sistema = 2 -- PK
   --AND a.cod_nivel_salto = 1 -- PK
 ORDER BY cod_sistema, cod_nivel_salto;


tron2000.ed_k_260_ct_mgt; -- MANEJO DE CONTROLES TECNICOS A NIVEL DE CASCO MARITIMO (260)
em_k_gen_ct; -- GENERAL DE CONTROLES TECNICOS

-- polizas con control tecnico
-- CONTROL TECNICO DE LA POLIZA
--MCA_AUTORIZACION, COD_CIA indice
--COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, COD_COB, COD_SECC_REAS, COD_ERROR
SELECT * 
  FROM a2000221 a
  WHERE a.cod_cia = 1  -- indice
    -- AND a.mca_autorizacion = 'S' -- INDICE
    --AND a.NUM_POLIZA LIKE '413%'
    AND a.num_poliza    = '4130000000114'  -- INDICE
    AND a.num_spto      = 0  -- INDICE
    AND a.num_apli      = 0  -- INDICE
    AND a.num_spto_apli = 0  -- INDICE
    --AND a.num.riesgo    = 0  -- INDICE
    --AND a.cod_cob       = 9999 -- INDICE
    --AND a.cod_secc_reas  = 0  -- INDICE
    AND a.cod_error     = 540
    --AND a.cod_error in (2011,2025,2024,2023,2004,2003,2000,2017,2084,9571,2006,2026,9599,9221)
;

-- polizas vigentes con control tecnico sin autorizar
SELECT * 
  FROM a2000221 a
 WHERE a.num_poliza LIKE '260%'
   AND a.cod_error  IN (2011,2025,2024,2023,2004,2003,2000,2017,2084,9571,2006,2026,9599,9221)
   AND a.mca_autorizacion = 'N'
   AND a.num_poliza IN (SELECT b.num_poliza 
                          FROM a2000030 b 
                         WHERE b.cod_cia            = 2 
                           AND b.cod_ramo           = 260
                           AND b.mca_provisional    = 'N' 
                           AND b.mca_poliza_anulada = 'N' 
                           AND b.mca_spto_anulado   = 'N'
                           AND b.mca_exclusivo      = 'N'
                           AND TRUNC(b.fec_efec_spto) >= TO_DATE('01/01/2022','DD/MM/YYYY') 
                           AND b.num_poliza NOT IN (SELECT NUM_POLIZA 
                                                      FROM a2000030 c 
                                                     WHERE c.mca_poliza_anulada = 'S'
                                                     )
                       )
ORDER BY a.num_poliza ASC;

-- errores de control tecnico
select * from G2000210 where cod_error in (9124, 9599, 9600);

-- definicion errores ct
select * from g2000211 where cod_cia = 2 AND UPPER(NOM_ERROR) LIKE '%FIDEL%';
