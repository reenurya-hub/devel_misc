-- DEFINICION DEL CONTROL TECNICO
-- COD_CIA, COD_SISTEMA, COD_SECTOR, COD_SUBSECTOR, COD_RAMO, COD_NIVEL1, COD_NIVEL2, COD_NIVEL3,    -- PK
-- COD_NIVEL_SALTO, NUM_MENU_OPCION, NUM_OPCION, COD_EST                                             -- PK 
SELECT a.*
  FROM G2000200 a
 WHERE 1=1 
   AND a.COD_CIA            = 1                                      -- PK
   AND a.COD_SISTEMA        = 2                                      -- PK                    
   AND a.COD_SECTOR         = 77                                     -- PK
   AND a.COD_RAMO           = 985                                    -- PK
   AND a.COD_SUBSECTOR      = 9999                                   -- PK
   AND a.COD_NIVEL1         = 99                                     -- PK
   AND a.COD_NIVEL2         = 999                                    -- PK
   AND a.COD_NIVEL3         = 9999                                   -- PK
   AND a.COD_NIVEL_SALTO    = '8'                                    -- PK
   -- AND a.NOM_PRG            = 'EV_K_985_CT.P_CT_GRABAR'
   -- AND a.COD_USR            = 'SSGOMEZ'
   -- AND TRUNC(a.FEC_ACTU)    = TO_DATE('01/01/2023','DD/MM/YYYY')
   AND a.NUM_MENU_OPCION    = 0                                      -- PK
   AND a.NUM_OPCION         = 0                                      -- PK
   AND a.COD_EST            = '9999'
;
