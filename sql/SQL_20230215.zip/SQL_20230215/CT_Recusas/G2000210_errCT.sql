-- COD_CIA, COD_ERROR              PK
-- ERRORES DE CONTROL TECNICO
SELECT a.*
  FROM G2000210 a
 WHERE 1=1 
   AND a.COD_CIA = 1                                                 -- PK
   AND a.COD_ERROR = 160                                             -- PK
   -- AND a.TIP_RECHAZO            = 3
   -- AND a.COD_NIVEL_AUTORIZACION = 6
   -- AND a.MCA_SPTO               = 'S'
   -- AND a.MCA_RF                 = 'S'
   -- AND a.MCA_POLIZA             = 'S'
   -- AND a.MCA_ERROR_SPTO         = 'S'
   -- AND a.NOM_PRG_AUTORIZA       = '' -- IS NULL
   -- AND a.NOM_PRG_RECHAZA        = '' -- IS NULL
   -- AND a.TIP_ACCION_RECHAZO     = '' -- IS NULL
   -- AND a.TIP_AUTORIZA_ERROR     = 1 
   -- AND a.COD_USR                = 'TRON2000'
   -- AND TRUNC(a.FEC_ACTU)        = TO_DATE('19/01/20000','DD/MM/YYYY')
   -- AND a.COD_SIST_AUT           = '' -- IS NULL
   -- AND a.MCA_OBS_OBLIGATORIAS   = 'N' 
   -- AND a.COD_EST_DETALLE        = '' -- IS NULL 
;
