ED_K_228_CT; -- emision ramo 228
ed_k_gen_ct  -- generales
TS_K_228_CT; -- siniestros ramo 228
ts_k_diversos_ct; 
