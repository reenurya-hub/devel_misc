select * from A2992130_VCR where num_poliza = '4135000032777';

-- recusas dev 
-- RAMO 985:
3459 SEM RECUSA
3460 CONSULTA RECUSA DOCUM PEP TOMADOR
2118 COD_PROFISSAO + SOMA ASSEGURADA TITULAR
2149 COD_PROFISSAO + SOMA ASSEGURADA TITULAR
2153 COD_PROFISSAO + SOMA ASSEGURADA TITULAR
2752 CONSULTA RECUSA DOCUM PEP ASEGURADO
2762 RECUSA RESTRICAO
2801 CONSULTA RECUSA DPS

--Tabela de Definicao das recursos por modalidade
SELECT * FROM tron2000.G2992051_VCR where cod_cia = 1 and cod_recusa = 2752;
--Tabela de Definicao dos campos associados as regras de recusa
SELECT * FROM tron2000.G2992151_VCR where cod_cia = 1 and cod_ramo = 985;
--Tabela com a ordem das regras de recusa a serem aplicadas
SELECT * FROM tron2000.G2992152_VCR where cod_cia = 1 and cod_ramo = 985;
--Tabela definicao dos codigos de recusa flex
SELECT * FROM tron2000.G2992153_VCR where cod_cia = 1 and cod_ramo = 985;
SELECT * FROM tron2000.G2992153_VCR where cod_cia = 1 and cod_ramo = 985 and cod_recusa = 2153;
-- Recusas por poliza
SELECT * FROM tron2000.G2992154_VCR where cod_cia = 1 and cod_ramo = 985;
SELECT * FROM tron2000.G2992154_VCR where cod_cia = 1 and cod_ramo = 985 and cod_recusa = 2153;



-- recusas homologacion
SELECT * FROM corpp0.G2992051_VCR where cod_cia = 1;
SELECT * FROM corpp0.G2992151_VCR where cod_cia = 1 and cod_ramo = 985;
SELECT * FROM corpp0.G2992152_VCR where cod_cia = 1 and cod_ramo = 985;
SELECT * FROM corpp0.G2992153_VCR where cod_cia = 1 and cod_ramo = 985;
SELECT * FROM corpp0.G2992154_VCR where cod_cia = 1 and cod_ramo = 985;
SELECT * FROM corpp0.G2992154_VCR where cod_cia = 1 and cod_ramo = 985 and cod_recusa = 2153;
