-- CONTROL TECNICO DE LA POLIZA
-- COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, COD_COB, COD_SECC_REAS, COD_ERROR  -- PK
SELECT a.*
  FROM A2000221 a
 WHERE a.COD_CIA                 = 1                                 -- PK
   AND a.NUM_POLIZA              = '1105500010550'                   -- PK
   AND a.NUM_SPTO                = 2                                 -- PK
   AND a.NUM_APLI                = 0                                 -- PK
   AND a.NUM_SPTO_APLI           = 0                                 -- PK
   AND a.NUM_RIESGO              = 1                                 -- PK
   AND a.COD_COB                 = 0                                 -- PK
   AND a.COD_SECC_REAS           = 0                                 -- PK
   -- AND a.COD_SISTEMA             = a.COD_SISTEMA                  -- PK
   -- AND a.COD_NIVEL_SALTO         = a.COD_NIVEL_SALTO              -- PK
   AND a.COD_ERROR               = 238                               -- PK
   -- AND a.MCA_AUTORIZACION        = a.MCA_AUTORIZACION             -- PK
   -- AND a.FEC_AUTORIZACION        = a.FEC_AUTORIZACION             -- PK
   -- AND a.COD_USR_AUTORIZACION    = a.COD_USR_AUTORIZACION         -- PK
   -- AND a.OBS_AUTORIZACION        = a.OBS_AUTORIZACION             -- PK
   -- AND a.COD_SIST_AUT            = a.COD_SIST_AUT                 -- PK
   -- AND a.TXT_ERROR_CT            = a.TXT_ERROR_CT                 -- PK      
   -- AND a.OBS_ERROR               = a.OBS_ERROR                    -- PK
;
