SELECT * 
  FROM g2999003_mgt a 
 WHERE a.cod_cia  = 2 
   AND a.cod_ramo = 228 
   AND nom_nemotecnico = 'VAL_MAXIMO_EDIF_CONT';