cod_act_tercero = 1 (Clientes)



Los cod_act_tercero est�n en:

SELECT * FROM a1002200; -- DEFINICION DE ACTIVIDADES DE TERCERO

cod_act_tercero => c�digo de actividad del tercero
1 - Clientes -> A1001331 >> A1000802 (batch P10001331)
2 - Corredores Agentes o intermediarios o agencias -> A1001332 >> A1001332_VCR
Otros -> A1001300



SELECT * FROM a1001390 WHERE cod_cia = 1 AND tip_docum = 'CPF' AND cod_docum = '5619280969'; -- ACTIVIDADES DE UN TERCERO
SELECT * FROM a1001399 WHERE cod_cia = 1 AND tip_docum = 'CPF' AND cod_docum = '5619280969'; -- DATOS FIJOS DE TERCERO
