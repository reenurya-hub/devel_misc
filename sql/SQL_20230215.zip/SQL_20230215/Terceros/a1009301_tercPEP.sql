-- TERCEROS PEP
SELECT a.*
  FROM a1009301 a
 WHERE 1=1
   -- AND a.cod_cia = 2
   -- AND a.tip_pep = a.tip_pep
   -- AND a.tip_docum = a.tip_docum
   -- AND a.cod_docum = a.cod_docum
   -- AND a.tip_docum_rela = a.tip_docum_rela
   -- AND a.cod_docum_rela = a.cod_docum_rela
   -- AND a.ape1_tercero = a.ape1_tercero
   -- AND a.ape2_tercero = a.ape2_tercero
   -- AND a.ape3_tercero = a.ape3_tercero
   -- AND a.nom_tercero = a.nom_tercero
   -- AND a.nom2_tercero = a.nom2_tercero
   -- AND a.tip_relac = a.tip_relac
   -- AND a.nom_relac = a.nom_relac
   -- AND a.nom_emp = a.nom_emp
   -- AND a.cod_pais = a.cod_pais
   -- AND a.cod_prov = 0 --= a.cod_prov
   -- AND a.cod_estado = 0 --= a.cod_estado
   -- AND a.cod_localidad = 0 --= a.cod_localidad
   -- AND a.tip_domicilio = 0 --= a.tip_domicilio
   -- AND a.nom_domicilio = a.nom_domicilio
   -- AND a.cod_postal = a.cod_postal
   -- AND a.num_apartado = a.num_apartado
   -- AND a.tlf_pais = a.tlf_pais
   -- AND a.tlf_zona = a.tlf_zona
   -- AND a.tlf_numero = a.tlf_numero
   -- AND a.fax_numero = a.fax_numero
   -- AND a.email = a.email
   -- AND a.cargo = a.cargo
   -- AND a.TRUNC(fec_fin_cargo) = TO_DATE('01/01/2023','DD/MM/YYYY')
;



--TERCEROS PEP
         SELECT a.*
           FROM a1009301 a
          WHERE a.cod_cia   = g_cod_cia
            AND a.tip_docum = pc_tip_docum
            AND a.cod_docum = pc_cod_docum
          ORDER BY a.tip_docum,
                   a.cod_docum;
