--COD_DOCUM, TIP_DOCUM, TIP_BENEF                                                                         INDICE
--COD_CIA, COD_DOCUM, TIP_DOCUM, TIP_BENEF, NUM_POLIZA                                                    INDICE
--TIP_DOCUM, COD_DOCUM, TIP_BENEF                                                                         INDICE
--COD_CIA, NUM_POLIZA                                                                                     INDICE
--TIP_BENEF, TIP_DOCUM, COD_DOCUM                                                                         INDICE
--NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, TIP_BENEF, TIP_DOCUM, COD_DOCUM, COD_CIA     PK

SELECT * 
  FROM a2000060 a
 WHERE a.cod_cia       = 1                       -- INDICE
   AND a.num_poliza    = '4135000091977'         -- INDICE
   AND a.num_spto      = 0                       -- PK
   AND a.num_apli      = 0                       -- PK
   AND a.num_spto_apli = 0                       -- PK
   AND a.num_riesgo    = 1                       -- PK
   AND a.tip_benef     = 2                       -- PK
   AND a.tip_docum     = 'CPF'                   -- PK
   AND a.cod_docum     = '2084803900'            -- PK
   
