-- PERSONAS DESIGNADAS
    SELECT *
      FROM a1001320 A
     WHERE A.cod_cia         = 2;
