select * from corpp0.v1001390 where cod_docum = '92842776550';

select * from v1001390 where cod_docum = '92842776550';

select * from corpp0.a2000060 where num_poliza = '4135000140677';

select * from corpp0.A1001399 where cod_docum = '32182554734';

FROM A1001399 , A1001390, G1000900

select * from A1001390;

select * from G1000900;


/*************************************/

SELECT
       A1001399.COD_CIA
     , A1001399.TIP_DOCUM
     , A1001399.COD_DOCUM
     , A1001399.APE1_TERCERO
     , A1001399.APE2_TERCERO
     , A1001399.NOM_TERCERO
     , A1001399.NOM2_TERCERO
     , A1001399.TIP_SUFIJO_NOMBRE
     , A1001399.MCA_FISICO
     , A1001390.COD_ACT_TERCERO
     , A1001390.COD_TERCERO
     , A1001390.TIP_DOCUM_PADRE
     , A1001390.COD_DOCUM_PADRE
     , A1001399.COD_SOC_GL
     , A1001399.TLF_MOVIL
     , A1001399.NOM_ALIAS
     , A1001399.TIP_PREFIJO_NOMBRE
     ,
     DECODE(G1000900.MCA_PREFIJO_NOMBRE,'S',DECODE(A1001399.TIP_PREFIJO_NOMBRE,NULL,NULL,ss_f_nom_valor('TIP_PREFIJO_NOMBRE'       ,
                                                                                                        999                        ,
                                                                                                        A1001399.TIP_PREFIJO_NOMBRE,
                                                                                                        trn_k_global.cod_idioma    )) ||' '||
     DECODE(A1001399.MCA_FISICO,'N',A1001399.NOM_TERCERO,
        DECODE(G1000900.MCA_SUFIJO_NOMBRE,'S', RTRIM(LTRIM(A1001399.NOM_TERCERO)) ||' '||
                                                     DECODE(G1000900.MCA_NOM2_TERCERO,'S',RTRIM(LTRIM(A1001399.NOM2_TERCERO)) ||' '||
                                                            DECODE(A1001399.TIP_SUFIJO_NOMBRE,NULL,NULL,ss_f_nom_valor('TIPO_SUFIJO_NOMBRE'      ,
                                                                                                                       999                       ,
                                                                                                                       A1001399.TIP_SUFIJO_NOMBRE,
                                                                                                                       trn_k_global.cod_idioma   )),
                                                      ' '|| DECODE(A1001399.TIP_SUFIJO_NOMBRE,NULL,NULL,ss_f_nom_valor('TIPO_SUFIJO_NOMBRE'      ,
                                                                                                                       999                       ,
                                                                                                                       A1001399.TIP_SUFIJO_NOMBRE,
                                                                                                                       trn_k_global.cod_idioma   ))),
                                                     DECODE(G1000900.MCA_NOM2_TERCERO,'S',
                                                     RTRIM(LTRIM(A1001399.NOM_TERCERO)) ||' '||
                                                     RTRIM(LTRIM(A1001399.NOM2_TERCERO)) ||' '||
                                                     RTRIM(LTRIM(A1001399.APE1_TERCERO)) || ' '  ||
                                                     RTRIM(LTRIM(A1001399.APE2_TERCERO)),
                                                     RTRIM(LTRIM(A1001399.NOM_TERCERO)) ||' '||
                                                     RTRIM(LTRIM(A1001399.APE1_TERCERO)) || ' '  ||
                                                     RTRIM(LTRIM(A1001399.APE2_TERCERO)) ))),
      DECODE(A1001399.MCA_FISICO,'N',A1001399.NOM_TERCERO,
        DECODE(G1000900.MCA_SUFIJO_NOMBRE,'S', RTRIM(LTRIM(A1001399.NOM_TERCERO)) ||' '||
                                                     DECODE(G1000900.MCA_NOM2_TERCERO,'S',RTRIM(LTRIM(A1001399.NOM2_TERCERO)) ||' '||
                                                            DECODE(A1001399.TIP_SUFIJO_NOMBRE,NULL,NULL,ss_f_nom_valor('TIPO_SUFIJO_NOMBRE'      ,
                                                                                                                       999                       ,
                                                                                                                       A1001399.TIP_SUFIJO_NOMBRE,
                                                                                                                       trn_k_global.cod_idioma   )),
                                                      ' '|| DECODE(A1001399.TIP_SUFIJO_NOMBRE,NULL,NULL,ss_f_nom_valor('TIPO_SUFIJO_NOMBRE'      ,
                                                                                                                       999                       ,
                                                                                                                       A1001399.TIP_SUFIJO_NOMBRE,
                                                                                                                       trn_k_global.cod_idioma   ))),
                                                     DECODE(G1000900.MCA_NOM2_TERCERO,'S',
                                                     RTRIM(LTRIM(A1001399.NOM_TERCERO)) ||' '||
                                                     RTRIM(LTRIM(A1001399.NOM2_TERCERO)) ||' '||
                                                     RTRIM(LTRIM(A1001399.APE1_TERCERO)) || ' '  ||
                                                     RTRIM(LTRIM(A1001399.APE2_TERCERO)),
                                                     RTRIM(LTRIM(A1001399.NOM_TERCERO)) ||' '||
                                                     RTRIM(LTRIM(A1001399.APE1_TERCERO)) || ' '  ||
                                                     RTRIM(LTRIM(A1001399.APE2_TERCERO)) )))) NOM_COMPLETO
 FROM A1001399 , A1001390, G1000900
      WHERE A1001399.COD_CIA    = A1001390.cod_cia
        AND G1000900.COD_CIA    = A1001390.cod_cia
        AND A1001399.TIP_DOCUM  = A1001390.tip_docum
        AND A1001399.COD_DOCUM  = A1001390.cod_docum;
