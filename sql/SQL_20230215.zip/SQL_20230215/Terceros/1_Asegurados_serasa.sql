SELECT a.*
       --a.tip_docum, a.cod_docum
  FROM a2009016_vcr a
 WHERE a.cod_cia = 1 --INDICE
   AND a.cod_situacao = 2
   AND a.desc_servico = 'SERASA_PF' -- INDICE
   --AND a.tip_docum = 'CPF' -- INDICE
   --AND a.cod_docum = '36066586807' --INDICE
   --AND a.cod_chave = '36066586807' --INDICE
   AND a.fec_validez >= (SYSDATE + 15) 
   AND a.cod_docum NOT IN (SELECT b.cod_docum FROM a2000030 b WHERE b.cod_cia = 1 AND b.cod_ramo = 985)
   AND EXISTS (SELECT 1 FROM a1001331 c WHERE c.cod_docum = a.cod_docum)
;


select * from a2009016_vcr
;



select * from CORPP0.a2009016_vcr WHERE COD_DOCUM = '5745530880';

select * from CORPP0.a2009016_vcr where cod_situacao <> 2;


SELECT b.tip_docum, b.cod_docum
    FROM corpp0.a2009016_vcr b
   Where b.cod_cia = 1
     and b.cod_situacao = 2
     and b.desc_servico = 'SERASA_PF'
     --and cod_docum = '36066586807'
     AND fec_validez >= (SYSDATE + 15) 
     --and b.cod_docum not in (select cod_docum from corpp0.a2000030 where cod_cia = 1 and cod_ramo = 985)
     and exists (select 1 from corpp0.a1001331 where cod_docum = b.cod_docum)


select * from a2000030

SELECT b.*
    FROM a2009016_vcr b
   Where b.cod_cia = 1
     and b.cod_situacao = 2
     and b.desc_servico = 'SERASA_PF'
     --and cod_docum = '36066586807'
     AND fec_validez >= (SYSDATE + 15) order by fec_validez desc;



SELECT b.tip_docum, b.cod_docum
    FROM a2009016_vcr b
   Where b.cod_cia = 1
     and b.cod_situacao = 2
     and b.desc_servico = 'SERASA_PF'
     --and cod_docum = '36066586807'
     AND fec_validez >= (SYSDATE + 15) order by fec_validez desc;

l_fec_nacimiento := dc_k_ptd_thp.f_dev_fec_nacimiento_aseg;
TRON2000.dc_k_ptd_thp;
SELECT * FROM A1001331 WHERE COD_DOCUM = '5927576338' FOR UPDATE;
SELECT * FROM G2000020 WHERE COD_RAMO = 985;
EV_K_985_DV;
EV_K_985_DV.P_PRE_NUM_EDAD_REAL;

COD_MODALIDAD = 98501 FIJO
98502 VINCULADO
