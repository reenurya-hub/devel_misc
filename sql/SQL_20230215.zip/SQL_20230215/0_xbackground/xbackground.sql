delete from xbackground where cod_marco = '228';
commit;
