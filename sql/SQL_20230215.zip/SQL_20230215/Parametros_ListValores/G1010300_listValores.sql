-- LISTAS DE VALORES
--NOM_TABLA, COD_VERSION, NUM_ORDEN_TABLA, NOM_COLUMNA, COD_CIA
SELECT * 
  FROM G1010300 a 
 WHERE a.nom_tabla       = 'G1010031' 
   AND a.cod_version     = 28
   AND a.num_orden_tabla = 1
   AND a.nom_columna     = 'NOM_VALOR'
   AND a.cod_cia = 7     -- MSV
;
