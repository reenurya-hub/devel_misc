-- g1010310
-- TABLA TEMPORAL PARA LISTA DE VALORES CREADOS POR PROCEDIMIENTO
-- NOM_TABLA, COD_VERSION, COD_CIA pk
SELECT * 
  FROM g1010310 a 
 WHERE a.nom_tabla = 'G1010031' 
   AND a.txt_where = 'g1010031.cod_campo = ''TIP_REPORTE''' 
   AND a.cod_version = 28 
   AND a.cod_cia = 7 -- MSV
;
