-- VALORES DE LISTA DE OPCIONES
SELECT * 
  FROM G1010031 a 
 WHERE a.cod_campo = 'TIP_REPORTE' 
   AND a.num_orden = 1
   AND a.cod_cia   = 7 -- msv
   ;
