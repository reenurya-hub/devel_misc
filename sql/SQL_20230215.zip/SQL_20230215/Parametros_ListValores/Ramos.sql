
-- configuracion de ramo
select * from a1001800 where cod_cia = 1 and cod_ramo = 985;
