-- VALORES NEMOTECNICOS
SELECT a.*
  FROM g2999003_msv a
 WHERE a.cod_cia = 7 
   AND a.cod_ramo = 228
   AND a.nom_nemotecnico = 'TARIFA_PRIMA_MINIMA'
   -- AND a.cod_modalidad = a.cod_modalidad
   -- AND a.cod_campo = a.cod_campo
   -- AND a.txt_valor_minimo = a.txt_valor_minimo
   -- AND a.txt_valor_maximo = a.txt_valor_maximo
   -- AND a.cod_cob = a.cod_cob
   -- AND a.txt_valor_cob_minimo = a.txt_valor_cob_minimo
   -- AND a.txt_valor_cob_maximo = a.txt_valor_cob_maximo
   -- AND a.tip_campo = a.tip_campo
   -- AND a.txt_descripcion = a.txt_descripcion
   -- AND a.txt_campo_alterno = a.txt_campo_alterno
   -- AND a.fec_validez = a.fec_validez
   -- AND a.mca_inh = a.mca_inh
   -- AND a.fec_baja = a.fec_baja
   -- AND a.fec_actu = a.fec_actu
   -- AND a.cod_usr = a.cod_usr
;
