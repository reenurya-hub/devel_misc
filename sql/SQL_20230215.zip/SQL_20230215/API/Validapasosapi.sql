-- valida paso apis
SELECT * FROM TRON2000.G9999991 WHERE COD_CIA = 1 AND COD_RAMO = 985;

ev_k_985_cob;

ev_k_985_batch;

gc_k_gera_arquivo_cnab;

tron2000.em_k_ptd_end_vcr;

ev_k_985_dv.p_ws_consulta_dps
ev_k_985_cob.p_ws_val_premio
gc_k_gera_arquivo_cnab.p_ws_grava_pagamento
ev_k_985_dv.p_ws_retorna_status
ev_k_985_batch.p_ws_gera_inf_recurrencia
ev_k_985_dv.p_ws_d_para_profissao
ev_k_985_batch.p_ws_devuelve_spto_cancelamento
ev_k_985_batch.p_ws_gera_inf_prorrogacao
ev_k_985_dv.p_ws_dev_info_endereco
ev_k_gen_ws.p_ws_v_cod_docum
em_k_backoffice_ws.p_ws_consulta_restricoes
ev_k_985_dv.p_ws_dev_tip_capital
ev_k_backoffice_ws.p_ws_inicio_proceso_din_985
ev_k_backoffice_ws.p_ws_consulta_dps
ev_k_backoffice_ws.p_ws_concluir_din
em_k_ptd_end_vcr.pp_retorna_tip_cancelamento
