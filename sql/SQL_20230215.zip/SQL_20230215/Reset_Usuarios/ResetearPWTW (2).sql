-- Resetear contrasenia tronweb
SELECT a.*,ROWID FROM g1010108 a where cod_saptron = 'NJGARC1' for update;
-- COLOCAR EN TXT_CLAVE_SAPTRON = Z9eSdZgXC5iig8KMLeHuZA==
UPDATE g1010108 SET TXT_CLAVE_SAPTRON = 'Z9eSdZgXC5iig8KMLeHuZA==' where cod_saptron = 'NJGARC1';
COMMIT;
