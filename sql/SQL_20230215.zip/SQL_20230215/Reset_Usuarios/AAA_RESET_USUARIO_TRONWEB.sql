-- para cuando se bloquee por intentos guatemala:
--colocar en txt_clave_saptron esto:
select * from G1010108 where cod_saptron IN ('TRON2000');-- FOR UPDATE;
UPDATE G1010108 SET txt_clave_saptron = 'Z9eSdZgXC5iig8KMLeHuZA==' WHERE cod_saptron = 'TRON2000';
COMMIT;

select * from G1010108 where cod_saptron IN ('TRON2000') FOR UPDATE;
mca_forzar_usuario_red = S
mca_modificar_usuario = n
mca_acceso_sin_clave = n

TRN_K_AP101108;
