3012201004327;
gc_p_envio_alerta_riesgo_msv
begin
  -- Call the procedure
  trn_k_global.asigna('COD_USR','TRON2000');
  trn_k_global.asigna('COD_CIA',7);
  trn_k_global.asigna('COD_IDIOMA','ES');
  --
  gc_p_envio_alerta_riesgo_msv(7,310322000026);
end;


SELECT * FROM a2000030 WHERE num_poliza = '3010322000026';
SELECT * FROM g2999003_msv WHERE TXT_VALOR_MINIMO IN ('LPLOPEU') --delete
SELECT * FROM g2999003_msv WHERE TXT_VALOR_MINIMO IN ('CLOBO') --nuevo
SELECT * FROM g2999003_msv WHERE nom_nemotecnico = 'EMAIL';
SELECT * FROM g2999003_msv WHERE NOM_NEMOTECNICO IN ('TIP_INGRESOS')
--
SELECT * FROM g1002700 WHERE cod_usr_cia IN ('CLOBO')
SELECT c.cod_usr_cia,
             c.email_usr_cia
        FROM g2999003_msv a,
             g1002700 c
       WHERE a.txt_valor_minimo = c.cod_usr_cia
         AND a.nom_nemotecnico  = 'EMAIL'
         AND a.cod_campo        = 'COD_USR_CIA';
--CTRC1
SELECT * FROM a5021600 WHERE  NUM_BLOQUE_TES = 310322000026 FOR UPDATE
SELECT * FROM a5029652_msv WHERE  NUM_BLOQUE_TES = 310322000026

SELECT * FROM a1009302_MSV WHERE cod_docum = '06142112061046' FOR UPDATE
SELECT * FROM a5029652_msv
SELECT * FROM v1001390
SELECT * 
  FROM a2000060 a
 WHERE a.num_poliza = g_num_poliza
   AND tip_benef = '16' 
   AND mca_vigente = 'S'
 
SELECT * FROM a2009006_msv
SELECT * FROM a2009006_msv;
SELECT * FROM a1003001 WHERE cod_nota = 'CTRC1';
SELECT * FROM a1003002 WHERE cod_nota = 'CTRC1' FOR UPDATE; --mandar
EM_K_A2000060;.p_lee_vigente(p_cod_cia    => ,
                            p_num_poliza => ,
                            p_num_apli   => ,
                            p_num_riesgo => ,
                            p_tip_benef  => ,
                            p_tip_docum  => ,
                            p_cod_docum  => )
dc_k_notas_p;
em_k_a2009006_msv_msv;
gc_p_envio_alerta_riesgo_msv;
ed_k_201_dv
SELECT *
         FROM a5029652_msv a,
              a5021600 b
        WHERE a.cod_cia        = b.cod_cia
          AND a.num_bloque_tes = b.num_bloque_tes
          AND a.cod_cia        = 7
          AND a.num_bloque_tes = 310322000026
          AND b.tip_actu       = 'CT'
        ORDER BY b.tip_docum;
