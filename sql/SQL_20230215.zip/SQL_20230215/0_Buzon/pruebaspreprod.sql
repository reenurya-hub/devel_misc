SELECT * FROM trazas_msv@preprod WHERE cod_traza='lmurcia' AND fec_traza > '01/01/2023';
SELECT * FROM trazas_msv@preprod WHERE cod_traza='mq1';
SELECT * FROM all_source@preprod WHERE text LIKE '%dc_p_trazas_msv(''lm%'
SELECT * FROM a7001000@preprod WHERE tip_exp ='DPA' AND fec_aper_EXP > '12/12/2022';
--
SELECT * FROM a7000900@preprod WHERE num_sini =301230000000000
SELECT * FROM a7006050@preprod WHERE num_sini =301230000000000
SELECT * FROM a2000030@preprod WHERE num_poliza='3012201004309';
SELECT * FROM a1000101@preprod;
SELECT * FROM a1001332@preprod WHERE cod_agt=3040;
SELECT * FROM a1001300@preprod WHERE cod_act_tercero = 17 AND email_com IS NOT NULL;
