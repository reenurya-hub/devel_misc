-- G1010100  PROGRAMAS DE UN MENU
-- COD_CIA, COD_PADRE, COD_PGM pk
SELECT a.* 
  FROM G1010100 a 
 WHERE a.cod_cia   = 7 
   AND a.cod_padre = 'AM300009' 
   AND a.cod_pgm   = 'MSVTSINPOL'
;
