-- g0200001 TAREAS
-- COD_CIA, COD_TAR
SELECT a.* 
  FROM g0200001 a
 WHERE a.cod_cia = 7 
   AND a.cod_tar = 'MSVTSINPOL';
