select sysdate + 8 from dual;
select EXTRACT(YEAR FROM sysdate) from dual;
select EXTRACT(month FROM sysdate) from dual;
select EXTRACT(day FROM sysdate) from dual;
select MONTHS_BETWEEN(trunc(sysdate), to_date('06/01/1985','dd/mm/yyyy')) from dual;
select CAST ('29-DEC-22 01.00.00.000000 AM' AS TIMESTAMP) from dual;
select to_number(to_char(LAST_DAY(SYSDATE), 'DD'))  from dual;
select add_months(TO_DATE('10/06/2020','DD/MM/YYYY'),5) from dual; --retorna '10/11/20'
select add_months(TO_DATE('10/06/2020','DD/MM/YYYY'),-5) from dual; --retorna '01/10/20'
select last_day(TO_DATE('10/02/2020','DD/MM/YYYY')) from dual;-- "29/02/20"
select next_day(TO_DATE('10/02/2020','DD/MM/YYYY'),'MONDAY') from dual; 
select current_date from dual;
select current_timestamp from dual;
select systimestamp from dual;

