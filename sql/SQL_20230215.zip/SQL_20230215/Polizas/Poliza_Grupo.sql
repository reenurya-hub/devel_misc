-- Consultas Jaime
select *from G2990001 WHERE num_contrato IN ('6667')        ;  -- TABLA GENERAL DE CONTRATOS.  

select *from G2990017 where num_poliza IN ('736000006667'); -- TABLA GENERAL DE POLIZAS GRUPO.    

select *from A2000010 where num_poliza IN ('736000006667'); -- TABLA DE CONTRATOS ASOCIADOS A POLIZA GRUPO.  Fecha Ven
select *from G2990027 where num_contrato IN ('6667')      ;  -- CABECERA DE CONTRATOS POR RAMO.  FEchas validez

select *from G2990000 WHERE num_contrato IN ('6667');   -- DATOS FIJOS DE CONTRATOS.  fecha validez

select *from G2990026 where num_contrato IN ('6667');


-- Consultas Bruna

Select * from g0009020 where cod_cia = 1 and cod_estructura = 'EA_COTIZA_FLOTA' and cod_plano = 'DADOS_GRUPO_SEGURADO'; -- Estrutura planilha Segurado
(EA_COTIZA_FLOTA - Cota��o)

select * from g0009020 where cod_cia = 1 and cod_estructura = 'EA_COTIZA_FLOTA' and cod_plano = 'RIESGOS'; -- Estrutura planilha risco (EA_COTIZA_FLOTA - Cota��o)

select * from g0009020 where cod_cia = 1 and cod_estructura = 'EA_EMISSA_FLOTA' and cod_plano = 'DADOS_GRUPO_SEGURADO'; -- Estrutura planilha Segurado (EA_EMISSA_FLOTA - Cota��o)

select * from g0009020 where cod_cia = 1 and cod_estructura = 'EA_EMISSA_FLOTA' and cod_plano = 'RIESGOS'; -- Estrutura planilha risco (EA_EMISSA_FLOTA - Cota��o)

select * from g0009010 where cod_cia = 1 and cod_estructura = 'EA_COTIZA_FLOTA' and cod_plano = 'DADOS_GRUPO_SEGURADO'; -- Estrutua de processos

select * from g0009010 where cod_cia = 1 and cod_estructura = 'EA_COTIZA_FLOTA' and cod_plano = 'RIESGOS'; -- Estrutua de processos

select * from g2990019 where cod_cia = 1 and num_contrato = 27; -- MODIFICACION DE DATOS VARIABLES DEL RAMO PARA UN CONTRATO

Select * from G2990017 where cod_cia = 1 and num_poliza_grp = '2252020000222'; -- AGRUPACION DE RECIBOS POLIZA GRUPO

select * from g2990028 where cod_cia = 1 and num_poliza = '9999999999231'; -- Estrutura de campos Ap�lice Grupo.

Select * from a2000012 where cod_cia = 1 and num_poliza_grp = '2252020000222'; -- Dados vari�veis ap�lice grupo

Select * from a2000011 where cod_cia = 1 and num_poliza_grp = '2252020000222'; -- Endosso ap�lice grupo

Select * from a2000013 where cod_cia = 1 and num_poliza_grp = '2252020000222'; -- AGRUPACION DE RECIBOS POLIZA GRUPO
