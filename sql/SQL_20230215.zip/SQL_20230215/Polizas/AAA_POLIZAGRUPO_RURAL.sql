select * from a2000010 where cod_cia =1 and num_contrato = '9003'; -- TABLA DE CONTRATOS ASOCIADOS A POLIZA GRUPO.

select * from g2990001 where num_contrato ='9003'; -- TABLA GENERAL DE CONTRATOS. 

select * from g2990017 where num_poliza = '4135000035977'; -- TABLA GENERAL DE NUM_POLIZA GRUPO.

select *from G2990000 WHERE num_contrato IN ('9003');   -- DATOS FIJOS DE CONTRATOS.  fecha validez

select * from g2990019 where num_contrato IN ('73402');  -- DATOS VARIABLES DE CONTRATOS

select *from G2990026 where num_contrato IN ('73402'); -- COBERTURAS DE CONTRATOS

select * from g2990028 where num_poliza = '7340300001291'; --DATOS VARIABLES DE POLIZA GRUPO (precampo y validaciones)
select * from a2000011; -- suplementos poliza grupo
select * from a2000012; -- datos variables poliza grupo


em_k_ap200100


cpf 216459818
