-- fecha vencimiento poliza grupo
SELECT *
from CORPP0.A2000010
WHERE COD_CIA = 1
AND NUM_POLIZA = '9762022000831';


-- fechas de proceso
select * from A1001600

select * from 
corpp0.A1001600;


ev_k_985_df;

tron2000.EM_K_GEN_DF_VCR;

fec_vcto_spto 1

;em_k_llamador_vcr;

tron2000.em_k_llamador_trn;

select * from corpp0.a2000030 where num_poliza = '4135000233677';


trn_k_df_cmn_nwt_xx_cnn.f_vrb_nam_val(p_vrb_nam => 'NUM_DIAS_CANCELAMENTO_AP');


SELECT * FROM df_cmn_nwt_xx_cnn where vrb_nam ='NUM_DIAS_CANCELAMENTO_AP'
