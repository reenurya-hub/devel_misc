-- DATOS FIJOS DE LA POLIZA
SELECT * 
  FROM a2000030 a 
 WHERE a.cod_cia                 = 7
   AND a.cod_sector              = 2
   AND a.cod_ramo                = 228
   AND a.num_poliza              = '2282200000112';
