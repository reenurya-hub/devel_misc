/* CONSULTA SIMPLE POLIZAS PRIMERA EMISION*/
SELECT * 
  FROM a2000030 a 
 WHERE a.cod_cia                 = 2--7       --1 
   --AND a.cod_sector              = 2       --77
   --AND a.cod_ramo                = 228     --985
   AND a.num_spto                =  0
   AND a.num_apli                =  0
   AND a.num_spto_apli           =  0
   AND a.tip_spto                = 'XX'
   AND a.cod_mon                 =  1
   AND TRUNC(a.fec_efec_spto)    >= TO_DATE('01/12/2022','DD/MM/YYYY')
   AND a.mca_poliza_anulada      = 'N'
   AND a.mca_spto_anulado        = 'N'
   AND a.mca_exclusivo           = 'N' -- para descartar polizas bloqueadas en tronweb
ORDER BY fec_efec_spto desc, a.num_poliza desc;


/* CONSULTA POLIZAS QUE NO ESTEN ANULADAS*/
SELECT * 
  FROM a2000030 a 
 WHERE a.cod_cia                 = 1 
   AND a.cod_sector              = 77
   AND a.cod_ramo                = 985
   AND a.num_spto                =  0
   AND a.num_apli                =  0
   AND a.num_spto_apli           =  0
   AND a.tip_spto                = 'XX'
   AND a.cod_mon                 =  1
   AND TRUNC(a.fec_efec_spto)    >= TO_DATE('01/12/2022','DD/MM/YYYY')
   AND a.mca_poliza_anulada      = 'N'
   AND a.mca_spto_anulado        = 'N'
   /* *** polizas que no est�n anuladas *** */
   AND NOT EXISTS (SELECT 0
                     FROM a2000030 e
                    WHERE e.cod_cia    = a.cod_cia 
                      AND e.cod_sector = a.cod_sector
                      AND e.cod_ramo   = a.cod_ramo
                      AND e.num_poliza = a.num_poliza
                      AND e.num_spto   = (SELECT MAX(f.num_spto) 
                                            FROM a2000030 f
                                           WHERE f.cod_cia    = e.cod_cia 
                                             AND f.cod_sector = e.cod_sector
                                             AND f.cod_ramo   = e.cod_ramo
                                             AND f.num_poliza = e.num_poliza)
                      AND e.tip_spto           = 'AT'
                      AND e.mca_poliza_anulada = 'S')   
ORDER BY a.fec_efec_spto desc, a.num_poliza desc;


/* CONSULTA POLIZAS MAXIMO NUM_SPTO, NUM_APLI, NUM_SPTO_APLI */
SELECT * 
  FROM a2000030 a 
 WHERE a.cod_cia                 = 1 
   AND a.cod_sector              = 77
   AND a.cod_ramo                = 985
   AND a.cod_mon                 =  1
   --AND a.cod_agt                 = 97493
   --AND a.cod_nivel1              = 11
   --AND a.cod_nivel2              = 506
   --AND a.cod_nivel3              = 4135
   --AND a.cod_canal1              = 1
   --AND a.cod_canal2              = 1
   --AND a.cod_canal3              = 4
   --AND a.mca_exclusivo           = 'N'
   --AND a.mca_provisional         = 'N'
   --AND a.mca_impresion           = 'N'  -- Welcome Kit
   --AND a.num_presupuesto         IS NOT NULL
   /* *** Maximo num_spto *** */
   AND a.num_spto = (SELECT MAX(b.num_spto) 
                       FROM a2000030 b
                      WHERE b.cod_cia    = a.cod_cia 
                        AND b.cod_sector = a.cod_sector
                        AND b.cod_ramo   = a.cod_ramo
                        AND b.num_poliza = a.num_poliza
                        AND b.cod_mon    = a.cod_mon
                    )
   /* *** Maximo num_apli *** */
   AND a.num_apli   = (SELECT MAX(c.num_apli) 
                         FROM a2000030 c
                        WHERE c.cod_cia    = a.cod_cia 
                          AND c.cod_sector = a.cod_sector
                          AND c.cod_ramo   = a.cod_ramo
                          AND c.num_poliza = a.num_poliza
                          AND c.cod_mon    = a.cod_mon
                      )
   /* *** polizas max num_spto_apli *** */
   AND a.num_spto_apli = (SELECT MAX(d.num_spto_apli) 
                            FROM a2000030 d
                           WHERE d.cod_cia    = a.cod_cia 
                             AND d.cod_sector = a.cod_sector
                             AND d.cod_ramo   = a.cod_ramo
                             AND d.num_poliza = a.num_poliza
                             AND d.cod_mon    = a.cod_mon
                         )
   AND a.mca_spto_anulado        = 'N'
ORDER BY a.fec_efec_spto desc, a.num_poliza desc;


/* CONSULTA GENERAL POLIZAS */
SELECT * 
  FROM a2000030 a 
 WHERE a.cod_cia                 = 1 
   AND a.cod_sector              = 77
   AND a.cod_ramo                = 985
   --AND a.num_poliza              = '4135000072577'
   --AND a.num_spto                = 0
   --AND a.num_apli                = 0
   --AND a.num_spto_apli           = 0
   --AND TRUNC(a.fec_validez)      >= TO_DATE('01/12/2022','DD/MM/YYYY')
   --AND TRUNC(a.fec_emision)      >= TO_DATE('01/12/2022','DD/MM/YYYY')   
   --AND TRUNC(a.fec_emision_spto) >= TO_DATE('01/12/2022','DD/MM/YYYY')
   --AND TRUNC(a.fec_efec_poliza)  >= TO_DATE('01/12/2022','DD/MM/YYYY')   
   --AND TRUNC(a.fec_vcto_poliza)  >= TO_DATE('01/12/2022','DD/MM/YYYY')   
   AND TRUNC(a.fec_efec_spto)    >= TO_DATE('01/12/2022','DD/MM/YYYY')
   --AND TRUNC(a.fec_vcto_spto)    >= TO_DATE('01/12/2022','DD/MM/YYYY')
   --AND a.tip_duracion            = 1
   --AND a.num_riesgos             = 1
   --AND a.cod_mon                 = 1
   --AND a.cod_fracc_pago          = 2301
   --AND a.cant_renovaciones       = 1
   --AND a.num_renovaciones        = 1
   --AND a.mca_poliza_anulada      = 'N'
   --AND a.mca_spto_anulado        = 'N'
   --AND a.cod_agt                 = 97493
   --AND a.cod_nivel1              = 11
   --AND a.cod_nivel2              = 506
   --AND a.cod_nivel3              = 4135
   --AND a.cod_canal1              = 1
   --AND a.cod_canal2              = 1
   --AND a.cod_canal3              = 4
   --AND a.mca_exclusivo           = 'N'
   --AND a.mca_provisional         = 'N'
   --AND a.mca_impresion           = 'N'  -- Welcome Kit
   --AND a.num_presupuesto         IS NOT NULL
ORDER BY a.fec_efec_spto desc, a.num_poliza desc;
