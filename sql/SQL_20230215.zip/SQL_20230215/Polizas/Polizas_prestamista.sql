select * from a2000030 where cod_cia = 1 and cod_ramo = 985
and trunc(fec_efec_spto) >= to_date('01/12/2022','DD/MM/YYYY');

select * from a2000030 where num_poliza = '4135000079577';


em_k_ptd_gni


