-- tabla general de polizas
select * from a2000030 where cod_cia = 1 and cod_ramo =734;
