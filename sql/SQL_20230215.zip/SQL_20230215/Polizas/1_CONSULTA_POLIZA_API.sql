-- PARA CONSULTAR LA POLIZA GENERADA POR LA API
select num_poliza from a2000030 where num_presupuesto = '9851987782064';

select num_poliza from corpp0.a2000030 where num_presupuesto = '9851987785000';

select * from corpp0.a2000030 where num_poliza = '4135000444377';

select * from corpp0.P1001331 where cod_docum = '7897493865';
