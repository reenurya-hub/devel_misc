--prueba homologaci�n; 4135000370077
--prueba de 02/01/2023 : 4135000438977


/********************************* TABLA A2000500 ***********************************/
-- A2000500
-- COLUMNAS INDICE1: COD_CIA, NUM_POLIZA
-- COLUMNAS INDICE2: NUM_ORDEN, TIP_AUTORIZA_CT, TIP_MVTO_BATCH, FEC_TRATAMIENTO
-- COLUMNAS INDICE3: FEC_TRATAMIENTO, NUM_ORDEN, TIP_MVTO_BATCH, NUM_POLIZA_DEFINITIVO, COD_CIA
-- COLUMNAS INDICE4: COD_CIA, COD_RAMO, NUM_POLIZA_GRUPO

select * from a2000500 where cod_cia = 1 and cod_sector = 77 and cod_ramo = 985 and trunc (fec_tratamiento) = to_date('29/12/2022','DD/MM/YYYY');


select * from a2000500
WHERE TIP_MVTO_BATCH = 3 -- INDICE
--AND NUM_ORDEN = 0 --INDICE
AND COD_CIA = 1 -- INDICE
AND COD_SECTOR = 77 
AND COD_RAMO = 985
AND COD_MON = 1 
-- AND NUM_POLIZA_GRUPO = '' -- INDICE
AND NUM_POLIZA_DEFINITIVO = '' -- INDICE
AND TRUNC(FEC_TRATAMIENTO) = TO_DATE('23/12/2022','DD/MM/YYYY') -- INDICE
--AND TIP_AUTORIZA_CT = NULL

select * from CORPP0.a2000500
WHERE TIP_MVTO_BATCH = 3 -- INDICE
--AND NUM_ORDEN = 0 --INDICE
AND COD_CIA = 1 -- INDICE
AND COD_SECTOR = 77 
AND COD_RAMO = 985
AND COD_MON = 1 
-- AND NUM_POLIZA_GRUPO = '' -- INDICE
AND NUM_POLIZA_DEFINITIVO = '4135000370077' -- INDICE
AND TRUNC(FEC_TRATAMIENTO) = TO_DATE('19/12/2022','DD/MM/YYYY') -- INDICE
--AND TIP_AUTORIZA_CT = NULL



/********************************* TABLA P2000030 ***********************************/
-- COLUMNAS INDICE: COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI
select * from corpp0.p2000030 
where cod_cia = 1
and cod_sector = 77
and cod_ramo = 985
and num_poliza = '9551987079011';


/********************************* TABLA A2000030 ***********************************/
-- ESTA TABLA TIENE MULTIPLES INDICES

SELECT * 
 FROM A2000030
WHERE COD_CIA    = 1 -- INDICE
  AND COD_SECTOR = 77 -- INDICE
  AND COD_RAMO   = 985 -- INDICE
  --AND NUM_POLIZA = '' -- INDICE
  --AND NUM_SPTO   = 0  -- INDICE
  -- AND NUM_SPTO_APLI = 0 --INDICE
  -- AND NUM_PRESUPUESTO = ''   --INDICE
  AND TRUNC(FEC_EFEC_SPTO) = TO_DATE('01/01/2023','DD/MM/YYYY') -- INDICE
  --AND MCA_IMPRESION = 'N'     -- INDICE
  --AND MCA_DATOS_MINIMOS = 'N' --INDICE
  --AND COD_USR = '' -- INDICE
;  
  
SELECT * 
 FROM CORPP0.A2000030
WHERE COD_CIA    = 1 -- INDICE
  AND COD_SECTOR = 77 -- INDICE
  AND COD_RAMO   = 985 -- INDICE
  --AND NUM_POLIZA = '' -- INDICE
  --AND NUM_SPTO   = 0  -- INDICE
  -- AND NUM_SPTO_APLI = 0 --INDICE
  -- AND NUM_PRESUPUESTO = ''   --INDICE
  AND TRUNC(FEC_EFEC_SPTO) = TO_DATE('01/12/2022','DD/MM/YYYY') -- INDICE
  --AND MCA_IMPRESION = 'N'     -- INDICE
  --AND MCA_DATOS_MINIMOS = 'N' --INDICE
  --AND COD_USR = '' -- INDICE
;

/********************************* TABLA A2000020 ***********************************/
select * 
from a2000020
where 1=1
AND COD_CIA = 1
AND COD_RAMO = 985
--AND NUM_SPTO = 1
--AND NUM_PERIODO = 1
--AND VAL_CAMPO = ''
AND NUM_POLIZA = '4135000019977'
AND NUM_RIESGO = 1
AND MCA_VIGENTE = 'S'
AND MCA_VIGENTE_APLI = 'S'
--AND COD_CAMPO = ''
--AND VAL_COR_CAMPO = ''
;

select * 
from CORPP0.a2000020
where 1=1
AND COD_CIA = 1
AND COD_RAMO = 985
--AND NUM_SPTO = 1
--AND NUM_PERIODO = 1
--AND VAL_CAMPO = ''
AND NUM_POLIZA = '4135000019977'
AND NUM_RIESGO = 1
AND MCA_VIGENTE = 'S'
AND MCA_VIGENTE_APLI = 'S'
--AND COD_CAMPO = ''
--AND VAL_COR_CAMPO = ''
;

/********************************* TABLA P2000020 ***********************************/

select * 
from p2000020
WHERE COD_CIA = 1
AND NUM_POLIZA = ''
AND NUM_SPTO = 
AND NUM_APLI =
AND NUM_SPTO_APLI =
AND NOM_RIESGO =
AND NUM_PERIODO =
AND COD_CAMPO =
AND COD_RAMO = 
;

select * 
from CORPP0.p2000020
WHERE COD_CIA = 1
AND NUM_POLIZA = ''
AND NUM_SPTO = 
AND NUM_APLI =
AND NUM_SPTO_APLI =
AND NOM_RIESGO =
AND NUM_PERIODO =
AND COD_CAMPO =
AND COD_RAMO = 
;


/************************* a2000030 a2000500 ********************************/

SELECT a.* 
  FROM corpp0.a2000030 a
 WHERE a.cod_cia    = 1 
   AND a.cod_sector = 77 
   AND a.cod_ramo   = 985 
   AND a.num_poliza_grupo IS NOT NULL
   AND a.num_poliza       IN (SELECT b.num_poliza_definitivo 
                                FROM corpp0.a2000500 b
                               WHERE b.tip_mvto_batch = 3 -- INDICE
                               --AND b.NUM_ORDEN = 0 --INDICE
                                 AND b.cod_cia    = 1 -- INDICE
                                 AND b.cod_sector = 77 
                                 AND b.cod_ramo   = 985
                                 AND b.cod_mon    = 1 );

/********************************* TABLA A2000040 ***********************************/

SELECT * 
  FROM A2000040 a
 WHERE a.cod_cia         = 1
   AND a.cod_ramo        = 985
   AND a.num_poliza      = '4135000020577'
   AND a.num_spto        = 1
   AND a.num_apli        = 0
   AND a.num_spto_apli   = 0
   AND a.num_riesgo      = 1
   AND a.num_periodo     = 1
   AND a.cod_cob         = 9011 
   AND a.mca_vigente     = 'S'
   AND a.mca_baja_riesgo = 'N';
