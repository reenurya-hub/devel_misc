update a2000030 set mca_exclusivo = 'N' WHERE COD_CIA = 1 AND NUM_POLIZA = '4135000046177';
COMMIT;

EM_K_LLAMADOR_TRN
em_k_x2000030
EM_K_AP200120_TRN
IF em_k_a2000030.f_mca_exclusivo = 'S'
   THEN
     --
     g_cod_mensaje := 20033;
     g_anx_mensaje := NULL;
     --
     pp_devuelve_error;
     --
  END IF;
select * from x2000030 where num_poliza = 2282200000493 for update;
select * from a2000030 where num_poliza = 2282200000493 for update;
