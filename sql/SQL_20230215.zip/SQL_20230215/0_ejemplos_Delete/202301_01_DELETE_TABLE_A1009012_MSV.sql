DECLARE
--
BEGIN
   --
   BEGIN
      --
      DELETE a1009012_msv
       WHERE num_secu =20 AND cod_ramo = 228 AND COD_REPORT IN ('EM_K_JRP_POLIZA_228_PS_MSV','EM_K_JRP_POLIZA_228_PS_TR_MSV');
      --
      COMMIT;
      --
   END;
   --
EXCEPTION
   --
   WHEN OTHERS
   THEN
      --
      NULL;
      --
END;
/
--EXIT
