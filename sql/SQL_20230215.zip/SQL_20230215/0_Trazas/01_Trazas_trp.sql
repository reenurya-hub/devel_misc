      trn_k_ptd.p_habilita_traza('AO');
      g_cod_cia           := fp_devuelve_n('JBCOD_CIA');
      g_txt_dir_origen    := g_k_ap_lis;
      g_nom_archivo_plano := fp_devuelve_c('JBNOM_ARQUIVO');
      --
      trn_k_ptd.p_gen_traza_parametro('p_inicio' ,'g_cod_cia',g_cod_cia);
      trn_k_ptd.p_gen_traza_parametro('p_inicio' ,'g_txt_dir_origen',g_txt_dir_origen);
      trn_k_ptd.p_gen_traza_parametro('p_inicio' ,'g_nom_archivo_plano',g_nom_archivo_plano);
      trn_k_ptd.p_deshabilita_traza;
 
;TRON2000.trn_k_ptd

 $$PLSQL_LINE

SUBSTR(dbms_utility.format_call_stack,1,800)

select * from tron2000.t_trn_trn_r_dbg where dbg_idn = 'reuy' 
and  tim_inv BETWEEN CAST ('29-DEC-22 01.00.00.000000 AM' AS TIMESTAMP) AND
CAST ('30-DEC-22 01.00.00.000000 AM' AS TIMESTAMP)

select * 
from tron2000.t_trn_trn_r_dbg 
where dbg_idn = 'reuy' 
--and pgm_nam = 'reuy'
and  tim_inv BETWEEN CAST ('19-DEC-22 01.00.00.000000 AM' AS TIMESTAMP) AND
CAST ('20-DEC-22 01.00.00.000000 AM' AS TIMESTAMP)

drop trigger tron2000.TMP_A2000030;


trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
trn_k_ptd.p_gen_traza_variable('reuy', 'nom_riesgo', $$PLSQL_LINE || ' num_poliza:' || :new.num_poliza || SUBSTR(dbms_utility.format_call_stack,1,800));
trn_k_ptd.p_deshabilita_traza;


trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
trn_k_ptd.p_gen_traza_variable('reuy', 'nom_riesgo', 'num_poliza:' || :new.num_poliza || ' nom_riesgo: ' || :new.nom_riesgo || SUBSTR(dbms_utility.format_call_stack,1,800));
trn_k_ptd.p_deshabilita_traza;

select * from a2000020;

drop TRIGGER TRON2000.TMP_A2000020;

CREATE OR REPLACE TRIGGER TRON2000.TMP_A2000020  BEFORE INSERT ON A2000020 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
       trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
       trn_k_ptd.p_gen_traza_variable('reuy', 'insert', $$PLSQL_LINE || ' num_poliza:' || :new.num_poliza || ' cod_campo: ' || :new.cod_campo ||  ' val_campo: ' || :new.val_campo || SUBSTR(dbms_utility.format_call_stack,1,800));
       trn_k_ptd.p_deshabilita_traza;

    END IF;
    IF UPDATING THEN
       trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
       trn_k_ptd.p_gen_traza_variable('reuy', 'update', $$PLSQL_LINE || ' num_poliza:' || :new.num_poliza || ' cod_campo: ' || :new.cod_campo ||  ' val_campo: ' || :new.val_campo || SUBSTR(dbms_utility.format_call_stack,1,800));
       trn_k_ptd.p_deshabilita_traza;
    END IF;
  END;




CREATE OR REPLACE TRIGGER TRON2000.TMP_A2000031  BEFORE INSERT ON A2000031 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
       trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
       trn_k_ptd.p_gen_traza_variable('reuy', 'insert', 'num_poliza:' || :new.num_poliza || ' nom_riesgo: ' || :new.nom_riesgo || SUBSTR(dbms_utility.format_call_stack,1,800));
       trn_k_ptd.p_deshabilita_traza;

    END IF;
    IF UPDATING THEN
       trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
       trn_k_ptd.p_gen_traza_variable('reuy', 'update', 'num_poliza:' || :new.num_poliza || ' nom_riesgo: ' || :new.nom_riesgo || SUBSTR(dbms_utility.format_call_stack,1,800));
       trn_k_ptd.p_deshabilita_traza;
    END IF;
  END;


CREATE OR REPLACE TRIGGER TRON2000.TMP_P2000031  BEFORE INSERT ON P2000031 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
       trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
       trn_k_ptd.p_gen_traza_variable('reuy', 'insert P2000031', 'num_poliza:' || :new.num_poliza || ' nom_riesgo: ' || :new.nom_riesgo || SUBSTR(dbms_utility.format_call_stack,1,800));
       trn_k_ptd.p_deshabilita_traza;

    END IF;
    IF UPDATING THEN
       trn_k_ptd.p_gen_habilita_traza('reuy',TRUE);
       trn_k_ptd.p_gen_traza_variable('reuy', 'update P2000031', 'num_poliza:' || :new.num_poliza || ' nom_riesgo: ' || :new.nom_riesgo || SUBSTR(dbms_utility.format_call_stack,1,800));
       trn_k_ptd.p_deshabilita_traza;
    END IF;
  END;


trn_k_ptd.p_gen_habilita_traza('99',TRUE);
trn_k_ptd.p_gen_traza_variable('reuy', 'l_tip_docum', l_tip_docum);
trn_k_ptd.p_gen_traza_variable('reuy', 'l_cod_docum', l_cod_docum);
trn_k_ptd.p_gen_traza_variable('reuy', 'l_mca_valida', l_mca_valida);
trn_k_ptd.p_deshabilita_traza;
