TRAZAS TRP
select * from tron2000.t_trn_trn_r_dbg

PAQUETE TRAZAS:
trn_k_ptd.p_gen_comienzo_traza

-- para activar las trazas mx
select * from g1010107 where cod_usr = 'JOSPINA';

se le cambia la columna GENERA.TRAZAS TXT_VALOR_VARIABLE = S
