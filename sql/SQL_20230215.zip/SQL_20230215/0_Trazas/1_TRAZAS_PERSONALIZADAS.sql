--traza del error
l_error := SUBSTR(dbms_utility.format_error_backtrace,1,32000);

tron2000.tmp_p_ejecuta_traza('objeto LINEA: '|| $$PLSQL_LINE, 'valor : ' || valor);
-- TRAZAS PERSONALIZADAS
-- SELECT trazas
SELECT * FROM TRON2000.tmp_traz;
select * from trazas_mpr;
-- DELETE trazas
DELETE FROM TRON2000.tmp_traz;
COMMIT;

-- DROP OBJETOS TRAZAS 
DROP TRIGGER   TRON2000.TMP_TRG_A2000221;
DROP PROCEDURE TRON2000.tmp_p_ejecuta_traza;
DROP PROCEDURE TRP_XX_DL.tmp_p_ejecuta_traza;
DROP TABLE     TRON2000.tmp_traz;

-- CREATE tabla de trazas
CREATE TABLE   TRON2000.tmp_traz
(
  cod_traza   VARCHAR2(1000),
  descripcion clob
);

-- grant todo a usuarios para tabla
GRANT SELECT, INSERT, UPDATE, DELETE ON TRON2000.tmp_traz TO APP_TRON2000, CONSULTA, CONSULTAS, MARLMON, NWT_DM_APP, ROL_TRON2000_SEL, ROL_TRON_BI_SEL_ALL;

-- INSERT 'a pelo' de la traza en el codigo
BEGIN
  INSERT INTO TRON2000.tmp_traz 
  VALUES ('l_reg_a1009031_vcr.mca_inh: ' || l_reg_a1009031_vcr.mca_inh);
  COMMIT;
END;

-- Procedimiento autonomo para ejecutar la traza
CREATE OR REPLACE PROCEDURE TRON2000.tmp_p_ejecuta_traza(p_desc_traza varchar2, p_traza varchar2) IS
--CREATE OR REPLACE PROCEDURE TRP_XX_DL.tmp_p_ejecuta_traza(p_desc_traza varchar2, p_traza varchar2) IS
   PRAGMA autonomous_transaction;
BEGIN
   --
   INSERT INTO TRON2000.tmp_traz 
   VALUES     (p_desc_traza, p_traza);
   COMMIT;    
   --
END;
    
-- LLAMADO
TRP_XX_DL.tmp_p_ejecuta_traza;
TRON2000.tmp_p_ejecuta_traza;

-- Linea de codigo ejemplo traza   
TRP_XX_DL.tmp_p_ejecuta_traza('objeto LINEA: '|| $$PLSQL_LINE, 'valor : ' || valor);
TRON2000.TMP_X2000221('objeto LINEA: '|| $$PLSQL_LINE, 'valor : ' || valor);
TRP_XX_DL.tmp_p_ejecuta_traza('objeto LINEA: '|| $$PLSQL_LINE, ' l_cant_reg : ' || l_cant_reg || ' ERROR : ' || SQLERRM);

-- Trigger para capturar el flujo de programa hasta el insert de una tabla
CREATE OR REPLACE TRIGGER TRON2000.TMP_TRG_A2990700  BEFORE INSERT ON A2990700 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      tron2000.tmp_p_ejecuta_traza('INSERT A2990700', ' NUM_RECIBO: ' || :new.num_recibo || ' new.fec_efec_recibo: ' || :new.fec_efec_recibo || ' new.fec_vcto_recibo: ' ||  :new.fec_vcto_recibo || ' new.fec_emision_spto: ' || :new.fec_emision_spto || ' new.fec_vcto_pago: ' || :new.fec_vcto_pago || dbms_utility.format_call_stack);
    END IF;
    IF UPDATING THEN
      tron2000.tmp_p_ejecuta_traza('UPDATE A2990700', ' NUM_RECIBO: ' || :new.num_recibo || ' new.fec_efec_recibo: ' || :new.fec_efec_recibo || ' OLD.fec_efec_recibo: ' || :old.fec_efec_recibo || ' new.fec_vcto_recibo: ' ||  :new.fec_vcto_recibo || ' old.fec_vcto_recibo: ' ||  :old.fec_vcto_recibo || ' new.fec_emision_spto: ' || :new.fec_emision_spto || ' old.fec_emision_spto: ' || :old.fec_emision_spto || ' new.fec_vcto_pago: ' || :new.fec_vcto_pago || ' old.fec_vcto_pago: ' || :old.fec_vcto_pago || dbms_utility.format_call_stack);
    END IF;
  END;
  
select * from x2000221
CREATE OR REPLACE TRIGGER tron2000.TMP_TRG_A2000030  BEFORE INSERT ON TRON2000.A2000030 FOR EACH ROW
BEGIN
   -- 
   IF INSERTING  THEN
      tmp_p_ejecuta_traza('INSERT EN A2000030: ', 'NUM_POLIZA:' || :new.num_poliza ||dbms_utility.format_call_stack);
   END IF;
   --
END;

CREATE OR REPLACE TRIGGER tron2000.TMP_X2000221  BEFORE INSERT ON TRON2000.X2000221 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      tmp_p_ejecuta_traza('INSERT X2000221 ', ':new.num_poliza: ' || :new.num_poliza || ' new.cod_error: ' || :new.cod_error || ' new.tip_rechazo: ' ||  :new.tip_rechazo || dbms_utility.format_call_stack);
    END IF;
    IF UPDATING THEN
      tmp_p_ejecuta_traza('UPDATE X2000221 ', ':new.num_poliza: ' || :new.num_poliza || ' new.cod_error: ' || :new.cod_error || ' new.tip_rechazo: ' ||  :new.tip_rechazo || ' old.tip_rechazo: ' ||  :old.tip_rechazo || dbms_utility.format_call_stack);
    END IF;
  END;
