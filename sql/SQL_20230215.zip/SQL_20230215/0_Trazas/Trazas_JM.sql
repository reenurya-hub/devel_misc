poner traza 
SELECT * FROM TRAZAS_MPR WHERE COD_TRAZA = 'MY' ORDER BY ID_TRAZA DESC;
DELETE FROM TRAZAS_MPR WHERE COD_TRAZA = 'MY' ;
|dc_p_trazas_mpr ('JGG', 'XXXXXX => ' || NULL);

PTD
SELECT * FROM tron2000.t_trn_trn_r_dbg
delete from tron2000.t_trn_trn_r_dbg where pgm_nam='ed_k_417_dv'
trn_k_ptd.p_gen_traza_variable('p_val_pacotes', 'l_tip_relac', l_tip_relac);
Trn_k_ptd.p_habilita_traza(p_idn_traza => 'PTD');

em_k_ptd_atr.p_asg_mca_salto(p_mca_salto => l_mca_salto);

trn_k_ptd.p_gen_error (p_cod_idioma  => l_cod_idioma              ,
                                                 p_cod_mensaje => 20095619                  ,
                                                 p_t_valores   => trn_k_ptd.t_t_valores_aux ,
                                                 p_pre_mensaje => NULL                      ,
                                                 p_pos_mensaje => NULL   





SELECT *  FROM G1010310;   ---TABLAS DE AYUDA
SELECT  * FROM G1010300;   ---TABAL�AS DE AYUDA
G1010020=tabla de mensajes
G2000210=mensaje error control tecnico
SELECT * FROM G1010031 WHERE COD_CAMPO='TIP_NIVEL'--ver los datos variables a que nivel estan
--VER LOS DATOS AVRIABLES ASOCIADOS A LA COBERTURA
SELECT * FROM G2000010 WHERE COD_CAMPO='VAL_CAPITAL_INMOVILIDAD';   -- etiquetas
SELECT * FROM G2000020 WHERE COD_COB=8113;
SELECT  * FROM G2990006 WHERE COD_CAMPO='VAL_CAPITAL_INMOVILIDAD';
SELECT * FROM a1000510 WHERE cod_mon=14 ORDER BY  fec_cambio DESC; --tasas de cambio
RE2000030  -- TABLA DE POLIZAS RECHAZADAS POR CT

SELECT * FROM G1010031 WHERE COD_CAMPO = 'TIP_PRIMAS_MANUALES';---ayudas por campos

en  C/local/scripts... escritorio  remoto encuentro los scrips

tablas principales

a2000020 datos variables 
g2000020 par�metros datos variables
a2000030 datos fijos 
a2000031 datos de los riesgos 
a1001331 terceros 
A1000710
A1001332 agentes
A1001342
A1001399 = nombre tercero 
a1001332 agentes
a1001390 nombres de los terceros
a2000040 datos coberturas por poliza 
a2000060 datos terceros por poliza 
a1002150 conf coberturas por ramo 
g2000200 controles t�cnicos por paquetes 
a1009012_mgt  Objetos de reportes
G2990004 = Modalidades Cia
A2100300 = Modalidades por Ramo
A2300101 = Tabla Principal de Modalidades Vida
A2300102 = Coberturas por Modalidad
TA299020_MUY = Planes por Modalidad
A2990700 Recibos
A5020301 Historico Recibos
G2000020 = Datos Variables a nivel poliza, Riesgo, Cobertura
G2999009_MUY = Salto de campos por Modalidad
A1002150 = Coberturas por Ramo y Modalidad
G2000170=Conceptos de desglose a Nivel compa��a
A2100170 = Conceptos de desglose asociados a polizas
G2000180 = Conceptos de desglose por ramo
G2000190 = Modificaci�n de desglose por ramo
g2999003_mgt definir campos
G0200001Tareas o programas
G1010020=tabla de mensajes
G2000210=mensaje error control tecnico
G1010020  = TABLA DE MENSAJES
G2990006 = TABLA DE AYUDA(POSIBLE VALORES QUE PUEDE TOMAR UN DV)
a1002090 =  mca obligatorio modalidad->cobertura
g1010300 = ayudas 
g1010310 = ayudas
clausulas = a9990010
g1010031 = tabal de ayuda de busqeuda de campos
G1010021 =TOLTIPS
g2000275  = dv que se dejan modificr en endosos 
a1009039_vcr = configuracion del impuesto
G2990019 =  dv a nivel de pol grupo}
a2000400 = Motivos suplementos 
G2990300 = suplementos 
a1009039_vcr= Veronica 
A1002091 = Modalidad /cobertura 
a1002200 = cada actividad tercero-> se define estructura y pantalla
G2000260 = Dar permisos para autorizar CT
g2000230 = Dar permisos para autorizar CT
g2990005 = Monedas y decimasles
a2000221 = controles tecnicos
G2000210 = ct (observacion,)
x2000025 = tipo lista 
Recordar las particiones al moemento de instalar ramos en brasil
G2000161 = conceptos economicos
a1001320 = terceros no deseados
a1001600 = cmabiar fechas proceso
g1002000 = ramo contable
SELECT owner,
       decode(partition_name,
              NULL,
              segment_name,
              segment_name || ':' || partition_name) NAME,
       segment_type,
       tablespace_name,
       bytes,
       initial_extent,
       next_extent,
       pct_increase,
       extents,
       max_extents
  FROM dba_segments
 WHERE 1 = 1
   --AND extents > 1
   AND owner = 'TRON2000'
   AND partition_name IS NOT NULL
   AND segment_type = 'TABLE PARTITION'
   AND partition_name LIKE '%417%'
 ORDER BY 2;
/opt/apache-tomcat-6.0.26/webapps/wtw_reports/WEB-INF/classes/com/mapfre/msv/jrp

Guatemala
/opt/apache-tomcat-6.0.26/webapps/wtw_reports/WEB-INF/classes/com/mapfre/mgt/jrp/gc

/opt/tomcat6/gt/apache-tomcat-6.0.53/webapps/wtw_reports/WEB-INF/classes/com/mapfre/mgt/jrp





-----------------------------------------------------------


(seenoevil)

SELECT owner,
       decode(partition_name,
              NULL,
              segment_name,
              segment_name || ':' || partition_name) NAME,
       segment_type,
       tablespace_name,
       bytes,
       initial_extent,
       next_extent,
       pct_increase,
       extents,
       max_extents
  FROM dba_segments
 WHERE 1 = 1
   --AND extents > 1
   AND owner = 'TRON2000'
   AND partition_name IS NOT NULL
   AND segment_type = 'TABLE PARTITION'
   AND partition_name LIKE '%417%'
 ORDER BY 2;

endososos--suplementos
C�sar, 10:00 a.m.
SELECT * FROM DF_CMN_NWT_XX_VRB_CNC WHERE cmp_val = 1 and vrb_nam = 'COD_SUB_COD_SPTO' and lob_val in(418) FOR UPDATE;--motivos 
SELECT * FROM G2990300 WHERE COD_CIA = 1 AND cod_Ramo= 417;--motivos 
SELECT * FROM G2000030 WHERE cod_cia= 1 AND cod_Ramo=417;--ok
SELECT * FROM g2000275 WHERE cod_cia= 1;--dvs para endosso


precondiciones endoso de restitucion

juan, 2:40 p.m.
Para poder hacer pruebas se debe de realizar cambios en recibos para dejarlos pagados y poder realizar la restitucion.

SELECT * FROM a2990700 WHERE num_poliza = '3354000019291' --> Cambiar algunos tip_situacion = CT;
SELECT * FROM a5029102_vcr WHERE num_poliza = '3354000019291' --> Cambiar algunos mca_proceso_vcr = N relacionarlos con la a2990700 por num_spto;

 a1009039_VCR-> impuesto brasil

coprcims3  CiM$tRon#0#0
