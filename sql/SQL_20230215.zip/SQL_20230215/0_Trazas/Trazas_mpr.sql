tron2000.trn_k_ptd.p_gen_comienzo_traza
tron2000.trn_k_ptd.p_gen_final_traza
t_trn_trn_r_dbg

-- Procedimiento que inserta las trazas en la tabla trazas_mpr
DC_P_TRAZAS_MPR

-- tabla donde est�n las dc_p_trazas_mpr ('afp', 'INICIO' || NULL);
SELECT * FROM trazas_msv WHERE cod_traza = 'reuy';


select * from trazas_mpr;

--ejemplo de llamado a trazas_mpr
DC_K_AP10091332_VCR
    dc_p_trazas_mpr('cag',' p_num_secu_k-->' || p_num_secu_k); 
    dc_p_trazas_mpr('cag',' l_cod_docum-->' || l_cod_docum);
    dc_p_trazas_mpr('cag',' tip_classificacao_corretor-->' || l_reg32.tip_classificacao_corretor);           



-- procedimiento dc_p_trazas_mpr
CREATE OR REPLACE PROCEDURE TRON2000.DC_P_TRAZAS_MPR(p_cod_traza VARCHAR2, p_descripcion VARCHAR2)
IS
PRAGMA AUTONOMOUS_TRANSACTION;
V_TEXT VARCHAR2(500);
BEGIN
--
  INSERT INTO TRAZAS_MPR (id_traza, Cod_Traza, DESCRIPCION, FEC_TRAZA, Usr_Traza, SESSION_ID)
  VALUES (STRAZAS_MPR.NEXTVAL,
         p_cod_traza,
         p_descripcion,
         SYSDATE,
         sys_context('USERENV','OS_USER'),
         sys_context('USERENV','SESSIONID')
  );
--
  COMMIT; -- Este commit solo afecta a la transaccion autonoma
EXCEPTION
          WHEN OTHERS THEN
            NULL;
END;
