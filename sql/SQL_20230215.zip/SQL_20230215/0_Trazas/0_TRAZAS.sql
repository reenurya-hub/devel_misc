-- brasil
select * from tron2000.trazas_mpr;
tron2000.dc_p_trazas_mpr;
--
DELETE FROM  TRAZAS_MPR where cod_traza = 'reuy';
COMMIT;
select * from TRAZAS_MPR where cod_traza = 'reuy' ORDER BY ID_TRAZA;



-- inserta trazas
dc_p_trazas_mpr('reuy','em_k_ld_com_trn: '|| $$PLSQL_LINE || ' g_reg_p2000253.num_poliza : '|| g_reg_p2000253.num_poliza);

-- TRAZAS SALVADOR
-- recupera trazas
DELETE FROM  TRAZAS_MSV where cod_traza = 'reuy';
COMMIT;
select * from TRAZAS_MSV where cod_traza = 'reuy' ORDER BY ID_TRAZA;
-- ejemplo trazas
tron2000.dc_p_trazas_msv('reuy','em_k_ld_com_trn: '|| $$PLSQL_LINE || ' g_reg_p2000253.num_poliza : '|| g_reg_p2000253.num_poliza);

--TRAZAS GUATEMALA
-- recupera trazas
DELETE FROM  TRAZAS_MPR where cod_traza = 'reuy';
COMMIT;
select * from TRAZAS_MPR where cod_traza = 'reuy' ORDER BY ID_TRAZA;
-- ejemplo trazas
dc_p_trazas_mpr('reuy','em_k_ld_com_trn: '|| $$PLSQL_LINE || ' g_reg_p2000253.num_poliza : '|| g_reg_p2000253.num_poliza);
dc_p_trazas_mpr('reuy','em_k_ld_com_trn: '|| $$PLSQL_LINE || ' g_reg_p2000253.num_poliza : ' ||g_reg_p2000253.num_poliza || dbms_utility.format_call_stack);

--para recuperar la linea
$$PLSQL_LINE
--PARA BOOLEANOS: 
sys.diutil.bool_to_int(bool)

--ejemplo trigger
 CREATE OR REPLACE TRIGGER TMP_A2000253  BEFORE INSERT OR UPDATE ON A2000253 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      dc_p_trazas_mpr('reuy','insert a2000253 num_poliza : '|| :new.num_poliza || ' cod_agt: ' || :new.cod_agt || ' pct_comis: ' || :new.pct_comis || dbms_utility.format_call_stack );
    END IF;
    IF UPDATING THEN
      dc_p_trazas_mpr('reuy','update a2000253 num_poliza : '|| :new.num_poliza || ' cod_agt: ' || :new.cod_agt || ' pct_comis: ' || :new.pct_comis || ' old pct_comis: ' || :old.pct_comis || dbms_utility.format_call_stack );
    END IF;
  END;
  
-- trigger con if dentro del updating
 CREATE OR REPLACE TRIGGER TMP_A2000161  BEFORE INSERT OR UPDATE ON A2000161 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      IF :new.cod_eco in(1,4,21) THEN
         dc_p_trazas_mpr('reuy','insert a2000161 num_poliza : '|| :new.num_poliza 
         || ' cod_eco: ' || :new.cod_eco || ' imp_eco: ' || :new.imp_eco || dbms_utility.format_call_stack );
      END IF;
    END IF;
    IF UPDATING THEN
      IF :new.cod_eco in(1,4,21) THEN
         dc_p_trazas_mpr('reuy','update a2000161 num_poliza : '|| :new.num_poliza 
         || ' cod_eco: ' || :new.cod_eco || ' imp_eco: ' || :new.imp_eco || ' old imp_eco: ' || :old.imp_eco || dbms_utility.format_call_stack );
      END IF;
    END IF;
  END;



BEGIN
--
  INSERT INTO TRAZAS_MPR (id_traza, Cod_Traza, DESCRIPCION, FEC_TRAZA, Usr_Traza, SESSION_ID)
  VALUES (STRAZAS_MPR.NEXTVAL,
         p_cod_traza,
         p_descripcion,
         SYSDATE,
         sys_context('USERENV','OS_USER'),
         sys_context('USERENV','SESSIONID')
  );
--
  COMMIT; -- Este commit solo afecta a la transaccion autonoma
EXCEPTION
          WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE( 'trazas_mpr: '||SQLERRM );
            NULL;
END;
