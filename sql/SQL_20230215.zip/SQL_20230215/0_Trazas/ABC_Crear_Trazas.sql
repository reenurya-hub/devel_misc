-- CREAR TRAZAS
drop table TRON2000.tmp_traz;

create table TRON2000.tmp_traz
(
  cod_traza   VARCHAR2(100),
  descripcion VARCHAR2(500)
);

grant select, insert, update, delete on TRON2000.tmp_traz to ROL_TRON2000_APP, NWT_IL, ANALISTAS,USUARIOS,TRP_XX_DL;

select * from TRON2000.tmp_traz;

delete from TRON2000.tmp_traz;
commit;
