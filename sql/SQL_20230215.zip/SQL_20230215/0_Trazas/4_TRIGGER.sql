/********************************** TRONWEB ****************************/

CREATE OR REPLACE TRIGGER TRON2000.TMP_TRG_A2990700  BEFORE INSERT ON A2990700 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      tron2000.tmp_p_ejecuta_traza('INSERT A2990700', ' NUM_RECIBO: ' || :new.num_recibo || ' new.fec_efec_recibo: ' || :new.fec_efec_recibo || ' new.fec_vcto_recibo: ' ||  :new.fec_vcto_recibo || ' new.fec_emision_spto: ' || :new.fec_emision_spto || ' new.fec_vcto_pago: ' || :new.fec_vcto_pago || dbms_utility.format_call_stack);
    END IF;
    IF UPDATING THEN
      tron2000.tmp_p_ejecuta_traza('UPDATE A2990700', ' NUM_RECIBO: ' || :new.num_recibo || ' new.fec_efec_recibo: ' || :new.fec_efec_recibo || ' OLD.fec_efec_recibo: ' || :old.fec_efec_recibo || ' new.fec_vcto_recibo: ' ||  :new.fec_vcto_recibo || ' old.fec_vcto_recibo: ' ||  :old.fec_vcto_recibo || ' new.fec_emision_spto: ' || :new.fec_emision_spto || ' old.fec_emision_spto: ' || :old.fec_emision_spto || ' new.fec_vcto_pago: ' || :new.fec_vcto_pago || ' old.fec_vcto_pago: ' || :old.fec_vcto_pago || dbms_utility.format_call_stack);
    END IF;
  END;


/********************************** IAXIS ****************************/
select * from seguros where npoliza = 3100020123  and ncertif = 0 and csituac = 0;
select * from seguros where npoliza = 3100020122  and csituac = 0;
select * from detmovsegurocol where sseguro_0 = 1504186;
select * from int_carga_generico where proceso = 5;
select * from recibos where sseguro = 1504186 order by nmovimi desc;
select * from detrecibos where nrecibo =175358408;
select * from MOVSEGURO where sseguro = 1503942 order by nmovimi desc;
P_CONTROL_ERROR('39788', 1, 'INSERT vdetrecibos nrecibo: ' || :new.nrecibo || ' NEW.icombru: ' || :new.icombru || dbms_utility.format_call_stack);
P_CONTROL_ERROR('133383', 1, $$PLSQL_LINE || ' PAC_MD_CFG.F_SKIP_FORM_WIZARD pcidcfg: ' || pcidcfg);
select * from detmovsegurocol where sseguro_0 = 501004 and sseguro_cert = 546519;
select * from seguros where npoliza = 3100020137 and ncertif = 0;
  -- Buscar las trazas que genera el trigger por fecha, por ID y por SEQERROR
  select max(SEQERROR) from axis.control_error;
  --
  SELECT *
    FROM AXIS.CONTROL_ERROR 
   WHERE 1=1
   AND ID  LIKE '%131116%'
   --OR ID LIKE '%37681_1110%'
     AND TRUNC(FECHA) = TO_DATE('30/07/2021', 'DD/MM/RR')
     --AND SUCESO LIKE '%UPDATE MOVSEGURO SSEGURO: 1470847%'
     --and suceso like '%vtablamortal%'
     --AND SEQERROR BETWEEN 23493000 AND 234943657
    AND SEQERROR > 247176081
     --AND DONDE = '4_f1_dias'
   ORDER BY SEQERROR desC;
   
   
   234714679 EMPIEZA
  -- Borrar trazas del trigger
  DELETE FROM AXIS.CONTROL_ERROR WHERE ID LIKE '%130063%' AND TRUNC(FECHA) = TO_DATE('/07/2021', 'DD/MM/RR');  COMMIT;
--  38819 PRUEBA PARA PERIODICIDAD SEMESTRAL DEL 39819
SELECT * FROM axis.SEGUROS WHERE NPOLIZA = 3100020290  and ncertif = 0;
SELECT * FROM RIESGOS WHERE SPERSON IS NOT NULL;
SELECT * FROM MOVSEGURO;

select * from liquidalin;
  CREATE OR REPLACE TRIGGER TMP_LIQUIDALIN_131114  BEFORE INSERT ON LIQUIDALIN FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      P_CONTROL_ERROR('131114', 1, 'INSERT LIQUIDALIN NRECIBO: ' || :new.nrecibo || ' new.nliqmen: ' || :new.nliqmen || ' new.smovrec: ' ||  :new.smovrec || ' new.icomisi: ' || :new.icomisi || ' new.iprinet: ' || :new.iprinet || dbms_utility.format_call_stack);
    END IF;
    IF UPDATING THEN
      P_CONTROL_ERROR('131114', 1, 'UPDATE LIQUIDALIN NRECIBO: ' || :new.nrecibo || ' new.nliqmen: ' || :new.nliqmen || ' new.smovrec: ' ||  :new.smovrec || ' new.icomisi: ' || :new.icomisi ||  ' old.icomisi: ' || :old.icomisi || ' new.iprinet: ' || :new.iprinet || dbms_utility.format_call_stack);
    END IF;
  END;


select * from liquidaCAB;
  CREATE OR REPLACE TRIGGER TMP_LIQUIDACAB_131114  BEFORE INSERT ON LIQUIDACAB FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      P_CONTROL_ERROR('131114', 1, 'INSERT LIQUIDACAB CAGENTE: ' || :new.CAGENTE || ' new.nliqmen: ' || :new.nliqmen || ' new.sproliq: ' ||  :new.sproliq || dbms_utility.format_call_stack);
    END IF;
    IF UPDATING THEN
      P_CONTROL_ERROR('131114', 1, 'UPDATE LIQUIDACAB CAGENTE: ' || :new.CAGENTE || ' new.nliqmen: ' || :new.nliqmen || ' new.sproliq: ' ||  :new.sproliq || dbms_utility.format_call_stack);
    END IF;
  END;


select * from ctactes;
  CREATE OR REPLACE TRIGGER TMP_CTACTES_131114  BEFORE INSERT ON CTACTES FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      P_CONTROL_ERROR('131114', 1, 'INSERT CTACTES CAGENTE: ' || :new.CAGENTE || ' new.nnumlin: ' || :new.nnumlin || ' new.iimport: ' ||  :new.iimport ||  ' new.sproces: ' ||  :new.sproces ||dbms_utility.format_call_stack);
    END IF;
    IF UPDATING THEN
      P_CONTROL_ERROR('131114', 1, 'UPDATE CTACTES CAGENTE: ' || :new.CAGENTE || ' new.nnumlin: ' || :new.nnumlin || ' new.iimport: ' ||  :new.iimport ||  ' new.sproces: ' ||  :new.sproces || dbms_utility.format_call_stack);
    END IF;
  END;


select * from MOVSEGURO;
  CREATE OR REPLACE TRIGGER tmp_MOVSEGURO_130063  BEFORE UPDATE ON MOVSEGURO FOR EACH ROW
  BEGIN
  if UPDAting then
    P_CONTROL_ERROR('130063', 1, 'UPDATE MOVSEGURO SSEGURO: ' || :new.SSEGURO || ' NEW.CMOTMOV: ' || :new.CMOTMOV  ||  ' NEW.CMOVSEG: ' ||  :NEW.CMOVSEG ||  ' OLD.CMOVSEG: ' ||  :OLD.CMOVSEG || ' NEW.FEFECTO: ' || :NEW.FEFECTO || dbms_utility.format_call_stack);
  END IF;
  END;

select * from MOVRECIBO;
  CREATE OR REPLACE TRIGGER tmp_MOVRECIBO_130063  BEFORE UPDATE ON MOVRECIBO FOR EACH ROW
  BEGIN
  if UPDAting then
    P_CONTROL_ERROR('130063', 1, 'UPDATE MOVRECIBO NRECIBO: ' || :new.NRECIBO || ' NEW.CESTREC: ' || :new.CESTREC  ||  ' OLD.CESTREC: ' || :OLD.CESTREC  || dbms_utility.format_call_stack);
  END IF;
  END;



select * from MOVSEGURO;
  CREATE OR REPLACE TRIGGER tmp_MOVSEGURO_40467_i  BEFORE INSERT ON MOVSEGURO FOR EACH ROW
  BEGIN
  if INSERting then
    P_CONTROL_ERROR('40467', 1, 'INSERT MOVSEGURO SSEGURO: ' || :new.SSEGURO || ' NEW.FEFECTO: ' || :new.FEFECTO || ' NEW.NMOVIMI: ' ||  :NEW.NMOVIMI || dbms_utility.format_call_stack);
  end if;
  if UPDAting then
    P_CONTROL_ERROR('40467', 1, 'UPDATE MOVSEGURO SSEGURO: ' || :new.SSEGURO || ' NEW.FEFECTO: ' || :new.FEFECTO || ' NEW.NMOVIMI: ' ||  :NEW.NMOVIMI || dbms_utility.format_call_stack);
  END IF;
  END;
/



select * from recibos;
  CREATE OR REPLACE TRIGGER tmp_recibos_40467_i  BEFORE INSERT ON RECIBOS FOR EACH ROW
  BEGIN
  if INSERting then
    P_CONTROL_ERROR('40467', 1, 'INSERT RECIBOS nrecibo: ' || :new.nrecibo || ' NEW.sseguro: ' || :new.sseguro || ' NEW.FEFECTO: ' ||  :NEW.FEFECTO  || ' NEW.ctiprec: ' || :new.ctiprec || dbms_utility.format_call_stack);
  end if;
  if UPDAting then
    P_CONTROL_ERROR('40467', 1, 'UPDATE RECIBOS nrecibo: ' || :new.nrecibo || ' NEW.sseguro: ' || :new.sseguro || ' NEW.FEFECTO: ' ||  :NEW.FEFECTO  ||' NEW.ctiprec: ' || :new.ctiprec || dbms_utility.format_call_stack);
  END IF;
  END;




select * from contab_asient_interf;
  CREATE OR REPLACE TRIGGER t_contab_asient_interf  BEFORE INSERT OR UPDATE ON contab_asient_interf FOR EACH ROW
  BEGIN
    if INSERting then
         P_CONTROL_ERROR('CMREN', 1, 'INSERT contab_asient_interf sinterf: ' || :new.sinterf || ' NEW.idpago: ' || :new.idpago || dbms_utility.format_call_stack);
    end if;
    if UPDAting then
         P_CONTROL_ERROR('CMREN', 1, 'UPDATE contab_asient_interf sinterf: ' || :new.sinterf || ' NEW.idpago: ' || :new.idpago || dbms_utility.format_call_stack);
    end if;
  END;


select * from recibos;
  CREATE OR REPLACE TRIGGER tmp_recibos_40082_i  BEFORE INSERT ON RECIBOS FOR EACH ROW
  BEGIN
    P_CONTROL_ERROR('40082', 1, 'INSERT RECIBOS nrecibo: ' || :new.nrecibo || ' NEW.sseguro: ' || :new.sseguro || ' NEW.ctiprec: ' || :new.ctiprec || dbms_utility.format_call_stack);
  END;

  CREATE OR REPLACE TRIGGER tmp_recibos_40082_u  BEFORE UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    P_CONTROL_ERROR('40082', 1, 'UPDATE RECIBOS nrecibo: ' || :new.nrecibo || ' NEW.sseguro: ' || :new.sseguro || ' NEW.ctiprec: ' || :new.ctiprec || dbms_utility.format_call_stack);
  END;

select * from detrecibos;
  CREATE OR REPLACE TRIGGER tmp_detrecibos_131116_i  BEFORE INSERT OR UPDATE ON DETRECIBOS FOR EACH ROW
  BEGIN
    IF INSERTING THEN
      IF :new.cconcep = 11 THEN
        P_CONTROL_ERROR('131116', 1, 'INSERT DETRECIBOS nrecibo: ' || :new.nrecibo || ' NEW.iconcep: ' || :new.iconcep || dbms_utility.format_call_stack);
      END IF;
    END IF;
    IF UPDATING THEN
      IF :new.cconcep = 11 THEN
        P_CONTROL_ERROR('131116', 1, 'UPDATE DETRECIBOS nrecibo: ' || :new.nrecibo || ' NEW.iconcep: ' || :new.iconcep || dbms_utility.format_call_stack);
      END IF;
    END IF;
  END;

  CREATE OR REPLACE TRIGGER tmp_detrecibos_40082_u  BEFORE UPDATE ON DETRECIBOS FOR EACH ROW
  BEGIN
    if :new.cconcep = 0 then
    P_CONTROL_ERROR('40082', 1, 'UPDATE DETRECIBOS nrecibo: ' || :new.nrecibo || ' NEW.iconcep: ' || :new.iconcep || dbms_utility.format_call_stack);
    end if;
  END;





select * from vdetrecibos;
  CREATE OR REPLACE TRIGGER tmp_vdetrecibos_39788  BEFORE INSERT OR UPDATE ON vdetrecibos FOR EACH ROW
  BEGIN
    if INSERting then
         P_CONTROL_ERROR('39788', 1, 'INSERT vdetrecibos nrecibo: ' || :new.nrecibo || ' NEW.icombru: ' || :new.icombru || dbms_utility.format_call_stack);
    end if;
    if UPDAting then
         P_CONTROL_ERROR('39788', 1, 'UPDATE vdetrecibos nrecibo: ' || :new.nrecibo || ' NEW.icombru: ' || :new.icombru || ' old.icombru: ' || :old.icombru || dbms_utility.format_call_stack);
    end if;
  END;




select * from detrecibos;
  CREATE OR REPLACE TRIGGER tmp_detrecibos_39819  BEFORE INSERT OR UPDATE ON detrecibos FOR EACH ROW
  BEGIN
    if INSERting then
         P_CONTROL_ERROR('39819', 1, 'INSERT detrecibos nrecibo: ' || :new.nrecibo || ' NEW.cconcep: ' || :new.cconcep || ' new.iconcep: ' || :new.iconcep || dbms_utility.format_call_stack);
    end if;
    if UPDAting then
         P_CONTROL_ERROR('39819', 1, 'UPDATE detrecibos nrecibo: ' || :new.nrecibo || ' NEW.cconcep: ' || :new.cconcep || ' new.iconcep: ' || :new.iconcep || dbms_utility.format_call_stack);
    end if;
  END;


  CREATE OR REPLACE TRIGGER tmp_MOVSEGURO_37659  BEFORE INSERT OR UPDATE ON MOVSEGURO FOR EACH ROW
  BEGIN
    if INSERting then
         P_CONTROL_ERROR('37659', 1, 'INSERT MOVSEGURO sseguro: ' || :new.sseguro || ' NEW.FEFECTO: ' || :new.FEFECTO || dbms_utility.format_call_stack);
    end if;
    if UPDAting then
         P_CONTROL_ERROR('37659', 1, 'UPDATE riesgos sseguro: ' || :new.sseguro || ' NEW.FEFECTO: ' || :new.FEFECTO || ' OLD.FEFECTO: ' || :OLD.FEFECTO ||  dbms_utility.format_call_stack);
    end if;
  END;


  CREATE OR REPLACE TRIGGER tmp_riesgos_38819  BEFORE INSERT OR UPDATE ON riesgos FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('38819', 1, 'UPDATE riesgos sseguro: ' || :new.sseguro || ' NEW.tnatrie: ' || :new.tnatrie || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('38819', 1, 'INSERT riesgos sseguro: ' || :new.sseguro || ' NEW.tnatrie: ' || :new.tnatrie ||  dbms_utility.format_call_stack);
    end if;
  END;



  CREATE OR REPLACE TRIGGER tmp_seguros_38819  BEFORE INSERT OR UPDATE ON seguros FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('38819', 1, 'UPDATE seguros sseguro: ' || :new.sseguro || ' NEW.fcarpro: ' || :new.fcarpro || ' old.fcarpro: ' || :old.fcarpro || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('38819', 1, 'INSERT seguros sseguro: ' || :new.sseguro || ' NEW.fcarpro: ' || :new.fcarpro ||  dbms_utility.format_call_stack);
    end if;
  END;



"INSERT demovseguro sseguro: 1504186 NEW.nmovimi: 14 tvalord: 21;----- PL/SQL Call Stack -----
  object      line  object
  handle    number  name
8000000436bc6080         2  AXIS.TMP_DETMOVSEGURO_I
30000003f36a0c40     11473  package body AXIS.PAC_POS_CARGUE.PR_PROCESA_CARGUE_POS
10000003d787ebc0         1  anonymous block
"
"INSERT recibos sseguro: 1504186 nrecibo: 175358748 NEW.ctiprec: 13----- PL/SQL Call Stack -----
  object      line  object
  handle    number  name
d00000041ba23e80         6  AXIS.TMP_RECIBOS
1000000409505e40       992  function AXIS.F_INSRECIBO
30000003f36a0c40     13743  package body AXIS.PAC_POS_CARGUE.F_AGRUPARECIBO_POS
30000003f36a0c40     11218  package body AXIS.PAC_POS_CARGUE.PR_PROCESA_CARGUE_POS
10000003d787ebc0         1  anonymous block
"

"INSERT demovseguro sseguro: 1504186 NEW.nmovimi: 13 tvalord: 21 - ----- PL/SQL Call Stack -----
  object      line  object
  handle    number  name
8000000436bc6080         2  AXIS.TMP_DETMOVSEGURO_I
30000003f36a0c40     10978  package body AXIS.PAC_POS_CARGUE.PR_PROCESA_CARGUE_POS
10000003d787ebc0         1  anonymous block
"

select * from detrecibos;
  CREATE OR REPLACE TRIGGER tmp_detrecibos_i  BEFORE INSERT ON detrecibos FOR EACH ROW
  BEGIN
    if inserting then
         P_CONTROL_ERROR('37659', 1, 'INSERT detrecibos nrecibo: ' || :new.nrecibo || ' NEW.cconcep: ' || :new.cconcep ||  dbms_utility.format_call_stack);
    end if;
  END;



select * from detmovsegurocol;
CREATE OR REPLACE TRIGGER tmp_detmovsegurocol_i  BEFORE INSERT ON detmovsegurocol FOR EACH ROW
  BEGIN
         P_CONTROL_ERROR('37659', 1, 'INSERT detmovsegurocol sseguro_0: ' || :new.sseguro_0 || ' NEW.nmovimi_0: ' || :new.nmovimi_0 || ' new.sseguro_cert: ' || :new.sseguro_cert||  dbms_utility.format_call_stack);
  END;

CREATE OR REPLACE TRIGGER tmp_detmovsegurocol_u  BEFORE UPDATE ON detmovsegurocol FOR EACH ROW
  BEGIN
         P_CONTROL_ERROR('37659', 1, 'UPDATE detmovsegurocol sseguro_0: ' || :new.sseguro_0 || ' NEW.nmovimi_0: ' || :new.nmovimi_0 || ' new.sseguro_cert: ' || :new.sseguro_cert || dbms_utility.format_call_stack);
  END;


select * from movseguro;
CREATE OR REPLACE TRIGGER tmp_movseguro_i  BEFORE INSERT ON movseguro FOR EACH ROW
  BEGIN
         P_CONTROL_ERROR('37659', 1, 'INSERT movseguro sseguro: ' || :new.sseguro || ' NEW.nmovimi: ' || :new.nmovimi ||  dbms_utility.format_call_stack);
  END;

CREATE OR REPLACE TRIGGER tmp_movseguro_u  BEFORE UPDATE ON movseguro FOR EACH ROW
  BEGIN
         P_CONTROL_ERROR('37659', 1, 'UPDATE movseguro sseguro: ' || :new.sseguro || ' NEW.nmovimi: ' || :new.nmovimi || ' new.cmotmov: ' || :new.cmotmov || dbms_utility.format_call_stack);
  END;

select * from detmovseguro;
CREATE OR REPLACE TRIGGER tmp_detmovseguro_i  BEFORE INSERT ON detmovseguro FOR EACH ROW
  BEGIN
         P_CONTROL_ERROR('37659', 1, 'INSERT demovseguro sseguro: ' || :new.sseguro || ' NEW.nmovimi: ' || :new.nmovimi || ' tvalord: ' || :new.tvalord || dbms_utility.format_call_stack);
  END;

CREATE OR REPLACE TRIGGER tmp_detmovseguro_u  BEFORE UPDATE ON detmovseguro FOR EACH ROW
  BEGIN
         P_CONTROL_ERROR('37659', 1, 'UPDATE detmovseguro sseguro: ' || :new.sseguro || ' NEW.nmovimi: ' || :new.nmovimi || ' new.cmotmov: ' || :new.cmotmov ||  ' tvalord: ' || :new.tvalord || dbms_utility.format_call_stack);
  END;

CREATE OR REPLACE TRIGGER tmp_detmovseguro_d  BEFORE DELETE ON detmovseguro FOR EACH ROW
  BEGIN
         P_CONTROL_ERROR('37659', 1, 'DELETE detmovseguro sseguro: ' || :new.sseguro || ' NEW.nmovimi: ' || :new.nmovimi || ' new.cmotmov: ' || :new.cmotmov ||  ' tvalord: ' || :new.tvalord || dbms_utility.format_call_stack);
  END;


  CREATE OR REPLACE TRIGGER tmp_recibos  BEFORE INSERT OR UPDATE ON recibos FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37659', 1, 'UPDATE recibos nrecibo: ' || :new.nrecibo || ' NEW.sseguro: ' || :new.sseguro || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37659', 1, 'INSERT recibos sseguro: ' || :new.sseguro || ' nrecibo: ' || :new.nrecibo || ' NEW.ctiprec: ' || :new.ctiprec ||  dbms_utility.format_call_stack);
    end if;
  END;






P_CONTROL_ERROR('36831', 1,' v_coacedido: ' || v_coacedido);
P_CONTROL_ERROR('36941', 1,:new.cpregun || ' *** ' || dbms_utility.format_call_stack);

--p_control_error('37785_12630',1,'PK_SUPLEMENTOS psseguro: ' || psseguro || ' pcmodo: ' ||  pcmodo);
-- ALTER SESSION SET CURRENT_SCHEMA = AXIS; 
  
  select * from control_error
  
  select * from axis.tmp_control_error;
  
  select * from axis.prueba1 order by tiempo desc;

delete from tmp_control_error;

select * from tmp_control_error;

CREATE TABLE "AXIS"."TMP_CONTROL_ERROR" (
  "FECHA"      DATE,
  "ID"         VARCHAR2(30 BYTE),
  "DONDE"      VARCHAR2(60 BYTE),
  "SUCESO"     CLOB,
  "SEQERROR"   NUMBER);
  
FECHA,ID,DONDE,SUCESO
  "SEQERROR"   NUMBER
  
  P_TMP_CONTROL_ERROR('1','PAC_MD_PRODUCCION.F_CONSULTAPOLIZA', TO_CLOB(SQUERY));
create or replace PROCEDURE          "P_TMP_CONTROL_ERROR" (
   pid       IN   VARCHAR2,
   pdonde    IN   VARCHAR2,
   psuceso   IN   CLOB
)
AS
/* - procedimiento que controla los erorres
                         producidos */
   PRAGMA autonomous_transaction;

   v_seq   NUMBER;
BEGIN

      SELECT seqerror.NEXTVAL
        INTO v_seq
        FROM dual;

--truncate table tmp_control_error;

--select * from tmp_control_error;
   INSERT INTO TMP_CONTROL_ERROR
               (seqerror, fecha, id, donde, suceso)
        VALUES (v_seq, F_Sysdate, pid, pdonde, psuceso);
   COMMIT;
END;
  
  "begin
   select count(1)
     into :mi_cambio
     from (select g.cpregun, g.crespue, g.nriesgo, g.cgarant
             from pregungaranseg g, seguros s
            where g.sseguro = 1492171
              and s.sseguro = g.sseguro
              and nvl (f_pargaranpro_v (s.cramo, s.cmodali, s.ctipseg, s.ccolect, s.cactivi, g.cgarant, upper ('tipo')), 0) not in (4, 5)
              and g.cpregun <> 1002
              and g.nmovimi = (select max(p.nmovimi)
                               from pregunseg p
                              where p.sseguro = 1492171)
              and g.nriesgo in(select r.nriesgo
                               from riesgos r
                              where r.sseguro = 1492171
                                and r.fanulac is null)
              and g.nriesgo in(select er.nriesgo
                               from estriesgos er
                              where er.sseguro = 1102503
                                and er.fanulac is null)
           minus
           select g.cpregun, g.crespue, g.nriesgo, g.cgarant
             from estpregungaranseg g, estseguros s
            where g.sseguro = 1102503
              and g.nmovimi = 3
              and s.sseguro = g.sseguro
              and nvl (f_pargaranpro_v (s.cramo, s.cmodali, s.ctipseg, s.ccolect, s.cactivi, g.cgarant, upper ('tipo')), 0) not in (4, 5)
              and g.cpregun <> 1002
              and g.nriesgo in(select r.nriesgo
                               from riesgos r
                              where r.sseguro = 1492171
                                and r.fanulac is null)
              and g.nriesgo in(select er.nriesgo
                               from estriesgos er
                              where er.sseguro = 1102503
                                and er.fanulac is null)); end;"
  
  select *--count(1)
     --into :mi_cambio
     from (select g.cpregun, g.crespue, g.nriesgo, g.cgarant
             from pregungaranseg g, seguros s
            where g.sseguro = 1492171
              and s.sseguro = g.sseguro
              and nvl (f_pargaranpro_v (s.cramo, s.cmodali, s.ctipseg, s.ccolect, s.cactivi, g.cgarant, upper ('tipo')), 0) not in (4, 5)
              and g.cpregun <> 1002
              and g.nmovimi = (select max(p.nmovimi)
                               from pregunseg p
                              where p.sseguro = 1492171)
              and g.nriesgo in(select r.nriesgo
                               from riesgos r
                              where r.sseguro = 1492171
                                and r.fanulac is null)
              and g.nriesgo in(select er.nriesgo
                               from estriesgos er
                              where er.sseguro = 1102503
                                and er.fanulac is null)
           minus
           select g.cpregun, g.crespue, g.nriesgo, g.cgarant
             from estpregungaranseg g, estseguros s
            where g.sseguro = 1102503
              and g.nmovimi = 3
              and s.sseguro = g.sseguro
              and nvl (f_pargaranpro_v (s.cramo, s.cmodali, s.ctipseg, s.ccolect, s.cactivi, g.cgarant, upper ('tipo')), 0) not in (4, 5)
              and g.cpregun <> 1002
              and g.nriesgo in(select r.nriesgo
                               from riesgos r
                              where r.sseguro = 1492171
                                and r.fanulac is null)
              and g.nriesgo in(select er.nriesgo
                               from estriesgos er
                              where er.sseguro = 1102503
                                and er.fanulac is null));
  
  
  select * from movseguro where sseguro in (select sseguro from seguros where npoliza = 3100019519 and ncertif = 0);
  
  
  truncate table prueba1;
  --
  SELECT * 
  FROM AXIS.INT_CONTROL_ERRORES 
  WHERE TRUNC(fecha) = TO_DATE('24/11/20','dd/mm/rr')
  ORDER BY SERROR DESC;
  AND t_error LIKE '%3100019470%';
  --
  SELECT * 
  FROM log_consultas 
  WHERE TLLAMADA = 'pac_anulacion.f_recibos' 
  AND TRUNC(FCONSULTA) = TO_DATE('13/11/2020','DD/MM/RR') 
  ORDER BY SLOGCONSUL DESC;
--  
  -- Buscar las trazas que genera el trigger por fecha, por ID y por SEQERROR
  SELECT * 
    FROM AXIS.TMP_CONTROL_ERROR 
   WHERE 1=1
     AND ID  LIKE '%37658%'
     --and suceso like '%9937%'
     AND TRUNC(FECHA) = TO_DATE('26/10/2020', 'DD/MM/RR')
     --AND SUCESO LIKE '%pac_anulacion%'
     --AND SEQERROR BETWEEN 2938433759 AND 2938433761
   ORDER BY SEQERROR DESC
--
  -- Borrar trazas del trigger
  DELETE FROM AXIS.CONTROL_ERROR WHERE ID LIKE '%35901%';
  COMMIT;

/* ******************CREATE OR REPLACE TRIGGER TMP_RECIBOS38586 BEFORE INSERT OR UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('38586', 1, 'UPDATE RECIBOS nrecibo: '  || :new.nrecibo  || ' new.ctiprec: '  || :new.ctiprec || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('38586', 1, 'INSERT RECIBOS nrecibo: '  || :new.nrecibo  || ' new.ctiprec: '  || :new.ctiprec || dbms_utility.format_call_stack);
    end if;
  END; TRIGGERS PARA GENERAR TRAZAS EN TABLAS ****************** */
  

--
  SELECT * 
    FROM AXIS.CONTROL_ERROR 
   WHERE 1=1
     AND ID    = '37166' 

--
  --
  SELECT * 
    FROM AXIS.TMP_CONTROL_ERROR 
   WHERE 1=1
     AND ID  LIKE '%36994%' --proceso_PAGARE  59738
     --and suceso like '%9937%'
     AND TRUNC(FECHA) = TO_DATE('16/09/2020', 'DD/MM/RR')
     --AND SUCESO LIKE '%8790%'
     --AND SEQERROR BETWEEN 2938433759 AND 2938433761
   ORDER BY SEQERROR DESC
--
  -- Borrar trazas del trigger
  DELETE FROM AXIS.TMP_CONTROL_ERROR
  WHERE ID LIKE '%36941%'; --proceso_PAGARE  59738
  COMMIT;
 CREAR LA TABLA TEMPORAL Y COLOCAR EL INSERT EN P_CONTROL_ERROR
drop table "AXIS"."TMP_CONTROL_ERROR"
CREATE TABLE "AXIS"."TMP_CONTROL_ERROR" (
  "FECHA"      DATE,
  "ID"         VARCHAR2(30 BYTE),
  "DONDE"      VARCHAR2(60 BYTE),
  "SUCESO"     clob,
  "SEQERROR"   NUMBER);
   INSERT INTO TMP_CONTROL_ERROR
               (seqerror, fecha, id, donde, suceso)
        VALUES (v_seq, F_Sysdate, pid, pdonde, psuceso);
   COMMIT;
--

SELECT * FROM per_contactos;
  CREATE OR REPLACE TRIGGER tmp_per_contactos_39999 BEFORE INSERT OR UPDATE ON per_contactos FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('39999', 1, 'UPDATE PER_CONTACTOS NEW.SPERSON: ' || :NEW.SPERSON || ' OLD.SPERSON: ' || :old.sperson || ' NEW.TVALCON: ' || :NEW.TVALCON || ' OLD.TVALCON: ' || :OLD.TVALCON || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('39999', 1, 'INSERT PER_CONTACTOS NEW.SPERSON: ' || :NEW.SPERSON || ' NEW.TVALCON: ' || :NEW.TVALCON || dbms_utility.format_call_stack);
    end if;
  END;



select * from tomadores;

  CREATE OR REPLACE TRIGGER tmp_tomadores BEFORE INSERT OR UPDATE ON tomadores FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37175', 1, 'UPDATE tomadores SPERSON: ' || :new.SPERSON || ' NEW.sseguro: ' || :new.sseguro || ' NEW.sseguro: ' || :new.sseguro ||' NEW.cdomici: ' || :new.cdomici || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37175', 1, 'INSERT tomadores  SPERSON: ' || :new.SPERSON || ' NEW.sseguro: ' || :new.sseguro || ' NEW.sseguro: ' || :new.sseguro ||' NEW.cdomici: ' || :new.cdomici ||  dbms_utility.format_call_stack);
    end if;
  END;



  CREATE OR REPLACE TRIGGER tmp_per_contactos BEFORE INSERT OR UPDATE ON per_contactos FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37175', 1, 'UPDATE per_contactos SPERSON: ' || :new.SPERSON || ' NEW.CTIPCON: ' || :new.CTIPCON || ' NEW.TVALCON: ' || :NEW.TVALCON || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37175', 1, 'INSERT per_CONTACTOS SPERSON: ' || :new.SPERSON || ' NEW.CTIPCON: ' || :new.CTIPCON || ' NEW.TVALCON: ' || :NEW.TVALCON || dbms_utility.format_call_stack);
    end if;
  END;



  CREATE OR REPLACE TRIGGER tmp_per_direcciones BEFORE INSERT OR UPDATE ON per_direcciones FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37175', 1, 'UPDATE per_direcciones SPERSON: ' || :new.SPERSON || ' NEW.CDOMICI: ' || :new.CDOMICI || ' NEW.TDOMICI: ' || :NEW.TDOMICI || ' OLD.TDOMICI: ' || :OLD.TDOMICI ||  ' NEW.CPOBLAC: ' || :NEW.CPOBLAC || ' OLD.CPOBLAC: ' || :OLD.CPOBLAC ||   ' NEW.CPROVIN: ' || :NEW.CPROVIN || ' OLD.CPROVIN: ' || :OLD.CPROVIN || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37175', 1, 'INSERT per_direcciones sperson: ' || :new.sperson || ' NEW.cdomici: ' || :new.cdomici || ' new.tdomici: ' || :new.tdomici || ' new.cpoblac: ' || :new.cpoblac || ' new.cprovin: ' || :new.cprovin || dbms_utility.format_call_stack);
    end if;
  END;


  CREATE OR REPLACE TRIGGER tmp_per_contacto BEFORE INSERT OR UPDATE ON per_direcciones FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37175', 1, 'UPDATE per_direcciones SPERSON: ' || :new.SPERSON || ' NEW.CDOMICI: ' || :new.CDOMICI || ' NEW.TDOMICI: ' || :NEW.TDOMICI || ' OLD.TDOMICI: ' || :OLD.TDOMICI ||  ' NEW.CPOBLAC: ' || :NEW.CPOBLAC || ' OLD.CPOBLAC: ' || :OLD.CPOBLAC ||   ' NEW.CPROVIN: ' || :NEW.CPROVIN || ' OLD.CPROVIN: ' || :OLD.CPROVIN || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37175', 1, 'INSERT per_direcciones sperson: ' || :new.sperson || ' NEW.cdomici: ' || :new.cdomici || ' new.tdomici: ' || :new.tdomici || ' new.cpoblac: ' || :new.cpoblac || ' new.cprovin: ' || :new.cprovin || dbms_utility.format_call_stack);
    end if;
  END;


-- 37681 37681 37681 37681

  CREATE OR REPLACE TRIGGER TMP_PER_CONTACTOSCP205 BEFORE INSERT OR UPDATE ON PER_CONTACTOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('CP205', 1, 'UPDATE PER_CONTACTOS SPERSON: '  || :new.sperson   || ' ctipcon: '  || :new.ctipcon || ' cmodcon: '  || :new.cmodcon || ' tvalcon: '  || :new.tvalcon || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('CP205', 1, 'INSERT PER_CONTACTOS SPERSON: '    || :new.SPERSON  || ' ctipcon: '  || :new.ctipcon || ' cmodcon: '  || :new.cmodcon || ' tvalcon: '  || :new.tvalcon || dbms_utility.format_call_stack);
    end if;
  END;
SELECT * FROM PER_DIRECCIONES;
  CREATE OR REPLACE TRIGGER TMP_PER_DIRECCIONESCP205 BEFORE INSERT OR UPDATE ON PER_DIRECCIONES FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('CP205', 1, 'UPDATE PER_DIRECCIONES SPERSON: '  || :new.sperson    || ' cdomici: '  || :new.cdomici || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('CP205', 1, 'INSERT PER_DIRECCIONES SPERSON: '    || :new.SPERSON  || ' cdomici: '  || :new.cdomici || dbms_utility.format_call_stack);
    end if;
  END;

SELECT * FROM RECIBOS;
  CREATE OR REPLACE TRIGGER TMP_RECIBOS38922 BEFORE INSERT OR UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('38992', 1, 'UPDATE RECIBOS SSEGURO: '  || :new.sseguro   || ' NRECIBO: '  || :new.nrecibo || ' ctiprec: '  || :new.ctiprec || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('38992', 1, 'INSERT RECIBOS SSEGURO: '  || :new.sseguro   || ' NRECIBO: '  || :new.nrecibo || ' ctiprec: '  || :new.ctiprec || dbms_utility.format_call_stack);
    end if;
  END;
SELECT * FROM detrecibos;
  CREATE OR REPLACE TRIGGER TMP_DETRECIBOS38922 BEFORE INSERT OR UPDATE ON DETRECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('38992', 1, 'UPDATE DETRECIBOS NRECIBO: '  || :new.nrecibo    || ' cconcep: '  || :new.cconcep || ' cgarant: ' || :new.cgarant || ' iconcep: ' || :new.iconcep || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('38992', 1, 'INSERT DETRECIBOS NRECIBO: '  || :new.nrecibo    || ' cconcep: '  || :new.cconcep || ' cgarant: ' || :new.cgarant || ' iconcep: ' || :new.iconcep || dbms_utility.format_call_stack);
    end if;
  END;





  CREATE OR REPLACE TRIGGER TMP_RECIBOS37681 BEFORE INSERT OR UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('37681', 1, 'UPDATE RECIBOS nrecibo: '  || :new.nrecibo || ' new.sseguro: '  || :new.sseguro || ' new.ctiprec: ' || :new.ctiprec || ' :new.fvencim: ' || :new.fvencim || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('37681', 1, 'INSERT RECIBOS nrecibo: ' || :new.nrecibo || ' new.sseguro: '  || :new.sseguro || ' new.ctiprec: ' || :new.ctiprec || ' :new.fvencim: ' || :new.fvencim || dbms_utility.format_call_stack);
    end if;
  END;


  CREATE OR REPLACE TRIGGER tmp_DETRECIBOS37681 BEFORE INSERT OR UPDATE ON DETRECIBOS FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37681', 1, 'UPDATE DETRECIBOS new.nrecibo: ' || :new.nrecibo || ' new.cgarant: ' || :new.cgarant || ' new.cconcep: ' || :new.cconcep || ' old.iconcep: ' || :old.iconcep || ' new.iconcep: ' || :new.iconcep || ' old.iconcep: ' || :old.iconcep || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37681', 1, 'INSERT DETRECIBOS new.nrecibo: ' || :new.nrecibo || ' new.cgarant: ' || :new.cgarant || ' new.cconcep: ' || :new.cconcep || ' old.iconcep: ' || :old.iconcep || ' new.iconcep: ' || :new.iconcep || ' old.iconcep: ' || :old.iconcep || dbms_utility.format_call_stack);
    end if;
  END;
  

  CREATE OR REPLACE TRIGGER tmp_VDETRECIBOS37681 BEFORE INSERT OR UPDATE ON VDETRECIBOS FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37681', 1, 'UPDATE VDETRECIBOS NRECIBO: ' || :new.NRECIBO || ' NEW.ITOTPRI: ' || :new.itotpri || ' old.itotpri: ' || :old.itotpri || ' old.itotalr: ' || :old.itotalr || ' new.itotalr: ' || :new.itotalr || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37681', 1, 'INSERT VDETRECIBOS  NRECIBO: ' || :new.NRECIBO || ' NEW.ITOTPRI: ' || :new.itotpri || ' old.itotpri: ' || :old.itotpri || ' old.itotalr: ' || :old.itotalr || ' new.itotalr: ' || :new.itotalr || dbms_utility.format_call_stack);
    end if;
  END;



  CREATE OR REPLACE TRIGGER tmp_37681 BEFORE INSERT OR UPDATE ON adm_recunif FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37681', 1, 'UPDATE adm_recunif NRECIBO: ' || :new.NRECIBO || ' NEW.NRECUNIF: ' || :new.nrecunif || ' old.nrecunif: ' || :old.nrecunif || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('37681', 1, 'INSERT adm_recunif  NRECIBO: ' || :new.NRECIBO || ' NEW.NRECUNIF: ' || :new.nrecunif || ' old.nrecunif: ' || :old.nrecunif || dbms_utility.format_call_stack);
    end if;
  END;
-- 37681 37681 37681 37681
  

  CREATE OR REPLACE TRIGGER tmp_GARANSEG38266 BEFORE INSERT OR UPDATE ON GARANSEG FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('38266', 1, 'UPDATE GARANSEG sseguro: ' || :new.sseguro || ' cgarant: ' || :new.cgarant || ' iprianu: ' || :new.iprianu ||  ' old.iprianu: ' || :old.iprianu || ' ipritar: ' || :new.ipritar || ' old.ipritar: ' || :old.ipritar || dbms_utility.format_call_stack);
    end if;
    if inserting then
         P_CONTROL_ERROR('38266', 1, 'INSERT GARANSEG sseguro: ' || :new.sseguro || ' cgarant: ' || :new.cgarant || ' iprianu: ' || :new.iprianu ||  ' old.iprianu: ' || :old.iprianu || ' ipritar: ' || :new.ipritar || ' old.ipritar: ' || :old.ipritar || dbms_utility.format_call_stack);
    end if;
  END;

SELECT * FROM ESTGARANSEG


  CREATE OR REPLACE TRIGGER TMPPDSESTSEGUROSUPL785 BEFORE INSERT OR UPDATE ON pds_estsegurosupl FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.cmotmov = 699 OR :new.cmotmov = 670 THEN
    IF updating then
         P_CONTROL_ERROR('37785', 1, 'UPDATE pds_estsegurosupl sseguro: '  || :new.sseguro || ' cmotmov: ' || :new.cmotmov || ' *** ' || dbms_utility.format_call_stack);
    END IF;
    IF inserting then
         P_CONTROL_ERROR('37785', 1, 'INSERT pds_estsegurosupl sseguro: '  || :new.sseguro || ' cmotmov: ' || :new.cmotmov || ' *** ' || dbms_utility.format_call_stack);
    END IF;
  END;

  CREATE OR REPLACE TRIGGER TMPVDETRECIBO37681 BEFORE INSERT OR UPDATE ON VDETRECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.cmotmov = 699 OR :new.cmotmov = 670 THEN
    IF updating then
         P_CONTROL_ERROR('37681', 1, 'UPDATE VDETRECIBOS nrecibo: '  || :new.NRECIBO || ' *** ' || dbms_utility.format_call_stack);
    END IF;
    IF inserting then
         P_CONTROL_ERROR('37681', 1, 'INSERT VDETRECIBOs nrecibo: '  || :new.NRECIBO || ' *** ' || dbms_utility.format_call_stack);
    END IF;
  END;



  CREATE OR REPLACE TRIGGER TMP_ESTDETMOVSEGURO37681 BEFORE INSERT OR UPDATE ON ESTDETMOVSEGURO FOR EACH ROW
  BEGIN
    IF updating then
         P_CONTROL_ERROR('37681', 1, 'UPDATE estdetmovseguro sseguro: '  || :new.sseguro || ' nmovimi: ' || :new.nmovimi || ' tvalora: ' || :new.tvalora || ' tvalord: ' || :new.tvalord || ' *** ' || dbms_utility.format_call_stack);
    END IF;
    IF inserting then
         P_CONTROL_ERROR('37681', 1, 'INSERT estdetmovseguro sseguro: '  || :new.sseguro || ' nmovimi: ' || :new.nmovimi ||  ' tvalora: ' || :new.tvalora || ' tvalord: ' || :new.tvalord || ' *** ' || dbms_utility.format_call_stack);
    END IF;
  END;


  CREATE OR REPLACE TRIGGER tmp_movrecibo37658 BEFORE INSERT OR UPDATE ON movRECIBO FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('37658', 1, 'UPDATE MOVRECIBOS NRECIBO: ' || :new.nrecibo || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('37658', 1, 'INSERT MOVRECIBOS NRECIBO: ' || :new.nrecibo  || dbms_utility.format_call_stack);
    end if;
  END;

  CREATE OR REPLACE TRIGGER tmp_pds_estsegurosupl38026 BEFORE INSERT OR UPDATE ON pds_estsegurosupl FOR EACH ROW
  BEGIN
    if updating then
         P_CONTROL_ERROR('38026', 1, 'UPDATE pds_estsegurosupl SSEGURO: ' || :new.sseguro ||  ' cmotmov: ' || :new.cmotmov ||  'old cmotmov: ' || :old.cmotmov || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('38026', 1, 'INSERT pds_estsegurosupl sseguro: ' || :new.sseguro  || dbms_utility.format_call_stack);
    end if;
  END;

  CREATE OR REPLACE TRIGGER TMP_ESTGARANSEG_37997 BEFORE INSERT OR UPDATE ON ESTGARANSEG FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    if updating then
         P_CONTROL_ERROR('37997', 1, 'UPDATE ESTGARANSEG NEW SSEGURO: ' || :new.sseguro || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('37997', 1, 'INSERT ESTGARANSEG NEW sseguro: ' || :new.sseguro || dbms_utility.format_call_stack);
    end if;
  END;
SELECT * FROM SIN_TRAMITA_RESERVA
  CREATE OR REPLACE TRIGGER TMP_SIN_TRAMITA_RESERVA BEFORE INSERT OR UPDATE ON sin_tramita_reserva FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
   /* if updating then
         P_CONTROL_ERROR('37997', 1, 'UPDATE ESTGARANSEG NEW SSEGURO: ' || :new.sseguro || dbms_utility.format_call_stack);
    end if;*/
    --END IF;
    if inserting then
         P_CONTROL_ERROR('STR', 1, 'INSERT sin_tramita_reserva NEW NSINIES: ' || :new.NSINIES || ' IRESERVA: ' || :NEW.IRESERVA || dbms_utility.format_call_stack);
    end if;
  END;

  CREATE OR REPLACE TRIGGER TMP_GARANSEG_37997 BEFORE INSERT OR UPDATE ON GARANSEG FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    if updating then
         P_CONTROL_ERROR('37997', 1, 'UPDATE ESTGARANSEG NEW SSEGURO: ' || :new.sseguro || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('37997', 1, 'INSERT ESTGARANSEG NEW sseguro: ' || :new.sseguro || dbms_utility.format_call_stack);
    end if;
  END;



  CREATE OR REPLACE TRIGGER TMP_ESTSEGUROS_38040 BEFORE INSERT OR UPDATE ON ESTSEGUROS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    if updating then
         P_CONTROL_ERROR('38040', 1, 'UPDATE estseguros NEW SSEGURO: ' || :new.sseguro ||  ' NEW ccobban: ' || :new.ccobban ||  ' OLD ccobban: ' || :old.ccobban || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('38040', 1, 'INSERT estseguros NEW sseguro: ' || :new.sseguro || ' NEW ccobban: ' || :new.ccobban || dbms_utility.format_call_stack);
    end if;
  END;

select * from movseguro;

  CREATE OR REPLACE TRIGGER TMP_MOVSEGURO_38096 BEFORE INSERT OR UPDATE ON MOVSEGURO FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.cmotmov = 322 then
    IF updating then
         P_CONTROL_ERROR('38096', 1, 'UPDATE MOVSEGURO sseguro: '  || :new.sseguro || ' OLD.nmovimi: '  || :old.nmovimi || ' new.nmovimi: ' || :new.nmovimi ||  ' *** ' || dbms_utility.format_call_stack);
    END IF;
    IF inserting then
         P_CONTROL_ERROR('38096', 1, 'INSERT MOVSEGURO sseguro: '  || :new.sseguro || ' new.nmovimi: ' || :new.nmovimi || ' *** ' || dbms_utility.format_call_stack);
    END IF;
    --END IF;
  END;


  CREATE OR REPLACE TRIGGER TMP_MOVSEGURO_38026 BEFORE INSERT OR UPDATE OR DELETE ON MOVSEGURO FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.cmotmov = 322 then
    IF updating then
         P_CONTROL_ERROR('38026', 1, 'UPDATE MOVSEGURO sseguro: '  || :new.sseguro  ||  ' cmotmov new: ' || :new.cmotmov || ' *** ' || dbms_utility.format_call_stack);
    END IF;
    IF inserting then
         P_CONTROL_ERROR('38026', 1, 'INSERT MOVSEGURO sseguro: '  || :new.sseguro || ' *** ' || dbms_utility.format_call_stack);
    END IF;/*
    IF deleting then
         P_CONTROL_ERROR('37904', 1, 'DELETE MOVSEGURO sseguro: '  || :new.sseguro || ' *** ' || dbms_utility.format_call_stack);
    END IF;*/
    --END IF;
  END;


  CREATE OR REPLACE TRIGGER TMP_RECIBOS38220 BEFORE UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('38220', 1, 'UPDATE RECIBOS nrecibo: '  || :new.nrecibo || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('38220', 1, 'INSERT RECIBOS : ' || dbms_utility.format_call_stack);
    end if;
  END;

select * from detrecibos;

  CREATE OR REPLACE TRIGGER TMP_DETRECIBOS38220 BEFORE UPDATE ON DETRECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('38220', 1, 'UPDATE DETRECIBOS nrecibo: '  || :new.nrecibo || ' CGARANT new: ' || :new.cgarant || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('38220', 1, 'INSERT DETRECIBOS '  || dbms_utility.format_call_stack);
    end if;
  END;



  CREATE OR REPLACE TRIGGER TMP_RECIBOS37658_2 BEFORE UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.csituac = 3 then
    if updating then
         P_CONTROL_ERROR('37658', 1, 'UPDATE RECIBOS FEMISIO: '  || :new.femisio || ' FEMISIO OLD: ' || :old.femisio || dbms_utility.format_call_stack);
    end if;
    --END IF;
    if inserting then
         P_CONTROL_ERROR('37658', 1, 'INSERT RECIBOS sseguro: '   || dbms_utility.format_call_stack);
    end if;
  END;


  CREATE OR REPLACE TRIGGER TMP_RECIBOS37681 BEFORE INSERT OR UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    --IF :new.fvencim IS NOT NULL then
         P_CONTROL_ERROR('35901_SEG', 1, ' sseguro: '  || :new.sseguro ||  ' fvencim: ' || :new.fvencim || ' *** ' || dbms_utility.format_call_stack);
    --END IF;
  END;


  CREATE OR REPLACE TRIGGER TMP_RECIBOS38096 BEFORE INSERT OR UPDATE ON RECIBOS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    IF updating then
         P_CONTROL_ERROR('38096', 1, 'UPDATE RECIBOS nrecibo: '  || :new.nrecibo ||  ' sseguro: ' || :new.sseguro || ' *** ' || dbms_utility.format_call_stack);
    END IF;
    IF inserting THEN
        P_CONTROL_ERROR('38096', 1, 'INSERT RECIBOS nrecibo: '  || :new.nrecibo || ' sseguro: ' || :new.sseguro || ' *** ' || dbms_utility.format_call_stack);
    END IF;    
  END;

  CREATE OR REPLACE TRIGGER TMP_ADM_RECUNIF37681 BEFORE INSERT OR UPDATE ON ADM_RECUNIF FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    IF updating then
         P_CONTROL_ERROR('37681', 1, 'UPDATE ADM_RECUNIF nrecibo: '  || :new.nrecibo ||  ' nrecunif: ' || :new.nrecunif || ' *** ' || dbms_utility.format_call_stack);
    END IF;
    IF inserting THEN
        P_CONTROL_ERROR('37681', 1, 'INSERT ADM_RECUNIF nrecibo: '  || :new.nrecibo || ' nrecunif: ' || :new.nrecunif || ' *** ' || dbms_utility.format_call_stack);
    END IF;    
  END;


  CREATE OR REPLACE TRIGGER REUY_ESTGARANSEG BEFORE INSERT ON ESTGARANSEG FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    if inserting THEN
        P_CONTROL_ERROR('37166-ESTGARANSEG', 1, ' SSEGURO: ' ||  :new.sseguro ||  ' IPRIANU: '  || :new.iprianu || ' *** ' || dbms_utility.format_call_stack);
    end if;    
  END;

  CREATE OR REPLACE TRIGGER TMP_msv_tb_cargue_masivo_DET BEFORE INSERT OR UPDATE ON msv_tb_cargue_masivo_det FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    IF updating then
      --IF :new.cconcep = 11 or :new.cconcep = 15 then
         P_CONTROL_ERROR('38121-TRG_UPDATE DET', 1, ' id: '  || :new.id  ||' *** ' || dbms_utility.format_call_stack);
      --END IF;
    end if;
    if inserting THEN
      --IF :new.cconcep = 11 or :new.cconcep = 15 then
        P_CONTROL_ERROR('38121-TRG_INSERT DET', 1, ' id: '  || :new.id || ' *** ' || dbms_utility.format_call_stack);
      --END IF;
    end if;    
  END;

  -- Crear el trigger despues del insert
  CREATE OR REPLACE TRIGGER TMP_ESTSEGUROS_38026 BEFORE INSERT OR UPDATE ON ESTSEGUROS FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    IF updating then
      --IF :new.cconcep = 11 or :new.cconcep = 15 then
         P_CONTROL_ERROR('38026', 1, 'UPDATE ESTSEGUROS sseguro: '  || :new.sseguro || 'sseguro old:' || :old.sseguro ||  ' cbancar: ' || :new.cbancar || ' cbancar old: ' || :old.cbancar || ' *** ' || dbms_utility.format_call_stack);
      --END IF;
    end if;
    if inserting THEN
      --IF :new.cconcep = 11 or :new.cconcep = 15 then
        P_CONTROL_ERROR('38026', 1, 'INSERT ESTSEGUROS sseguro: '  || :new.sseguro || ' cbancar: ' || :new.cbancar  || dbms_utility.format_call_stack);
      --END IF;
    end if;    
  END;
--
  -- Crear el trigger para que se dispare despues del insert o del update
  CREATE OR REPLACE TRIGGER ESTGARANSEG_61968
    BEFORE INSERT 
    OR UPDATE 
    ON ESTGARANSEG
    FOR EACH ROW
  BEGIN
    -- Inserta trazas a control_error
    P_CONTROL_ERROR('61968-TRIGGER_EST', 1,:new.cpregun || ' *** ' || dbms_utility.format_call_stack);
  END;
--
CREATE TRIGGER ESTPRIMASGARANSEG_37681
  BEFORE INSERT OR UPDATE ON ESTPRIMASGARANSEG
  --FOR EACH ROW
--DECLARE
--  <<declare variables>>
BEGIN
--  IF( :new.cpregun = 4777 )
--  THEN
    P_CONTROL_ERROR('37681', 1, ' *** ' || dbms_utility.format_call_stack);
--  END IF;
END;
  -- Borrar el trigger creado previamente
  DROP TRIGGER ESTPREGUNPOLSEG_54804_N;


