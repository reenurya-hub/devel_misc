/*                
tron2000.gc_k_ac502012_trn;
gc_k_ac502012.p_query_mvtos(1)
gc_k_ac502012.p_devuelve_mvtos(19)
*/
--COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_CUOTA, NUM_MVTO, MCA_CA, MCA_CV -- PK
-- MOVIMIENTOS O HISTORICO DE CUOTAS
SELECT * 
  FROM a5020301 a
 WHERE a.cod_cia       = 1
   AND a.num_poliza    = '4135000092077'
   AND a.num_recibo    = 405063703
   --AND a.num_spto      = 0
   --AND a.num_apli      = 0
   --AND a.num_spto_apli = 0
   --AND a.num_cuota     = 1
   AND a.num_mvto      = (SELECT MAX(b.num_mvto) 
                            FROM a5020301 b
                           WHERE b.cod_cia       = 1
                             AND b.num_poliza    = '4135000092077'
                             AND b.num_recibo    = 405063703
                             --AND b.num_spto      = 0
                             --AND b.num_apli      = 0
                             --AND b.num_spto_apli = 0
                             --AND b.num_cuota     = 1
                          )
;

/******************** */
-- CONSULTA MOVIMIENTOS DE TRONWEB
      SELECT num_mvto,
             tip_situacion,
             fec_situacion,
             tip_gestor,
             cod_gestor,
             num_bloque_tes,
             num_ord_pago,
             tip_docum_pago,
             cod_docum_pago,
             cod_causa_anu,
             cod_usr,
             tip_cobro,
             fec_aux1,
             fec_vcto_pago,
             cod_cia_cobro,
             mca_dcto_comis,
             fec_ctable
        FROM a5020301
       WHERE cod_cia = 1--g_cod_cia
         AND num_recibo = 405063703--c_num_recibo
       GROUP BY num_mvto,
                tip_situacion,
                fec_situacion,
                tip_gestor,
                cod_gestor,
                num_bloque_tes,
                num_ord_pago,
                tip_docum_pago,
                cod_docum_pago,
                cod_causa_anu,
                cod_usr,
                tip_cobro,
                fec_aux1,
                fec_vcto_pago,
                cod_cia_cobro,
                mca_dcto_comis,
                fec_ctable
       ORDER BY num_mvto;
