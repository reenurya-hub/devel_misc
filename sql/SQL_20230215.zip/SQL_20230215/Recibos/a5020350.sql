
-- RECIBO NO-PRIMA

      SELECT a.num_recibo,
             a.tip_situacion,
             a.fec_efec_recibo,
             a.fec_vcto_recibo,
             a.tip_gestor,
             a.cod_gestor,
             a.tip_docum_pago,
             a.cod_docum_pago,
             a.fec_vcto_pago
        FROM a5020350 a
       WHERE a.cod_cia = 1--g_cod_cia
         AND a.num_poliza = '4135000092077'--p_num_poliza
         AND a.num_apli =
             DECODE(0/*p_num_apli*/, NULL, a.num_apli, 0, a.num_apli, 0)--p_num_apli)
         AND a.ROWID IN (SELECT MIN(b.ROWID)
                           FROM a5020350 b
                          WHERE b.cod_cia = 1--g_cod_cia
                            AND b.num_poliza = '4135000092077'--p_num_poliza
                            AND b.num_apli = DECODE(0,--p_num_apli,
                                                    NULL,
                                                    b.num_apli,
                                                    0,
                                                    b.num_apli,
                                                    0)--p_num_apli)
                            AND b.num_recibo = a.num_recibo)
         AND (   (   'N' = 'N')--g_cons_rec_agrp   = 'N')
              OR (   'S' = 'S')-- g_cons_rec_agrp   = 'S')
                  AND a.fec_efec_recibo = g_cons_fec_desde
                  AND a.fec_vcto_recibo = g_cons_fec_hasta)
       ORDER BY a.fec_efec_recibo,
                a.num_recibo;
