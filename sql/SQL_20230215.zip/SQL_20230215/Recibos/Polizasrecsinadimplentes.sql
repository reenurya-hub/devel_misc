--trp_xx_dl.ev_k_end_cancel_inadimpl_vcr

   SELECT a.*
     FROM a2000030 a
     FROM CORPP0.a2000030 a
    WHERE a.cod_cia          = 1--g_cod_cia
      AND a.cod_sector       = 77--g_cod_sector
      AND a.cod_ramo         = 985--g_cod_ramo
      AND a.mca_provisional  = 'N' --g_mca_provisional
      --AND a.fec_emision_spto = TO_DATE('19/05/2022','DD/MM/YYYY')--g_fec_emision_spto
                                                                                              -- ULTIMO ENDOSO      
      AND a.num_spto         = (SELECT MAX(num_spto)                                          
                                  FROM a2000030 b 
                                 WHERE b.cod_cia          = a.cod_cia 
                                   AND b.cod_sector       = a.cod_sector 
                                   AND b.cod_ramo         = a.cod_ramo
                                   AND b.mca_provisional  = a.mca_provisional
                                   AND b.fec_emision_spto = a.fec_emision_spto
                                   AND b.num_poliza       = a.num_poliza)
      AND a.num_apli         = 0--trn.cero
                                                                                              -- POLIZAS QUE NO ESTAN ANULADAS
      AND NOT EXISTS (SELECT 1 
                        FROM a2000030 c
                       WHERE c.cod_cia              = a.cod_cia
                         AND c.cod_ramo             = a.cod_ramo
                         AND c.num_poliza           = a.num_poliza
                         AND c.mca_provisional      = a.mca_provisional
                         AND c.tip_spto             = 'AT'
                         AND c.mca_poliza_anulada   = 'S')--trn.si)
                                                                                              -- RECIBOS QUE HAYAN VENCIDO SIN PAGARSE
      AND EXISTS     (SELECT 1 
                        FROM a2990700 a1
                       WHERE a1.cod_cia             = a.cod_cia
                         AND a1.num_poliza          = a.num_poliza
                         AND a1.tip_situacion       IN ('EP','RE'))
                         AND (TRUNC(SYSDATE) - a1.fec_vcto_recibo) >= 70);--g_k_num_dias_inadimpl);
