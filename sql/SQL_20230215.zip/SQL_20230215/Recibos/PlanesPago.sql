--a1001410 planes de pago

select * from a1001410
