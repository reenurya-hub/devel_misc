-- recibos pendientes 
SELECT fec_efec_recibo, num_recibo, tip_situacion, cod_mon, SUM(imp_recibo)
  FROM a2990700 a
 WHERE a.cod_cia         =  2--p_cod_cia
   AND a.num_poliza      =  a.num_poliza--p_num_poliza
   AND a.tip_situacion   IN ('RE', 'EP')--p_tip_situacion)
   AND a.num_recibo +0   > 0
   AND a.num_apli        = 0
   AND a.tip_docum_pago  IS NULL
   AND a.cod_docum_pago  IS NULL
   AND a.num_aviso       IS NULL
   AND TRUNC(a.fec_efec_recibo) <= TO_DATE('14/11/2022','DD/MM/YYYY')
   -- recibos que no esten en cobro de recibo batch
   AND (select COUNT(b.NUM_RECIBO) from a5020039 b where b.cod_cia = a.cod_cia and b.num_recibo =  a.num_recibo) = 0
 GROUP BY a.fec_efec_recibo, a.num_recibo, a.tip_situacion, a.cod_mon
HAVING SUM(a.imp_recibo) > 0;
