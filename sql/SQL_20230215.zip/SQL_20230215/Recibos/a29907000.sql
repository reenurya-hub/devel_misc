-- RECIBOS/CUOTAS DE UNA POLIZA
-- COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_CUOTA, MCA_CA, MCA_CV, COD_AGT  -- PK

TRON2000.gc_k_ac502011_trn;
/*
 gc_k_ac502011.p_devuelve_recibos;
 gc_k_ac502011
 --
TRON2000.gc_k_ac502011_trn;
p_query_recibos(p_num_poliza    IN a2990700.num_poliza    %TYPE,
                             p_num_spto      IN a2990700.num_spto      %TYPE,
                             p_num_apli      IN a2990700.num_apli      %TYPE,
                             p_num_spto_apli IN a2990700.num_spto_apli %TYPE)
*/
--CODIGO DE LA SITUACION EN QUE SE ENCUENTRA EL RECIBO, DEBE ESTAR DEFINIDO EN LA A5020500
--SELECT * FROM A5020500;

-- RECIBOS/CUOTAS DE UNA POLIZA
SELECT * 
  FROM corpp0.a2990700 a
 WHERE a.cod_cia       = 1               -- INDICE
   AND a.num_poliza    = '4135000092077' -- INDICE
   --AND a.num_spto      = 0               -- INDICE
   --AND a.num_apli      = 0
   --AND a.num_spto_apli = 0
   --AND a.num_cuota     = 1               -- INDICE
   --AND a.num_recibo    = 405063683       -- INDICE
   --AND TRUNC(a.fec_efec_recibo) = TO_DATE('05/01/2023','DD/MM/YYYY') -- INDICE
   --AND TRUNC(a.fec_vcto_recibo) = TO_DATE('01/10/2023','DD/MM/YYYY')
   --AND a.mca_ca        = 'N'
   --AND a.mca_cv        = 'N'
   --AND a.cod_agt       = 97493 
;

/******************************  */
-- CONSULTA QUERY RECIBOS DE TRONWEB
      SELECT a.num_recibo,
             a.tip_situacion,
             a.fec_efec_recibo,
             a.fec_vcto_recibo,
             a.tip_gestor,
             a.cod_gestor,
             a.tip_coaseguro,
             a.num_cuota,
             a.num_spto,
             a.fec_vcto_pago
        FROM a2990700 a
       WHERE a.cod_cia = 1 --g_cod_cia
         AND a.num_poliza = '4135000092077' --p_num_poliza
         AND a.num_apli =
             DECODE(0/*p_num_apli*/, NULL, a.num_apli, 0, a.num_apli, 0)--p_num_apli)
         AND a.ROWID IN (SELECT MIN(b.ROWID)
                           FROM a2990700 b
                          WHERE b.cod_cia = 1--g_cod_cia
                            AND b.num_poliza = '4135000092077'--p_num_poliza
                            AND b.num_spto <= 0--p_num_spto
                            AND b.num_apli = DECODE(0,--p_num_apli,
                                                    NULL,
                                                    b.num_apli,
                                                    0,
                                                    b.num_apli,
                                                    0)--p_num_apli)
                            AND b.num_spto_apli <= NVL(0, 999999)--p_num_spto_apli, 999999)
                            AND b.num_recibo = a.num_recibo)
         AND (   (    'N' = 'N') --g_cons_rec_agrp   = 'N')
              OR (    'N' = 'N'--g_cons_rec_agrp   = 'S'
                  AND trunc(a.fec_efec_recibo) =  to_date('04/01/2023','dd/mm/yyyy')--g_cons_fec_desde
                  AND trunc(a.fec_vcto_recibo) =  to_date('04/01/2023','dd/mm/yyyy')))--g_cons_fec_hasta))
       ORDER BY a.fec_efec_recibo,
                a.num_recibo;




      SELECT c.num_recibo     ,
             c.tip_situacion  ,
             c.fec_efec_recibo,
             c.fec_vcto_recibo,
             c.tip_gestor     ,
             c.cod_gestor     ,
             c.tip_coaseguro  ,
             c.num_cuota      ,
             c.num_spto       ,
             c.fec_vcto_pago
        FROM a2000030 a,
             a2990700 c
       WHERE a.cod_cia        = c.cod_cia
         AND a.num_poliza     = c.num_poliza
         AND a.num_spto       = c.num_spto
         AND a.num_apli       = c.num_apli
         AND a.num_spto_apli  = c.num_spto_apli
         AND a.cod_cia        = 1--pc_cod_cia
         AND a.num_poliza     = '4135000092077'--pc_num_poliza
         --AND a.num_apli       = 0--pc_num_apli
         --AND a.num_spto_apli  = 0
         --AND c.mca_cv         = 'N'
         AND a.fec_efec_spto >= (SELECT MAX(b.fec_efec_spto)
                                   FROM a2000030 b
                                  WHERE a.cod_cia        = b.cod_cia
                                    AND a.num_poliza     = b.num_poliza
                                    AND trunc(b.fec_efec_spto) <= to_date(sysdate,'dd/mm/yyyy')--pc_fec_consulta
                                    AND b.tip_spto      IN ('XX','RF'))
         AND a.fec_efec_spto  < NVL((SELECT MIN(b.fec_efec_spto)
                                       FROM a2000030 b
                                      WHERE a.cod_cia        = b.cod_cia
                                        AND a.num_poliza     = b.num_poliza
                                        AND trunc(b.fec_efec_spto)  > to_date(sysdate,'dd/mm/yyyy')--pc_fec_consulta
                                        AND b.tip_spto      IN ('XX','RF')),a.fec_efec_spto + 1)
         AND  (   ( 'N'    = 'N')--g_cons_rec_agrp   = 'N')
               OR (    'S'    = 'S'--g_cons_rec_agrp   = 'S'
                   AND c.fec_efec_recibo = a.fec_efec_spto--g_cons_fec_desde
                   AND c.fec_vcto_recibo = a.fec_vcto_poliza ))--g_cons_fec_hasta))
       ORDER BY a.num_spto     ,
                a.num_spto_apli;
