-- principal de recibos desarrollo
select * from A2990700 where num_recibo = '405452754';

-- principal de recibos homologacion
select * from corpp0.A2990700 where num_recibo = '405452754';
