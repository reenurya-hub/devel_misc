prompt Importing table g2000510...
set feedback off
set define off

insert into g2000510 (COD_CIA, FEC_TRATAMIENTO, NUM_ORDEN, TIP_MVTO_BATCH, TXT_ALIAS, TIP_SITU_FILTRO, NOM_PRG_EXCEPCION, MCA_RECALCULA_FECHA, TIP_FECHA_BASE, COD_USR, FEC_ACTU)
values (2, to_date('23-08-2022', 'dd-mm-yyyy'), 31, '3', 'CARGA DE POLIZAS MAPFRE', '6', null, 'N', null, 'TRON2000', null);

prompt Done.
