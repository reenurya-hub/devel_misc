1. EN LA P2000060 PARA EL RIESGO 0 EL TIPO DE BENEFICIARIO (SI VA) TIENE QUE SER 1 (TOMADOR ALTERNO) EN TIP_NIVEL=1 (A NIVEL DE POLIZA).
Y COMO SE EMITE EN TRONWEB, DE ACUERDO A LO QUE SE DEFINIO EN EL A1001801
select * from a1001801 where cod_cia = 2 and cod_ramo = 228 and tip_nivel = 1
2. EN LA P2000030 EL VALOR DEL IMP_CUOTA_INICIAL DEBE SER IGUAL A 0
3. en la p2000040 no estaba la cobertura 9998 y 9997
4. en la p2100170 no estaba la cobertura 9998 y 9997
5. FALTA VALIDAR EL 
em_k_cob
llamado a p_v_txt_suma_aseg (7980)
PREGUNTAR A CAROLINA O A OTRO SI PARA PRESUPUESTO C�MO VALIDA ct PRIMA MINIMA.

select * from a1002150 where cod_cia = 2 and cod_ramo = 228;
ED_K_228_COB

select * from x2000221;

ED_K_228_CT
ED_K_228_CT.P_CT_OPCION_GRABAR
ed_k_gen_ct
ed_k_gen_ct.p_ct_opcion_grabar;

DELETE FROM  TRAZAS_MPR where cod_traza = 'reuy';
COMMIT;
select * from TRAZAS_MPR where cod_traza = 'reuy' ORDER BY ID_TRAZA;


select * from x2000221 where num_poliza = '2282200000738';

EM_K_BATCH_POLIZA_TRN;
em_k_ap200000
em_k_ap200000.p_ctrl_tecnico_terminar;
EM_K_BATCH_TRN;
em_k_batch_poliza

TRAZA OTRO ERROR BATCH
insert a2000221 num_poliza : 2282200000738----- PL/SQL Call Stack -----
  object      line  object
  handle    number  name
0x70498868         4  TRON2000.TMP_A2000221
0x86b6a028       625  package body TRON2000.EM_K_VALIDADOR_EMISION_TRN.PP_INSERTA_ERROR
0x86b6a028      3576  package body TRON2000.EM_K_VALIDADOR_EMISION_TRN.P_VALIDA
0x8a30a318      4743  package body TRON2000.EM_K_AP200000_TRN.P_GRABAR
0x8a30a318      4552  package body TRON2000.EM_K_AP200000_TRN.P_CTRL_TECNICO_GRABAR
0x758e0b48      2774  package body TRON2000.EM_K_BATCH_POLIZA_TRN.PP_TERMINA_POLIZA
0x758e0b48      5416  package body TRON2000.EM_K_BATCH_POLIZA_TRN.P_EMITE
0x86589d38      2394  package body TRON2000.EM_K_BATCH_TRN.PP_EMITE
0x86589d38      3138  package body TRON2000.EM_K_BATCH_TRN.PP_LLAMA_PROCESO
0x86589d38      4484  package body TRON2000.EM_K_BATCH_TRN.PP_TRATA_CURSOR
0x86589d38      4633  package body TRON2000.EM_K_BATCH_TRN.PP_MONOHILO
0x86589d38      4838  package body TRON2000.EM_K_BATCH_TRN.P_PROCESO
0x759959c0        83  anonymous block

TRAZA ERROR COTIZACION ONLINE
insert x2000221 num_poliza : 2222800000101 cod_nivel_salto: 8 cod_error: 31----- PL/SQL Call Stack -----
  object      line  object
  handle    number  name
0x84e9aaf8         4  TRON2000.TMP_X2000221
0x7d7ea9d0       249  package body TRON2000.EM_K_X2000221_TRN.P_INSERTA
0x8888df78       683  package body TRON2000.ED_K_GEN_CT_MGT.PP_REGISTRO_X2000221
0x8888df78      2683  package body TRON2000.ED_K_GEN_CT_MGT.PP_CTRL_RECIBOS_MINIMO
0x8888df78      3111  package body TRON2000.ED_K_GEN_CT_MGT.P_CT_OPCION_GRABAR
0x88896168       786  package body TRON2000.ED_K_228_CT_MGT.P_CT_OPCION_GRABAR
0x82212998         1  anonymous block
0x8acfa950       355  package body TRON2000.TRN_K_DINAMICO.P_EJECUTA_PROCEDIMIENTO
0x8c7862a0        18  procedure TRON2000.TRN_P_DINAMICO
0x888cf010       148  procedure TRON2000.DC_P_CONTROL_TECNICO_TRN
0x888d8690       430  package body TRON2000.EM_K_CONTROL_TECNICO_TRN.F_HAY
0x8a30a318      2477  package body TRON2000.EM_K_AP200000_TRN.FP_CTRL_TECNICO
0x8a30a318      4545  package body TRON2000.EM_K_AP200000_TRN.P_CTRL_TECNICO_GRABAR
0x82216a40         1  anonymous block


;EM_K_AP200000_TRN;
select * from g2000200;
tron2000.EM_K_CONTROL_TECNICO_TRn;
em_k_a2000030
select * from a2000221;
 CREATE OR REPLACE TRIGGER TMP_a2000221  BEFORE INSERT OR UPDATE ON a2000221 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
       --if :new.cod_error = 31 then
         dc_p_trazas_mpr('reuy','insert a2000221 num_poliza : '|| :new.num_poliza || ' cod_nivel_salto: ' || :new.cod_nivel_salto || ' cod_error: ' || :new.cod_error || dbms_utility.format_call_stack );
       --end if;
    END IF;
    IF UPDATING THEN
       --if :new.cod_error = 31 then
         dc_p_trazas_mpr('reuy','update a2000221 num_poliza : '|| :new.num_poliza ||  ' cod_nivel_salto: ' || :new.cod_nivel_salto || ' cod_error: ' || :new.cod_error || dbms_utility.format_call_stack );
       --end if;
    END IF;
  END;



 CREATE OR REPLACE TRIGGER TMP_p2000221  BEFORE INSERT OR UPDATE ON p2000221 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
       --if :new.cod_error = 31 then
         dc_p_trazas_mpr('reuy','insert p2000221 num_poliza : '|| :new.num_poliza ||  ' cod_nivel_salto: ' || :new.cod_nivel_salto || ' cod_error: ' || :new.cod_error || dbms_utility.format_call_stack );
       --end if;
    END IF;
    IF UPDATING THEN
       --if :new.cod_error = 31 then
         dc_p_trazas_mpr('reuy','update p2000221 num_poliza : '|| :new.num_poliza ||  ' cod_nivel_salto: ' || :new.cod_nivel_salto || ' cod_error: ' || :new.cod_error || dbms_utility.format_call_stack );
       --end if;
    END IF;
  END;



 CREATE OR REPLACE TRIGGER TMP_x2000221  BEFORE INSERT OR UPDATE ON x2000221 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
       --if :new.cod_error = 31 then
         dc_p_trazas_mpr('reuy','insert x2000221 num_poliza : '|| :new.num_poliza ||  ' cod_nivel_salto: ' || :new.cod_nivel_salto || ' cod_error: ' || :new.cod_error ||dbms_utility.format_call_stack );
       --end if;
    END IF;
    IF UPDATING THEN
       --if :new.cod_error = 31 then
         dc_p_trazas_mpr('reuy','update x2000221 num_poliza : '|| :new.num_poliza ||  ' cod_nivel_salto: ' || :new.cod_nivel_salto || ' cod_error: ' || :new.cod_error ||dbms_utility.format_call_stack );
       --end if;
    END IF;
  END;
  
OJO: POSIBLE ERROR DE LOS TERCEROS EN EM_K_X2000060_A_MGT LINEA 4109 ( pp_carga_tabla_batch; )NO RECUPERA DATOS!!!
Y NO ESTA GENERANDO RECIBO

DC_K_PROCESO_BATCH_MGT_MGT
DC_K_DV_TRN
EM_K_AC200500_TRN
em_k_a1001801;
tron2000.em;
em.TIP_BENEF_TOMADOR
1. lo de los terceros puede ser que para el riesgo 0 estan agregando tipos de beneficiario = 2
entonces el proceso masivo lee los de tipo de beneficiario 2 en el riesgo 1
select * from a1001801 where cod_cia = 2 and cod_ramo = 228 and tip_nivel = 1
select * from a1001801 where cod_cia = 2 and cod_ramo = 260
em_k_ap200000.p_ctrl_tecnico_terminar
select * from g2000210 where cod_cia = 2 and cod_error in (-5,31);
select * from g2999003_mgt where cod_cia = 2 and cod_ramo = 228;
ed_k_228_ct;
ed_k_gen_ct
em_k_llamador_trn;
prompt Done.;

         SELECT SUM (a.imp_spto)
           FROM p2100170 a
          WHERE a.cod_cia       = 2
            AND a.num_poliza    = 2222800001012 for update;

.
select * from g2999003_mgt where cod_cia = 2 and cod_ramo = 228 and nom_nemotecnico in ('RECIBOS_MENOR', 'VAL_RECIBO_MINIMO');

ed_k_gen_ct

em_k_batch_trn
em_k_batch_poliza
EM_K_X2000060_A_MGT
em_k_batch; 4633
em_k_batch.pp_llama_proceso;
em_k_batch.pp_emite; --3138
em_k_batch_poliza
em_k_batch_poliza.p_emite;
em_k_batch_poliza.pp_llamador;
em_k_llamador
em_k_llamador.p_trata_proceso_masivo;
em_k_llamador_trn
   em_k_llamador_trn.p_llama_programa;
   em_k_llamador_trn;
     EM_K_DATOS_FIJOS_TRN
     EM_K_DATOS_FIJOS_TRN.p_trata_proceso_masivo
       EM_K_DATOS_FIJOS_TRN.P_TERMINA;
       em_k_batch_poliza_trn
pp_datos_fijos
Call stack
EM_K_BATCH_POLIZA_TRN [Line 1703]   em_k_datos_fijos.p_trata_proceso_masivo;
error en la a1001342 codigo inexistente;

EM_K_DATOS_FIJOS_TRN

em_k_batch_poliza_trn;-- 5349
em_k_batch_poliza_trn; 1703
em_k_batch_trn 2394
em_k_datos_fijos_trn
presupuesto pruebas: 2222800001000
presupuesto ejemplo des= 2222800000098,2222800000099

update p2000030 set num_poliza = '2222800001012', MCA_POLIZA_ANULADA = 'N' WHERE cod_cia = 2 AND num_poliza = '2222800001011';
update p2000060 set num_poliza = '2222800001012' WHERE cod_cia = 2 AND num_poliza = '2222800001011';
UPDATE p2000040 SET NUM_POLIZA = '2222800001012' WHERE num_poliza = '2222800001011';
UPDATE p2000031 SET NUM_POLIZA = '2222800001012' WHERE num_poliza = '2222800001011';
UPDATE p2100170 SET NUM_POLIZA = '2222800001012' WHERE num_poliza = '2222800001011';
UPDATE p2000020 SET NUM_POLIZA = '2222800001012' WHERE num_poliza = '2222800001011';
update a2000500 set tip_situ = 1, NUM_POLIZA = '2222800001012'  WHERE cod_cia = 2 AND num_poliza = '2222800001011';
update p2000030 set MCA_POLIZA_ANULADA = 'N' WHERE cod_cia = 2 AND num_poliza = '2222800001012';
update a2000500 set tip_situ = 1 WHERE cod_cia = 2 AND num_poliza = '2222800001012';
update g2000510 set tip_situ_filtro  = 6  WHERE cod_cia = 2 AND  trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy') and num_orden =31;
commit;

delete from p2000040 WHERE cod_cia = 2 AND num_poliza = '2222800001012';


select * from  P2000020 WHERE cod_cia = 2 AND num_poliza = '2222800001012';


select * from  P2000030 WHERE cod_cia = 2 AND num_poliza = '2222800001012';


select * from  P2000031 WHERE cod_cia = 2 AND num_poliza = '2222800001012';


select * from  P2000040 WHERE cod_cia = 2 AND num_poliza = '2222800001012' and cod_cob in (9997,9998);


select * from  P2000060 WHERE cod_cia = 2 AND num_poliza = '2222800001012';


select * from  P2100170 WHERE cod_cia = 2 AND num_poliza = '2222800001012';


select * from  a2000500 WHERE cod_cia = 2 AND num_poliza = '2222800001012';


select * from  g2000510 WHERE cod_cia = 2 AND  
trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy') and num_orden =31;






trn_k_global.ref_f_global

         SELECT SUM (a.imp_spto)
           FROM p2100170 a
          WHERE a.cod_cia       = 2--g_cod_cia
            AND a.num_poliza    = '2222800001010'; 
select * from  P2000030 WHERE cod_cia = 2 AND num_poliza IN ( '2222800001007','2222800000099') FOR UPDATE;
select * from  P2000031 WHERE cod_cia = 2 AND num_poliza IN ( '2222800001007','2222800000099') FOR UPDATE;
select * from  P2000040 WHERE cod_cia = 2 AND num_poliza IN ( '2222800001007','2222800000099') ORDER BY COD_COB FOR UPDATE;
select * from  P2100170 WHERE cod_cia = 2 AND num_poliza IN ( '2222800001007','2222800000099') ORDER BY COD_COB FOR UPDATE;
select * from  P2000040 WHERE cod_cia = 2 AND num_poliza = '2222800001008' for update;

2203
2206
2207
2209
2210
2241
2242
2243
9998
2246
2247
2249
2250
2254
2264
2265
2301
2302
2316
2317
2318
2319
2320
2321
2342
2343
2344
2345
2346
2381
2391
3001
3002
3003
3004
3005
3007
3009
3010
3012
3013
3016
3020
3031
3033
9997


UNION 
select 

 from  P2000030 WHERE cod_cia = 2 AND num_poliza = '2222800001007'
FOR UPDATE;
select * from  p2000060 WHERE cod_cia = 2 AND num_poliza = '2222800001003';
select COD_COB from  p2000040 WHERE cod_cia = 2 AND num_poliza = '2222800001007';
select * from  p2000031 WHERE cod_cia = 2 AND num_poliza = '2222800001004';
select * from  p2100170 WHERE cod_cia = 2 AND num_poliza = '2222800001003';
select * from  p2000020 WHERE cod_cia = 2 AND num_poliza = '2222800001003';
select * from  p2000020 WHERE cod_cia = 2 AND num_poliza = '2222800001003';

SELECT * FROM p2000030 WHERE cod_cia = 2 AND num_poliza = '2222800001003' FOR UPDATE;
SELECT * FROM p2000030 WHERE cod_cia = 2 AND num_poliza in( '2222800000098','2222800001001') FOR UPDATE;
SELECT * FROM p2000060 WHERE cod_cia = 2 AND num_poliza in( '2222800000099','2222800001000') FOR UPDATE;

SELECT * FROM p2000030 WHERE cod_cia = 2 AND num_poliza = '2222800001000' for update;--DATOS FIJOS DEL PRESUPUESTO
update a2000500 set num_poliza = '2222800001000' where cod_cia = 2 AND num_poliza = '1930000001671' ;
commit;
SELECT * FROM p2000030 WHERE cod_cia = 2 AND num_poliza in( '2222800001001','2222800000099') ; for update;
SELECT * FROM p2000031 WHERE cod_cia = 2 AND num_poliza = '2222800001001' for update;
SELECT * FROM p2000031 WHERE cod_cia = 2 AND num_poliza in( '2222800001000','2222800000099') ;--RIESGOS DEL PRESUPUESTO
SELECT * FROM p2000060 WHERE cod_cia = 2 AND num_poliza = '2222800001001' for update;
SELECT * FROM p2000060 WHERE cod_cia = 2 AND num_poliza = '2222800001000';--TERCEROS DEL PRESUPUESTO
UPDATE p2000020 SET NUM_POLIZA = '2222800001002' WHERE num_poliza = '2222800001001';
SELECT * FROM p2000020 WHERE cod_cia = 2 AND num_poliza = '2222800001001';--DATOS VARIABLES DEL PRESUPUESTO
UPDATE p2000040 SET NUM_POLIZA = '2222800001002' WHERE num_poliza = '2222800001001';
SELECT * FROM p2000040 WHERE cod_cia = 2 AND num_poliza ='2222800001001' for update;
SELECT * FROM p2000040 WHERE cod_cia = 2 AND num_poliza ='2222800001001';--COBERTURAS DEL PRESUPUESTO
SELECT * FROM p2000040 WHERE cod_cia = 2 AND num_poliza in ('2222800001000','2222800000099') ;--COBERTURAS DEL PRESUPUESTO
SELECT * FROM p2000040 WHERE cod_cia = 2 AND num_poliza in ('2222800001000','2222800000099') and cod_cob in (9997, 9998) for update;--COBERTURAS DEL PRESUPUESTO
SELECT * FROM x2000040 WHERE cod_cia = 2 AND num_poliza = '2222800001000';--COBERTURAS DEL PRESUPUESTO
UPDATE p2100170 SET NUM_POLIZA = '2222800001002' WHERE num_poliza = '2222800001001';
SELECT * FROM p2100170 WHERE cod_cia = 2 AND num_poliza = '2222800001003' for update;
SELECT * FROM p2100170 WHERE cod_cia = 2 AND num_poliza in( '2222800001000','2222800000099')
update a2000500 set tip_situ = 1, NUM_POLIZA = '2222800001002'  WHERE cod_cia = 2 AND num_poliza = '2222800001001';
commit;


and cod_cob in (9997,9998) for update;--CONCEPTOS DE DESGLOSE ECONOMICO DEL PRESUPUESTO
SELECT * FROM g2000510 WHERE cod_cia = 2 and trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy') and num_orden =31;
em_k_cob


DC_K_PROCESO_BATCH_MGT
select * from a2991800 where cod_cia = 2 and cod
select * from a2100170;
select * from a2000030 where num_poliza = 2282200000732;
select * from a2000040 where num_poliza = 2282200000732;
select * from a2000060 where num_poliza = 2282200000732;
select * from a2000221 where num_poliza = 2282200000732;
select * from a2000500 WHERE cod_cia = 2 AND num_poliza = '2222800001001' for update;
update a2000500 set tip_situ = 1 WHERE cod_cia = 2 AND num_poliza = '2222800001002';
commit;
update g2000510 set tip_situ_filtro  = 6  WHERE cod_cia = 2 AND  trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy') and num_orden =31;
commit;
em_k_p2000060
em_k_p2000060
DC_K_PROCESO_BATCH_MGT
select * from a1001342 where cod_docum in ('26356090', '825317K');
em_k_batch_trn;
em_k_des
cod_cia = 2
num_poliza =
num_riesgo = 0
tip_benef = 1
SELECT *
          FROM p2000060
         WHERE cod_cia         = pc_cod_cia
           AND num_poliza      = pc_num_poliza
           AND tip_benef       = pc_tip_benef
           AND num_riesgo      = pc_num_riesgo;
select * from a2000500 WHERE cod_cia = 2 AND num_poliza = '2222800001000' for update;


        SELECT ''
          FROM g2000510
         WHERE cod_cia         = 2--g_cod_cia
           AND fec_tratamiento = g_fec_tratamiento
           AND num_orden       = g_num_orden
           AND tip_mvto_batch  = pc_tip_mvto_batch
           AND tip_situ_filtro NOT IN ( pc_tip_situ_filtro_1 , pc_tip_situ_filtro_2 )


     SELECT *
          FROM a2000500


SELECT * FROM g2000510;
nwt_il.IL_PLY_MPG_PSS_TRW_TRN

 g_k_no_tratada          CONSTANT a2000500.tip_situ           %TYPE := '1';
 g_k_en_proceso          CONSTANT a2000500.tip_situ           %TYPE := '2';
 g_k_terminada           CONSTANT a2000500.tip_situ           %TYPE := '3';
 g_k_con_error           CONSTANT a2000500.tip_situ           %TYPE := '4';
 g_k_excepcion           CONSTANT a2000500.tip_situ           %TYPE := '5';
 g_k_retenida            CONSTANT a2000500.tip_situ           %TYPE := '6';
 g_k_rechazo_accion      CONSTANT a2000500.tip_situ           %TYPE := '7';
 g_k_tratada_con_error   CONSTANT a2000500.tip_situ           %TYPE := '0';


SELECT *
          FROM g2000510
         WHERE cod_cia         = 2
           AND TRUNC(fec_tratamiento) = TO_DATE('23/08/2022','DD/MM/YYYY')
           AND num_orden       = 31--g_num_orden
           AND tip_mvto_batch  = 3--pc_tip_mvto_batch;


select * from a2000500 where trunc(fec_tratamiento) = to_date('01/09/2022','dd/mm/yyyy');
DC_K_PROCESO_BATCH_MGT
em_k_batch;

select * from a5100601 WHERE cod_cia = 2 AND num_poliza = '1930000001671';

BALANCE_PA

DELETE FROM  p2000030 where num_poliza = '1930000001671';
SELECT * FROM p2000030 where num_poliza = '1930000001671';

DELETE FROM  p2000031 where num_poliza = '1930000001671';
COMMIT;
SELECT * FROM p2000031 where num_poliza = '1930000001671';

;tron2000.em_k_batch_trn

select * from  a2000500 where num_poliza = '1930000001671';

select * from g1005010;

select * from p2000020;

select * from p2000030;


select * from g2000510;

tron2000.em_k_batch_trn;
begin
  em_k_batch_trn.p_proceso;
  end;

Buena tarde reinaldo,
El proceso actualmente consta del llenado de datos en las tablas buz�n y la ejecuci�n del proceso batch, 
EM_K_BATCH.P_PROCESO.
En un correo anterior, se te proporciono 2 presupuestos ya ingresados en las tablas buz�n del ambiente de Of0, las cuales seg�n indico George, le servir�an para hacer sus pruebas.
Si necesitan los datos en desarrollo podr�an copiar los datos de las tablas de OF0.

Saludos.
Cabe mencionar que creando los presupuestos o p�lizas directamente en TRON, el sistema si valida la prima m�nima, por lo cual el inconveniente �nicamente se est� presentando en el proceso batch.

--ed_k_gen_ct linea 2678 quitar lo de suma minima
ed_k_gen_ct
-- puede ser que no esta insertando en la tabla P2000060 TERCEROS DEL PRESUPUESTO

-- principal de proceso
ed_k_228_emi_masivo;
ed_k_228_emi_masivo_mgt.p_pre_procesa_registro_dt;
tron2000.dc_k_proceso_batch_mgt
tron2000.dc_k_proceso_batch_mgt.p_pre_procesa_registro_dt;


2282200000655

SELECT * FROM A2000010 WHERE NUM_POLIZA = '2282200000600';
SELECT * FROM A2000020 WHERE NUM_POLIZA = '2282200000600';
SELECT * FROM A2000030 WHERE NUM_POLIZA = '2282200000600';-- A PARTIR DE PRESUPUESTO 1930000001648

SELECT * FROM G0009010; --DEFINICION DE ESTRUCTURAS - PARAMETROS GENERALES
SELECT * FROM G0009020_MGT WHERE COD_ESTRUCTURA = 'ED_228_MIGRAC';
dc_k_proceso_batch
ED_K_228_EMI_MASIVO;
ED_K_228_EMI_MASIVO.P_V_ID_POLIZA
A2000012
A2000031

SELECT * FROM 

-- CONSULTA OF0
POLIZA OF0 ERROR= 2282200000600;
SELECT * FROM P2000060 WHERE NUM_POLIZA = 2282200000600;

p2000040


NUMEROS DE PRESUPUESTO O POLIZA = 
1930000001671
1930000001672
-- CONSULTA OF0
select * from g2000510 where trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy');
select * from a2000500 where num_poliza in ('1930000001648');

-- 23 agosto 2022
select * from g2000510 where num_orden = 31 and trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy'); 
SELECT * FROM A2000500 WHERE NUM_POLIZA IN ('1930000001671','1930000001672'); --POLIZAS A TRATAR EN LOS PROCESOS MASIVOS


select * from p2000020 where num_poliza = '1930000001671';
select * from p2000040 where num_poliza = '1930000001671';
select * from p2000060 where num_poliza = '1930000001672';
select * from p2000030 where num_poliza = '1930000001671';
select * from p2000031 where num_poliza = '1930000001671';
select * from p2100170 where num_poliza = '1930000001671';
select * from p2000025 where num_poliza = '1930000001671';-- dv lista




-- BUZON DE RIESGOS EN EMISION
select * from s2000031 where trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy') 
and trunc(fec_efec_riesgo) = to_date('23/08/2022','dd/mm/yyyy'); 

--BUZON DE DATOS FIJOS EN EMISION
select * from s2000030 where trunc(fec_tratamiento) = to_date('23/08/2022','dd/mm/yyyy') 
and trunc(fec_efec_spto) = to_date('23/08/2022','dd/mm/yyyy'); 

ED_K_228_EMI_MASIVO;


select * from a2000010; --TABLA DE CONTRATOS ASOCIADOS A POLIZA GRUPO
select * from g2990001; --CONTRATOS
select * from g2990000 where cod_cia = 2 and cod_ramo = 228;--PARAMETOS DE CONTRATOS DE POLIZAS GRUPO

-- contrato 40000

select * from g2000510;
select * from A2000500;
SELECT * FROM A2000520;

Cotizacion DES= 2222800000093


SELECT * FROM P2000020 WHERE NUM_POLIZA = 2222800000093;
SELECT * FROM P2000040 WHERE NUM_POLIZA = 2222800000093;
SELECT * FROM P2000060 WHERE NUM_POLIZA = 2222800000093;

select * from g0009010_mgt where cod_estructura = 'ED_228_MIGRAC'; --DEFINICION DE ESTRUCTURAS - PARAMETROS GENERALES
select * from g0009020_mgt where cod_estructura = 'ED_228_MIGRAC'; --DETALLE DE LA ESTRUCTURA DE LOS ORIGENES DE DATOS
SELECT * FROM g0009030_mgt  where cod_estructura = 'ED_228_MIGRAC';-- PARA VER ERRORES -- TABLA DE CONTROL DE PROCESO EN CARGA DE DATOS A PARTIR DE UN ORIGEN DE DATOS dc_k_ap100910_mgt
