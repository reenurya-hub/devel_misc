prompt Importing table P2000031...
set feedback off
set define off

insert into P2000031 (COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, TIP_SPTO, COD_MODALIDAD, NOM_RIESGO, FEC_EFEC_RIESGO, FEC_VCTO_RIESGO, MCA_BAJA_RIESGO, MCA_VIGENTE, MCA_EXCLUSIVO, COD_USR_EXCLUSIVO, NUM_CERTIFICADO, NOM_CERTIFICADO, TXT_ID_RIESGO)
values (2, '2222800001010', 0, 0, 0, 1, 'XX', 99999, 'RIESGO NRO. 1', to_date('23-08-2022', 'dd-mm-yyyy'), to_date('23-08-2023', 'dd-mm-yyyy'), 'N', 'S', null, null, null, null, null);

prompt Done.
