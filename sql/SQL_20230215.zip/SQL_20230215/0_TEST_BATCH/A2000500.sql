-- POLIZAS A TRATAR EN LOS PROCESOS MASIVOS   
-- COD_CIA, NUM_POLIZA
-- NUM_ORDEN, TIP_AUTORIZA_CT, TIP_MVTO_BATCH, FEC_TRATAMIENTO
-- FEC_TRATAMIENTO, NUM_ORDEN, TIP_MVTO_BATCH, NUM_POLIZA_DEFINITIVO, COD_CIA
-- COD_CIA, COD_RAMO, NUM_POLIZA_GRUPO
SELECT * 
  FROM a2000500 a
 WHERE 1=1 
   AND TRUNC(a.fec_tratamiento) = TO_DATE('05/01/2023','DD/MM/YYYY') -- INDICE
   AND a.num_orden             = 0                                   -- INDICE
   AND a.tip_mvto_batch        = 3                                   -- INDICE
   AND a.cod_cia               = 1                                   -- INDICE
   AND a.cod_ramo              = 985--985                            -- INDICE
   AND a.num_poliza_grupo      = '9762022000830'                     -- INDICE
   AND a.num_poliza            = '9851989791068'                     -- INDICE (PROPUESTA)
   AND a.num_poliza_definitivo = '4135000090177'                     -- INDICE
;
