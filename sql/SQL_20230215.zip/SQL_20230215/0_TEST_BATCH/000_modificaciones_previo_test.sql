select * from a2000500 where num_poliza = '9856339836892' for update;
select * from a2000500 where num_poliza_grupo = '9762022000830'  for update;
update a2000500 set tip_situ = 1 where  num_poliza_grupo = '9762022000830';

select * from P2000030 where num_poliza = '9856339836892'

select * from P2000020 where num_poliza = '9856339836892'

select * from P2000031 where num_poliza = '9856339836892' for update;

select * from P1001331 where COD_DOCUM = '10499622812' for update;

4135000079677
;dc_k_terceros
dc_k_terceros.p_lee_con_poliza

select * from a1001331  where COD_DOCUM = '10499622812'  where num_poliza = '4135000079877';
em_k_batch
ultimo num_poliza_definitivo = 4135000080177--4135000079977--4135000079877,4135000079777

select * from a2000500 where  NUM_POLIZA_grupo = '9762022000830' for update;

select * from a2000500 where num_poliza = '9851987782089' for update;  -- actualizar tip_situ y la fecha

select * from P2000030 WHERE COD_CIA = 1 AND COD_RAMO = 985 
AND NUM_POLIZA_grupo = '9762022000830' for update; -- actualizar fechas (solo al inicio del dia)


select * from a2000520 where num_poliza = '9851987782089'; -- ver si hay errores

select * from a2000020  where num_poliza = '4135000080177' for update; --quitar el num_proposta
select * from a2000030  where num_poliza = '4135000080177' for update;--quitar el num_presupuesto

trp_xx_dl.EV_K_985_DV_VCR;
tron2000.em_k_ptd_gni
em_k_ptd_gni.f_lee_poliza_x_proposta

select * from P1001331 WHERE COD_CIA = 1 AND COD_DOCUM = '1001367000192' FOR UPDATE;
