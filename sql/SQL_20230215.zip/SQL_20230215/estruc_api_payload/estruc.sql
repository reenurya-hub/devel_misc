   l_num_poliza       VARCHAR2(13) := '9851987782089';--'9851989771030';
   l_num_poliza_grupo VARCHAR2(13) := '9762022000830';

SELECT * FROM P1001331 WHERE COD_CIA = 1 AND TIP_DOCUM =  'CPF' AND COD_DOCUM = '7897493865' AND trunc(fec_tratamiento) = trunc(sysdate);
SELECT * FROM P1001331 WHERE COD_CIA = 1 AND TIP_DOCUM =  'CPF' AND COD_DOCUM = '7897493865';
   SELECT * FROM P2000060 WHERE NUM_POLIZA = '9851987782089';
SELECT * FROM A2000500 WHERE NUM_POLIZA    = '9851987782089';
   SELECT * FROM P2000040 WHERE NUM_POLIZA = '9851987782089';

{
    "addressInsured": {
        "address": "Rua do Espinheiro",
        "addressComplement": "Centro",
        "addressNumber": "157",
        "cep": "52020213",
        "email": "htgtcl@gmail.com",
        "phoneNumber": "(011) 998425879"
    },      
    "financialResponsible": {--SELECT * FROM P1001331 WHERE COD_CIA = 1 AND TIP_DOCUM =  'CPF' AND COD_DOCUM = '26885116882' AND trunc(fec_tratamiento) = trunc(sysdate);
        "cpfCnpjNumber": "26885116882",                                    P1001331.TIP_DOCUM(VALIDANDO NUMERO) Y P1001331.COD_DOCUM
        "nameFinancialResponsible": "JOAO FRANCISCO DE SOUSA"              P1001331.NOM_TERCERO
        "agencyNumber": "4919",                                            P1001331.COD_OFICINA
        "bankNumber": 748,                                                 P1001331.COD_ENTIDAD
        "accountNumber": "02901",                                          P1001331.CTA_CTE
        "checkDigit": "9",                                                 P1001331.CTA_DC
    },
    "insured": {-- SELECT * FROM P1001331 WHERE COD_CIA = 1 AND TIP_DOCUM =  'CGC' AND COD_DOCUM = '7897493865' AND trunc(fec_tratamiento) = trunc(sysdate);
        "birthDate": "26/01/1962",                                         P1001331.FEC_NACIMIENTO
        "career": "1634",                                                  P1001331.COD_PROFESION
        "cpf": "7897493865",                                               P1001331.COD_DOCUM
        "name": "JOAO FRANCISCO DE SOUSA",                                 P1001331.NOM_TERCERO
        "nationality": "B"                                                 P1001331.COD_NACIONALIDAD
    },

        
        
        
        "checkDigit": "9",
