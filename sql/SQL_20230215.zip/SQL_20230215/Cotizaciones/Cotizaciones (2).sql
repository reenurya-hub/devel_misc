-- tabla cotizaciones
select * from c2000000;
