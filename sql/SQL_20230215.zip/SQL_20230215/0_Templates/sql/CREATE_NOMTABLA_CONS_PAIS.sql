DECLARE
   --
   CURSOR c_cursor_t
   IS
      SELECT COUNT (*)
        FROM all_tab_columns t
       WHERE UPPER(t.table_name) = UPPER('NOM_TABLA');
   --
   CURSOR c_cursor_i
   IS
      SELECT COUNT (*)
        FROM all_indexes t
       WHERE UPPER(t.index_name) = UPPER('NOM_TABLA');
   --
   l_count            NUMBER        ;
   l_hacer            BOOLEAN       ;
   --
   l_drop_table       VARCHAR2(0030);
   l_create_table     VARCHAR2(6000);
   l_alter_pk         VARCHAR2(2000);
   --
   l_comentario_tabla VARCHAR2(2000);
   l_comentario_col01 VARCHAR2(2000);
   l_comentario_col02 VARCHAR2(2000);
   l_comentario_col03 VARCHAR2(2000);
   l_comentario_col04 VARCHAR2(2000);
   l_comentario_col05 VARCHAR2(2000);
   l_comentario_col06 VARCHAR2(2000);
   l_comentario_col07 VARCHAR2(2000);
   l_comentario_col08 VARCHAR2(2000);
   l_comentario_col09 VARCHAR2(2000);
   --
   l_drop_index       VARCHAR2(2000);
   --
BEGIN
   --
   -- Crear los scripts para la tablas
   --
   l_drop_table := 'DROP TABLE NOM_TABLA';
   l_drop_index := 'DROP INDEX NOM_TABLA';
   --
   l_create_table := 'CREATE TABLE NOM_TABLA (COD_CIA      NUMBER(2)   NOT NULL,' || CHR (13) ||
                     '                        COLOM_UNO    TIPO_DATO           ,' || CHR (13) ||
                     '                        COLOM_DOS    TIPO_DATO   NOT NULL,' || CHR (13) ||
                     '                        COLOM_TRES   TIPO_DATO           ,' || CHR (13) ||
                     '                        COLOM_CUATRO TIPO_DATO   NOT NULL,' || CHR (13) ||
                     '                        COLOM_CINCO  TIPO_DATO           ,' || CHR (13) ||
                     '                        MCA_INH      VARCHAR2(1) NOT NULL,' || CHR (13) ||
                     '                        COD_USR      VARCHAR2(8) NOT NULL,' || CHR (13) ||
                     '                        FEC_ACTU     DATE        NOT NULL)'               ;
   --
   l_alter_pk := 'ALTER TABLE NOM_TABLA ADD PRIMARY KEY (COD_CIA  ,' || CHR (13) ||
                 '                                       COLOM_UNO,' || CHR (13) ||
                 '                                       COLOM_DOS)'               ;
   --
   l_comentario_tabla := 'COMMENT ON TABLE  NOM_TABLA              IS ''DESCRIPCION DE LA TABLA (PARA QUE ES O QUE INFORMACION TENDRA'''                                                     ;
   l_comentario_col01 := 'COMMENT ON COLUMN NOM_TABLA.COD_CIA      IS ''CODIGO DE LA COMPANIA'''                                                                                             ;
   l_comentario_col02 := 'COMMENT ON COLUMN NOM_TABLA.COLOM_UNO    IS ''DESCRIPCION DEL CAMPO UNO    (POSIBLES VALORES, O CUALQUIER COSA QUE PUEDA AYUDAR A SABER PARA QUE SIRVE EL CAMPO)''';
   l_comentario_col03 := 'COMMENT ON COLUMN NOM_TABLA.COLOM_DOS    IS ''DESCRIPCION DEL CAMPO DOS    (POSIBLES VALORES, O CUALQUIER COSA QUE PUEDA AYUDAR A SABER PARA QUE SIRVE EL CAMPO)''';
   l_comentario_col04 := 'COMMENT ON COLUMN NOM_TABLA.COLOM_TRES   IS ''DESCRIPCION DEL CAMPO TRES   (POSIBLES VALORES, O CUALQUIER COSA QUE PUEDA AYUDAR A SABER PARA QUE SIRVE EL CAMPO)''';
   l_comentario_col05 := 'COMMENT ON COLUMN NOM_TABLA.COLOM_CUATRO IS ''DESCRIPCION DEL CAMPO CUATRO (POSIBLES VALORES, O CUALQUIER COSA QUE PUEDA AYUDAR A SABER PARA QUE SIRVE EL CAMPO)''';
   l_comentario_col06 := 'COMMENT ON COLUMN NOM_TABLA.COLOM_CINCO  IS ''DESCRIPCION DEL CAMPO CINCO  (POSIBLES VALORES, O CUALQUIER COSA QUE PUEDA AYUDAR A SABER PARA QUE SIRVE EL CAMPO)''';
   l_comentario_col07 := 'COMMENT ON COLUMN NOM_TABLA.MCA_INH      IS ''INDICA SI EL REGISTRO O FILA ESTA INHABILITADA (DADA DE BAJA)'''                                                     ;
   l_comentario_col08 := 'COMMENT ON COLUMN NOM_TABLA.COD_USR      IS ''USUARIO QUE ACTUALIZA EL REGISTRO'''                                                                                 ;
   l_comentario_col09 := 'COMMENT ON COLUMN NOM_TABLA.FEC_ACTU     IS ''FECHA DE ACTUALIZACION DEL REGISTRO'''                                                                               ;
   --
   IF c_cursor_t%ISOPEN
   THEN
      --
      CLOSE c_cursor_t;
      --
   END IF;
   --
   l_hacer := TRUE;
   --
   WHILE l_hacer
   LOOP
      --
      OPEN c_cursor_t;
      -- 
      FETCH c_cursor_t INTO l_count;
      -- 
      CLOSE c_cursor_t;
      -- 
      IF l_count != 0
      THEN
         --
         EXECUTE IMMEDIATE l_drop_table;
         --
      ELSE
         --
         l_hacer := FALSE;
         --
      END IF;
      --
   END LOOP;
   --
   EXECUTE IMMEDIATE l_create_table    ;
   --
   EXECUTE IMMEDIATE l_alter_pk        ;
   --
   EXECUTE IMMEDIATE l_comentario_tabla;
   --
   EXECUTE IMMEDIATE l_comentario_col01;
   EXECUTE IMMEDIATE l_comentario_col02;
   EXECUTE IMMEDIATE l_comentario_col03;
   EXECUTE IMMEDIATE l_comentario_col04;
   EXECUTE IMMEDIATE l_comentario_col05;
   EXECUTE IMMEDIATE l_comentario_col06;
   EXECUTE IMMEDIATE l_comentario_col07;
   EXECUTE IMMEDIATE l_comentario_col08;
   EXECUTE IMMEDIATE l_comentario_col09;
   --
   OPEN c_cursor_i;
   -- 
   FETCH c_cursor_i INTO l_count;
   -- 
   CLOSE c_cursor_i;
   --
   IF l_count != 0
   THEN
      --
      EXECUTE IMMEDIATE l_drop_index;
      --
   END IF;
   --
END;
/
EXIT
