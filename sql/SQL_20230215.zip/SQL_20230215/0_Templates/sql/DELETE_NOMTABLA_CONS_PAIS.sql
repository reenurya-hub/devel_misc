DECLARE
   --
BEGIN
   --
   DELETE nom_tabla a
    WHERE a.cod_cia   = valor_cod_cia
      AND a.colom_uno = valor_colom_uno;
   --
EXCEPTION
   --
   WHEN OTHERS
   THEN
      --
      NULL;
      --
   --
END;
/
EXIT
