DECLARE
   --
   CURSOR lc_cursor (pc_nom_tabla all_tab_columns.table_name %TYPE,
                     pc_nom_campo all_tab_columns.column_name%TYPE)
   IS
      SELECT COUNT (*)
        FROM all_tab_columns t
       WHERE t.table_name  = pc_nom_tabla
         AND t.column_name = pc_nom_campo;
   --
   l_nom_campo       VARCHAR2(0100);
   l_nom_tabla       VARCHAR2(0100);
   l_alter_table_add VARCHAR2(1000);
   l_comentarios     VARCHAR2(1000);
   --
   l_count           NUMBER        ;
   --
BEGIN
   --
   l_nom_tabla := 'NOM_TABLA' ;
   l_nom_campo := 'NOM_CAMPO1';
   --
   l_alter_table_add := 'ALTER TABLE '          || l_nom_tabla ||
                        ' ADD '                 || l_nom_campo ||
                        ' DATE DEFAULT SYSDATE'                  ;
   --
   l_comentarios := 'COMMENT ON COLUMN '                                   || l_nom_tabla ||
                    '.'                                                    || l_nom_campo ||
                    ' IS ''DESCRIPCION DEL NUEVO CAMPO (PARA QUE SIRVE)'''                  ;
   --
   IF lc_cursor%ISOPEN
   THEN
      --
      CLOSE lc_cursor;
      --
   END IF;
   --
   OPEN lc_cursor (pc_nom_tabla => l_nom_tabla,
                   pc_nom_campo => l_nom_campo);
   --
   FETCH lc_cursor INTO l_count;
   --
   CLOSE lc_cursor;
   --
   IF l_count = 0
   THEN
      --
      EXECUTE IMMEDIATE l_alter_table_add;
      EXECUTE IMMEDIATE l_comentarios    ;
      --
   END IF;
   --
   l_nom_campo := 'NOM_CAMPO2';
   --
   -- Por si lleva valor por defecto
   l_alter_table_add := 'ALTER TABLE '               || l_nom_tabla ||
                        ' ADD '                      || l_nom_campo ||
                        ' VARCHAR2(1) DEFAULT ''N'''                  ;
   --
   l_comentarios := 'COMMENT ON COLUMN '                                   || l_nom_tabla ||
                    '.'                                                    || l_nom_campo ||
                    ' IS ''DESCRIPCION DEL NUEVO CAMPO (PARA QUE SIRVE)'''                  ;
   --
   IF lc_cursor%ISOPEN
   THEN
      --
      CLOSE lc_cursor;
      --
   END IF;
   --
   OPEN lc_cursor (pc_nom_tabla => l_nom_tabla,
                   pc_nom_campo => l_nom_campo);
   --
   FETCH lc_cursor INTO l_count;
   --
   CLOSE lc_cursor;
   --
   IF l_count = 0
   THEN
      --
      EXECUTE IMMEDIATE l_alter_table_add;
      EXECUTE IMMEDIATE l_comentarios    ;
      --
   END IF;
   --
END;
/
EXIT
