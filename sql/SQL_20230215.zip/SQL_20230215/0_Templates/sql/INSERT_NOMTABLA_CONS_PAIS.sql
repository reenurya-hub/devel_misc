DECLARE
   --
BEGIN
   --
   -- Se puede poner los DELETE de la tabla, por la llave primaria que se van a insertar a continuacion
   DELETE nom_tabla n
    WHERE n.pk = valor_pk;
   --
   BEGIN
      --
      INSERT INTO nom_tabla (cod_cia, colom_uno, colom_dos, colom_tres, colom_cuatro, colom_cinco, mca_inh, cod_usr, fec_actu)
                     VALUES (valor_cod_cia, valor_colom_uno, valor_colom_dos, valor_colom_tres, valor_colom_cuatro, valor_colom_cinco, 'N' (o 'S'),'INFORCOL', TRUNC(SYSDATE));
      --
   EXCEPTION
      --
      WHEN DUP_VAL_ON_INDEX
      THEN
         --
         NULL;
         --
      --
   END;
   --
   BEGIN
      --
      INSERT INTO nom_tabla (cod_cia, colom_uno, colom_dos, colom_tres, colom_cuatro, colom_cinco, mca_inh, cod_usr, fec_actu)
                     VALUES (valor_cod_cia, valor_colom_uno, valor_colom_dos, valor_colom_tres, valor_colom_cuatro, valor_colom_cinco, 'N' (o 'S'),'INFORCOL', TRUNC(SYSDATE));
      --
   EXCEPTION
      --
      WHEN DUP_VAL_ON_INDEX
      THEN
         --
         NULL;
         --
      --
   END;
   --
EXCEPTION
   --
   WHEN OTHERS
   THEN
      --
      NULL;
      --
   --
END;
/
EXIT
