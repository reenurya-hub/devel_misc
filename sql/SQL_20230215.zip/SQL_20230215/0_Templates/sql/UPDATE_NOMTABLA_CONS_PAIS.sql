DECLARE
   --
BEGIN
   --
   UPDATE nom_tabla a
      SET a.colom_cinco = valor_cambiar_colom_cinco,
          a.cod_usr     = 'INFORCOL'               ,
          a.fec_actu    = TRUNC(SYSDATE)
    WHERE a.cod_cia   = valor_cod_cia
      AND a.colom_uno = valor_colom_uno;
   --
EXCEPTION
   --
   WHEN OTHERS
   THEN
      --
      NULL;
      --
   --
END;
/
EXIT
