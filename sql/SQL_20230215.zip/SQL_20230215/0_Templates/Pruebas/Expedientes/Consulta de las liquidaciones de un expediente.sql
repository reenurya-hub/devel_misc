SELECT a00.*
  FROM a5021604 a04,
       a3001700 a00
 WHERE /*a04.mca_provisional = 'N'
   AND*/ a04.cod_cia         = 1
   AND a00.cod_cia         = a04.cod_cia
   AND a00.num_ord_pago    = a04.num_ord_pago
   AND a00.tip_docum       = a04.tip_docum
   AND a00.cod_docum       = a04.cod_docum
   --AND a00.fec_anu_liq     IS NULL
   --AND a00.fec_pago        IS NULL
   --AND a00.mca_provisional = a04.mca_provisional
   --AND a00.imp_liq         < 0
   --AND a00.num_sini        = ''
   --AND a00.cod_ramo        = 
   AND a00.num_sini        IN (SELECT a.num_sini
                                 FROM a7001000 a
                                WHERE a.mca_provisional = 'N'
                                  AND a.tip_est_exp     = 'P'
                                  --AND a.cod_ramo        = 
                                  AND a.tip_exp IN (SELECT g.tip_exp
                                                      FROM G7000090 g
                                                     WHERE g.mca_exp_recobro = 'N'
                                                       AND g.mca_positivo    = 'N'))
 ORDER BY a00.cod_ramo;