SELECT a.*
  FROM a7001000 a
 WHERE a.mca_provisional = 'N'
   AND a.tip_est_exp     = 'P'
   --AND a.num_sini        = ''
   --AND a.cod_ramo        = 
   AND a.tip_exp IN (SELECT g.tip_exp
                       FROM G7000090 g
                      WHERE g.mca_exp_recobro = 'N'
                        AND g.mca_positivo    = 'N');