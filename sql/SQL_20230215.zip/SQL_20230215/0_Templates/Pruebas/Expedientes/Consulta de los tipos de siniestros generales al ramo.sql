SELECT gr.cod_ramo       ,
       gr.tip_exp        ,
       gc.nom_exp        ,
       gc.mca_positivo   ,
       gc.mca_exp_recobro
  FROM G7000090 gc,
       G7000100 gr
 WHERE gc.mca_exp_recobro  = 'N'
   AND gc.mca_positivo     = 'N'
   AND gr.cod_cia          = gc.cod_cia
   AND gr.tip_exp          = gc.tip_exp
 ORDER BY gr.cod_ramo;
--
SELECT gr.*
  FROM G7000090 gc,
       G7000100 gr
 WHERE gc.mca_exp_recobro = 'N'
   AND gr.cod_cia         = gc.cod_cia
   AND gr.tip_exp         = gc.tip_exp
   --AND gr.cod_ramo        = 
 ORDER BY gr.cod_ramo;