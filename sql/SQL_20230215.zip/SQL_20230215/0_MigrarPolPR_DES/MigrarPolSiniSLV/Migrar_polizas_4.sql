DECLARE
   g_num_poliza a2000030.num_poliza%TYPE; --varchar2(20) :='0040000015093';--'0040000027834';
   g_dblink     VARCHAR2(20);

   TYPE typ_reg IS RECORD(
      tabla VARCHAR2(100),
      cant  NUMBER);
   reg typ_reg;
   --
   TYPE cur_typ IS REF CURSOR;
   c_query cur_typ;

   --Para buscar las tablas por ramo que tienen programas
   CURSOR c_tablas IS
      SELECT table_name,
             'SELECT ''' || table_name ||
             ''' tabla, COUNT(0) CANT  FROM tron2000.' || table_name ||
             '@tron_pro WHERE NUM_POLIZA=''' || g_num_poliza || '''' col_query
        FROM all_tab_columns@tron_pro
       WHERE owner = 'TRON2000'
         AND table_name NOT LIKE 'X%'
          AND table_name NOT LIKE 'R%'
         AND table_name NOT LIKE 'S%'
            --AND table_name NOT IN ('A9000030')
         AND table_name NOT LIKE 'REMOTO%'
         AND upper(column_name) = 'NUM_POLIZA'
         AND table_name IN (
                       SELECT object_name FROM all_objects WHERE object_type = 'TABLE'
                ) 
		 ;
   --
   CURSOR c_lista_polizas IS
   --
      SELECT DISTINCT num_poliza
        FROM a2000030@tron_pro
       --WHERE num_poliza_grupo = '8310101'
       WHERE num_poliza = '3012100000204';
   --
   CURSOR c_cod_docum IS
      SELECT cod_docum
        FROM a2000060@tron_pro
       WHERE num_poliza = g_num_poliza
      UNION
      SELECT cod_docum
        FROM a2000030@tron_pro
       WHERE num_poliza = g_num_poliza;
   --
   vcdelete   VARCHAR2(1000);
   vcupdate   VARCHAR2(1000);
   vcsql      VARCHAR2(1000);
   vcinstr    VARCHAR2(1000);
   vcerror    VARCHAR2(1000);
   l_hora_ini VARCHAR2(100);
   l_hora_fin VARCHAR2(100);
   --
BEGIN

   dbms_output.put_line('Inicio:::');

   FOR pol IN c_lista_polizas LOOP
   
      g_num_poliza := pol.num_poliza;
   
      dbms_output.put_line('g_num_poliza: ' || g_num_poliza);
   
      FOR tab IN c_tablas LOOP
         vcupdate := NULL;
         vcinstr  := tab.col_query;
         OPEN c_query FOR tab.col_query;
         FETCH c_query
            INTO reg;
         --dbms_Output.put_Line( ' Tabla: ' || reg.tabla || ' Cant: ' || reg.cant );
         IF reg.cant <> 0 THEN
            l_hora_ini := to_char(SYSDATE, 'DDMMYYYY HH24:MI:SS');
            --dbms_Output.put_Line( ' Tabla: ' || reg.tabla || ' Cant: ' || reg.cant );
            IF reg.tabla = 'A2990700' THEN
               vcsql := 'DELETE A2990700 WHERE NUM_RECIBO IN (SELECT NUM_RECIBO FROM A2990700@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               EXECUTE IMMEDIATE vcsql;
            ELSIF reg.tabla = 'A9000030' THEN
               vcsql := 'DELETE A9000030 WHERE NUM_RECIBO IN (SELECT NUM_RECIBO FROM A9000030@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               EXECUTE IMMEDIATE vcsql;
            ELSIF reg.tabla = 'A5029650' THEN
               vcsql := 'DELETE a5029650 WHERE (NUM_DOCTO_INTERNO) IN (SELECT NUM_DOCTO_INTERNO FROM A5029650@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               EXECUTE IMMEDIATE vcsql;
            ELSIF reg.tabla = 'A5020301' THEN
               vcsql := 'DELETE A5020301 WHERE NUM_RECIBO IN (SELECT to_char(NUM_RECIBO) FROM A5020301@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               EXECUTE IMMEDIATE vcsql;
            ELSIF reg.tabla = 'A5021800' THEN
               vcsql := 'DELETE A5021800 WHERE NUM_CRUCE IN (SELECT to_char(NUM_RECIBO) FROM A2990700@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               EXECUTE IMMEDIATE vcsql;
               --
               vcsql := 'INSERT INTO a5021800 ' ||
                        'SELECT * FROM a5021800@tron_pro WHERE num_cruce IN ' ||
                        '(SELECT to_char(NUM_RECIBO) FROM A2990700@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               --
               EXECUTE IMMEDIATE vcsql;
               --
            ELSIF reg.tabla = 'A5021801' THEN
               vcsql := 'DELETE A5021801 WHERE NUM_CRUCE IN (SELECT to_char(NUM_RECIBO) FROM A2990700@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               EXECUTE IMMEDIATE vcsql;
               --
               vcsql := 'INSERT INTO a5021801 ' ||
                        'SELECT * FROM a5021801@tron_pro WHERE num_cruce IN ' ||
                        '(SELECT to_char(NUM_RECIBO) FROM A2990700@tron_pro WHERE NUM_POLIZA = ''' ||
                        pol.num_poliza || ''')';
               --
               EXECUTE IMMEDIATE vcsql;
               --
            END IF;
         
            --Genera los Delete
            BEGIN
               vcdelete := 'delete ' || reg.tabla || ' WHERE num_poliza=''' ||
                           g_num_poliza || '''';
               --dbms_Output.put_Line(vcDelete);
               EXECUTE IMMEDIATE vcdelete;
               COMMIT;
            
               --Genera los insert
            
               vcupdate := 'Insert into ' || reg.tabla ||
                           ' select * from tron2000.' || reg.tabla ||
                           '@tron_pro WHERE num_poliza=''' || g_num_poliza || '''';
               --dbms_Output.put_Line('-- Insert a '|| reg.tabla ||' realizado con exito.  Cant: '||reg.cant);
               --dbms_Output.put_Line(vcUpdate);
               BEGIN
                  --
                  vcinstr := NULL;
                  EXECUTE IMMEDIATE vcupdate;
                  --
               EXCEPTION
                  WHEN OTHERS THEN
                     --
                     vcinstr := ' - Error :: ' || SQLERRM;
                     --
               END;
               COMMIT;
               --
            EXCEPTION
               WHEN OTHERS THEN
                  vcinstr := ' - Error :: ' || SQLERRM;
            END;
         
            --Genera los select despues de ralizar el DML 
            --vcInstr := 'select * from ' || reg.tabla || ' WHERE num_poliza='||g_num_poliza||';';
            --dbms_Output.put_Line(vcInstr);
            l_hora_fin := to_char(SYSDATE, 'DDMMYYYY HH24:MI:SS');
            dbms_output.put_line(' Tabla: ' || RPAD(reg.tabla,20,' ') || ' Cant: ' ||
                                 RPAD(reg.cant,6,' ') || ' Seg: ' ||
                                 to_char(round((to_date(l_hora_fin,
                                                        'ddmmyyyy hh24:mi:ss') -
                                               to_date(l_hora_ini,
                                                        'ddmmyyyy hh24:mi:ss')) *
                                               (60 * 60 * 24),
                                               2)) || vcinstr);
            --
         ELSE
            --
            --dbms_Output.put_Line( ' Tabla: ' || RPAD(reg.tabla,20,' ') || ' NO ' );
            NULL;
            --
         END IF;
         CLOSE c_query;
      END LOOP;
   
      COMMIT;
      --
      l_hora_ini := to_char(SYSDATE, 'DDMMYYYY HH24:MI:SS');
      DELETE a5021800
       WHERE num_cruce IN (SELECT to_char(num_recibo)
                             FROM a2990700@tron_pro
                            WHERE num_poliza = g_num_poliza);
      INSERT INTO a5021800
         SELECT *
           FROM a5021800@tron_pro
          WHERE num_cruce IN
                (SELECT to_char(num_recibo)
                   FROM a2990700@tron_pro
                  WHERE num_poliza = g_num_poliza);
      --
      DELETE a5021801
       WHERE num_cruce IN (SELECT to_char(num_recibo)
                             FROM a2990700@tron_pro
                            WHERE num_poliza = g_num_poliza);
      INSERT INTO a5021801
         SELECT *
           FROM a5021801@tron_pro
          WHERE num_cruce IN
                (SELECT to_char(num_recibo)
                   FROM a2990700@tron_pro
                  WHERE num_poliza = g_num_poliza);
      --  
      l_hora_fin := to_char(SYSDATE, 'DDMMYYYY HH24:MI:SS');
      dbms_output.put_line(' Delete 1800 y 1801 Seg: ' ||
                           to_char((to_date(l_hora_fin,
                                            'ddmmyyyy hh24:mi:ss') -
                                   to_date(l_hora_ini,
                                            'ddmmyyyy hh24:mi:ss')) *
                                   (60 * 60 * 24)));
      l_hora_ini := to_char(SYSDATE, 'DDMMYYYY HH24:MI:SS');
      --
      FOR cod_ter IN c_cod_docum LOOP
      BEGIN
         dbms_output.put_line('TERCERO: '||cod_ter.cod_docum);
         DELETE a1001399 WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
     dbms_output.put_line('TERCERO 1: '||cod_ter.cod_docum);
         INSERT INTO a1001399
           SELECT *
              FROM a1001399@tron_pro
             WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
      dbms_output.put_line('TERCERO 2: '||cod_ter.cod_docum);
      EXCEPTION
      WHEN OTHERS
      THEN
       dbms_output.put_line('Error Tercero: '||cod_ter.cod_docum);
      END;
      BEGIN
         DELETE a1001331 WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
      
         INSERT INTO a1001331
            SELECT *
              FROM a1001331@tron_pro
             WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
      EXCEPTION
      WHEN OTHERS
      THEN
       dbms_output.put_line('Error Tercero: '||cod_ter.cod_docum);
      END;
      BEGIN
         DELETE a1001390 WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
      
         INSERT INTO a1001390
            SELECT *
              FROM a1001390@tron_pro
             WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
      EXCEPTION
      WHEN OTHERS
      THEN
       dbms_output.put_line('Error Tercero: '||cod_ter.cod_docum);
      END;
      BEGIN 
         DELETE a1002201 WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
      
         INSERT INTO a1002201
            SELECT *
              FROM a1002201@tron_pro
             WHERE cod_docum = cod_ter.cod_docum;
         COMMIT;
       EXCEPTION
      WHEN OTHERS
      THEN
       dbms_output.put_line('Error Tercero: '||cod_ter.cod_docum);
      END;
      
      END LOOP;
      l_hora_fin := to_char(SYSDATE, 'DDMMYYYY HH24:MI:SS');
      dbms_output.put_line(' Terceros Seg: ' ||
                           to_char((to_date(l_hora_fin,
                                            'ddmmyyyy hh24:mi:ss') -
                                   to_date(l_hora_ini,
                                            'ddmmyyyy hh24:mi:ss')) *
                                   (60 * 60 * 24)));
   
   END LOOP;
   dbms_output.put_line('Fin:::');
/*EXCEPTION
   WHEN OTHERS THEN
      raise_application_error(-20000, vcinstr || ' Error: ' || SQLERRM);*/
END;

/*
select * from a7000900 where num_poliza=0040000024704;
*/

--select * from A5029650@tron_paralelo where num_poliza in ('0040000000452');
