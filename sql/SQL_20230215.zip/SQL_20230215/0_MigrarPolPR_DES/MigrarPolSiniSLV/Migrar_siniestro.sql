DECLARE
   --
   TYPE cv_results IS REF CURSOR; 
   --
   g_table_name  VARCHAR2(100)  ;
   l_anx_mensaje VARCHAR2(1000) ;
   l_column      VARCHAR2(20000);
   l_delete      VARCHAR2(20000);
   l_query       VARCHAR2(20000);
   --
   l_num NUMBER;
   --
   CURSOR lc_tables
   IS
      SELECT table_name
        FROM all_tab_columns 
       WHERE column_name LIKE '%NUM_SINI%' 
         AND table_name NOT LIKE '%X%'
         AND table_name NOT LIKE '%P%'
         AND table_name NOT LIKE '%S%';
   --
   CURSOR lc_columns 
   IS
      SELECT column_name
        FROM all_tab_columns
       WHERE table_name = g_table_name
       ORDER BY column_id ASC;
   --
   CURSOR lc_siniestros
   IS
      SELECT *
        FROM a7000900@tron_pro
       WHERE num_poliza = '&NUM_POLIZA';
BEGIN
   --
   FOR sini IN lc_siniestros
   LOOP
      --
      FOR tabla IN lc_tables
      LOOP
         --
         l_query := 'INSERT INTO ';
         --
         g_table_name := tabla.table_name;
         --
         l_query := l_query||tabla.table_name||' (';
         --
         FOR column IN lc_columns
         LOOP
            --
            l_column := l_column||column.column_name||', ';
            --
         END LOOP;
         --
         l_num := LENGTH(l_column) - 2;
         --
         l_column := SUBSTR(l_column, 1, l_num);
         --
         l_query := l_query||l_column||') SELECT * FROM '||tabla.table_name||'@tron_pro WHERE num_sini = '||sini.num_sini;
         --
         l_delete := 'DELETE * FROM '||tabla.table_name||' WHERE num_sini = '||sini.num_sini;
         --
         BEGIN 
            --
            BEGIN
               --
               EXECUTE IMMEDIATE l_delete;
               --
            EXCEPTION
            WHEN OTHERS
            THEN
               --
               NULL;
               --
            END;
            --
            EXECUTE IMMEDIATE l_query;
            --
            dbms_output.put_line('TABLA ACTUALIZADA => '||g_table_name);
            --
         EXCEPTION
         WHEN OTHERS
         THEN
            --
            l_anx_mensaje := SQLERRM;
            dbms_output.put_line('TABLA NO ACTUALIZADA => '||g_table_name||' SQLERRM => '||l_anx_mensaje);
            --
         END;
         --
         l_query  := NULL;
         l_column := NULL;
         --
      END LOOP;
      --
   END LOOP;
   --
END;
