SELECT * FROM a7001000@preprod WHERE fec_aper_exp > to_date('15/11/2022','dd/mm/yyyy');
SELECT * FROM a3001700@preprod WHERE num_sini =301220000003147;



SELECT * FROM TRON2000.C2000030
