-- COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, COD_CLAUSULA, NUM_SECU   PK
-- LINEAS DE CLAUSULAS CON TEXTO VARIABLE DE LA POLIZA
SELECT a.*
  FROM a2990320 a
 WHERE 1=1
   AND a.cod_cia = 7
   AND a.num_poliza       = '2282200000112'
   AND a.num_spto         = 0
   AND a.num_apli         = 0
   AND a.num_spto_apli    = 0
   AND a.num_riesgo       = 1
   AND a.cod_clausula     = 'TRON228-001'
   AND a.num_secu         = 3
   -- AND a.txt_clausula    = a.txt_clausula
;
