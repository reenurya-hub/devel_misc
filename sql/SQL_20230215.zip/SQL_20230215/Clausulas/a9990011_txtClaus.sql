-- COD_CLAUSULA, NUM_SECU, FEC_EDICION    -- PK
-- TEXTOS DE CLAUSULAS
SELECT a.*
  FROM a9990011 a
 WHERE 1=1
   AND a.cod_clausula        = 'TRON228-001'                         -- PK
   AND a.num_secu            = 1                                     -- PK
   AND TRUNC(a.fec_edicion)  = TO_DATE('02/06/2020','DD/MM/YYYY')    -- PK
   -- AND a.txt_clausula     = a.txt_clausula                        
   -- AND a.mca_txt_variable = a.mca_txt_variable
;
