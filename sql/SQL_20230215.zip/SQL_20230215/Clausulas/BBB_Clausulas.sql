SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 ORDER BY TIP_NIVEL, NUM_SECU;
TRON2000.EA_K_231_CLA_VCR
EA_K_231_CLA_VCR.P_V_CGAUTO029

-- Clausula defenicion
SELECT * FROM a9990010 a
where not exists (select * from a9990015 b where b.cod_cia = 1 and b.cod_ramo = 231 and b.cod_clausula = a.cod_clausula) ;
-- Clausula Textos Definicion
SELECT * FROM a9990011 a
where exists (select * from a9990015 b where b.cod_cia = 1 and b.cod_ramo = 231 and b.cod_clausula = a.cod_clausula) ;
-- Clausulas Ramo - Definicion
SELECT b.nom_clausula, a.* FROM a9990015 a, a9990010 b where cod_cia = 1 and cod_ramo = 231
and a.cod_clausula = b.cod_clausula;
-- Clausulas Poliza Grupo - Definicion
SELECT * FROM g2990031 a ;---> a9990015
-- Clausulas pol individual - Real
SELECT * FROM a2000265 a ;
-- Clausulas Textos Pol Individual - Real
SELECT * FROM a2990320 a ;
-- Clausulas pol grupo - Real
SELECT * FROM a2000015 a ; ---> a2000265
-- Clausulas Textos Pol Grupo - Real
SELECT * FROM a2000016 a ; ---> a2990320
-- hojas anexas Pol Grupo
SELECT * FROM RL_PLY_NWT_XX_GPP_ANX a;
-- buzon hojas anexas Pol Grupo Y RIESGO
SELECT * FROM ML_PLY_NWT_XX_GPP_ANX a;
