-- COD_CIA, COD_RAMO, COD_CLAUSULA, FEC_VALIDEZ
-- CLAUSULAS DEL RAMO
SELECT a.*
  FROM a9990015 a
 WHERE a.cod_cia             = 7
   AND a.cod_ramo            = 228
   AND a.cod_clausula        = 'TRON228-001'
   AND TRUNC(a.fec_validez)  = TO_DATE('01/01/2018','DD/MM//YYYY')
   -- AND a.num_secu         = a.num_secu
   -- AND a.cod_cob          = a.cod_cob
   -- AND a.nom_prg          = a.nom_prg
   -- AND a.cod_usr          = a.cod_usr
   -- AND a.fec_actu         = a.fec_actu
   -- AND a.tip_act_clausula = a.tip_act_clausula
   -- AND a.mca_inh          = a.mca_inh
   -- AND a.mca_imprimible   = a.mca_imprimible
;
