package mapfre.mgt.gc;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import mapfre.trn.*;
import mapfre.com.c.GUI.*;
import mapfre.trn.saptron.*;

/** 
* Mantenimiento de la Tabla:A5029650
*/

//Escriba su c�digo entre los comentarios TG_IMP
//<<TG_IMP
//>>TG_IMP

// [JAVADOC] 

public class AP502931_MGT extends mapfre.com.c.GUI.TDialogQuery 
{
	//Escriba su c�digo entre los comentarios TG_CBC
	//<<TG_CBC
	//>>TG_CBC

	public AP502931_MGT()
	{
		super();
		init();
	} // Fin de la constructora

	public AP502931_MGT(Frame f)
	{
		super(f);
		init();
	}

	public AP502931_MGT(Dialog d)
	{
		super(d);
		init();
	}


		/** El siguiente c�digo se genera autom�ticamente por Visual Cafe al <br>
		 * a�adir componentes al entorno visual. A partir del mismo se crean <br>
		 * ejemplares e inicializan componentes. Para modificarlo , use solo  <br>
		 * sintaxis que concuerde con lo que Visual Cafe pueda generar, o el  <br>
		 * sistema podr�a verse incapaz de analizar el archivo java dentro del entorno visual <br>
		 */ 
	public void init()
	{
		//{{INIT_CONTROLS
		setMetodoInicio(this,"");
		setAutoCommit(false);
		setDatosPrograma("AP502931_MGT, 1.0, Genoma");
		getContentPane().setLayout(new BorderLayout(0,0));
		setSize(794,545);
		setVisible(false);
		pnlBarrasHerramientas.setMetodoTeclas(this,"null");
		pnlBarrasHerramientas.setLayout(new FlowLayout(FlowLayout.LEFT,5,2));
		getContentPane().add(BorderLayout.NORTH, pnlBarrasHerramientas);
		brhGeneral.setBotonesDefecto("DatosBHGeneral");
		brhGeneral.setLayout(new FlowLayout(FlowLayout.LEFT,5,5));
		pnlBarrasHerramientas.add(brhGeneral);
		brhGeneral.setBackground(java.awt.Color.lightGray);
		brhMantenimientoEdicion.setBotonesDefecto("DatosBHMantenimientoEdicion");
		brhMantenimientoEdicion.setLayout(new FlowLayout(FlowLayout.LEFT,5,5));
		pnlBarrasHerramientas.add(brhMantenimientoEdicion);
		pnlGeneral.setMetodoTeclas(this,"null");
		pnlGeneral.setLayout(new BorderLayout(0,0));
		getContentPane().add(BorderLayout.CENTER, pnlGeneral);
		scrGeneral.setOpaque(true);
		pnlGeneral.add(BorderLayout.CENTER, scrGeneral);
		pnlGeneral1.setLayout(new BorderLayout(0,0));
		scrGeneral.getViewport().add(pnlGeneral1);
		pnlGeneral1.setBounds(0,0,791,500);
		pnlQuery.setMetodoPrePanel(this,"prePnlQuery");
		pnlQuery.setMetodoTeclas(this,"teclasFuncionPnlQuery");
		pnlQuery.setBorder(ttlSinTitulo);
		pnlQuery.setOpaque(false);
		pnlQuery.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		pnlGeneral1.add(BorderLayout.NORTH, pnlQuery);
		pnlQuery0.setMetodoTeclas(this,"null");
		pnlQuery0.setAlignmentX(0.498361F);
		pnlQuery0.setOpaque(false);
		pnlQuery0.setLayout(new BoxLayout(pnlQuery0,BoxLayout.Y_AXIS));
		pnlQuery.add(pnlQuery0);
		pnlQueryInfo0.setOpaque(false);
		pnlQueryInfo0.setLayout(new FlowLayout(FlowLayout.LEFT,5,1));
		pnlQuery0.add(pnlQueryInfo0);
		pnlQueryInfo0.add(lblQueryFechaHasta);
		pnlQueryInfo0.add(txtQueryFechaHasta);
		lblQueryFechaHasta.setAnchura(100);
		lblQueryFechaHasta.setModuloCodigo("trn,736");
		txtQueryFechaHasta.setNombreCampo("FechaHasta");
		txtQueryFechaHasta.setMascaraFecha("dd-MM-yyyy");
		txtQueryFechaHasta.setTipoDato("FECHA");
		txtQueryFechaHasta.setLongitud("15,15");
		txtQueryFechaHasta.setFuncionValidacion("GC_K_AP502931_MGT.p_v_fec_hasta(2)");
		txtQueryFechaHasta.setMetodoPreValidacion(this,"preValTxtQueryFecHasta");
		txtQueryFechaHasta.setPanelGrupo(pnlQuery);
		txtQueryFechaHasta.setToolTip("trn,736");
		txtQueryFechaHasta.setTipoAnchura("TABLA");
		txtQueryFechaHasta.setValidaNulo(false);
		pnlQueryInfo1.setOpaque(false);
		pnlQueryInfo1.setLayout(new FlowLayout(FlowLayout.LEFT,5,1));
		pnlQuery0.add(pnlQueryInfo1);
		pnlQueryInfo1.add(lblQueryTipDocto);
		pnlQueryInfo1.add(txtQueryTipDocto);
		lblQueryTipDocto.setAnchura(100);
		lblQueryTipDocto.setModuloCodigo("ts,1054");
		txtQueryTipDocto.setNombreCampo("TipDocto");
		txtQueryTipDocto.setTipoDato("TEXTO");
		txtQueryTipDocto.setLongitud("2,2");
		txtQueryTipDocto.setListaVal("A5021620,6");
		txtQueryTipDocto.setFuncionValidacion("GC_K_AP502931_MGT.p_v_tip_docto(1)");
		txtQueryTipDocto.setMetodoPreValidacion(this,"preValTxtQueryTipDocto");
		txtQueryTipDocto.setPanelGrupo(pnlQuery);
		txtQueryTipDocto.setToolTip("ts,1054");
		txtQueryTipDocto.setTipoAnchura("TABLA");
		txtQueryTipDocto.setValidaNulo(false);
		pnlQueryInfo1.add(lblQueryNumDocto);
		pnlQueryInfo1.add(txtQueryNumDocto);
		lblQueryNumDocto.setAnchura(100);
		lblQueryNumDocto.setModuloCodigo("ts,1055");
		txtQueryNumDocto.setNombreCampo("NumDocto");
		txtQueryNumDocto.setTipoDato("TEXTO");
		txtQueryNumDocto.setLongitud("19,20");
		txtQueryNumDocto.setFuncionValidacion("GC_K_AP502931_MGT.p_v_num_docto(1)");
		txtQueryNumDocto.setMetodoPreValidacion(this,"preValTxtQueryNumDocto");
		txtQueryNumDocto.setPanelGrupo(pnlQuery);
		txtQueryNumDocto.setToolTip("ts,1055");
		txtQueryNumDocto.setTipoAnchura("TABLA");
		txtQueryNumDocto.setValidaNulo(false);
		pnlQueryInfo2.setOpaque(false);
		pnlQueryInfo2.setLayout(new FlowLayout(FlowLayout.LEFT,5,1));
		pnlQuery0.add(pnlQueryInfo2);
		pnlQueryInfo2.add(lblQueryNumPoliza);
		pnlQueryInfo2.add(txtQueryNumPoliza);
		lblQueryNumPoliza.setAnchura(100);
		lblQueryNumPoliza.setModuloCodigo("gc,797");
		txtQueryNumPoliza.setNombreCampo("NumDocto");
		txtQueryNumPoliza.setTipoDato("TEXTO");
		txtQueryNumPoliza.setLongitud("16,20");
		txtQueryNumPoliza.setFuncionValidacion("GC_K_AP502931_MGT.p_v_num_poliza(1)");
		txtQueryNumPoliza.setMetodoPreValidacion(this,"preValTxtQueryNumPoliza");
		txtQueryNumPoliza.setPanelGrupo(pnlQuery);
		txtQueryNumPoliza.setToolTip("gc,797");
		txtQueryNumPoliza.setTipoAnchura("TABLA");
		txtQueryNumPoliza.setValidaNulo(false);
		pnlQueryInfo2.add(lblQueryNumRecibo);
		pnlQueryInfo2.add(txtQueryNumRecibo);
		lblQueryNumRecibo.setAnchura(100);
		lblQueryNumRecibo.setModuloCodigo("gc,85");
		txtQueryNumRecibo.setNombreCampo("NumDocto");
		txtQueryNumRecibo.setTipoDato("TEXTO");
		txtQueryNumRecibo.setLongitud("5,11");
		txtQueryNumRecibo.setFuncionValidacion("GC_K_AP502931_MGT.p_v_num_recibo(1)");
		txtQueryNumRecibo.setMetodoPreValidacion(this,"preValTxtQueryNumRecibo");
		txtQueryNumRecibo.setPanelGrupo(pnlQuery);
		txtQueryNumRecibo.setToolTip("gc,85");
		txtQueryNumRecibo.setTipoAnchura("TABLA");
		txtQueryNumRecibo.setValidaNulo(false);
		pnlQueryInfo3.setOpaque(false);
		pnlQueryInfo3.setLayout(new FlowLayout(FlowLayout.RIGHT,5,1));
		pnlQuery0.add(pnlQueryInfo3);
		sprConsultar.setPixelsSeparacion(0);
		pnlQueryInfo3.add(sprConsultar);
		btnConsultar.setMetodoAccion(this,"accionBtnConsultar");
		btnConsultar.setModuloCodigo("trn,22");
		btnConsultar.setActionCommand("Consultar");
		pnlQueryInfo3.add(btnConsultar);
		pnlDatos.setMetodoPrePanel(this,"prePnlDatos");
		pnlDatos.setMetodoTeclas(this,"teclasFuncionPnlDatos");
		pnlDatos.setOpaque(false);
		pnlDatos.setLayout(new BorderLayout(0,0));
		pnlGeneral1.add(BorderLayout.CENTER, pnlDatos);
		pnlDatos1.setOpaque(false);
		pnlDatos1.setLayout(new BorderLayout(0,0));
		pnlDatos.add(BorderLayout.CENTER, pnlDatos1);
		pnlTabla.setMetodoTeclas(this,"null");
		pnlTabla.setOpaque(false);
		pnlTabla.setLayout(new GridBagLayout());
		pnlDatos1.add(BorderLayout.CENTER, pnlTabla);
	    tblTabla.setMetodoMarcar(this, "marcarDesmarcar");
		tblTabla.setMetodoCambio(this,"cambioRegTblTabla");
		tblTabla.setMetodoTeclas(this,"teclasFunciontblTabla");
	    tblTabla.setCargarTodos(true);
	    tblTabla.setPermiso(true);
		tblTabla.setMetodoPreConsulta(this,"preConsultaTblTabla");
		tblTabla.setMetodoBorrar(this,"preBorradoRegTblTabla");
		tblTabla.setMetodoPreAlta(this,"preAltaRegTblTabla");
		tblTabla.setMetodoPreModificacion(this,"preModificacionRegTblTabla");
		tblTabla.setFuncionGrabar("p_graba");
	    tblTabla.setObjetoPosterior(this.tblTabla);
		tblTabla.setFuncionPreModificacion("p_modifica(2)");
		//tblTabla.setFuncionModificacion("p_actualiza(7)");
		tblTabla.setFuncionConsultar("p_query(7)");
		//tblTabla.setFuncionActualizar("p_actualiza(7)");
		tblTabla.setFuncionPreActualizar("p_alta(1)");
		tblTabla.setFuncionRecuperar("p_devuelve(11)");
		tblTabla.setFuncionBorrar("p_borra(2)");
		//tblTabla.setObjetoPosterior(pnlBotonAceptar);
		tblTabla.setTipoSeleccion("PRIMERO");
		tblTabla.setModoSeleccion("SOLO CONSULTA");
		tblTabla.setMultiregistro(true);
		tblTabla.setObjetoAnterior(pnlQuery0);
		tblTabla.setCodigoPackage("GC_K_AP502931_MGT");
		tblTabla.setLayout(new BoxLayout(tblTabla,BoxLayout.X_AXIS));
		pnlTabla.add(tblTabla, new com.symantec.itools.awt.GridBagConstraintsD(0,0,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.VERTICAL,new Insets(0,0,0,0),0,-275));
		
		clmNumPoliza.setReal(14);
		clmNumPoliza.setTipoDato("TEXTO");
		clmNumPoliza.setMayusculas(true);
		clmNumPoliza.setPosicion(1);
		clmNumPoliza.setModuloCodigo("gc,797");
		clmNumPoliza.setVisibleLong(15);
		tblTabla.add(clmNumPoliza);
		clmNumPoliza.setVisible(false);
		
		clmNumRecibo.setReal(12);
		clmNumRecibo.setTipoDato("NUMERICO");
		clmNumRecibo.setPosicion(2);
		clmNumRecibo.setModuloCodigo("gc,85");
		clmNumRecibo.setVisibleLong(7);
		tblTabla.add(clmNumRecibo);
		clmNumRecibo.setVisible(false);
		
		clmTipDocto.setReal(3);
		clmTipDocto.setTipoDato("TEXTO");
		clmTipDocto.setMayusculas(true);
		clmTipDocto.setPosicion(3);
		clmTipDocto.setModuloCodigo("ts,1054");
		clmTipDocto.setVisibleLong(3);
		tblTabla.add(clmTipDocto);
		clmTipDocto.setVisible(false);
		
		clmNumDocto.setReal(21);
		clmNumDocto.setTipoDato("TEXTO");
		clmNumDocto.setMayusculas(true);
		clmNumDocto.setPosicion(4);
		clmNumDocto.setModuloCodigo("ts,1055");
		clmNumDocto.setVisibleLong(15);
		tblTabla.add(clmNumDocto);
		clmNumDocto.setVisible(false);
		
		clmImpTotal.setReal(23);
		clmImpTotal.setTipoDato("NUMERICO");
		clmImpTotal.setPosicion(5);
		clmImpTotal.setModuloCodigo("gc,122");
		clmImpTotal.setVisibleLong(8);
		clmImpTotal.setDecimalesDef(true);
		tblTabla.add(clmImpTotal);
		clmImpTotal.setVisible(false);
		
		clmFecDocto.setReal(9);
		clmFecDocto.setTipoDato("dd-MM-yyyy");
		clmFecDocto.setPosicion(6);
		clmFecDocto.setModuloCodigo("ts,1061");
		clmFecDocto.setVisibleLong(11);
		tblTabla.add(clmFecDocto);
		clmFecDocto.setVisible(false);
		
		clmCantDias.setReal(3);
		clmCantDias.setTipoDato("NUMERICO");
		clmCantDias.setPosicion(8);
		clmCantDias.setModuloCodigo("ts,1092");
		clmCantDias.setVisibleLong(17);
		tblTabla.add(clmCantDias);
		clmCantDias.setVisible(false);
		
		clmUsuario.setReal(9);
		clmUsuario.setTipoDato("TEXTO");
		clmUsuario.setPosicion(9);
		clmUsuario.setModuloCodigo("ts,855");
		clmUsuario.setVisibleLong(14);
		tblTabla.add(clmUsuario);
		clmUsuario.setVisible(false);
		
		pnlDetalle.setBorder(ttlSinTitulo);
		pnlDetalle.setOpaque(false);
		pnlDetalle.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		pnlDatos1.add(BorderLayout.SOUTH, pnlDetalle);
		pnlDetalle1.setAlignmentX(0.498442F);
		pnlDetalle1.setOpaque(false);
		pnlDetalle1.setLayout(new BoxLayout(pnlDetalle1,BoxLayout.Y_AXIS));
		pnlDetalle.add(pnlDetalle1);
		pnlDetalleInfo0.setOpaque(false);
		pnlDetalleInfo0.setLayout(new FlowLayout(FlowLayout.LEFT,5,1));
		pnlDetalle1.add(pnlDetalleInfo0);
		pnlBotonAceptar.setGrupoAnterior(pnlTabla);
		pnlBotonAceptar.setMetodoTeclas(this,"null");
		pnlBotonAceptar.setOpaque(false);
		pnlBotonAceptar.setLayout(new FlowLayout(FlowLayout.RIGHT,5,2));
		pnlDatos.add(BorderLayout.SOUTH, pnlBotonAceptar);
		btnListado.setMetodoAccion(this, "accionBtnListado");
	    btnListado.setModuloCodigo("co,175");
	    btnListado.setEnabled(false);
	    btnListado.setNextFocusableComponent(this.tblTabla);
	    pnlBotonAceptar.add(this.btnListado);
		btnAceptar.setMetodoAccion(this,"accionBtnAceptar");
		btnAceptar.setModuloCodigo("trn,188");
		btnAceptar.setActionCommand("Ramo");
		btnAceptar.setEnabled(false);
	    btnAceptar.setNextFocusableComponent(this.tblTabla);
		pnlBotonAceptar.add(btnAceptar);
		brsEstado.setLayout(new BorderLayout(0,0));
		getContentPane().add(BorderLayout.SOUTH, brsEstado);
		//$$ ttlSinTitulo.move(0,561);
		//}}

		this.setAutoCommit(true);
		setFuncionInicio("GC_K_AP502931_MGT.p_inicio");
		this.setMetodoInicio(this,"preDlgQuery");
		tblTabla.ajustaAncho(785);
		tblTabla.setMascara(AP502931_MGT.FECDOCTO,"dd-MM-yyyy");
		//Escriba su c�digo entre los comentarios TG_CNS
		//<<TG_CNS
		//>>TG_CNS
	} // Fin del m�todo init() 

	//{{DECLARE_CONTROLS
	mapfre.com.c.GUI.TPanel pnlBarrasHerramientas = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TBarraHerramientas brhGeneral = new mapfre.com.c.GUI.TBarraHerramientas();
	mapfre.com.c.GUI.TBarraHerramientas brhMantenimientoEdicion = new mapfre.com.c.GUI.TBarraHerramientas();
	mapfre.com.c.GUI.TPanel pnlGeneral = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TScrollPanel scrGeneral = new mapfre.com.c.GUI.TScrollPanel();
	mapfre.com.c.GUI.ImageTPanel pnlGeneral1 = new mapfre.com.c.GUI.ImageTPanel();
	mapfre.com.c.GUI.TPanel pnlQuery = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TPanel pnlQuery0 = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TPanel pnlDatos = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TPanel pnlDatos1 = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TPanel pnlTabla = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TPanel pnlDetalle = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TPanel pnlDetalle1 = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TPanel pnlBotonAceptar = new mapfre.com.c.GUI.TPanel();
	mapfre.com.c.GUI.TButton btnAceptar = new mapfre.com.c.GUI.TButton();
	mapfre.com.c.GUI.TButton btnListado = new mapfre.com.c.GUI.TButton();
	mapfre.com.c.GUI.TTitledBorder ttlSinTitulo = new mapfre.com.c.GUI.TTitledBorder();
	mapfre.com.c.GUI.TBarraEstado brsEstado = new mapfre.com.c.GUI.TBarraEstado();
	mapfre.com.c.GUI.TTablaEdicion tblTabla = new mapfre.com.c.GUI.TTablaEdicion();
	mapfre.com.c.GUI.TPanel pnlQueryInfo0 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TPanel pnlQueryInfo1 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TPanel pnlQueryInfo2 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TPanel pnlQueryInfo3 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtQueryNumDoctoInterno = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TLabel lblQueryFechaDesde = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtQueryFechaDesde = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TLabel lblQueryFechaHasta = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtQueryFechaHasta = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TLabel lblQueryTipDocto = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtQueryTipDocto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TLabel lblQueryNumDocto = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtQueryNumDocto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TLabel lblQueryNumPoliza = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtQueryNumPoliza = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TLabel lblQueryNumRecibo = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtQueryNumRecibo = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprConsultar = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TButton btnConsultar = new mapfre.com.c.GUI.TButton();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo0 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleNumSptoApli = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleNumRecibo = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleNumOrdPago = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleNumBloqueTes = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleNumPolizaGrupo = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo1 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleNumCruce = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleCodNivel3Captura = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodNivel3 = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodNivel3 = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodNivel3 = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleNumItem = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleNumItem = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleNumItem = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodActTercero = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodActTercero = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodActTercero = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleTipDocum = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleTipDocum = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleTipDocum = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo2 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TSeparador sprDetalleCodDocum = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodDocum = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodDocum = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodAgt = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodAgt = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodAgt = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleTipDocto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleNumDocto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo3 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleNumDoctoInterno = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodMon = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodMon = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodMon = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleValCambio = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleValCambio = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleValCambio = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodImpto = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodImpto = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodImpto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleTipImpto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo4 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleImpExento = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleImpBase = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleImpIntereses = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleImpRecargo = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo5 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleImpDescuento = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleImpCuotaImpto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleImpTotal = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleTipEstado = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleTipEstadoCob = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleTipMvto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleFecEmisionDocto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleFecDocto = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleCantDias = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleUsuario = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo6 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleFecImpresion = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleFecAnulacion = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleCodUsrAnulacion = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleFecLibro = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo7 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleNomMovim = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo8 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TTextField txtDetalleTipDoctoModifica = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleNumDoctoModifica = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodCtoCobPag = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodCtoCobPag = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodCtoCobPag = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodRamoCtable = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodRamoCtable = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodRamoCtable = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDetalleCodCtoVenta = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TPanel pnlDetalleInfo9 = new mapfre.com.c.GUI.TPanel ();
	mapfre.com.c.GUI.TSeparador sprDetalleTxtAux1 = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleTxtAux1 = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleTxtAux1 = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleCodUsr = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleCodUsr = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleCodUsr = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TSeparador sprDetalleFecActu = new mapfre.com.c.GUI.TSeparador();
	mapfre.com.c.GUI.TLabel lblDetalleFecActu = new mapfre.com.c.GUI.TLabel();
	mapfre.com.c.GUI.TTextField txtDetalleFecActu = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TColumna clmCodCia = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodSector = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodRamo = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumPoliza = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumSpto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumApli = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumSptoApli = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumRecibo = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumOrdPago = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumBloqueTes = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumPolizaGrupo = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumCruce = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodNivel3Captura = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodNivel3 = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumItem = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodActTercero = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTipDocum = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodDocum = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodAgt = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTipDocto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumDocto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumDoctoInterno = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodMon = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmValCambio = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodImpto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTipImpto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmImpExento = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmImpBase = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmImpIntereses = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmImpRecargo = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmImpDescuento = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmImpCuotaImpto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmImpTotal = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTipEstado = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTipEstadoCob = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTipMvto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmFecEmisionDocto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmFecDocto = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCantDias = new mapfre.com.c.GUI.TColumna(); 
	mapfre.com.c.GUI.TColumna clmUsuario = new mapfre.com.c.GUI.TColumna(); 
	mapfre.com.c.GUI.TColumna clmFecImpresion = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmFecAnulacion = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodUsrAnulacion = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmFecLibro = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNomMovim = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTipDoctoModifica = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmNumDoctoModifica = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodCtoCobPag = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodRamoCtable = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodCtoVenta = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmTxtAux1 = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmCodUsr = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmFecActu = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TColumna clmMcaCobro = new mapfre.com.c.GUI.TColumna();
	mapfre.com.c.GUI.TTextField txtMarcar = new mapfre.com.c.GUI.TTextField();
	mapfre.com.c.GUI.TTextField txtDesMarcar = new mapfre.com.c.GUI.TTextField();

	//mapfre.com.c.GUI.TColumna clmFecActu = new mapfre.com.c.GUI.TColumna();
	//}}

	// Nombre de la clase que contiene el dialogo de mantenimiento de datos
	/*private static final String DLG_MANTENIMIENTO = "AP502931_MGT_1";*/
	// posiciones de los campos del registro en la tabla 
	protected static final int NUMSECUK  = 0;
	protected static final int NUMPOLIZA = 1;
	protected static final int NUMRECIBO = 2;
	protected static final int TIPDOCTO  = 3;
	protected static final int NUMDOCTO  = 4;
	protected static final int IMPTOTAL  = 5;
	protected static final int FECDOCTO  = 6;
    protected static final int MCASELECCION = 7;
	protected static final int CANTDIAS   =8; 
	protected static final int USUARIO   = 9;
	
	private Object[] camposDetalle = {
	/* txtDetalleNumSptoApli
	,txtDetalleNumRecibo
	,txtDetalleNumOrdPago
	,txtDetalleNumBloqueTes
	,txtDetalleNumPolizaGrupo
	,txtDetalleNumCruce
	,txtDetalleCodNivel3Captura
	,txtDetalleCodNivel3
	,txtDetalleNumItem
	,txtDetalleCodActTercero
	,txtDetalleTipDocum
	,txtDetalleCodDocum
	,txtDetalleCodAgt
	,txtDetalleTipDocto
	,txtDetalleNumDocto
	,txtDetalleNumDoctoInterno
	,txtDetalleCodMon
	,txtDetalleValCambio
	,txtDetalleCodImpto
	,txtDetalleTipImpto
	,txtDetalleImpExento
	,txtDetalleImpBase
	,txtDetalleImpIntereses
	,txtDetalleImpRecargo
	,txtDetalleImpDescuento
	,txtDetalleImpCuotaImpto
	,txtDetalleImpTotal
	,txtDetalleTipEstado
	,txtDetalleTipEstadoCob
	,txtDetalleTipMvto
	,txtDetalleFecEmisionDocto
	,txtDetalleFecDocto
	,txtDetalleFecImpresion
	,txtDetalleFecAnulacion
	,txtDetalleCodUsrAnulacion
	,txtDetalleFecLibro
	,txtDetalleNomMovim
	,txtDetalleTipDoctoModifica
	,txtDetalleNumDoctoModifica
	,txtDetalleCodCtoCobPag
	,txtDetalleCodRamoCtable
	,txtDetalleCodCtoVenta
	,txtDetalleTxtAux1
	,txtDetalleCodUsr
	,txtDetalleFecActu*/
	};

	private int[] posicionTabla = {
	/* AP502931_MGT.NUMPOLIZA
	,AP502931_MGT.NUMRECIBO
	,AP502931_MGT.TIPDOCTO
	,AP502931_MGT.NUMDOCTO
	,AP502931_MGT.IMPTOTAL
	,AP502931_MGT.FECDOCTO*/
	};
	private Object[] componentesQuery = {
		txtQueryFechaDesde,
		txtQueryFechaHasta,
		txtQueryTipDocto,
		txtQueryNumDocto,
		txtQueryNumPoliza,
		txtQueryNumRecibo,
	};
	public Object[] nombresComponentesQuery = {
	    "txtQueryFechaDesde",
		"txtQueryFechaHasta",
		"txtQueryTipDocto",
		"txtQueryNumDocto",
		"txtQueryNumPoliza",
		"txtQueryNumRecibo"
	};

	//====METODOS DEL MANTENIMIENTO DE TABLA=====
	
	protected Object[] getQuery()
	{
		return new Object [] {
	 	Globales.getVariableGeneral("cod_cia"),"IN"
	,	txtQueryFechaDesde,"IN"
	,	txtQueryFechaHasta,"IN"
	,	txtQueryTipDocto  ,"IN"
	,	txtQueryNumDocto  ,"IN"
	,	txtQueryNumPoliza ,"IN"
	,	txtQueryNumRecibo, "IN"};
	}
	
	protected Object[] getPreAlta()
	{
		return new Object [] {
	 	"AP502931_MGT","IN"		};
	}
	
	protected Object[] getPreModificacion()
	{
		return new Object [] {
	 	tblTabla.getNumRegistroActivo(),"IN"
	,	"AP502931_MGT","IN"		};
	}
	
	protected Object[] getBorra()
	{
		return new Object [] {
	 	tblTabla.getNumRegistroActivo(),"IN"
	,	"AP502931_MGT","IN"		};
	}
//========================================================================================
	//METODOS QUE NECESITA TDialogQuery PARA OPERAR CORRECTAMENTE
	//los siguientes m�todos son generados autom�ticamente y no deben
	//ser modificados por el programador

	//Recupera el nombre de la clase de la pantalla de imputaci�n
	/*protected String   getDlgMantenimiento() {return DLG_MANTENIMIENTO;}*/

	//Recupera la informaci�n para rellenar el detalle
	protected Object[] getDetalle() {return new Object [] {camposDetalle, posicionTabla};}

	//Recupera el panel de query
	protected TPanel   getPnlQuery() {return pnlQuery;}

	//Recupera el panel que contiene a la tabla
	protected TPanel   getPnlDatos() {return pnlDatos;}

	//Recupera el bot�n de aceptar
	protected TButton  getBtnAceptar() {return btnAceptar;}

	//Recupera el bot�n de consultar
	protected TButton  getBtnConsultar() {return btnConsultar;}

	//Recupera el panel general que contiene al resto
	protected TPanel   getPnlGeneral() {return pnlGeneral;}

	//Recupera los componentes del panel de query junto con sus nombres
	protected Object[] getComponentesQuery() {return new Object[] {componentesQuery,nombresComponentesQuery};}
	public void addNotify()
	{
		// Record the size of the window prior to calling parents addNotify.
		Dimension size = getSize();
		super.addNotify();
		if (frameSizeAdjusted)
			return;
		frameSizeAdjusted = true;
		// Adjust size of frame according to the insets and menu bar
		Insets insets = getInsets();
		javax.swing.JMenuBar menuBar = getRootPane().getJMenuBar();
		int menuBarHeight = 0;
		if (menuBar != null)
			menuBarHeight = menuBar.getPreferredSize().height;
		setSize(insets.left + insets.right + size.width, insets.top + insets.bottom + size.height + menuBarHeight);
	}
	// Used by addNotify
	boolean frameSizeAdjusted = false;
	   int auxMarca = 0;
   public static void main(String[] args) {
      try {
         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      } catch (Exception var2) {
      }
      AP502931_MGT dlg = new AP502931_MGT();
      dlg.setVisible(true);
   }
   public Boolean preValTxtQueryFecDesde() {
      this.txtQueryFechaDesde.addParametro(this.txtQueryFechaDesde, "IN", 0, 1);
      return Boolean.TRUE;
   }
   public Boolean preValTxtQueryFecHasta() {
      this.txtQueryFechaHasta.addParametro(this.txtQueryFechaDesde, "IN", 0, 2);
      this.txtQueryFechaHasta.addParametro(this.txtQueryFechaHasta, "IN", 1, 2);
      return Boolean.TRUE;
   }
   public Boolean preValTxtQueryTipDocto() {
      this.txtQueryTipDocto.addParametro(this.txtQueryTipDocto, "IN", 0, 1);
      return Boolean.TRUE;
   }
   public Boolean preValTxtQueryNumDocto() {
      this.txtQueryNumDocto.addParametro(this.txtQueryNumDocto, "IN", 0, 1);
      return Boolean.TRUE;
   }
   public Boolean preValTxtQueryNumPoliza() {
      this.txtQueryNumPoliza.addParametro(this.txtQueryNumPoliza, "IN", 0, 1);
      return Boolean.TRUE;
   }
   public Boolean preValTxtQueryNumRecibo() {
      this.txtQueryNumRecibo.addParametro(this.txtQueryNumRecibo, "IN", 0, 1);
      return Boolean.TRUE;
   }
   public Boolean accionBtnConsultar() {	   
      this.tblTabla.setEnabled(true);
      this.tblTabla.setMetodoMarcar(this, "");
      Component lAnteriorComponenteQuery = this.getComponenteActual();
      System.out.println("---------------------------entra a consultar");
      if (this.tblTabla.ejecutarConsulta()) {
         this.pnlQuery.setEnabled(false);
         System.out.println("---------------------------entra a if 1");
         int a = this.tblTabla.getJTable().getRowCount();
         this.tblTabla.getJTable().requestFocus();
         if (a == 1) {
            this.tblTabla.marcarRegistro(0);
            System.out.println("---------------------------entra a if 2");
         }
         this.marcarExcluye();
      }
      return Boolean.TRUE;
   }
   
   private void marcarExcluye() {
      int iLongitudTabla = this.tblTabla.getJTable().getRowCount();
      Vector lvRegistroActual = null;
      System.out.println("---------------------entro a marca excluye---------------------------------");
      for(int i = 0; i < iLongitudTabla; ++i) {
         lvRegistroActual = this.tblTabla.getRegistro(i);
         if (lvRegistroActual != null) {
            if (((String)lvRegistroActual.elementAt(7)).trim().equals("S")) {
               this.tblTabla.marcarRegistro(i);
            } else {
               this.tblTabla.desMarcarRegistro(i);
            }
         }
      }
      this.tblTabla.setMetodoMarcar(this, "marcarDesmarcar");
      this.tblTabla.irPrimeraActiva(0);
   }
   public Vector marcarDesmarcar(Vector pvMarcados, Vector pvDesmarcados) {
      this.txtMarcar.setFuncionValidacion("GC_K_AP502931_MGT.p_marcar(1)");
      this.txtDesMarcar.setFuncionValidacion("GC_K_AP502931_MGT.p_desmarcar(1)");
      Vector registro = this.tblTabla.getRegistro();
      Vector vBloqueo = new Vector();
      this.bloquea(true);
      int d;
      int regd;
      for(d = 0; d < pvMarcados.size(); ++d) {
         this.txtMarcar.inicializaParametros();
         this.tblTabla.setHuboCambiosLocales(true);
         regd = ((Integer)pvMarcados.elementAt(d)).intValue();
         registro = this.tblTabla.getRegistro(regd);
         this.txtMarcar.addParametro(((String)registro.elementAt(4)).trim(), "IN", 0, 1);
         this.txtMarcar.lanzaValidacionOracle();
         this.auxMarca = regd;
         if (((String)registro.elementAt(7)).trim().equals("S")) {
            this.tblTabla.marcarRegistro(regd);
            this.tblTabla.irPrimeraActiva(regd);
         } else {
            Herramientas.mostrarMensaje("trn", "20202", 0, this);
            this.tblTabla.desbloquea(regd);
            this.tblTabla.desMarcarRegistro(regd);
            this.tblTabla.bloquea(regd);
         }
      }
      for(d = 0; d < pvDesmarcados.size(); ++d) {
         this.txtDesMarcar.inicializaParametros();
         regd = ((Integer)pvDesmarcados.elementAt(d)).intValue();
         registro = this.tblTabla.getRegistro(regd);
         this.auxMarca = regd;
         this.txtDesMarcar.addParametro(((String)registro.elementAt(4)).trim(), "IN", 0, 1);
         this.txtDesMarcar.lanzaValidacionOracle();
         this.tblTabla.desMarcarRegistro(regd);
         this.tblTabla.irPrimeraActiva(regd);
      }
      this.tblTabla.setHuboCambiosLocales(true);
      this.auxMarca = 0;
      this.bloquea(false);
      return vBloqueo;
   }
   private void bloquea(boolean b) {
      this.tblTabla.setMetodoMarcar(this, b ? "" : "marcarDesmarcar");
      int filas = this.tblTabla.getJTable().getRowCount();
      int i;
      for(i = 0; i < filas; ++i) {
         if (b) {
            this.tblTabla.bloquea(i);
         } else {
            this.tblTabla.desbloquea(i);
         }
      }
      for(i = 0; i < filas; ++i) {
      }
   }
   public Boolean accionBtnAceptar() {
      try {
         if (Herramientas.mostrarMensaje("trn", "99977904", 3, this) == 2) {
            TTextField lTxtValidarRegistro = new TTextField();
            TTextField lTxtValidarRegistro3 = new TTextField();
            lTxtValidarRegistro.setFuncionValidacion("gc_k_ap502931_mgt.p_v_anula_fac_ant(5)");
            int liLongitudTabla = this.tblTabla.getJTable().getRowCount();
            Vector lvRegistroActual = null;
            for(int i = 0; i < liLongitudTabla; ++i) {
               lvRegistroActual = this.tblTabla.getRegistro(i);
               if (lvRegistroActual != null && !((String)lvRegistroActual.elementAt(0)).equals("") && this.tblTabla.getJTable().isRowSelected(i)) {
                  lTxtValidarRegistro.addParametro((String)lvRegistroActual.elementAt(0), "IN", 0, 5);
                  lTxtValidarRegistro.addParametro((String)lvRegistroActual.elementAt(3), "IN", 1, 5);
                  lTxtValidarRegistro.addParametro((String)lvRegistroActual.elementAt(4), "IN", 2, 5);
                  lTxtValidarRegistro.addParametro((String)lvRegistroActual.elementAt(2), "IN", 3, 5);
                  //lTxtValidarRegistro.addParametro(this.txtQueryFechaDesde, "IN", 4, 6);
                  lTxtValidarRegistro.addParametro(this.txtQueryFechaHasta, "IN", 4, 5);
                  lTxtValidarRegistro.lanzaValidacionOracle();
                  lTxtValidarRegistro3.setFuncionValidacion("gc_k_ap502931_mgt.p_grabar");
                  lTxtValidarRegistro3.lanzaValidacionOracle();
               }
            }
         }
      } catch (Exception var9) {
         var9.getMessage();
      } finally {
         this.btnListado.setEnabled(true);
         TDialog.limpiaVentana(this);
      }
      return Boolean.TRUE;
   }
   public Boolean accionBtnListado() {
      TTextField lTxtValidarRegistro2 = new TTextField();
      lTxtValidarRegistro2.setFuncionValidacion("gc_k_genera_nc_masiva.p_proceso");
      lTxtValidarRegistro2.lanzaValidacionOracle();
      if (Globales.getVariableGeneral("genera_nc").equals("S")) {
         Herramientas.mostrarMensaje("trn", "99977905", 0, this);
      }
      return Boolean.TRUE;
   }
}