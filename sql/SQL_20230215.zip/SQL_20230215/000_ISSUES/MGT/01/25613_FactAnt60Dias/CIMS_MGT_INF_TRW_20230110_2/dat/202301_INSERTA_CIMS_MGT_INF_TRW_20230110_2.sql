--
/* --------------------DESCRIPCION--------------------
|| CIMS_MGT_INF_TRW_20230110_2
|| 2023/01/10   TRON2000
|| Autor:       SBETANCURT
|| Descripcion: Control de cims
*/ ---------------------------------------------------
--
BEGIN
--
INSERT INTO g0000001 VALUES ('CIMS_MGT_INF_TRW_20230110_2',SYSDATE);
--
EXCEPTION 
WHEN OTHERS
THEN
   --
   UPDATE g0000001 SET FEC_ACTU = SYSDATE WHERE COD_CIMS = 'CIMS_MGT_INF_TRW_20230110_2';
   --
END;
/
EXIT
