
;gc_k_ap502930
 gc_k_ap502930.p_v_num_recibo
 
 
 -- RECIBOS/CUOTAS DE UNA POLIZA PARA EL MANEJO DE UNIFICACION
   SELECT *
    FROM a2990700
   WHERE cod_cia +0 = p_cod_cia
     AND num_recibo = p_num_recibo
   ORDER BY num_spto DESC, num_spto_apli DESC;
 
 --RECIBO NO-PRIMA
  SELECT *
    FROM a5020350
   WHERE cod_cia         = 2--p_cod_cia
     AND num_recibo      = p_num_recibo;
     
     --DEFINICION DE VALIDACIONES ESPECIFICAS DE DISTINTAS ENTIDADES
     SELECT *
           FROM g1003000
          WHERE cod_cia        = 2--p_cod_cia
            AND cod_pgm        = 'AP502030'--p_cod_pgm
            AND cod_campo      = p_cod_campo;
      
     select * from a5020039_mgt;
     
     --COBRO DE RECIBOS BATCH (BUZON)
          select * from a5020039;
           
            
 xavid_novale;
 
 gc_k_rec_pdtes_antici_ant
 gc_k_rec_pdtes_antici_ant.p_open
 
 ;GC_K_CANCELA_CA_POL_T_TRN
 
 
       SELECT fec_efec_recibo, num_recibo, tip_situacion, cod_mon, SUM(imp_recibo)
        FROM a2990700 a
       WHERE a.cod_cia         =  2--p_cod_cia
         AND a.num_poliza      =  a.num_poliza--p_num_poliza
         AND a.tip_situacion   IN ('RE', 'EP')--p_tip_situacion)
         AND a.num_recibo +0   > 0
         AND a.num_apli        = 0
         AND a.tip_docum_pago  IS NULL
         AND a.cod_docum_pago  IS NULL
         AND a.num_aviso       IS NULL
         -- recibos que no esten en cobro de recibo batch
         AND (select COUNT(b.NUM_RECIBO) from a5020039 b where b.cod_cia = a.cod_cia and b.num_recibo =  a.num_recibo) = 0
         AND TRUNC(a.fec_efec_recibo) <= TO_DATE('14/11/2022','DD/MM/YYYY')
       GROUP BY a.fec_efec_recibo, a.num_recibo, a.tip_situacion, a.cod_mon
      HAVING SUM(a.imp_recibo) > 0;

GC_K_AP502931_MGT_MGT;


ERROR EN OF0:
GC_K_AP502931_MGT.p_devuelve (traza)

gc_k_ap502931_mgt.p_devuelve
gc_k_ap502931_mgt_mgt.p_devuelve
fec_desde = 01012019
fec_hasta = 01052019
num_recibo = 29923


 gc_k_nc_masiva
 
 
 error al generar el archivo CSV: trae otra cosa. paquete:
 
 GC_K_GENERA_NC_MASIVA_MGT
 
select * from a2990700 where  num_recibo = 29923
 
 
