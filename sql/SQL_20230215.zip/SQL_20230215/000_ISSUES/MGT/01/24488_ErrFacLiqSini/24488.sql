

TRON2000.GC_K_LIBRO_DE_VENTAS_MGT

SELECT * FROM a5021610 WHERE tip_libro = 'LC' AND COD_CIA = 2 AND TRUNC(FEC_CIERRE) > TO_DATE ('01/12/2022','DD/MM/YYYY');

insert into a5021610 (COD_CIA, TIP_LIBRO, FEC_CIERRE, TIP_ESTADO, COD_USR, FEC_ACTU)
values (2, 'LC', to_date('16-01-2023', 'dd-mm-yyyy'), null, 'TRON2000', to_date('22-12-2022', 'dd-mm-yyyy'));


gc_k_a5021610.p_lee


gc_k_ap502502.p_devuelve_inicio


gc_k_ap502502


gc_k_ap502502.p_val_tip_entorno

    SELECT *-- COUNT(*)
      FROM g1010131
       WHERE cod_pgm = 'ap502502'
        --AND num_menu_opcion = p_tip_entorno + 1
        AND cod_pgm IN (SELECT cod_pgm 
                         FROM g1010210
                        WHERE cod_rol IN (SELECT cod_rol
                                           FROM g1010220
                                          WHERE cod_usr = 'TRON2000' ));
-- marca registro diario
SELECT * FROM a5020037 WHERE cod_cajero = 'TRON2000' FOR UPDATE;

SELECT * FROM a3001700 WHERE num_sini = '200130022000587';
tip_docum = 'PAS'
cod_docum = '981510'
liquidacion = 200123001018

SELECT * FROM a5021610 WHERE cod_cia = 2 AND tip_libro = 'LV' AND TRUNC(FEC_CIERRE) = TO_DATE('31/01/2023','DD/MM/YYYY');


SELECT * FROM tronweb_reports ORDER BY fec_created DESC;

gc_k_jrp_facturacion_gt
gc_k_jrp_factura

SELECT * FROM a2000030 WHERE cod_cia = 2;


GC_K_GENERA_FACT_XML_GT_MGT;
GC_K_GENERA_FACT_XML_GT_TMP;


-- npUEDE SER AQUI EL ERROR: LINEA 462 - 463
TS_K_JRP_LIQUID_RECLAMO_MGT
;
PK_NUMLIT


DECLARE
BEGIN
  tron2000.ts_k_jrp_liquid_reclamo_mgt.fp_revisa_letras(1000);
  END;
  
  
  SELECT REGEXP_COUNT('100 QUETZALES CON 00/100 QUETZALES CON 00/100', 'QUETZALES CON 00/100', 1, 'i') FROM dual;
  
  DECLARE
  lvar VARCHAR2(100):='100 quetzales con 00/100     QuETZALES CoN 00/100';
  repeat INTEGER;
  BEGIN
  dbms_output.put_line('Entrada: ' || lvar);
  SELECT REGEXP_COUNT(UPPER(lvar), 'QUETZALES CON 00/100', 1, 'i') 
  INTO repeat
  FROM dual;
  dbms_output.put_line('Repetidos: ' || repeat);
  IF repeat > 1 THEN
    FOR i IN 1..repeat
      LOOP
    lvar:=REPLACE(UPPER(lvar),'QUETZALES CON 00/100','');
    END LOOP;
     lvar :=  TRIM(lvar) || ' QUETZALES CON 00/100';
    END IF;
 
  dbms_output.put_line('despues: ' || lvar);
  END;
  
  
  200110117000067
  
--  DATOS FIJOS DEL EXPEDIENTE
SELECT * FROM a7001000 WHERE COD_CIA = 2 AND COD_RAMO = 101 AND num_sini LIKE '200%' AND tip_exp = 'RDS' ORDER BY FEC_ACTU DESC;

ts_k_cabsini
ts_k_cabsini.p_v_num_sini;


select * from a7000900 where trunc(fec_sini) >= to_date('01/12/2022','dd/mm/yyyy');


SELECT * FROM a3001700 WHERE num_sini = '200130022000587';

COD_CIA = 2
COD_SECTOR = 3
COD_RAMO = 300
select * from TRAZAS_MPR where cod_traza = 'rurquijo';


pk_numlit

--PRUEBAS EN OF 0
num_sini = 200130021002509
num_liq  = 200123004016


-- PRUEBAS EN INT
NUM_SINI = 200130022000078
NUM_LIQ = 200123000035
-- PRUEBA 2
NUM_SINI = 200130022003023
NUM_LIQ  = 200123000036
