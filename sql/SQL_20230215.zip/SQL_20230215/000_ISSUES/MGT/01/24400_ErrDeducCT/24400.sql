SITUACI�N: 
De acuerdo al usuario: 
No se evidencian los controles t�cnicos: 
(num_sini=200122823001541)798 TERCERO SE ENCUENTRA EN LISTA NO DESEADA (TS_K_228_CT_MGT.p_ct_datos_fijos_liq -> pp_benef_no_deseado). 
(num_sini=200122823001542)799 BEFICIARIO EN LISTA DE PERSONAS DESIGNADAS (TS_K_228_CT_MGT.p_ct_datos_fijos_liq -> pp_benef_no_deseado). 
(num_sini=200122823001536)793 SINIESTRO CON CAPITAL COMPLETO (NO HAY UN PL QUE APUNTE A ALGO QUEW GENERE EL CT, LO MAS CERCANO ES: TS_K_228_CT_MGT.p_ct_cob_liquidacion -> TS_K_DIVERSOS_CT_MGT.p_ct_cob_exp -> pp_ct_val_capital_completo). 

HECHOS: 
Se comparan los objetos TS_K_228_CT_MGT y TS_K_DIVERSOS_CT_MGT y no se encuentran diferencias entre los ambientes de desarrollo y OF0. 

En ambiente desarrollo con el siniestro 2001228230000529 se genera y evidencia el control de TERCERO SE ENCUENTRA EN LISTA NO DESEADA, 
consultando en la pesta�a �Control T�cnico� en la secci�n de �Liquidaciones�. En ambiente OF0 con el siniestro 200122823001541 
tambi�n se evidencia en la misma ruta. 

En ambiente desarrollo hay error al enviar los par�metros para consultar el tercero en la tabla A1001320 (clientes no deseados definidos 
para terceros) en dc_p_cliente_lista_negra_mgt ,  Control t�cnico 798 TERCERO SE ENCUENTRA EN LISTA NO DESEADA. 

En ambiente OF0 con el siniestro 200122823001542 no se evidencia el control t�cnico. 
--- AJUSTE EN LAS TABLAS GENERALES DE DEFINICION DEL NOMBRE DEL ERROR DEL CONTROL TECNICO
SELECT a.* fROM g2000211 a  WHERE cod_cia = 2 and cod_error = 799 for update;

MX

select * from h7001200 where num_sini = 200122823000536;
select * from a2000040 where num_poliza = 2282201808283;

DC_P_CLIENTE_LISTA_NEGRA_MGT
ED_K_211_CT_MGT
TS_K_228_CT_MGT
EV_K_GEN_CT_VSD_MGT}
ed_k_228_cob_mgt
select * from TRAZAS_MPR where COD_traza = 'REUY'
DELETE FROM TRAZAS_MPR where COD_traza = 'REUY';
COMMIT;

SELECT * FROM a3001800 WHERE NUM_SINI = 200122823000546;

SELECT t.*
      FROM T_STL_TRN_M_SMB t
     WHERE btc_idn_val = pc_ses_val
       AND cmp_val     = pc_cod_cia
       AND lss_val     = pc_num_sini;

en emision:
2025 TERCERO EN LISTA DE PERSONAS DESIGNADAS
ed_k_228_ct;
ed_k_gen_ct.pp_ct_personas_designadas;
TRON2000.DC_P_VALIDA_DOCUM_MGT

TS_K_DIVERSOS_CT_MGT;
DC_K_AP100320
DC_K_AP100320.p_query

 SELECT * FROM a1001320_MGT

SELECT * FROM V1001390 WHERE TIP_DOCUM = 'PAS' AND COD_DOCUM = '114477885522';
 SELECT * FROM a1001320 A WHERE A.cod_cia = 2 and a.cod_tercero = 99
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 735 g_k_ts: TS
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 736 g_cod_cia: 2
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 737 l_cod_act_tercero: 99
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 738 g_tip_docum: PAS
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 739 g_cod_docum: 114477885522
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 740 g_cod_sector: 2
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 741 g_cod_ramo: 228
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 742 g_cod_nivel1: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 743 g_cod_nivel2: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 744 g_cod_nivel3: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 745 g_cod_agt: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 746 g_fec_efec_poliza: 
dc_p_cliente_lista_negra 80 p_mca_en_lista_negra: N
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 761 l_mca_en_lista_negra: N

    SELECT *
      FROM a1001320 A
     WHERE A.cod_cia         = 2
     And a.cod_ramo = 228
     and a.cod_act_tercero = 99

select * from a1001309;

-- PERSONAS DESIGNADAS
    SELECT *
      FROM a1001320 A
     WHERE A.cod_cia         = 2
     and a.cod_ramo = 228;


con un siniestro si pero con otros no : em_k_ac299355_trn.p_query_220 221 g_num_sini: 200130022000726
;
select * from a2000220 where num_sini= 200122823000530;

799
;TS_K_GEN_LIQ
TRON2000.TS_K_AP700300_MGT
-- PERSONAS DESIGNADAS
    SELECT *
      FROM a1001320 A
     WHERE A.cod_cia         = 2
     and cod_ramo = 228
     AND A.TIP_DOCUM = 'NIT'
     AND A.COD_DOCUM = '7320124';

TS_K_DIVERSOS_CT_MGT;
TS_K_228_CT_MGT;
TS_K_A2000220_TRN

TS_K_228_CT
TS_K_228_CT.P_CT_DATOS_FIJOS_LIQ
ts_k_ap700112
ts_k_ap700112.p_devuelve;
ts_k_ac700202
 ts_k_ac700202.p_devuelve;
 ts_k_ac700001
 =ts_k_ac700002.f_inh_inf_trami
select * from a2000220 where num_sini in (200130022000726,200122823000529) for update;

select * from a2000220 where num_sini = 200122823001542;


;ts_k_ac700006
 ts_k_ac700006.p_query_des(3)
(1): ts_k_ac700006.p_devuelve_des(10)

select * from a2000220 where num_liq <> 0

select * from a2000220 where  num_sini = 200130022000726;

  --
     SELECT COUNT(*) --INTO l_numero
     FROM a2000220
     WHERE cod_cia = 2--p_cod_cia
     AND num_sini = 200130022000726--p_num_sini
     AND NVL(num_exp,'0') = NVL(0,200130022000726)--p_num_exp,num_sini)
     AND NVL(num_liq,'0') = NVL(0,num_liq);--p_num_liq,num_liq);

SELECT * FROM A7990010 where num_sini in (200130022000726,200122823000529)
select * from tron2000.g2000210 where cod_cia = 2 and cod_error in (798,775);
select * from tron2000.g2000200 where cod_cia = 2 and cod_error in (798,775);
200123001045 1
;ts_k_ac700001
ts_k_ac700001.p_lee_siniestro


select * from a2000220 where num_sini=200122823000529;


NUM_LIQ

0
ts_k_ac799001
 ts_k_ac799001.p_query
(1): ts_k_ac799001.p_devuelve(7);
 em_k_ac299355
 em_k_ac299355.p_query_220(1)
(1): em_k_ac299355.p_devuelve(12)

select * from a2000221 where num_poliza = 2282201808274;

select * from a7000900 where num_sini  in (200130022000726,200122823000529);

select * from a1001800 where cod_ramo in( 228,300);

=ts_k_ac700001;
ts_k_consulta_stros
ts_k_consulta_stros.f_inh_inf_ct
PnlAC799001_1
TS_K_AC7000001_TRN.p_permisos_panel 1866 p_cod_pgm_01: PnlAC700202_1
TS_K_AC7000001_TRN.p_permisos_panel 1867 p_cod_pgm_02: PnlAC700017_2
TS_K_AC7000001_TRN.p_permisos_panel 1868 p_cod_pgm_03: PnlAC799001_1
TS_K_AC7000001_TRN.p_permisos_panel 1869 p_cod_pgm_04: PnlAC502011_1
TS_K_AC7000001_TRN.p_permisos_panel 1870 p_cod_pgm_05: PnlAC299306
TS_K_AC7000001_TRN.p_permisos_panel 1871 p_cod_pgm_06: PnlAC700001_3
TS_K_AC7000001_TRN.p_permisos_panel 1872 p_cod_pgm_07: PnlAC700001_2
ts_k_diversos_ct

EM_K_AC299355_TRN

TS_K_228_CT_MGT
dc_p_trazas_mpr('REUY','TS_K_AC7000001_TRN.p_permisos_panel ' || $$PLSQL_LINE ||  ' p_cod_pgm_02: '|| p_cod_pgm_02);
dc_p_trazas_mpr('REUY','TS_K_AC7000001_TRN.p_permisos_panel ' || $$PLSQL_LINE ||  ' p_cod_pgm_03: '|| p_cod_pgm_03);
dc_p_trazas_mpr('REUY','TS_K_AC7000001_TRN.p_permisos_panel ' || $$PLSQL_LINE ||  ' p_cod_pgm_04: '|| p_cod_pgm_04);
dc_p_trazas_mpr('REUY','TS_K_AC7000001_TRN.p_permisos_panel ' || $$PLSQL_LINE ||  ' p_cod_pgm_05: '|| p_cod_pgm_05);
dc_p_trazas_mpr('REUY','TS_K_AC7000001_TRN.p_permisos_panel ' || $$PLSQL_LINE ||  ' p_cod_pgm_06: '|| p_cod_pgm_06);
dc_p_trazas_mpr('REUY','TS_K_AC7000001_TRN.p_permisos_panel ' || $$PLSQL_LINE ||  ' p_cod_pgm_07: '|| p_cod_pgm_07);


select * from a7001000 where num_sini  in (200130022000726,200122823000529);
ts_f_cons_inh_inf_ct
ts_k_ac700001
ts_k_ac700001.f_inh_inf_ct
ts_f_cons_inh_inf_avisos
ts_k_ac700001.f_inh_inf_avisos


ts_k_ac700001
ts_k_ac700001.p_permisos_panel

TRON2000.TS_K_AP700100_TRN   -- AJUSTE LINEA 2439  SOLO PRUEBAS
;TS_K_A2000220_TRN;
TS_K_AS799001_TRN;
TS_K_228_CT_MGT


ORA-06512: at "TRON2000.EM_K_A2000030_TRN", line 73
ORA-06512: at "TRON2000.EM_K_A2000030_TRN", line 188
ORA-06512: at "TRON2000.TS_K_AP700100_TRN", line 2462;
TRON2000.TS_K_AP700100_TRn
select * from a2000030 where 

          SELECT ROWID , a2000030.*
            FROM a2000030
           WHERE cod_cia       = 2--pc_cod_cia
             AND num_poliza    = 2282201808271--pc_num_poliza
             AND num_spto      = pc_num_spto
             AND num_apli      = pc_num_apli
             AND num_spto_apli = pc_num_spto_apli;






PRUEBAS:
2282201808264
2011 tercero en lista pep
20012282300517nit    -- NO ESTA DANDO EL CT DE PEP

nit
6248845
2282201808265

2282201808267

2282201808268

2282201808269



2282201808270

EM_K_AC299355_TRN;
TS_K_AC700001_TRN;
TS_K_AS799001_TRN
select * from a2000220

select * from a2000060 where num_poliza = '2282201808264';

dc_p_trazas_mpr('REUY','pp_benef_no_deseado ' || 'entra a ts_k_as799001.p_grabar');
select * from TRAZAS_MPR where COD_traza = 'REUY'
DELETE FROM TRAZAS_MPR where COD_traza = 'REUY';
COMMIT;
ts_k_ld_param_sini_ramo
ts_k_ld_param_sini_ramo.f_pedir_imp_val_ini_sini
ts_k_g7000001
ts_k_g7000001.p_lee
em_k_ac299355_trn.em_k_p_query_220

select * from g7000001 where cod_cia = 2 and cod_ramo in (228,300)

select * from a1001320 where cod_docum = '6248845';
a1001320
; ts_k_ac700001
 ts_k_ac700001.p_permisos_panel

/* CONSULTA SIMPLE POLIZAS PRIMERA EMISION*/
SELECT * 
  FROM a2000030 a 
 WHERE a.cod_cia                 = 2 
   AND a.cod_sector              = 2
   AND a.cod_ramo                = 228
   AND a.num_poliza              = '2282300001333';

-- TERCEROS DE UNA POLIZA
SELECT * 
  FROM a2000060 a
 WHERE a.cod_cia       = 2                       -- INDICE
  -- AND a.num_poliza    = '2282300001333'            -- INDICE --'4135000092077'
   --AND a.num_spto      = 0                       -- PK
   --AND a.num_apli      = 0                       -- PK
   --AND a.num_spto_apli = 0                       -- PK
   --AND a.num_riesgo    = 1                       -- PK
   --AND a.tip_benef     = 2                       -- PK
   AND a.tip_docum     = 'NIT'                   -- PK
   AND a.cod_docum     = '6248845'            -- PK

-- TERCEROS PEP
SELECT a.*
  FROM a1009301 a
 WHERE 1=1
   -- AND a.cod_cia = 2
   -- AND a.tip_pep = a.tip_pep
    AND a.tip_docum = 'NIT'
    AND a.cod_docum = '6248845'
   -- AND a.tip_docum_rela = a.tip_docum_rela
   -- AND a.cod_docum_rela = a.cod_docum_rela
   -- AND a.ape1_tercero = a.ape1_tercero
   -- AND a.ape2_tercero = a.ape2_tercero
   -- AND a.ape3_tercero = a.ape3_tercero
   -- AND a.nom_tercero = a.nom_tercero
   -- AND a.nom2_tercero = a.nom2_tercero
   -- AND a.tip_relac = a.tip_relac
   -- AND a.nom_relac = a.nom_relac
   -- AND a.nom_emp = a.nom_emp
   -- AND a.cod_pais = a.cod_pais
   -- AND a.cod_prov = 0 --= a.cod_prov
   -- AND a.cod_estado = 0 --= a.cod_estado
   -- AND a.cod_localidad = 0 --= a.cod_localidad
   -- AND a.tip_domicilio = 0 --= a.tip_domicilio
   -- AND a.nom_domicilio = a.nom_domicilio
   -- AND a.cod_postal = a.cod_postal
   -- AND a.num_apartado = a.num_apartado
   -- AND a.tlf_pais = a.tlf_pais
   -- AND a.tlf_zona = a.tlf_zona
   -- AND a.tlf_numero = a.tlf_numero
   -- AND a.fax_numero = a.fax_numero
   -- AND a.email = a.email
   -- AND a.cargo = a.cargo
   -- AND a.TRUNC(fec_fin_cargo) = TO_DATE('01/01/2023','DD/MM/YYYY')
;


Liquidacion de capital completo
Siniestro con liquidacion de beneficiario en lista de clientes PEP.
Siniestro con liquidacion de beneficiario en lista de personas designadas - Liquidacion de siniestro

EN EL CODIGO(TS_K_228_CT):
g_k_benef_pep = 798 = TERCERO SE ENCUENTRA EN LISTA NO DESEADA
g_k_benef_desig = 799 = BEFICIARIO EN LISTA DE PERSONAS DESIGNADAS

EN LA TABLA G2000211:
4048 BENEFICIARIO ES TERCERO PEP (PERSONA EXPUESTA POLITICAMENTE)
799 BEFICIARIO EN LISTA DE PERSONAS DESIGNADAS (AJUSTAR)
793 SINIESTRO CON CAPITAL COMPLETO  -- O TAMBIEN PUEDE SER 711 SINIESTRO CON CAPITAL COMPLETO


SELECT * FROM TRON2000.A2000220; -- CONTROL TECNICO DEL SINIESTRO
SELECT * FROM TRON2000.A2000221; -- CONTROL TECNICO DE LA POLIZA

ts_k_as799001
ts_k_as799001.p_grabar;
ts_k_g7000000
ts_k_g7000000.f_nom_prg_carga_ct;

ts_k_a7990010
ts_k_a7990010.f_cuenta_a7990010


     SELECT COUNT(*) --INTO --l_numero
      FROM a7990010
     WHERE cod_cia       = 2--p_cod_cia
     AND   num_sini      = 200122823000529--p_num_sini
     AND  NVL(num_exp,'0') = NVL(p_num_exp,num_exp)
     AND  NVL(num_liq,'0') = NVL(p_num_liq,num_liq);

         SELECT *
           FROM g7000000
          WHERE cod_cia                  = 2;
          
          


/****************************************/
1. pruebas exitosas ok:

773 SINIESTRO DENUNCIADO FUERA DE TIEMPO
730 POLIZA TIENE DEUDA MAYOR A TREINTA DIAS
710 POLIZA CON SINIESTROS PENDIENTES
771 SINIESTRO POR RENOVACION
772 SINIESTRO EXTEMPORANEO
771 SINIESTRO POR RENOVACION
770 POLIZA NUEVA

select * from tron2000.g2000210 where cod_cia = 2 and cod_error in (798,775);
SELECT * FROM TRON2000.G9999031 where cod_cia = 2 and cod_error in (799,773);

2. prueba de siniestro con capital completo:
en las pruebas se muestra en la liquidacion el control tecnico
790 POLIZA TIENE DEUDA MAYOR A TREINTA DIAS
pero no sale el CT de siniestro con capital completo

3. prueba de siniestro con beneficiarios pep 
aparece es el control tecnico: 798 TERCERO SE ENCUENTRA EN LISTA NO DESEADA
pero no se muestra en la pantalla de siniestros


4. prueba ct beneficiario en lista de personas designadas.
se muestra en poliza:
2025 TERCERO EN LISTA DE PERSONAS DESIGNADA
pero no trae ninguna en el siniestro

/****************************************/
dc_p_trazas_mpr('JMO','pp_ct_poliza_nueva'); 
ts_k_as799001

select * from a7000900 where num_sini = 20012282300517;

select * from g2000220 where cod_cia = 2 and cod_sistema = 7
select * from g2000200 where cod_cia = 2 
select * from g2000211 where cod_cia = 2
select * from g2000210 where cod_cia = 2 and cod_error in ( 770, 798);

select * from a2000220 where num_sini = 200122823000529;

SELECT cod_error              ,
            obs_autorizacion       ,
            cod_nivel_salto        ,
            cod_usr_autorizacion   ,
            fec_autorizacion       ,
            cod_sistema            ,
            obs_error
       FROM A2000220 a
      WHERE a.cod_cia       = 2--g_cod_cia
        AND a.num_sini      = 200122823000529--g_num_sini  
        AND a.num_exp       = NVL   (1,0)--g_num_exp   , 0          )
        AND a.num_liq       = NVL   (g_num_liq   ,a.num_liq   )
       	AND a.cod_sistema   = 3--p_cod_sistema
     ORDER BY a.cod_nivel_salto, a.cod_error;


ts_k_ap700150
ts_k_ap700150.p_devuelve;
ts_k_ac700002
ts_k_ac700002.p_permisos_panel;
ts_k_ac799001.p_query
ts_k_ac799001.p_devuelve;
em_k_ac299355
em_k_ac299355.p_query_220
em_k_ac299355.p_devuelve


select * from G1010210;


ED_K_228_CT; -- emision ramo 228
ed_k_gen_ct
ed_k_gen_ct  -- generales
TS_K_228_CT; -- siniestros ramo 228
ts_k_diversos_ct; 

SELECT * FROM G2000210 WHERE COD_CIA = 2 AND COD_ERROR IN (2011,798)
; ts_k_ac700002
 ts_k_ac700002.p_permisos_panel(
; ts_k_ap700112
 ts_k_ap700112.p_devuelve(;
ts_k_ac700002
 ts_k_ac700002.f_inh_inf_trami

TS_K_228_CT_MGT
TS_K_DIVERSOS_CT_MGT
         SELECT *
           FROM programas

SELECT a.*
  FROM g2000211 a
 WHERE 1=1
   -- AND a.cod_cia = 2
   -- AND a.cod_error = 799 --= a.cod_error
    AND UPPER(a.nom_error) like '%CAPITAL%'
   -- AND a.cod_idioma = a.cod_idioma
   -- AND a.cod_usr = 'TRON2000'
   -- AND a.TRUNC(fec_actu) = TO_DATE('01/01/2023','DD/MM/YYYY')
;
select * from a1001800;21
select * from a1000702;
TS_K_VIDA_CT
DC_F_G2000200_TRN
DC_P_CONTROL_TECNICO_TRN
-- DEFINICION DEL CONTROL TECNICO
-- COD_CIA, COD_SISTEMA, COD_SECTOR, COD_SUBSECTOR, COD_RAMO, COD_NIVEL1, COD_NIVEL2, COD_NIVEL3,    -- PK
-- COD_NIVEL_SALTO, NUM_MENU_OPCION, NUM_OPCION, COD_EST                                             -- PK 
delete from xbackground where cod_marco = '228';
commit;
SELECT a.*
  FROM G2000200 a
 WHERE 1=1 
   AND a.COD_CIA            = 2                                      -- PK
   --AND a.COD_SISTEMA        = 2                                      -- PK                    
   --AND a.COD_SECTOR         = 77                                     -- PK
   --and upper(nom_prg) like '%LIQ%' for update --cod_subsector de 21 a 9999 TS_K_228_CT.P_CT_DATOS_FIJOS_LIQ
   AND UPPER(NOM_PRG) LIKE '%TS_K_228_CT%'
   AND a.COD_RAMO           = 228                           -- PK
   
   --AND a.COD_SUBSECTOR      = 9999                                   -- PK
   --AND a.COD_NIVEL1         = 99                                     -- PK
   --AND a.COD_NIVEL2         = 999                                    -- PK
   --AND a.COD_NIVEL3         = 9999                                   -- PK
   --AND a.COD_NIVEL_SALTO    = '8'                                    -- PK
   -- AND a.NOM_PRG            = 'EV_K_985_CT.P_CT_GRABAR'
   -- AND a.COD_USR            = 'SSGOMEZ'
   -- AND TRUNC(a.FEC_ACTU)    = TO_DATE('01/01/2023','DD/MM/YYYY')
   AND a.NUM_MENU_OPCION    = 0                                      -- PK
   AND a.NUM_OPCION         = 0                                      -- PK
   AND a.COD_EST            = '9999'
;




SELECT * FROM A2000220
-- Trigger para capturar el flujo de programa hasta el insert de una tabla
CREATE OR REPLACE TRIGGER TRON2000.TMP_TRG_A2990700  BEFORE INSERT ON A2990700 FOR EACH ROW
  BEGIN
    IF INSERTING  THEN
      tron2000.tmp_p_ejecuta_traza('INSERT A2990700', ' NUM_RECIBO: ' || :new.num_recibo || ' new.fec_efec_recibo: ' || :new.fec_efec_recibo || ' new.fec_vcto_recibo: ' ||  :new.fec_vcto_recibo || ' new.fec_emision_spto: ' || :new.fec_emision_spto || ' new.fec_vcto_pago: ' || :new.fec_vcto_pago || dbms_utility.format_call_stack);
    END IF;
    IF UPDATING THEN
      tron2000.tmp_p_ejecuta_traza('UPDATE A2990700', ' NUM_RECIBO: ' || :new.num_recibo || ' new.fec_efec_recibo: ' || :new.fec_efec_recibo || ' OLD.fec_efec_recibo: ' || :old.fec_efec_recibo || ' new.fec_vcto_recibo: ' ||  :new.fec_vcto_recibo || ' old.fec_vcto_recibo: ' ||  :old.fec_vcto_recibo || ' new.fec_emision_spto: ' || :new.fec_emision_spto || ' old.fec_emision_spto: ' || :old.fec_emision_spto || ' new.fec_vcto_pago: ' || :new.fec_vcto_pago || ' old.fec_vcto_pago: ' || :old.fec_vcto_pago || dbms_utility.format_call_stack);
    END IF;
  END;
