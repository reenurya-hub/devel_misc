TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 735 g_k_ts: TS
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 736 g_cod_cia: 2
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 737 l_cod_act_tercero: 99
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 738 g_tip_docum: PAS
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 739 g_cod_docum: 114477885522
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 740 g_cod_sector: 2
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 741 g_cod_ramo: 228
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 742 g_cod_nivel1: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 743 g_cod_nivel2: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 744 g_cod_nivel3: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 745 g_cod_agt: 
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 746 g_fec_efec_poliza: 
dc_p_cliente_lista_negra 80 p_mca_en_lista_negra: N
TS_K_228_CT_MGT.PP_BENEF_NO_DESEADO 761 l_mca_en_lista_negra: N

    SELECT *
      FROM a1001320 A
     WHERE A.cod_cia         = 2--p_cod_cia
       AND A.cod_act_tercero = 99--p_cod_act_tercero
       AND A.tip_docum       = p_tip_docum
       AND A.cod_docum       = p_cod_docum
       /*AND ((A.cod_calidad     IN ('1', '5', '6') AND p_cod_modulo = 'GC')   -- 1 UNDESIRED, 5 GARNISHEE ORDERS, 6 FREESING ORDERS
              OR
            (A.cod_calidad     NOT IN ( '5', '6') AND p_cod_modulo != 'GC'))*/ -- 5 GARNISHEE ORDERS, 6 FREESING ORDERS -- TODO MQ 22112019 VER LOS CODIGOS DE CALIDAD
       AND A.cod_sector     IN (p_cod_sector , dc.COD_SECTOR_GEN  )
       AND A.cod_ramo       IN (p_cod_ramo   , em.COD_RAMO_GEN    )
       AND A.cod_nivel1     IN (p_cod_nivel1 , dc.COD_NIVEL1_GEN  )
       AND A.cod_nivel2     IN (p_cod_nivel2 , dc.COD_NIVEL2_GEN  )
       AND A.cod_nivel3     IN (p_cod_nivel3 , dc.COD_NIVEL3_GEN  )
       AND A.cod_agt        IN (p_cod_agt    , trn.COD_TERCERO_GEN)
       AND a.fec_validez     = (SELECT MAX(fec_validez)
                                     FROM a1001320 B
                                    WHERE B.cod_cia         = a.cod_cia
                                      AND B.cod_act_tercero = a.cod_act_tercero
                                      AND B.tip_docum       = a.tip_docum
                                      AND B.cod_docum       = a.cod_docum
                                      AND B.cod_calidad     = a.cod_calidad
                                      AND B.cod_sector      = a.cod_sector
                                      AND B.cod_ramo        = a.cod_ramo
                                      AND B.cod_nivel1      = a.cod_nivel1
                                      AND B.cod_nivel2      = a.cod_nivel2
                                      AND B.cod_nivel3      = a.cod_nivel3
                                      AND B.cod_agt         = a.cod_agt);
