CREATE OR REPLACE PACKAGE BODY ts_k_228_ct_mgt
AS
   --
   /* -------------------- DESCRIPCION --------------------
   || Paquete para los CT de Siniestros en ramo Hogar
   */ -----------------------------------------------------
   --
   /* ------------------ VERSION = 1.02 --------------------*/
   --
   /* -------------------- MODIFICACIONES --------------------
   || 2023/01/24 - RURQUIJO - v1.02 ISSUE #24400
   || Se ajusta el procedimiento pp_carga_globales para que
   || realice de forma correcta la consulta de beneficiario
   || como persona designada.
   -----------------------------------------------------------
   || 2022/08/03 - KPAZAN - v1.01 ISSUE #24222
   || Se ajustan el procedimiento pp_ct_suma_cob_vigencia, se
   || agrega cursor cl_a2000040, para traer la suma asegurada
   || de las coberturas.
   -----------------------------------------------------------
   || 01/06/2020 - DORTEGA - 1.00
   || Creacion del paquete
   */ --------------------------------------------------------
   --
   /* -------------------------------------------------------------
   || Aqui comienza la declaracion de variables GLOBALES
   */ -------------------------------------------------------------
   --
   g_existe BOOLEAN := FALSE;
   --
   g_cod_cia           a2000030.cod_cia        %TYPE;
   g_cod_sector        a2000030.cod_sector     %TYPE;
   g_cod_ramo          a2000030.cod_ramo       %TYPE;
   g_num_poliza        a2000030.num_poliza     %TYPE;
   g_cod_docum         a2000030.cod_docum      %TYPE;
   g_tip_docum         a2000030.tip_docum      %TYPE;
   g_num_periodo       a2000040.num_periodo    %TYPE;
   g_num_riesgo        a2000031.num_riesgo     %TYPE;
   g_num_sini          a7000900.num_sini       %TYPE;
   g_num_exp           a7001000.num_exp        %TYPE;
   g_fec_efec_poliza   a2000030.fec_efec_poliza%TYPE;
   g_fec_sini          a7000900.fec_sini       %TYPE;
   g_fec_denu_sini     a7000900.fec_sini       %TYPE;
   g_cod_cob           a3001800.cod_cob        %TYPE;
   g_cod_cob_sublimite g7009001_mgt.cod_cob    %TYPE;
   g_cod_cto_rva       a3001800.cod_cto_rva    %TYPE;
   g_cod_cto_cob_pag   a3001800.cod_cto_cob_pag%TYPE;
   g_cod_mensaje_cp    g1010020.cod_mensaje    %TYPE;
   g_cod_error         a2000220.cod_error      %TYPE;
   g_obs_error         a2000220.obs_Error      %TYPE;
   g_cod_sistema       a2000220.cod_sistema    %TYPE;
   g_cod_nivel_salto   a2000220.cod_nivel_salto%TYPE;
   g_num_spto          a2000030.num_spto       %TYPE;
   g_num_apli          a2000030.num_apli       %TYPE;
   g_num_spto_apli     a2000030.num_spto_apli  %TYPE;
   g_fec_vcto_poliza   a2000030.fec_vcto_poliza%TYPE;
   g_fec_liq           a3001700.fec_liq        %TYPE;
   g_max_spto_40       a2000040.num_spto       %TYPE;
   g_max_spto_apli_40  a2000040.num_spto_apli  %TYPE;
   g_tip_exp           a7001000.tip_exp        %TYPE;
   g_num_liq           a3001800.num_liq        %TYPE;
   g_val_sospechoso    G2990006.cod_valor      %TYPE;
   g_num_insp          a7006001.num_insp       %TYPE;
   g_num_orden         a7006001.num_orden      %TYPE;
   --
   g_cod_nivel1 a7000900.cod_nivel1%TYPE;
   g_cod_nivel2 a7000900.cod_nivel2%TYPE;
   g_cod_nivel3 a7000900.cod_nivel3%TYPE;
   g_cod_agt    a7000900.cod_agt   %TYPE;
   g_tip_docto  a3001700.tip_docto %TYPE;
   g_imp_liq    a3001700.imp_liq   %TYPE;
   --
   g_cod_usr g1002700.cod_usr_cia%TYPE := trn_k_global.cod_usr;
   --
   g_tip_liquidacion VARCHAR2(10) ;
   g_anx_mensaje     VARCHAR2(100);
   --
   /* -------------------------------------------------------------
   || Aqui comienza la declaracion de constantes GLOBALES
   */ -------------------------------------------------------------
   --
   g_k_tip_poliza      CONSTANT VARCHAR2(01) := 'P'        ;
   g_k_tip_liq_t       CONSTANT VARCHAR2(01) := 'T'        ;
   g_k_tip_recibo      CONSTANT VARCHAR2(01) := 'R'        ;
   g_k_situ_ep         CONSTANT VARCHAR2(02) := 'EP'       ;
   g_k_situ_re         CONSTANT VARCHAR2(02) := 'RE'       ;
   g_k_situ_ct         CONSTANT VARCHAR2(02) := 'CT'       ;
   g_k_control_activo  CONSTANT VARCHAR2(02) := 'CA'       ; -- v1.02
   --
   g_k_cod_campo_docum CONSTANT VARCHAR (09) := 'COD_DOCUM';
   --
   g_k_campo_conductor CONSTANT a2000020.cod_campo        %TYPE := 'MCA_CONDUCTOR_MENOR'    ;
   g_k_cod_campo       CONSTANT a2000020.cod_campo        %TYPE := 'NUM_PASAJEROS'          ;
   g_k_conductor_2019  CONSTANT p2000020.cod_campo        %TYPE := 'VAL_ASEG_CONDUCTOR_2019';
   g_k_pasajero_2019   CONSTANT p2000020.cod_campo        %TYPE := 'VAL_ASEG_PASAJERO_2019' ;
   g_k_conductor_2024  CONSTANT p2000020.cod_campo        %TYPE := 'VAL_ASEG_CONDUCTOR_2024';
   g_k_pasajero_2024   CONSTANT p2000020.cod_campo        %TYPE := 'VAL_ASEG_PASAJERO_2024' ;
   g_k_cto_indemn      CONSTANT h7001200.cod_cto_rva      %TYPE := 1                        ;
   g_k_mvto_estimacion CONSTANT h7001200.tip_mvto         %TYPE := 'E'                      ;
   g_k_agrup_exp_pt    CONSTANT g7000090.tip_agrup_tip_exp%TYPE := 'PT'                     ;
   g_k_exp_mua         CONSTANT a7001000.tip_exp          %TYPE := 'MUA'                    ;
   g_k_exp_gme         CONSTANT a7001000.tip_exp          %TYPE := 'GME'                    ;
   g_k_exp_gfu         CONSTANT a7001000.tip_exp          %TYPE := 'GFU'                    ;
   g_k_exp_ded         CONSTANT a7001000.tip_exp          %TYPE := 'DED'                    ;
   g_k_exp_rec         CONSTANT a7001000.tip_exp          %TYPE := 'REC'                    ;
   g_k_exp_sal         CONSTANT a7001000.tip_exp          %TYPE := 'SAL'                    ;
   g_k_exp_dpa         CONSTANT a7001000.tip_exp          %TYPE := 'DPA'                    ;
   g_k_rot             CONSTANT a7001000.tip_exp          %TYPE := 'RPT'                    ;
   g_k_999             CONSTANT a7001000.tip_exp          %TYPE := '999'                    ;
   --
   g_k_nivel_cob_liq   CONSTANT NUMBER (02) := 2     ;
   g_k_round_2         CONSTANT NUMBER (02) := 2     ;
   g_k_lista_designada CONSTANT NUMBER (02) := 9     ; -- v1.02
   g_k_dias_30         CONSTANT NUMBER (03) := 30    ;
   g_k_dias_60         CONSTANT NUMBER (03) := 60    ;
   g_k_mayor_edad      CONSTANT NUMBER (03) := 18    ;
   g_k_cob_gme         CONSTANT NUMBER (04) := 2006  ;
   g_k_dias_anio       CONSTANT NUMBER (04) := 365   ;
   g_k_cod_cia_coa     CONSTANT NUMBER (06) := 999999;
   --
   g_k_cod_313      CONSTANT a3001800.cod_cto_cob_pag%TYPE:= '313' ;
   g_k_cod_317      CONSTANT a3001800.cod_cto_cob_pag%TYPE:= '317' ;
   g_k_cod_308      CONSTANT a3001800.cod_cto_cob_pag%TYPE:= '308' ;
   g_k_cod_302      CONSTANT a3001800.cod_cto_cob_pag%TYPE:= '302' ;
   g_k_exp_les      CONSTANT a7001000.tip_exp        %TYPE:= 'LES';-- v 1.01
   g_k_exp_rcb      CONSTANT a7001000.tip_exp        %TYPE:= 'RCB';-- v 1.01
   g_k_cob_rce      CONSTANT a2000040.cod_cob        %TYPE:= 2005 ;-- v 1.01
   g_k_cob_pago_com CONSTANT a2000040.cod_cob        %TYPE:= 2040 ;-- v 1.10
   --
   g_k_ts                CONSTANT VARCHAR2(02) := 'TS' ;
   g_k_tip_liquidacion   CONSTANT VARCHAR2(03) := 'LIQ';
   g_k_tip_rectificacion CONSTANT VARCHAR2(03) := 'REC';
   --
   g_k_rehab_sini          CONSTANT g2000210.cod_error%TYPE := 730;
   g_k_orden_liquidacion   CONSTANT g2000210.cod_error%TYPE := 715;
   g_k_sini_extemporaneo   CONSTANT g2000210.cod_error%TYPE := 725;
   g_k_sini_pago_comercial CONSTANT g2000210.cod_error%TYPE := 732;
   g_k_orden_reparacion    CONSTANT g2000210.cod_error%TYPE := 733;
   g_k_liq_dpa             CONSTANT g2000210.cod_error%TYPE := 734;
   g_k_735                 CONSTANT g2000210.cod_error%TYPE := 735;
   --
   g_k_cod_cob_generico    CONSTANT g7009001_mgt.cod_cob        %TYPE := '9999';
   g_k_cod_cto_cob_pag_gen CONSTANT g7009001_mgt.cod_cto_cob_pag%TYPE := '99'  ;
   g_k_benef_pep           CONSTANT g2000210.cod_error          %TYPE := 798   ;
   g_k_benef_desig         CONSTANT g2000210.cod_error          %TYPE := 799   ;
   g_k_supera_sum_vigencia CONSTANT g2000210.cod_error          %TYPE := 753   ;
   g_k_supera_sublimite    CONSTANT g2000210.cod_error          %TYPE := 704   ;
   --
   g_k_causa_otros_gen     CONSTANT g2000210.cod_error%TYPE := 705  ;
   g_k_causa_otr_fenom_nat CONSTANT g7000200.cod_causa%TYPE := '224';
   g_k_causa_otr_riesgos   CONSTANT g7000200.cod_causa%TYPE := '225';
   --
   g_k_cod_ct_facultativo   CONSTANT g2000210.cod_error        %TYPE := 750;
   g_k_supera_sublimite_vig CONSTANT g2000210.cod_error        %TYPE := 754;
   g_k_min_facultativo      CONSTANT a2501000.pct_participacion%TYPE := 40 ;
   --
   /* -------------------------------------------------------------
   || --@mx : Genera la traza
   */ -------------------------------------------------------------
   --
   PROCEDURE mx(p_tit VARCHAR2,
                p_val VARCHAR2)
   IS
   --
   BEGIN
      --
      trn_k_global.asigna ('fic_traza','ctl_sini');
      --
      trn_k_global.asigna ('cab_traza','ts_k_ct_sin');
      --
      em_k_traza.p_escribe (p_tit,
                            p_val);
      --
   END mx;
   --
   /* -------------------------------------------------------------
   || Devuelve el error al llamador
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_devuelve_error
   IS
   --
   BEGIN
      --
      --@mx('I','pp_devuelve_error');
      --
      IF g_cod_mensaje_cp BETWEEN 20000
                              AND 20999
      THEN
         --
         RAISE_APPLICATION_ERROR (-g_cod_mensaje_cp,
                                 ss_k_mensaje.f_texto_idioma (g_cod_mensaje_cp          ,
                                                              trn_k_global.cod_idioma ) ||
                                                              g_anx_mensaje              );
         --
      ELSE
         --
         RAISE_APPLICATION_ERROR (-20000,
                                  ss_k_mensaje.f_texto_idioma (g_cod_mensaje_cp          ,
                                                               trn_k_global.cod_idioma ) ||
                                                               g_anx_mensaje              );
         --
      END IF;
      --
      --@mx('F','pp_devuelve_error');
      --
   END pp_devuelve_error;
   --
   /* -----------------------------------------------------------
   || Procedimiento para recuperar las variables Globales
   */ -----------------------------------------------------------
   --
   PROCEDURE pp_a2000040_vig
   IS
   --
   BEGIN
      --
      ts_k_apertura.p_max_spto_a2000040 (g_cod_cia         ,
                                         g_num_sini        ,
                                         g_max_spto_40     ,
                                         g_max_spto_apli_40);
      --
      g_num_periodo := ts_k_a7000900.f_num_periodo;
      --
      em_k_a2000040.p_lee (g_cod_cia         ,
                           g_num_poliza      ,
                           g_max_spto_40     ,
                           g_num_apli        ,
                           g_max_spto_apli_40,
                           g_num_riesgo      ,
                           g_num_periodo     ,
                           g_cod_cob         ,
                           g_cod_ramo        );
      --
   END pp_a2000040_vig;
   --
   /* -------------------------------------------------------------
   || pp_carga_globales : Carga globales
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_carga_globales
   IS
      --
   BEGIN
      --
      --@mx('I','pp_carga_globales');
      --
      g_cod_cia         := trn_k_global.ref_f_global('cod_cia')                            ;
      g_cod_sector      := trn_k_global.ref_f_global('cod_sector')                         ;
      g_cod_ramo        := trn_k_global.ref_f_global('cod_ramo')                           ;
      g_num_poliza      := trn_k_global.ref_f_global('num_poliza')                         ;
      g_cod_docum       := trn_k_global.ref_f_global('cod_docum')                          ;
      g_tip_docum       := trn_k_global.ref_f_global('tip_docum')                          ;
      g_num_sini        := trn_k_global.ref_f_global('num_sini')                           ;
      g_num_riesgo      := trn_k_global.ref_f_global('num_riesgo')                         ;
      g_num_exp         := trn_k_global.ref_f_global('num_exp')                            ;
      g_tip_exp         := trn_k_global.ref_f_global('tip_exp')                            ;
      g_fec_sini        := TO_DATE(trn_k_global.ref_f_global('fec_sini'),'DD/MM/YYYY')     ;
      g_fec_denu_sini   := TO_DATE(trn_k_global.ref_f_global('fec_denu_sini'),'DD/MM/YYYY');
      g_cod_cob         := trn_k_global.ref_f_global('cod_cob')                            ;
      g_cod_cto_rva     := trn_k_global.ref_f_global('cod_cto_rva')                        ;
      g_cod_cto_cob_pag := trn_k_global.ref_f_global('cod_cto_cob_pag')                    ;
      g_cod_sistema     := trn_k_global.ref_f_global ('cod_sistema')                       ;
      g_cod_nivel_salto := trn_k_global.ref_f_global ('cod_nivel_salto')                   ;
      g_num_spto        := trn_k_global.ref_f_global ('num_spto')                          ;
      g_num_apli        := trn_k_global.ref_f_global ('num_apli')                          ;
      g_num_spto_apli   := trn_k_global.ref_f_global ('num_spto_apli')                     ;
      g_num_liq         := trn_k_global.ref_f_global ('num_liq')                           ;
      g_val_sospechoso  := trn_k_global.ref_f_global ('dvmca_sospechoso')                  ;
      g_num_insp        := trn_k_global.ref_f_global ('num_insp')                          ;
      g_num_orden       := trn_k_global.ref_f_global ('num_orden')                         ;
      --
      g_cod_nivel1      := trn_k_global.ref_f_global ('cod_nivel1')                        ;
      g_cod_nivel2      := trn_k_global.ref_f_global ('cod_nivel2')                        ;
      g_cod_nivel3      := trn_k_global.ref_f_global ('cod_nivel3')                        ;
      g_cod_agt         := trn_k_global.ref_f_global ('cod_agt')                           ;
      --
      g_tip_docto       := trn_k_global.ref_f_global('tip_docto');
      --
      --@mx('F','pp_carga_globales');
      --
   END pp_carga_globales;
   --
   /* -------------------------------------------------------------
   || pp_asigna : llama a trn_k_global.asigna
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_asigna(p_nom_global VARCHAR2,
                       p_val_global VARCHAR2)
   IS
   --
   BEGIN
      --
      --@mx('I','pp_asigna');
      --
      trn_k_global.asigna(p_nom_global, p_val_global);
      --
      --@mx('F','pp_asigna');
      --
   END pp_asigna;
   --
   /* -------------------------------------------------------------
   || fp_val_cob : Funcion que retorna la suma asegurada
   ||                    de una poliza
   */ -------------------------------------------------------------
   --
   FUNCTION fp_val_cob (p_cod_campo_val IN VARCHAR2)
   RETURN NUMBER
   IS
      --
      l_val_cob     NUMBER;
      --
     CURSOR c_p2000020 (c_num_poliza    p2000020.num_poliza    %TYPE,
                        c_cod_campo     p2000020.cod_campo     %TYPE) IS
         SELECT TO_NUMBER(val_campo)
           FROM p2000020 a
          WHERE a.num_poliza   = c_num_poliza
            AND a.cod_campo    = c_cod_campo   ;
      --
   BEGIN
      --
      OPEN  c_p2000020 (c_num_poliza => g_num_poliza   ,
                        c_cod_campo  => p_cod_campo_val);
      --
      FETCH c_p2000020 INTO l_val_cob;
      --
      CLOSE c_p2000020;
      --
      RETURN l_val_cob;
      --
   END fp_val_cob;
   --
   /* -------------------------------------------------------------
   || pp_lee_sublimite : busca sub limite asociado a los conceptos
   ||                    de cobro pago
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_lee_sublimite(
                 p_cod_cia           g7009001_mgt.cod_cia          %TYPE,
                 p_cod_ramo          g7009001_mgt.cod_ramo         %TYPE,
                 p_tip_exp           g7009001_mgt.tip_exp          %TYPE,
                 p_cod_cto_rva       g7009001_mgt.cod_cto_rva      %TYPE,
                 p_cod_cob           g7009001_mgt.cod_cob          %TYPE,
                 p_cod_cto_cob_pag   g7009001_mgt.cod_cto_cob_pag  %TYPE)
   IS
    --
    CURSOR cl_g7009001_mgt   IS
         SELECT cod_cob_sublimite
           FROM g7009001_mgt
          WHERE cod_cia           = p_cod_cia
            AND cod_ramo          = p_cod_ramo
            AND tip_exp           = p_tip_exp
            AND cod_cto_rva       = p_cod_cto_rva
            AND cod_cob           = p_cod_cob
            AND cod_cto_cob_pag   = p_cod_cto_cob_pag
            AND mca_inh           = trn.NO;
     --
     --Busca sub limite que apliquen para cualquier cobertura
     CURSOR cl_g7009001_cob_mgt   IS
         SELECT cod_cob_sublimite
           FROM g7009001_mgt
          WHERE cod_cia           = p_cod_cia
            AND cod_ramo          = p_cod_ramo
            AND tip_exp           = p_tip_exp
            AND cod_cto_rva       = p_cod_cto_rva
            AND cod_cob           = g_k_cod_cob_generico
            AND cod_cto_cob_pag   = p_cod_cto_cob_pag
            AND mca_inh           = trn.NO;
      --Busca sub limite que apliquen para cualquier cobertura y concepto de cobro pago
      CURSOR cl_g7009001_cto_cob_pag_mgt   IS
         SELECT cod_cob_sublimite
           FROM g7009001_mgt
          WHERE cod_cia           = p_cod_cia
            AND cod_ramo          = p_cod_ramo
            AND tip_exp           = p_tip_exp
            AND cod_cto_rva       = p_cod_cto_rva
            AND cod_cob           = g_k_cod_cob_generico
            AND cod_cto_cob_pag   = g_k_cod_cto_cob_pag_gen
            AND mca_inh           = trn.NO;
    --
   BEGIN
    --
    OPEN        cl_g7009001_mgt;
    FETCH       cl_g7009001_mgt    INTO g_cod_cob_sublimite;
    g_existe := cl_g7009001_mgt%FOUND;
    CLOSE       cl_g7009001_mgt;
    --
    IF g_existe = FALSE THEN
         OPEN        cl_g7009001_cob_mgt;
         FETCH       cl_g7009001_cob_mgt    INTO g_cod_cob_sublimite;
         g_existe := cl_g7009001_cob_mgt%FOUND;
         CLOSE       cl_g7009001_cob_mgt;
    END IF;
    --
    IF g_existe = FALSE THEN
         OPEN        cl_g7009001_cto_cob_pag_mgt;
         FETCH       cl_g7009001_cto_cob_pag_mgt    INTO g_cod_cob_sublimite;
         g_existe := cl_g7009001_cto_cob_pag_mgt%FOUND;
         CLOSE       cl_g7009001_cto_cob_pag_mgt;
    END IF;
    --
   END pp_lee_sublimite;
   --
  /* -------------------------------------------------------------
   || pp_ct_fecha_vig_poliza : Fecha de siniestro menor a 30 dias
   ||                          de la fecha de efecto de la poliza
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_ct_fecha_vig_poliza
   IS
      --
      l_dias              NUMBER  := trn.cero;           -- v 1.03 - estaba de 2
      --
   BEGIN
      --
      --@mx('I','pp_ct_fecha_vig_poliza');
      --
      em_k_a2000030.p_lee(p_cod_cia       => g_cod_cia       ,
                          p_num_poliza    => g_num_poliza    ,
                          p_num_spto      => g_num_spto      ,
                          p_num_apli      => g_num_apli      ,
                          p_num_spto_apli => g_num_spto_apli);
      --
      IF em_k_a2000030.f_fec_efec_poliza IS NOT NULL
      THEN
         --
         l_dias := g_fec_sini - em_k_a2000030.f_fec_efec_poliza;
         --
         IF l_dias < g_k_dias_30
         THEN
            --
            -- FECHA DE SINIESTRO MENOR A 30 DIAS DE LA FECHA DE EFECTO DE LA POLIZA
            --
            g_cod_error := 234;
            --
            ts_k_as799001.p_grabar (p_cod_error => g_cod_error) ;
            --
         END IF;
         --
      END IF;
      --
      --@mx('F','pp_ct_fecha_vig_poliza');
      --
   END pp_ct_fecha_vig_poliza;
   --
   /* -------------------------------------------------------------
   || pp_ct_prima_pendiente :Poliza tiene primas pendientes >= 30.
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_ct_prima_pendiente
   IS
      --
      l_fec_vcto_pago   a2990700.fec_vcto_pago  %TYPE;
      l_dias            NUMBER(3)                    ;
      --
      CURSOR cl_a2990700 IS
         SELECT MIN(a29.fec_vcto_recibo)--MIN(a29.fec_vcto_pago) --todo: cambiar por fec_vcto_pago, solo comente para hacer una prueba
           FROM a2990700 a29
          WHERE a29.cod_cia       = g_cod_cia
            AND a29.num_poliza    = g_num_poliza
            AND a29.num_spto      = (SELECT MAX(a2.num_spto)
                                       FROM a2990700 a2
                                      WHERE a2.cod_cia       =  g_cod_cia
                                        AND a2.num_poliza    =  g_num_poliza
                                        AND a2.tip_situacion <> g_k_situ_ct )
            AND a29.tip_situacion <> g_k_situ_ct
       ORDER BY a29.cod_cia,
                a29.num_poliza,
                a29.num_spto,
                a29.num_apli,
                a29.num_spto_apli,
                a29.num_cuota,
                a29.mca_ca,
                a29.mca_cv;
      --
   BEGIN
      --
      --@mx('I','pp_ct_prima_pendiente');
      --
      l_dias := trn.CERO;
      --
      OPEN cl_a2990700;
      --
      FETCH cl_a2990700 INTO l_fec_vcto_pago;
      --
      CLOSE cl_a2990700;
      --
      IF  l_fec_vcto_pago IS NOT NULL
      THEN
         --
         IF g_fec_sini >= l_fec_vcto_pago
         THEN
            --
            l_dias := g_fec_sini - l_fec_vcto_pago;
            --
            IF l_dias >= g_k_dias_60
            THEN
               --
               -- POLIZA TIENE MAS DE 60 DIAS DE NO PAGO
               --
               g_cod_error := 236;
               --
               ts_k_as799001.p_grabar (p_cod_error => g_cod_error);
               --
            END IF;
            --
         END IF;
         --
      END IF;
      --
      --@mx('F','pp_ct_prima_pendiente');
      --
   END pp_ct_prima_pendiente;
   --
   /* --------------------------------------------------------
   || pp_ct_suma_cob_vigencia:
   || La liquidacion supera la suma asegurada de la vigencia
   */ --------------------------------------------------------
   --
   PROCEDURE pp_ct_suma_cob_vigencia
   IS
      --
      l_num_poliza      a7000900.num_poliza     %TYPE;
      l_fec_efec_poliza a2000030.fec_efec_poliza%TYPE;
      l_fec_vcto_poliza a2000030.fec_vcto_poliza%TYPE;
      l_imp_liq         a3001800.imp_liq        %TYPE;
      l_imp_liq_total   a3001800.imp_liq        %TYPE;
      l_imp_iva         a3001800.imp_iva        %TYPE;
      l_sum_aseg        a2000040.suma_aseg      %TYPE; --V1.01
      --
      CURSOR cl_a3001800
      IS
          SELECT NVL(SUM (liq.imp_liq), trn.CERO) AS imp_liq
            FROM a3001800 liq
      INNER JOIN a7000900 s
              ON liq.cod_cia  = s.cod_cia
             AND liq.num_sini = s.num_sini
           WHERE liq.cod_cob  = g_cod_cob
             AND s.num_poliza = l_num_poliza
             AND s.fec_sini BETWEEN l_fec_efec_poliza AND l_fec_vcto_poliza;
      -- {v1.01
      CURSOR cl_a2000040
      IS
         --
         SELECT a.suma_aseg
           FROM a2000040 a
          WHERE a.num_poliza = l_num_poliza
            AND a.num_spto   = (SELECT MAX(b.num_spto)
                                  FROM a2000040 b
                                 WHERE b.num_poliza = a.num_poliza)
            AND cod_cob      = g_cod_cob;--v1.01}
      --
   BEGIN
      --
      --@mx('I','pp_ct_suma_cob_vigencia');
      --
      --obtener liquidacion de tablas de memoria
      ts_k_a3001800_1.leer_total_liq (p_imp_iva => l_imp_iva      ,
                                      p_imp_liq => l_imp_liq_total);
      --
      --obtener datos del siniestro
      ts_k_a7000900.p_lee_a7000900(p_cod_cia  => g_cod_cia ,
                                   p_num_sini => g_num_sini);
      --
      --obtiene datos fijos de la poliza
      em_k_a2000030.p_lee (p_cod_cia       => g_cod_cia                    ,
                           p_num_poliza    => ts_k_a7000900.f_num_poliza   ,
                           p_num_spto      => ts_k_a7000900.f_num_spto     ,
                           p_num_apli      => ts_k_a7000900.f_num_apli     ,
                           p_num_spto_apli => ts_k_a7000900.f_num_spto_apli);
      --
      l_fec_efec_poliza := em_k_a2000030.f_fec_efec_poliza;
      l_fec_vcto_poliza := em_k_a2000030.f_fec_vcto_poliza;
      --
      l_num_poliza := ts_k_a7000900.f_num_poliza;
      --
      --obtiene datos de la cobertura
      --{v1.01
      OPEN  cl_a2000040;
      --
      FETCH cl_a2000040 INTO l_sum_aseg;
      --
      CLOSE cl_a2000040; --v1.01}
      --
      OPEN cl_a3001800;
      --
      FETCH cl_a3001800 INTO l_imp_liq;
      --
      CLOSE cl_a3001800;
      --
      IF l_imp_liq IS NULL
      THEN
         --
         l_imp_liq:= trn.CERO;
         --
      END IF;
      --
      trn_k_global.p_asigna ('imp_valor_liquidado', l_imp_liq        );
      trn_k_global.p_asigna ('cod_cob_liquida'    , g_cod_cob        );
      trn_k_global.p_asigna ('l_num_poliza'       , l_num_poliza     );
      trn_k_global.p_asigna ('l_fec_efec_poliza'  , l_fec_efec_poliza);
      trn_k_global.p_asigna ('l_fec_vcto_poliza'  , l_fec_vcto_poliza);
      trn_k_global.p_asigna ('l_imp_liq_total'    , l_imp_liq_total  );
      --
      IF l_sum_aseg < (l_imp_liq + l_imp_liq_total)
      THEN
         --
         --@mx('g_cod_error*', g_cod_error);
         --
         g_cod_error := g_k_supera_sum_vigencia;
         --
         ts_k_as799001.p_grabar (p_cod_error => g_cod_error);
         --
      END IF;
      --
      --@mx('F','pp_ct_suma_cob_vigencia');
      --
   END pp_ct_suma_cob_vigencia;
   --
   /* -------------------------------------------------------------
   || pp_ct_suma_sub_limite:
   || la liquidacion supera la suma del sublimite
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_ct_suma_sub_limite
   IS
      --
      l_num_reg_a3001800 NUMBER(10);
      l_imp_liq           a3001800.imp_liq           %TYPE;
      l_cod_cob           a3001800.cod_cob           %TYPE;
      l_cod_cto_rva       a3001800.cod_cto_rva       %TYPE;
      l_cod_cto_cob_pag   a3001800.cod_cto_cob_pag   %TYPE;
      --
   BEGIN
      --
      --@mx('I','pp_ct_suma_sub_limite');
      --
       --obtener datos del siniestro
      ts_k_a7000900.p_lee_a7000900(p_cod_cia  => g_cod_cia ,
                                   p_num_sini => g_num_sini);
      --
      /*Obtener conceptos de cobro pago liquidados de la liquidacion actual*/
      --
      l_num_reg_a3001800 := NVL(ts_k_a3001800_1.f_nro_max_cptos, trn.CERO);
      --
      IF l_num_reg_a3001800 > trn.CERO
      THEN
         --
         FOR i IN trn.UNO..l_num_reg_a3001800
         LOOP
             --
             l_imp_liq         :=   ts_k_a3001800_1.f_imp_liq(i)            ;
             l_cod_cto_cob_pag :=   ts_k_a3001800_1.f_cod_cto_cob_pag(i)    ;
             l_cod_cto_rva     :=   ts_k_a3001800_1.f_cod_cto_rva(i)        ;
             l_cod_cob         :=   ts_k_a3001800_1.f_cod_cob(i)            ;
             --
             IF l_imp_liq IS NOT NULL
                AND l_imp_liq <> trn.CERO
             THEN
                --
                pp_lee_sublimite(p_cod_cia          => g_cod_cia          ,
                                 p_cod_ramo         => g_cod_ramo         ,
                                 p_tip_exp          => g_tip_exp          ,
                                 p_cod_cto_rva      => l_cod_cto_rva      ,
                                 p_cod_cob          => l_cod_cob          ,
                                 p_cod_cto_cob_pag  => l_cod_cto_cob_pag  );
                --
                IF g_cod_cob_sublimite IS NOT NULL
                THEN
                  --
                   --obtiene datos de la cobertura
                   em_k_a2000040.p_lee(p_cod_cia       => g_cod_cia                    ,
                                       p_num_poliza    => ts_k_a7000900.f_num_poliza   ,
                                       p_num_spto      => ts_k_a7000900.f_num_spto     ,
                                       p_num_apli      => ts_k_a7000900.f_num_apli     ,
                                       p_num_spto_apli => ts_k_a7000900.f_num_spto_apli,
                                       p_num_riesgo    => ts_k_a7000900.f_num_riesgo   ,
                                       p_num_periodo   => ts_k_a7000900.f_num_periodo  ,
                                       p_cod_cob       => g_cod_cob_sublimite          ,
                                       p_cod_ramo      => ts_k_a7000900.f_cod_ramo     );
                    --
                    IF em_k_a2000040.f_suma_aseg < l_imp_liq
                    THEN
                          --
                          g_cod_error := g_k_supera_sublimite;
                          --
                          ts_k_as799001.p_grabar (p_cod_error => g_cod_error);
                          --
                          RETURN;
                          --
                    END IF;
                    --
                END IF;
                --
             END IF;
             --
         END LOOP;
         --
      END IF;
      --
      --@mx('F','pp_ct_suma_sub_limite');
      --
   END pp_ct_suma_sub_limite;
   --
   /*-------------------------------------------------------------
   || Programa: pp_benef_no_deseado
   -------------------------------------------------------------*/
   --
   PROCEDURE pp_benef_no_deseado
   IS
      --
      l_cod_act_tercero       v1001390.cod_act_tercero   %TYPE          ;
      l_cod_error_pep         g2000211.cod_error         %TYPE          ;
      l_cod_error_desig       g2000211.cod_error         %TYPE          ;
      l_mca_en_lista_negra    VARCHAR2(1)                      := trn.NO;
      l_mca_en_lista_pep      VARCHAR2(1)                      := trn.NO;
      l_txt_motivo            VARCHAR2(4000)                            ;
      --
      CURSOR lc_a1009301 (pc_tip_docum a1009301.tip_docum%TYPE ,
                          pc_cod_docum a1009301.cod_docum%TYPE)
      IS
         --
         SELECT a.*
           FROM a1009301 a
          WHERE a.cod_cia   = g_cod_cia
            AND a.tip_docum = pc_tip_docum
            AND a.cod_docum = pc_cod_docum
          ORDER BY a.tip_docum,
                   a.cod_docum;
      --
      l_reg_a1009301 lc_a1009301 %ROWTYPE;
      -- { v1.02
      CURSOR lc_a1001320 (pc_cod_act_ter        a1001320.cod_act_tercero   %TYPE,
                          pc_tip_docum          a1001320.tip_docum         %TYPE,
                          pc_cod_docum          a1001320.cod_docum         %TYPE)
                          
      IS
         --
         SELECT a.*
           FROM a1001320 a
          WHERE a.cod_cia            = g_cod_cia
            AND a.cod_act_tercero    = pc_cod_act_ter
            AND a.tip_docum          = pc_tip_docum
            AND a.cod_docum          = pc_cod_docum
            AND a.cod_calidad        = g_k_lista_designada
            AND a.tip_estado_calidad = g_k_control_activo
            AND a.fec_validez        = (SELECT MAX(b.fec_validez)
                                          FROM a1001320 b
                                         WHERE b.cod_cia            = a.cod_cia
                                           AND b.cod_act_tercero    = a.cod_act_tercero
                                           AND b.tip_docum          = a.tip_docum
                                           AND b.cod_docum          = a.cod_docum
                                           AND b.cod_calidad        = a.cod_calidad
                                           AND b.tip_estado_calidad = a.tip_estado_calidad);
      --
      l_reg_a1001320 lc_a1001320 %ROWTYPE;
      -- } v1.02
   BEGIN
      --
      --@mx('I','pp_benef_no_deseado');
      --
      l_cod_error_pep   := g_k_benef_pep;
      l_cod_error_desig := g_k_benef_desig;
      --
      l_cod_act_tercero   := trn_k_global.ref_f_global('cod_act_tercero');
      --
      OPEN lc_a1009301 (pc_tip_docum => g_tip_docum,
                        pc_cod_docum => g_cod_docum);
      --
      FETCH lc_a1009301 INTO l_reg_a1009301;
      --
      IF lc_a1009301%FOUND
      THEN
         --
         l_mca_en_lista_pep := trn.SI;
         --
      END IF;
      --
      CLOSE lc_a1009301;
      --  { v1.02
      OPEN lc_a1001320 (pc_cod_act_ter => l_cod_act_tercero,
                        pc_tip_docum   => g_tip_docum      ,
                        pc_cod_docum   => g_cod_docum      );
      --
      FETCH lc_a1001320 INTO l_reg_a1001320;
      --
      IF lc_a1001320%FOUND
      THEN
         --
         l_mca_en_lista_negra := trn.SI;
         --
      END IF;
      --
      CLOSE lc_a1001320;
      --  } v1.02
      IF    l_mca_en_lista_negra = trn.SI
      THEN
         --
         ts_k_as799001.p_grabar(l_cod_error_desig);
         --
      END IF;
      --
      IF    l_mca_en_lista_pep = trn.SI
      THEN
         --
         ts_k_as799001.p_grabar(l_cod_error_pep);
         --
      END IF;
      --
      --@mx('F','pp_benef_no_deseado');
      --
   END pp_benef_no_deseado;
   --
   /*-------------------------------------------------------------
   || Programa: pp_val_causa_otros
   -------------------------------------------------------------*/
   --
   PROCEDURE pp_val_causa_otros
   IS
      --
      l_cod_causa             a7000900.cod_causa_sini    %TYPE          ;
      l_causa_otr_fenom_nat   a7000900.cod_causa_sini    %TYPE          ;
      l_causa_otr_riesgos     a7000900.cod_causa_sini    %TYPE          ;
      l_cod_error_otros       g2000211.cod_error         %TYPE          ;
      --
   BEGIN
      --
      --@mx('I','pp_val_causa_otros');
      --
      l_cod_error_otros   := g_k_causa_otros_gen;
      --
      --
      ts_k_a7000900.p_lee_a7000900(p_cod_cia  => g_cod_cia ,
                                   p_num_sini => g_num_sini);
      --
      l_cod_causa := ts_k_a7000900.f_cod_causa_sini;
      --
      l_causa_otr_fenom_nat := NVL((ts_k_228_utils.f_valor_parametro(p_cod_usr             => g_cod_usr                                                        ,
                                                                     p_txt_nombre_variable => ts_k_228_utils.g_k_causa_otr_fenom_nat)), g_k_causa_otr_fenom_nat);
      --
      l_causa_otr_riesgos := NVL((ts_k_228_utils.f_valor_parametro(p_cod_usr             => g_cod_usr                                                    ,
                                                                   p_txt_nombre_variable => ts_k_228_utils.g_k_causa_otr_riesgos)), g_k_causa_otr_riesgos);
      --
      --
      IF l_cod_causa IN(l_causa_otr_fenom_nat,l_causa_otr_riesgos)
      THEN
         --
         ts_k_as799001.p_grabar(l_cod_error_otros);
         --
      END IF;
      --
      --@mx('F','pp_val_causa_otros');
      --
   END pp_val_causa_otros;
   --
   /* -------------------------------------------------------------
   || pp_lee_sublimite : busca sub limite asociado a los conceptos
   ||                    de cobro pago
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_lee_sublimite(p_cod_cia           g7009001_mgt.cod_cia          %TYPE,
                              p_tip_exp           g7009001_mgt.tip_exp          %TYPE,
                              p_cod_cto_rva       g7009001_mgt.cod_cto_rva      %TYPE,
                              p_cod_cob           g7009001_mgt.cod_cob          %TYPE,
                              p_cod_cto_cob_pag   g7009001_mgt.cod_cto_cob_pag  %TYPE
                              )
   IS
   --
   CURSOR cl_g7009001_mgt
   IS
      SELECT cod_cob_sublimite
        FROM g7009001_mgt
       WHERE cod_cia           = p_cod_cia
         AND tip_exp           = p_tip_exp
         AND cod_cto_rva       = p_cod_cto_rva
         AND cod_cob           = p_cod_cob
         AND cod_cto_cob_pag   = p_cod_cto_cob_pag;
   --
   --Busca sub limite que apliquen para cualquier cobertura
   CURSOR cl_g7009001_cob_mgt
   IS
      SELECT cod_cob_sublimite
        FROM g7009001_mgt
       WHERE cod_cia           = p_cod_cia
         AND tip_exp           = p_tip_exp
         AND cod_cto_rva       = p_cod_cto_rva
         AND cod_cob           = g_k_cod_cob_generico
         AND cod_cto_cob_pag   = p_cod_cto_cob_pag   ;
   --Busca sub limite que apliquen para cualquier cobertura y concepto de cobro pago
   CURSOR cl_g7009001_cto_cob_pag_mgt
   IS
      SELECT cod_cob_sublimite
        FROM g7009001_mgt
       WHERE cod_cia           = p_cod_cia
         AND tip_exp           = p_tip_exp
         AND cod_cto_rva       = p_cod_cto_rva
         AND cod_cob           = g_k_cod_cob_generico
         AND cod_cto_cob_pag   = g_k_cod_cto_cob_pag_gen;
   --
   BEGIN
      --
      OPEN        cl_g7009001_mgt;
      --
      FETCH       cl_g7009001_mgt    INTO g_cod_cob_sublimite;
      --
      g_existe := cl_g7009001_mgt%FOUND;
      --
      CLOSE       cl_g7009001_mgt;
      --
      IF g_existe = FALSE
      THEN
         --
         OPEN  cl_g7009001_cob_mgt;
         --
         FETCH cl_g7009001_cob_mgt INTO g_cod_cob_sublimite;
         --
         g_existe := cl_g7009001_cob_mgt%FOUND;
         --
         CLOSE       cl_g7009001_cob_mgt;
         --
      END IF;
      --
      IF g_existe = FALSE
      THEN
         --
         OPEN        cl_g7009001_cto_cob_pag_mgt;
         --
         FETCH       cl_g7009001_cto_cob_pag_mgt    INTO g_cod_cob_sublimite;
         --
         g_existe := cl_g7009001_cto_cob_pag_mgt%FOUND;
         --
         CLOSE       cl_g7009001_cto_cob_pag_mgt;
         --
      END IF;
      --
   END pp_lee_sublimite;
   --
   /* -------------------------------------------------------------
   || pp_ct_sublimite_vigencia : la liquidacion supera la suma
   || asegurada del sublimite en la vigencia
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_ct_sublimite_vigencia
   IS
      --
      l_num_reg_a3001800  NUMBER(10);
      --
      l_imp_liq           a3001800.imp_liq           %TYPE;
      l_cod_cob           a3001800.cod_cob           %TYPE;
      l_cod_cto_rva       a3001800.cod_cto_rva       %TYPE;
      l_cod_cto_cob_pag   a3001800.cod_cto_cob_pag   %TYPE;
      l_fec_efec_poliza   a2000030.fec_efec_poliza   %TYPE;
      l_fec_vcto_poliza   a2000030.fec_vcto_poliza   %TYPE;
      l_imp_liq_total     a3001800.imp_liq           %TYPE;
      l_imp_iva           a3001800.imp_iva           %TYPE;
      --
      CURSOR     cl_a3001800 IS
          SELECT NVL(SUM (liq.imp_liq), trn.CERO) AS imp_liq
            FROM a3001800 liq
      INNER JOIN a7000900 s
              ON liq.cod_cia            =   s.cod_cia
             AND liq.num_sini           =   s.num_sini
      INNER JOIN a7001000 ex
              ON ex.cod_cia             =   s.cod_cia
             AND ex.num_sini            =   s.num_sini
             AND ex.num_exp             =   liq.num_exp
      INNER JOIN g7009001_mgt sub
              ON sub.cod_cia            =   liq.cod_cia
             AND sub.cod_ramo           =   s.cod_ramo
             AND sub.tip_exp            =   ex.tip_exp
             AND sub.cod_cto_rva        =   liq.cod_cto_rva
             AND sub.cod_cob            IN  (liq.cod_cob, em.COD_COB_GEN)
             AND sub.cod_cto_cob_pag    IN  (liq.cod_cto_cob_pag, '999')
           WHERE liq.cod_cob            =   g_cod_cob
             AND s.num_poliza           =   g_num_poliza
             AND sub.cod_cob_sublimite  =   g_cod_cob_sublimite
             AND s.fec_sini BETWEEN l_fec_efec_poliza AND l_fec_vcto_poliza;
      --
   BEGIN
      --
      --@mx('I','pp_ct_sublimite_vigencia');
      ----obtener datos del siniestro
      ts_k_a7000900.p_lee_a7000900(p_cod_cia  => g_cod_cia ,
                                   p_num_sini => g_num_sini);
      --
      --obtiene datos fijos de la poliza
      em_k_a2000030.p_lee (p_cod_cia       => g_cod_cia                    ,
                           p_num_poliza    => ts_k_a7000900.f_num_poliza   ,
                           p_num_spto      => ts_k_a7000900.f_num_spto     ,
                           p_num_apli      => ts_k_a7000900.f_num_apli     ,
                           p_num_spto_apli => ts_k_a7000900.f_num_spto_apli);
      --
      l_fec_efec_poliza:= em_k_a2000030.f_fec_efec_poliza;
      --
      l_fec_vcto_poliza:= em_k_a2000030.f_fec_vcto_poliza;
      --
      /*Obtener conceptos de cobro pago liquidados de la liquidacion actual*/
      --
      l_num_reg_a3001800 := NVL(ts_k_a3001800_1.f_nro_max_cptos, trn.CERO);
      --
      --@mx('tip_exp', g_tip_exp);
      --
      IF l_num_reg_a3001800 > trn.CERO
      THEN
         --
         FOR i IN trn.UNO..l_num_reg_a3001800
         LOOP
             --
             l_imp_liq         :=   ts_k_a3001800_1.f_imp_liq(i)            ;
             l_cod_cto_cob_pag :=   ts_k_a3001800_1.f_cod_cto_cob_pag(i)    ;
             l_cod_cto_rva     :=   ts_k_a3001800_1.f_cod_cto_rva(i)        ;
             l_cod_cob         :=   ts_k_a3001800_1.f_cod_cob(i)            ;
             --
             IF     l_imp_liq IS NOT NULL
                AND l_imp_liq <> trn.CERO
             THEN
                --
                pp_lee_sublimite(p_cod_cia          => g_cod_cia          ,
                                 p_tip_exp          => g_tip_exp          ,
                                 p_cod_cto_rva      => l_cod_cto_rva      ,
                                 p_cod_cob          => l_cod_cob          ,
                                 p_cod_cto_cob_pag  => l_cod_cto_cob_pag);
                --
                IF g_cod_cob_sublimite IS NOT NULL
                THEN
                   --Obtirne el valor liquidado en ese sub limite
                   l_imp_liq_total:= trn.CERO;
                   --
                   OPEN cl_a3001800;
                   --
                   FETCH cl_a3001800 INTO l_imp_liq_total;
                   --
                   CLOSE cl_a3001800;
                   --
                   IF l_imp_liq_total IS NULL
                   THEN
                      --
                      l_imp_liq_total:= trn.CERO;
                      --
                   END IF;
                   --obtiene datos de la cobertura
                   em_k_a2000040.p_lee(p_cod_cia       => g_cod_cia                    ,
                                       p_num_poliza    => ts_k_a7000900.f_num_poliza   ,
                                       p_num_spto      => ts_k_a7000900.f_num_spto     ,
                                       p_num_apli      => ts_k_a7000900.f_num_apli     ,
                                       p_num_spto_apli => ts_k_a7000900.f_num_spto_apli,
                                       p_num_riesgo    => ts_k_a7000900.f_num_riesgo   ,
                                       p_num_periodo   => ts_k_a7000900.f_num_periodo  ,
                                       p_cod_cob       => g_cod_cob_sublimite          ,
                                       p_cod_ramo      => ts_k_a7000900.f_cod_ramo     );
                    --
                    --Verifica que lo que se esta liquidando + lo que se liquido
                    --en siniestros anteriore
                    --
                    IF em_k_a2000040.f_suma_aseg < (l_imp_liq + l_imp_liq_total)
                    THEN
                       --
                       g_cod_error := g_k_supera_sublimite_vig;
                       --
                       ts_k_as799001.p_grabar (p_cod_error => g_cod_error);
                       --
                       RETURN;
                       --
                    END IF;
                    --
                END IF;
                --
             END IF;
             --
         END LOOP;
         --
      END IF;
      --
      --@mx('F','pp_ct_sublimite_vigencia');
      --
   END pp_ct_sublimite_vigencia;
   --
   /* --------------------------------------------------------
   || pp_ct_max_importe:
   || ct valida que la liquidacion no supere el maximo valor
   || del importe
   */ --------------------------------------------------------
   --
   PROCEDURE pp_ct_max_importe_liq
   IS
      --
      l_cod_tratamiento a1001800.cod_tratamiento%TYPE;
      l_val_max         tsctrl001.imp_maximo    %TYPE;
      l_cod_error       tsctrl002.cod_error     %TYPE;
      --
      l_num_reg_a3001800    NUMBER                   ;
      --
   BEGIN
      --
      --@mx('I','pp_ct_max_importe_liq');
      --
      dc_k_a1001800.p_lee (p_cod_cia  => g_cod_cia ,
                           p_cod_ramo => g_cod_ramo);
      --
      l_cod_tratamiento := dc_k_a1001800.f_cod_tratamiento;
      --
      -- obtener importe de la liquidacion
      l_num_reg_a3001800 := NVL(ts_k_a3001800_1.f_nro_max_cptos, trn.CERO);
      --
      IF l_num_reg_a3001800 > trn.CERO
      THEN
         --
         FOR i IN trn.UNO..l_num_reg_a3001800         -- Recorro la tabla de memoria
         LOOP
            --
            IF     ts_k_a3001800_1.f_imp_liq(i) IS NOT NULL
               AND ts_k_a3001800_1.f_imp_liq(i) <>trn.CERO
            THEN
               --
               -- recupera el valor de liquidacion actual
               g_imp_liq := nvl(g_imp_liq,trn.CERO) + NVL( ts_k_a3001800_1.f_imp_liq(i),trn.CERO);
               --
            END IF;
            --
         END LOOP;
         --
      END IF;
      --
      BEGIN
         --
         ts_k_tsctrl001.p_lee (p_cod_cia            => g_cod_cia        ,
                               p_cod_tratamiento    => l_cod_tratamiento,
                               p_cod_usr_tramitador => g_cod_usr        ,
                               p_tip_docto          => g_tip_docto      ,
                               p_cod_ramo           => em.COD_RAMO_GEN  ,
                               p_tip_exp            => ts.TIP_EXP_GEN   );
         --
         l_val_max := ts_k_tsctrl001.f_imp_maximo;
         --
      EXCEPTION
         WHEN OTHERS
         THEN
            --
            l_val_max := trn.CERO;
            --
      END;
      --
      IF g_imp_liq > l_val_max
      THEN
         --
         ts_k_tsctrl002.p_lee (p_cod_cia         => g_cod_cia        ,
                               p_cod_tratamiento => l_cod_tratamiento,
                               p_imp_maximo      => l_val_max        );
         --
         l_cod_error := ts_k_tsctrl002.f_cod_error;
         --
         ts_k_as799001.p_grabar(l_cod_error);
         --
      END IF;
      --
      --@mx('F','pp_ct_max_importe_liq');
      --
   END pp_ct_max_importe_liq;
   --
   /* -------------------------------------------------------------
   || pp_ct_porc_facultativo : verifica el porcentaje de reaseguro
   ||                          facultativo de la p�liza
   */ -------------------------------------------------------------
   --
   PROCEDURE pp_ct_porc_facultativo
   IS
   --
      l_cod_cia_facul          a2501500.cod_cia_facul           %TYPE            ;
      l_cod_broker             a2501500.cod_broker              %TYPE            ;
      l_pct_participacion      a2501500.pct_participacion       %TYPE            ;
      l_sum_pct_participacion  a2501500.pct_participacion       %TYPE := trn.CERO;
      --
      cursor cl_facultativo
      IS
         --
         SELECT cod_cia_facul,
                cod_broker,
                DECODE(g_num_riesgo, em.NUM_RIESGO_GEN , trn.CERO, pct_participacion) pct_participacion
           FROM a2501500
          WHERE cod_cia       = g_cod_cia
            AND num_poliza    = g_num_poliza
            AND num_spto      = g_num_spto
            AND num_apli      = g_num_apli
            AND num_spto_apli = g_num_spto_apli
            AND num_riesgo    = DECODE(g_num_riesgo, em.NUM_RIESGO_GEN , num_riesgo, g_num_riesgo)
            AND cod_secc_reas = 220
            AND num_mov       = trn.UNO
       GROUP BY cod_cia_facul,
                cod_broker,
                DECODE(g_num_riesgo, em.NUM_RIESGO_GEN, trn.CERO , pct_participacion)
       ORDER BY cod_cia_facul, cod_broker;
      --
   --
   BEGIN
      --
      --@mx('I','pp_ct_porc_facultativo');
      --
      OPEN cl_facultativo;
      --
      LOOP
      FETCH cl_facultativo INTO l_cod_cia_facul, l_cod_broker, l_pct_participacion;
      --
      EXIT WHEN cl_facultativo%NOTFOUND;
           --
           l_sum_pct_participacion := l_sum_pct_participacion + l_pct_participacion;
           --
      END LOOP;
      --
      CLOSE cl_facultativo;
      --
      IF l_sum_pct_participacion >= g_k_min_facultativo
      THEN
         --
         g_cod_error := g_k_cod_ct_facultativo;
         --
         ts_k_as799001.p_grabar (p_cod_error => g_cod_error) ;
         --
      END IF;
      --@mx('F','pp_ct_porc_facultativo');
      --
   END pp_ct_porc_facultativo;
   --
   /* -------------------------------------------------------------
   || p_ct_datos_siniestros :
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_datos_siniestros
   IS
      --
   BEGIN
      --
      --@mx('I','p_ct_datos_siniestros');
      --
      pp_carga_globales;
      --
      ts_k_diversos_ct.p_ct_ident_sini;
      --
      pp_ct_porc_facultativo;
      --
      --pp_ct_prima_pendiente;
      --
      --@mx('F','p_ct_datos_siniestros');
      --
   END p_ct_datos_siniestros;
   --
   /* -------------------------------------------------------------
   || p_ct_dato_comp_stros : Datos complementarios stros
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_dato_comp_stros
   IS
      --
   BEGIN
      --
      --@mx('I','p_ct_datos_siniestros');
      --
      pp_carga_globales;
      --
      --@mx('F','p_ct_datos_siniestros');
      --
   END p_ct_dato_comp_stros;
   --
   --
   /* -------------------------------------------------------------
   || p_ct_apert_exped : Sistema 7 Nivel 5
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_apert_exped
   IS
   --
   BEGIN
      --
      --
      --@mx('I','p_ct_cob_liquidacion');
      --
      pp_carga_globales;
      --
      --@mx('F','p_ct_cob_liquidacion');
      --
   END p_ct_apert_exped;
   --
   /* -------------------------------------------------------------
   || p_ct_cob_liquidacion : Sistema 3 Nivel 2
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_cob_liquidacion
   IS
   --
   BEGIN
      --
      --@mx('I','p_ct_cob_liquidacion');
      --
      --@mx('g_tip_liquidacion',g_tip_liquidacion);
      --
      IF g_tip_liquidacion IN(g_k_tip_liquidacion,g_k_tip_rectificacion)
      THEN
         --
         pp_carga_globales;
         --
         pp_ct_suma_sub_limite;
         --
         pp_ct_suma_cob_vigencia;
         --
         pp_ct_max_importe_liq;
         --
         pp_ct_sublimite_vigencia;
         --
         ts_k_diversos_ct.p_ct_cob_exp; -- v1.02
         --
      END IF;
      --
      --@mx('F','p_ct_cob_liquidacion');
      --
   END p_ct_cob_liquidacion;
   --
   /* -------------------------------------------------------------
   || p_ct_datos_fijos_liq : Sistema 3 Nivel 1
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_datos_fijos_liq
   IS
   --
   BEGIN
      --
      --@mx('I','p_ct_datos_fijos_liq');
      --
      pp_carga_globales;
      --
      pp_benef_no_deseado;
      --
      --@mx('F','p_ct_datos_fijos_liq');
      --
   END p_ct_datos_fijos_liq;
   --
   /* -------------------------------------------------------------
   || p_ct_cob_expediente : Sistema 3 Nivel 2
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_cob_expediente
   IS
      --
   BEGIN
      --
      --@mx('I','p_ct_cob_expediente');
      --
      pp_carga_globales;
      --
      --@mx('F','p_ct_cob_expediente');
      --
   END p_ct_cob_expediente;
   --
   /* -------------------------------------------------------------
   || p_ct_rehab_siniestro : Sistema 7 Nivel 8
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_rehab_siniestro
   IS
   --
   BEGIN
      --
      --@mx('I','p_ct_rehab_siniestro');
      --
      pp_carga_globales;
      --
      --@mx('F','p_ct_rehab_siniestro');
      --
   END p_ct_rehab_siniestro;
   --
   /* -------------------------------------------------------------
   || p_ct_causa_cons_stro : Sistema 7 Nivel 3
   */ -------------------------------------------------------------
   --
   PROCEDURE p_ct_causa_cons_stro
   IS
   --
   BEGIN
      --
      --@mx('I','p_ct_causa_cons_stro');
      --
      pp_carga_globales;
      --
      pp_val_causa_otros;
      --
      --@mx('F','p_ct_causa_cons_stro');
      --
   END p_ct_causa_cons_stro;
   --
END ts_k_228_ct_mgt;
/
