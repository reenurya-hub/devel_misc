BEGIN
trn_k_global.asigna('cod_cia'                  , 7               );
trn_k_global.asigna('jbcod_cia'                  , 7               );
  DBMS_SCHEDULER.RUN_JOB('COBRO_RECIBOS_ROJOS_NEGROS',TRUE);
END;
