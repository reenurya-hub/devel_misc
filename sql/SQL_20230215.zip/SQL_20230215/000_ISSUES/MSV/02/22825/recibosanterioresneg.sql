    SELECT a.num_recibo                  num_recibo_pos     ,
            SUM(NVL(a.imp_recibo,0))      imp_recibo_pos     ,
            SUM(NVL(a.imp_comis ,0))      imp_comis_pos      ,
            SUM(NVL(a.imp_total_comis,0)) imp_total_comis_pos
       FROM a2990700@preprod a
      WHERE a.cod_cia         = 7--p_cod_cia
        AND a.num_poliza      = '2282300000351'--pl_num_poliza_neg
        --AND a.num_recibo     != 5222--pl_num_recibo_neg
        AND a.num_recibo + 0  > 0
        AND a.tip_situacion || ''  IN ('EP', 'RE')--(gc.TIP_SITU_PENDIENTE,gc.TIP_SITU_REMESA) --('EP', 'RE')
        --AND a.fec_efec_recibo = to_date('05/03/2021','dd/mm/yyyy')--pl_fec_efec_recibo_neg
        --AND a.fec_vcto_recibo = to_date('05/04/2021','dd/mm/yyyy')--pl_fec_vcto_recibo_neg
  --    AND a.cod_agt         = pl_cod_agt_neg
        AND a.tip_docum_pago || '' IS NULL
        AND a.num_aviso      || '' IS NULL
      GROUP BY a.num_recibo
     HAVING SUM(NVL(a.imp_recibo,0))      > 0
        AND SUM(NVL(a.imp_recibo,0))      = ABS(-35.79) ;
 

SELECT * FROM a2990700 



    SELECT a.num_poliza ,a.num_recibo     num_recibo_pos     ,
            a.fec_efec_recibo,
            a.fec_vcto_recibo,
            SUM(NVL(a.imp_recibo,0))      imp_recibo_pos     ,
            SUM(NVL(a.imp_comis ,0))      imp_comis_pos      ,
            SUM(NVL(a.imp_total_comis,0)) imp_total_comis_pos
       FROM a2990700@preprod a
      WHERE a.cod_cia         = 7--p_cod_cia
        --AND a.num_poliza      = '3012100000400'--pl_num_poliza_neg
        --AND a.num_recibo     != 5222--pl_num_recibo_neg
        AND a.num_recibo + 0  > 0
        AND a.tip_situacion || ''  IN ('EP', 'RE')--(gc.TIP_SITU_PENDIENTE,gc.TIP_SITU_REMESA) --('EP', 'RE')
        --AND a.fec_efec_recibo = to_date('05/03/2021','dd/mm/yyyy')--pl_fec_efec_recibo_neg
        --AND a.fec_vcto_recibo = to_date('05/04/2021','dd/mm/yyyy')--pl_fec_vcto_recibo_neg
  --    AND a.cod_agt         = pl_cod_agt_neg
        AND a.tip_docum_pago || '' IS NULL
        AND a.num_aviso      || '' IS NULL
      GROUP BY a.num_poliza,a.num_recibo,a.fec_efec_recibo,
            a.fec_vcto_recibo
     HAVING SUM(NVL(a.imp_recibo,0))      > 0;
        --AND SUM(NVL(a.imp_recibo,0))      = ABS(-35.79) ;
