gc_p_cobro_rojo_negro_job_msv => 
gc_k_cobros_dp
gc_k_cobros_dp.p_proceso_con_globales;
BEGIN
trn_k_global.asigna('cod_cia'                  , 7               );
  DBMS_SCHEDULER.RUN_JOB('COBRO_RECIBOS_ROJOS_NEGROS',TRUE);
END;

3012100000400


SELECT * FROM g1002700@PREPROD WHERE cod_usr_cia = 'TRON2000'

insert into g1002700 (COD_CIA, COD_USR_CIA, NUM_USR_CIA, NOM_USR_CIA, COD_NIVEL3, MENU_DEFECTO, COD_USR, FEC_ACTU, COD_GRP_USR, EMAIL_USR_CIA, TIP_DOCUM, COD_DOCUM, MCA_INF_PARCIAL)
values (7, 'TRON2000', 1, 'TRON2000 PROPIETARIO APLIC', 2050, 'AM000000', 'JNAVASD', to_date('19-05-2022', 'dd-mm-yyyy'), 'GENERAL', 'notificaciones@mapfre.com.sv', null, null, 'N');

SELECT * FROM g1002700 WHERE cod_usr_cia = 'DGARCIA';

SELECT * FROM G1010020;

GC_K_COBROS_DP_TRN;

gc_k_a5020037
gc_k_a5020037.p_lee_cajero_habilitado


      SELECT *
        FROM a5020037
       WHERE cod_cia    = 7--pl_cod_cia
         AND cod_cajero = 'DGARCIA'
         AND NVL(mca_inh, 'N') ='N';
         
insert into a5020037 (COD_CIA, COD_CAJERO, NOM_CAJERO, TIP_CAJERO, MCA_ACTIVO, TIP_REEMPLA, MCA_ULTIMO, MCA_CUADRADO, MCA_PPAL_NIVEL2, NUM_ENTORNO, ULT_NUM_RECIBO, ULT_ORD_PAGO, ULT_NUM_GIRO, ULT_NUM_ANU, MCA_ENTORNO1, MCA_ENTORNO2, MCA_ENTORNO3, MCA_ENTORNO4, COD_USR, FEC_ACTU, MCA_FEC_VALOR, MCA_CAJERO_CENTRAL, MCA_PAGO_DIRECTO, MCA_VE_OP, COD_NIVEL3, MCA_TT_CAJA_BCO, MCA_REC_PDTES_ANT, MCA_EXT, MCA_INH, FEC_ALTA_CAJERO, FEC_BAJA_CAJERO, OBS_CAJERO)
values (7, 'TRON2000', 'DAVID GARCIA', 'S', 'N', null, 'N', 'S', 'N', 1, null, null, null, null, 'S', 'S', 'N', 'N', 'OUALVAR', to_date('26-03-2021', 'dd-mm-yyyy'), 'S', 'N', 'N', 'N', 2050, 'N', 'S', 'N', 'N', to_date('01-01-2001', 'dd-mm-yyyy'), null, null);



   SELECT a.num_poliza                  num_poliza_neg     ,
          a.num_recibo                  num_recibo_neg     ,
          a.fec_efec_recibo             fec_efec_recibo_neg,
          a.fec_vcto_recibo             fec_vcto_recibo_neg,
          SUM(NVL(a.imp_recibo,0))      imp_recibo_neg     ,
          SUM(NVL(a.imp_comis ,0))      imp_comis_neg      ,
          SUM(NVL(a.imp_total_comis,0)) imp_total_comis_neg
     FROM a2990700 a
     WHERE a.cod_cia      = 7--pc_cod_cia
       AND a.tip_situacion   IN ('EP', 'RE')--(gc.TIP_SITU_PENDIENTE,gc.TIP_SITU_REMESA) --('EP', 'RE')
       AND a.num_poliza      = '3012100000400'--pc_num_poliza
       AND a.num_recibo + 0  > 0
       AND a.tip_docum_pago || '' IS NULL
       AND a.num_aviso      || '' IS NULL
     GROUP BY a.num_poliza, a.num_recibo, a.fec_efec_recibo,a.fec_vcto_recibo
    HAVING SUM(NVL(a.imp_recibo,0)) < 0;
/*******************/
 gc_k_ap502075
 gc_k_ap502075.p_inicio
 gc_k_ap502075.p_v_mca_listado
 jb_k_ap020012
 jb_k_ap020012.p_rescata_datos
 gc_k_lista_rojos_negros.387080
 jb_k_ap020012.p_startup
 
 
 
 SELECT * FROM a2000030 WHERE cod_cia = 7 AND cod_ramo = 301
ORDER BY num_poliza, num_spto DESC;

SELECT * FROM a1001331;


SELECT * FROM a2000030 WHERE cod_cia = 7 AND cod_ramo = 301
AND TRUNC(fec_emision) >= to_date ('01012023' , 'DDMMYYYY');


EA_K_301_DV

ea_k_gen_dv_autos

PAS
576127556

        SELECT a.*
          FROM tagen002 a
         WHERE a.cod_cia   = 7--g_cod_cia
           AND a.cod_ramo  = 301--g_cod_ramo
           AND a.clase     = 'A'--pc_cod_clase
           AND a.sub_clase = 0--pc_sub_clase
         ORDER BY a.cod_cia ,
                  a.cod_ramo,
                  a.clase   ;
                  
                  
SELECT * FROM a2990700 WHERE num_poliza = '3012100000400' FOR UPDATE;

SELECT * FROM a2990700 WHERE num_poliza = '3012100000400' AND num_recibo = 3753 FOR UPDATE;
  

SELECT * FROM a2000030 WHERE cod_ramo = 301;
 

/**** 02022023 TODOS LOS RECIBOS CON SALDO EN CERO DESPUES DE ANULAR*/
PRE:
3012301006422
3012301006425



/* 
1. El informe de recibos negros y rojos trae las polizas anuladas que tengan recibos negativos y positivos que esten pendientes o remesadas.

2. Las polizas candidatas deben tener recibos pendientes o remesados con saldo negativo (de anulacion) 
y por lo menos un recibo positivos de emision con las mismas fechas del recibo negativo, y todo el saldo de recibos en ceros

3. Todo el proceso lo hace el codigo de nucleo, no se ha alterado nada del proceso.

4. Actualmente en ambiente PRE al anular las p�liza
*/



tiene recibos pendientes
pre
2282300000351

gc_k_ap502063
gc_k_ap502063.p_v_fec_remesa

SELECT * FROM a1001600@preprod;
