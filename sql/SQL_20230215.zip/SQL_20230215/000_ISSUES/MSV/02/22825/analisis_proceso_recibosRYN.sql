SELECT * FROM a5020037 WHERE COD_CAJERO = 'DGARCIA';
UPDATE a5020037 SET MCA_ACTIVO = 'N' WHERE COD_CAJERO = 'DGARCIA';


SELECT * FROM a2990700 WHERE num_poliza = 3012100000396;

-- POLIZAS PARA PRUEBAS EN PRE:
3012100000396
3012100000399
3012100000402
3012100000403
-- la 3012100000400 no permitio porque tiene un recibo remesado.



-- EL LISTADO SE GENERA CON:
gc_k_lista_rojos_negros_trn;
p_lista
-- EL PROCESO SE GENERA CON:
gc_k_cobros_dp_trn;
p_proceso

-- SE EJECUTA EL JOB:
COBRO_RECIBOS_ROJOS_NEGROS
-- EL JOB EJECUTA EL PROCEDIMIENTO:
gc_p_cobro_rojo_negro_job_msv
-- EL PROCEDIMIENTO gc_p_cobro_rojo_negro_job_msv EJECUTA:
gc_k_cobros_dp_trn;
p_proceso_con_globales
/**************************************/
 gc_k_ap502075.p_v_mca_listado

jb_k_ap020012

jb_k_ap020012.p_rescata_datos(28)
(1):  (0)IN OUT (1)IN OUT (2)IN OUT (3)IN OUT (4)IN OUT (5)IN OUT (6)IN OUT (7)IN OUT (8)IN OUT (9)IN OUT (10)IN OUT (11)IN OUT (12)IN OUT (13)IN OUT (14)IN OUT (15)IN OUT (16)IN OUT (17)IN OUT (18)IN OUT (19)IN OUT (20)IN OUT (21)IN OUT (22)IN OUT (23)IN OUT (24)IN OUT (25)IN OUT (26)IN OUT (27)IN OUT
(2):  (0)gc_k_lista_rojos_negros (1)ES (2) (3) (4) (5) (6) (7) (8) (9) (10) (11) (12) (13) (14) (15) (16) (17) (18) (19) (20) (21) (22) (23) (24) (25) (26) (27)
(3):  (0)null (1)null (2)null (3)null (4)null (5)null (6)null (7)null (8)null (9)null (10)null (11)null (12)null (13)null (14)null (15)null (16)null (17)null (18)null (19)null (20)null (21)null (22)null (23)null (24)null (25)null (26)null (27)NULL

SELECT * FROM g1010160 WHERE cod_listado = 'gc_k_lista_rojos_negros';

GC_K_AP502075;

gc_k_cobros_dp


   CURSOR c_datos (pc_cod_listado g1010160.cod_listado %TYPE) IS
          SELECT a.cod_listado cod_listado,
                 a.cod_idioma cod_idioma ,
                 a.nom_listado nom_listado,
                 NVL(b.tip_extension,'N') tip_extension,
                 NVL(b.mca_visualiza,'N') mca_visualiza,
                 NVL(b.mca_cliente,'N') mca_cliente,
                 c.nom_prg_visor nom_prg_visor,
                 c.nom_prg_lista nom_prg_lista,
                 NVL(b.mca_mantener_listado,'N') mca_mantener_listado,
                 NVL(b.mca_exporta,'N') mca_exporta ,
                 NVL(b.tip_exporta,'N/A') tip_exporta,
                 b.tip_listado,
                 b.imp_logica,
                 NVL(b.mca_cambio_imp,'N') mca_cambio_imp,
                 NVL(b.mca_imp_directa,'N') mca_imp_directa,
                 b.cant_copias,
                 NVL(b.mca_envio_correo,'N') mca_envio_correo,
                 NVL(b.mca_primacia,'N') mca_primacia,
                 NVL(b.mca_borrado_fisico,'N') mca_borrado_fisico,
                 NVL(c.mca_prg_visor_j,'N') mca_prg_visor_j,
                 NVL(c.mca_prg_lista_j,'N') mca_prg_lista_j,
                 b.ruta_raiz_historico,
                 b.modulo_listado,
                 NVL(b.tip_formato,'ND') tip_formato,
                 NVL(b.mca_ptf,'N') mca_ptf
            FROM g1010161 a , g1010160 b , g1010162 c
           WHERE a.cod_listado   = 'gc_k_lista_rojos_negros'--pc_cod_listado
             AND a.cod_idioma    = 'ES'--p_cod_idioma
             AND a.cod_listado   = b.cod_listado
             AND a.cod_cia       = 7--g_cod_cia
             AND b.tip_extension = c.tip_extension
             AND NVL(a.mca_subinforme,'N') = 'N'
           ORDER BY a.num_linea;
           
           
gc_k_lista_rojos_negros_trn;


SELECT * FROM a2990700;
