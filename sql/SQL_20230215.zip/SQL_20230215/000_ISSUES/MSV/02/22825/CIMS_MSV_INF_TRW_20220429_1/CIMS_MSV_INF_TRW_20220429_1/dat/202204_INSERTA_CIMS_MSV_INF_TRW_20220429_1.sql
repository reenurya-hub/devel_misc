--
/* ------------------DESCRIPCION---------------------------------------------------------
|| CIMS_MSV_INF_TRW_20220429_1
|| 2022/04/29   TRON2000
|| Autor:       JGUEVARA   
|| Descripcion: Proceso masivo para cobros de recibos rojos y negros de forma automatica
*/ --------------------------------------------------------------------------------------
--
BEGIN
--
INSERT INTO g0000001 VALUES ('CIMS_MSV_INF_TRW_20220429_1',SYSDATE);
--
EXCEPTION 
WHEN OTHERS
THEN
   --
   UPDATE g0000001 SET FEC_ACTU = SYSDATE WHERE COD_CIMS = 'CIMS_MSV_INF_TRW_20220429_1';
   --
END;
/
EXIT