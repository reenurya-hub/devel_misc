BEGIN
   DBMS_SCHEDULER.CREATE_JOB (
   job_name           =>  'COBRO_RECIBOS_ROJOS_NEGROS',
   job_type           =>  'STORED_PROCEDURE',
   job_action         =>  'GC_P_COBRO_ROJO_NEGRO_JOB_MSV',
   start_date         =>   TO_TIMESTAMP_TZ('30/4/2022 12:01:00.000 AM -06:00','dd/mm/yyyy hh12:mi:ss.ff AM tzr'),
   repeat_interval    =>  'FREQ=DAILY', 
   end_date           =>   NULL,
   auto_drop          =>   FALSE,
   enabled            =>   TRUE, 
   comments           =>  'COBRO DE RECIBOS ROJOS Y NEGROS');
END;
/
