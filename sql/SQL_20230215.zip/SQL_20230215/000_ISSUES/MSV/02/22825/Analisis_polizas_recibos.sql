--3012100000400 anulada
--3012100000396 anulada
--3012100000399 anulada
--3012100000402 anulada
--3012100000403 anulada

-- c_a2990700_neg_pol RECIBOS NEGATIVOS DE UNA POLIZA
   SELECT a.num_poliza                  num_poliza_neg     ,
          a.num_recibo                  num_recibo_neg     ,
          a.fec_efec_recibo             fec_efec_recibo_neg,
          a.fec_vcto_recibo             fec_vcto_recibo_neg,
          SUM(NVL(a.imp_recibo,0))      imp_recibo_neg     ,
          SUM(NVL(a.imp_comis ,0))      imp_comis_neg      ,
          SUM(NVL(a.imp_total_comis,0)) imp_total_comis_neg
     FROM a2990700 a
     WHERE a.cod_cia      = 7--pc_cod_cia
       AND a.tip_situacion   IN ('EP', 'RE')--(gc.TIP_SITU_PENDIENTE,gc.TIP_SITU_REMESA) --('EP', 'RE')
       AND a.num_poliza      = '3012100000400'--pc_num_poliza
       AND a.num_recibo + 0  > 0
       AND a.tip_docum_pago || '' IS NULL
       AND a.num_aviso      || '' IS NULL
     GROUP BY a.num_poliza, a.num_recibo, a.fec_efec_recibo,a.fec_vcto_recibo
    HAVING SUM(NVL(a.imp_recibo,0)) < 0;
    
    
    
-- RECIBOS NEGATIVOS POR POLIZAS DE UNA COMPANIA
   SELECT a.num_poliza                  num_poliza_neg     ,
          a.num_recibo                  num_recibo_neg     ,
          a.fec_efec_recibo             fec_efec_recibo_neg,
          a.fec_vcto_recibo             fec_vcto_recibo_neg,
          SUM(NVL(a.imp_recibo,0))      imp_recibo_neg     ,
          SUM(NVL(a.imp_comis ,0))      imp_comis_neg      ,
          SUM(NVL(a.imp_total_comis,0)) imp_total_comis_neg
     FROM a2990700 a
     WHERE a.cod_cia    + 0  = 7--p_cod_cia
       AND a.tip_situacion   IN ('EP', 'RE')--(gc.TIP_SITU_PENDIENTE,gc.TIP_SITU_REMESA) --('EP', 'RE')
       AND a.num_recibo + 0  > 0
       AND a.tip_docum_pago || '' IS NULL
       AND a.num_aviso      || '' IS NULL
     GROUP BY a.num_poliza, a.num_recibo, a.fec_efec_recibo,a.fec_vcto_recibo
    HAVING SUM(NVL(a.imp_recibo,0)) < 0;
    


      SELECT cod_mon,
             num_poliza,
             COUNT(DISTINCT num_recibo)               ,
             sum(NVL(imp_comis,0))       impcomis     ,
             sum(NVL(imp_total_comis,0)) imptotalcomis
        FROM a2990700
       WHERE cod_cia + 0   = 7--pc_cod_cia
         AND tip_situacion IN ('EP', 'RE')--(gc.TIP_SITU_PENDIENTE,gc.TIP_SITU_REMESA) --('EP', 'RE')
         AND num_recibo + 0 > 0
       GROUP BY cod_mon, num_poliza
      HAVING SUM(imp_recibo)         = 0
         AND COUNT(DISTINCT num_recibo) > 1;
