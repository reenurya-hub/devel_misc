em_k_jrp_228_emi_msv

SELECT * FROM A1001331


SELECT * FROM A2991800@PREPROD;

TITULOS 
PAS
576127556

COTIZACION TODO RIESGO
COBERTURA TOTAL:
2322800010028

2322800010028



SELECT * FROM tronweb_reports
ORDER BY fec_created DESC;


em_k_jrp_oferta_228_tr_CT_msv

SELECT * FROM a1009012_msv@preprod WHERE LOWER(cod_report) = 'em_k_jrp_oferta_228_tr_ct_msv'
ORDER BY num_secu;

COTIZACION TRADICIONAL

3 pp_agrega_tbl('T', g_k_titulo_18, fp_txt_reporte(g_k_21));    Se establece una prima m�nima por cuota de US $ PRIMA_MINIMA (enti�ndase como prima m�nima, la Prima Neta, que no incluye gastos ni impuestos).

linea 7911


     1       pp_agrega_tbl('T', 'titulo_16', fp_txt_reporte(18));              La presente oferta queda sujeta a inspecci�n satisfactoria por parte de la Compa��a.
     2       pp_agrega_tbl('T', 'titulo_17', fp_txt_reporte(19));              Queda entendido y convenido que las coberturas de Gastos M�dicos, Muerte Accidental y/o  desmembramiento, no aplican para personas menores de 1 a�o y mayores de 65 a�os.
     4       pp_agrega_tbl('T', 'titulo_19', fp_txt_reporte(21)); -- v1.15     Se establece una prima m�nima por cuota de US $ PRIMA_MINIMA (enti�ndase como prima m�nima, la Prima Neta, que no incluye gastos ni impuestos).
     5       pp_agrega_tbl('T', 'titulo_20', fp_txt_reporte(22)); -- v1.15     El presente seguro es exclusivamente para viviendas de uso habitacional, en caso la vivienda se utilice para fines comerciales o industriales el seguro queda sin efecto, quedando la Compa��a libre de su responsabilidad Clausula S�ptima-Agravaci�n o alteraci�n del riesgo de las Cond. Generales del plan Familia Hogar Seguro I Art. 1360 del C�digo de Comercio).
            pp_agrega_tbl('T', 'titulo_28', fp_txt_reporte(28));              Aplicaci�n deducible riesgos catastr�ficos: 2% de la suma asegurada total de la ubicaci�n afectada con m�nimo de $250, m�ximo $60,000.00 y en adici�n al deducible el asegurado participara con el 10% sobre el saldo neto de la indemnizaci�n determinada.
     6       pp_agrega_tbl('T', 'titulo_21', fp_txt_reporte(23)); -- v1.15     El presente seguro no cubre viviendas con construcciones de adobe o inferiores a este.
     7       pp_agrega_tbl('T', 'titulo_22', fp_txt_reporte(24)); -- v1.15     Se excluyen del presente seguro viviendas ubicadas en zonas de playa, lagos o monta�as.
     8       pp_agrega_tbl('T', 'titulo_27', fp_txt_reporte(27));              El Asegurado declara que a la fecha de aceptaci�n de la presente oferta la vivienda no presenta da�os en sus construcciones y/o contenido, asimismo declaro que no se encuentra ubicada en las zonas de alta exposici�n detalladas en link-"zonas de alta exposici�n"   
     9       pp_agrega_tbl('T', 'titulo_70', fp_txt_reporte(70)); -- v 1.10    En el caso de apartamento, aplica cobertura �nicamente para el rubro de contenido.
     10       pp_agrega_tbl('T', 'titulo_71', fp_txt_reporte(71)); -- v 1.10    CL�USULA DE RENOVACI�N AUTOM�TICA <br> El presente seguro se ha celebrado para el plazo establecido en las condiciones particulares de la p�liza y a su vencimiento, se prorrogar� autom�ticamente sin convenio expreso por periodos no superiores a un a�o, en cuyo caso no se necesitar� de anexo de renovaci�n. No obstante, cualquiera de las partes podr� oponerse a la pr�rroga mediante notificaci�n por escrito a la otra, efectuada con antelaci�n no inferior a treinta d�as de la conclusi�n del periodo de este seguro.
            pp_agrega_tbl('T', 'titulo_72', fp_txt_reporte(72)); -- v 1.10
            pp_agrega_tbl('T', 'titulo_73', fp_txt_reporte(73)); -- v 1.10
