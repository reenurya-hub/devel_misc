SELECT * FROM g1002700@PREPROD WHERE cod_cia = 7 AND cod_usr_cia = 'TRON2000';

SELECT * FROM g1002700@intdev WHERE cod_cia = 7 AND cod_usr_cia = 'TRON2000';

insert into g1002700@preprod (COD_CIA, COD_USR_CIA, NUM_USR_CIA, NOM_USR_CIA, COD_NIVEL3, MENU_DEFECTO, COD_USR, FEC_ACTU, COD_GRP_USR, EMAIL_USR_CIA, TIP_DOCUM, COD_DOCUM, MCA_INF_PARCIAL)
values (7, 'TRON2000', 1, 'TRON2000 PROPIETARIO APLIC', 2050, 'AM000000', 'JNAVASD', to_date('19-05-2022', 'dd-mm-yyyy'), 'GENERAL', 'notificaciones@mapfre.com.sv', null, null, 'N');

