SI la fecha de efecto del suplemento de la p�liza es anterior a la fecha de validez va a excepcionar porque 
NO encuentra un valor.


SELECT *
  FROM g2999003_msv a
 WHERE a.cod_cia              = 7                 --p_cod_cia
   AND a.nom_nemotecnico      = 'TARIFA_PRIMA_MINIMA'     --p_nom_nemotecnico
   AND a.cod_ramo             = 228               --p_cod_ramo
 

--ea_k_g2999003_msv.p_lee
SELECT *
  FROM g2999003_msv a
 WHERE a.cod_cia              = 7                 --p_cod_cia
   AND a.nom_nemotecnico      = 'FEC_TARIFAS'     --p_nom_nemotecnico
   AND a.cod_ramo             = 228               --p_cod_ramo
   AND a.cod_campo            = 'FECHA_TARIFA_ENE'--p_cod_campo
   AND a.cod_modalidad        = 99999             --p_cod_modalidad
   AND a.cod_cob              = 9999              --p_cod_cob FOR UP
   FOR UPDATE;
   AND a.fec_validez          = (SELECT MAX(b.fec_validez)--v1.01 
   FOR UPDATE;
                                            FROM g2999003_msv b
                                           WHERE b.cod_cia         = a.cod_cia
                                             AND b.nom_nemotecnico = a.nom_nemotecnico
                                             AND b.cod_ramo        = a.cod_ramo
                                             AND b.cod_modalidad   = a.cod_modalidad
                                             AND b.cod_cob         = a.cod_cob
                                             AND b.fec_validez    <= TO_DATE ('01012022' , 'DDMMYYYY'))FOR UPDATE;--p_fec_efec_spto);
                                             
                                             
prompt Importing table g2999003_msv...
set feedback off
set define off
insert into g2999003_msv (COD_CIA, NOM_NEMOTECNICO, COD_RAMO, COD_MODALIDAD, COD_CAMPO, TXT_VALOR_MINIMO, TXT_VALOR_MAXIMO, COD_COB, TXT_VALOR_COB_MINIMO, TXT_VALOR_COB_MAXIMO, TIP_CAMPO, TXT_DESCRIPCION, TXT_CAMPO_ALTERNO, FEC_VALIDEZ, MCA_INH, FEC_BAJA, FEC_ACTU, COD_USR)
values (7, 'FEC_TARIFAS', 228, 99999, 'FECHA_TARIFA_ENE', '18', '31122022', 9999, null, null, null, null, '01012023', to_date('01-01-2000', 'dd-mm-yyyy'), 'N', null, to_date('20-09-2022', 'dd-mm-yyyy'), 'TRON2000');

prompt Done.
                                             
