/* CONSULTA SIMPLE POLIZAS PRIMERA EMISION*/
SELECT * 
  FROM a2000030 a 
 WHERE a.cod_cia                     = 7
   AND a.cod_sector              = 2
   AND a.cod_ramo                = 228
   AND a.num_poliza              = '2282200000112';
   
   
SELECT * FROM a2990320 a WHERE a.num_poliza = '2282200000112';

SELECT * FROM a9990015 WHERE cod_ramo = 228;

SELECT * FROM a9990011 WHERE cod_clausula IN (SELECT cod_clausula FROM a9990015 WHERE cod_ramo = 228  )
ORDER BY cod_clausula, num_secu;

SELECT * FROM p2000265 a WHERE a.num_poliza              = '2282200000112';-- sin datos

SELECT * FROM p2990320 a WHERE a.num_poliza              = '2282200000112'; -- sin datos

SELECT * FROM p2000030


-- OBJETOS DE REPORTE
SELECT * FROM a1009012_msv WHERE num_secu IN(20, 21) AND cod_ramo = 228;
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_MSV' AND TIP_OBJETO = 'T' ORDER BY NUM_SECU;
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_TR_MSV' AND TIP_OBJETO = 'T' ORDER BY NUM_SECU;
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND NUM_SECU = 70;
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND CONTENIDO_OBJETO LIKE UPPER('%DEDUCIBLE%') 
SELECT * FROM a1009012_msv WHERE CONTENIDO_OBJETO LIKE UPPER('%DEDUCIBLE RIESGOS%') 
EM_K_JRP_POLIZA_228_PS_TR_MSV
SELECT DISTINCT(cod_report) FROM a1009012_msv WHERE cod_ramo = 228
EM_K_JRP_OFERTA_228_CT_MSV;

em_k_jrp_228_emi_msv

-- DESCRIPCION DE LA TABLA (PARA QUE ES O QUE INFORMACION TENDRA
SELECT * 
  FROM g2999003_msv a
 WHERE a.cod_cia = 7 
   AND a.cod_ramo = 228
   AND a.nom_nemotecnico = 'TARIFA_PRIMA_MINIMA';

ea_k_g2999003_msv

SELECT * FROM A2000030 WHERE NUM_POLIZA = '2222800000991';


em_k_jrp_228_cond_part_msv

SELECT * FROM a1001800;

SELECT * FROM a2000030 WHERE cod_ramo = 228;--9025


SELECT * FROM tronweb_reports
ORDER BY fec_created DESC;

policy_list

em_k_jrp_poliza_228_PS_tr_msv


El presente seguro es exclusivamente para viviendas de uso habitacional, en caso se utilice la vivienda para fines
comerciales o industriales el seguro queda sin efecto, quedando la Compa��a Libre de su responsabilidad (Clausula
S�ptima - Agravaci�n o alteraci�n del riesgo de las Cond. Generales del plan Familia Hogar Seguro /Art.1360 del
C�digo de Comercio).

anexo renovacion reportado migrado a des = 2282200000112
poliza emitida el 12/01/2023             = 2282200001244
cotizaci�n emitida el 13/01/2023         = 2222800000991



SELECT a.cod_cia      ,
                             a.num_poliza   ,
                             a.num_spto     ,
                             a.num_apli     ,
                             a.num_spto_apli,
                             a.num_riesgo   ,
                             a.cod_anexo    ,
                             a.num_secu     ,
                             a.texto         FROM a2000260 a  WHERE a.num_poliza    = '2282200000112' AND a.num_riesgo    IN ('0', 1) 
                             AND a.num_apli      = 0 
                             
                             
                             --TEXTOS DE LA POLIZA
                             SELECT * FROM a2000260 WHERE cod_cia = 7 AND num_poliza LIKE UPPER('228%') ;
                             
                             SELECT * FROM a2000030 WHERE num_poliza = '2282100100365';
                             
                             2282000000872
                             


--OBJETOS DE REPORTE
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228;
SELECT * FROM a1009012_msv WHERE num_secu = 20 AND cod_ramo = 228;
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_OFERTA_228_CT_MSV';
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_OFERTA_228_TR_CT_MSV';
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_MSV';
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_TR_MSV';
em_k_jrp_228_emi_msv

SELECT * FROM tronweb_reports
ORDER BY fec_created DESC;

SELECT * FROM A2000030;

8157
-- cotizacion todo riesgo = 2222800000991
-- cotizacion tradicional = 2222800000992
-- poliza todo riesgo     = 22822000012443
-- poliza tradicional     = 2282200001245
-- anexo renovacion todo riesgo (issue) = 2282200000112


SELECT * FROM a1009012_msv WHERE cod_ramo = 228 
AND (NUM_SECU IN(20,21) AND COD_REPORT IN ('EM_K_JRP_OFERTA_228_CT_MSV', 'EM_K_JRP_OFERTA_228_TR_CT_MSV'))
OR (NUM_SECU IN(20,21) AND COD_REPORT IN ('EM_K_JRP_POLIZA_228_PS_MSV', 'EM_K_JRP_POLIZA_228_PS_TR_MSV'))


JASPER:
PRINT WHEN EXPRESSION:
!$F{titulo_22}.equals( null )
US $ PRIMA_MINIMA

SELECT * FROM a1009012_msv WHERE num_secu =20 AND cod_ramo = 228 AND COD_REPORT IN ('EM_K_JRP_POLIZA_228_PS_MSV',
'EM_K_JRP_POLIZA_228_PS_TR_MSV') FOR UPDATE;

SELECT * FROM a1009012_msv WHERE num_secu =21 AND cod_ramo = 228

SELECT * FROM a1009012_msv@preprod WHERE num_secu =20 AND cod_ramo = 228;

SELECT * FROM g2999003_msv@preprod WHERE nom_nemotecnico = 'PRIMA_MINIMA' AND cod_ramo = 228;

SELECT * FROM g2999003_msv WHERE nom_nemotecnico = 'TARIFA_PRIMA_MINIMA' AND cod_ramo = 228;

SELECT * FROM g2999003_msv WHERE nom_nemotecnico = 'PRIMA_MINIMA'


SELECT * 
  FROM g2999003_msv@preprod a
 WHERE a.cod_cia = 7 
   AND a.cod_ramo = 228
   AND a.nom_nemotecnico = 'TARIFA_PRIMA_MINIMA';


SELECT * 
  FROM g2999003_msv a
 WHERE a.cod_cia = 7 
   AND a.cod_ramo = 228
   AND a.nom_nemotecnico = 'TARIFA_PRIMA_MINIMA';
   
   
SELECT * 
  FROM g2999003_msv@preprod a
 WHERE a.cod_cia = 7 
   AND a.cod_ramo = 228
   AND a.nom_nemotecnico = 'FEC_TARIFAS';


SELECT * 
  FROM g2999003_msv a
 WHERE a.cod_cia = 7 
   AND a.cod_ramo = 228
   AND a.nom_nemotecnico = 'FEC_TARIFAS'
   AND a.cod_campo = 'FECHA_TARIFA_ENE'
   --AND A.COD_MODALIDAD = 99999
   --AND a.cod_cob = 9999
   AND TRUNC(A.FEC_VALIDEZ) = to_date ('01012000' , 'DDMMYYYY') 
   
   
   cod_cia = 7 AND cod_ramo = 228 AND nom_nemotecnico = 'FEC_TARIFAS' AND cod_campo = 'FECHA_TARIFA_ENE' AND TRUNC(FEC_VALIDEZ) = to_date ('01012000' , 'DDMMYYYY') 
   
   (SELECT MAX(b.fec_validez)--v1.01
                                            FROM g2999003_msv b
                                           WHERE b.cod_cia         = a.cod_cia
                                             AND b.nom_nemotecnico = a.nom_nemotecnico
                                             AND b.cod_ramo        = a.cod_ramo
                                             AND b.cod_modalidad   = a.cod_modalidad
                                             AND b.cod_cob         = a.cod_cob
                                             AND b.fec_validez    <= TO_DATE ('21102022' , 'DDMMYYYY'));



insert into g2999003_msv (COD_CIA, NOM_NEMOTECNICO, COD_RAMO, COD_MODALIDAD, COD_CAMPO, TXT_VALOR_MINIMO, TXT_VALOR_MAXIMO, COD_COB, TXT_VALOR_COB_MINIMO, TXT_VALOR_COB_MAXIMO, TIP_CAMPO, TXT_DESCRIPCION, TXT_CAMPO_ALTERNO, FEC_VALIDEZ, MCA_INH, FEC_BAJA, FEC_ACTU, COD_USR)
values (7, 'FEC_TARIFAS', 228, 99999, 'FECHA_TARIFA_ENE', '18', '31122022', 9999, null, null, null, null, '01012023', to_date('01-01-2000', 'dd-mm-yyyy'), 'N', null, to_date('20-09-2022', 'dd-mm-yyyy'), 'TRON2000');


   
   SELECT * FROM  a1009012_msv
       WHERE num_secu =20 AND cod_ramo = 228 AND COD_REPORT IN ('EM_K_JRP_POLIZA_228_PS_MSV','EM_K_JRP_POLIZA_228_PS_TR_MSV');
/*************************/
SELECT * FROM A1001331;
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_MSV'; 
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_TR_MSV';
PAS 576127556
228300000331 TRADICIONAL
228300000332 TOTAL
228300000315

SELECT * FROM g2000020 WHERE cod_ramo = 228;
SELECT * FROM a2000020 WHERE cod_cia = 7 AND cod_ramo = 228 AND cod_campo = 'TIP_PRODUCTO' AND VAL_CAMPO = '2';
SELECT * FROM a2000030

SELECT * FROM a2000020 WHERE cod_cia = 7 AND cod_ramo = 228 AND cod_campo = 'TIP_PRODUCTO' AND VAL_CAMPO = '2' 
AND num_poliza IN (SELECT num_poliza FROM a2000030 WHERE cod_cia = 7 AND cod_ramo = 228 AND TRUNC(fec_efec_spto) <= to_date('01/01/2023','dd/mm/yyyy') AND num_renovaciones = 1)
ORDER BY num_poliza DESC;
SELECT * FROM a2000030 WHERE num_poliza = 2282300000336

2282300000337

cobertura total = 1  = 2283000000315
                       2282300000336 renovacion

tradiciona = 2   = 228200000236 VIEJA
                    2282200000133 renovcion


TRADIICIONAL = 2282200000140
TODO RIESGO = 2282200000253

8157
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_TR_MSV'


SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND cod_report IN ( 'EM_K_JRP_POLIZA_228_PS_TR_MSV', 'EM_K_JRP_POLIZA_228_PS_MSV')
AND NUM_SECU = 12;



beneficiarios designados son:


SELECT * FROM a1001331;
/**************************************************************************/

SELECT * FROM tronweb_reports@preprod
ORDER BY fec_created DESC;

POLIZAS NUEVAS EN DES
COBERTURA TOTAL: 2282300000338    EM_K_JRP_POLIZA_228_PS_TR_MSV  : todo riesgo o cobertura total
TRADICIONAL    = 2282300000339    EM_K_JRP_POLIZA_228_PS_MSV     : TRADICIONAL (EL DEL PROBLEMA)
cotizaciones
COBERTURA TOTAL: 2322800010024        TODO RIESGO O COBERTURA TOTAL
TRADICIONAL    = 2322800010025

WTW_K_TOOLS
SELECT * FROM G1010107;
SELECT * FROM a1009012_msv

EM_K_JRP_PRINT;
em_k_jrp_228_emi

SELECT * FROM tronweb_reports_templates;

TRN_K_REPORT

SELECT * FROM a1000600;

CA_K_AP100054_TRN
trn_k_lis
trn_k_lis.ext_mspool;

SELECT * FROM g0000000;
SELECT * FROM g1010021;
trn_k_global
trn_k_global.mspool_dir;

SELECT * FROM a0000010;

SELECT * FROM a0000020;

SELECT * FROM g1010107;

TRN_K_JSPOOL;

SELECT * FROM jspool;

SELECT * FROM g1010160;

 trn_k_global.mspool_dir;


SELECT * FROM a2000020@preprod WHERE cod_cia = 7 AND cod_ramo = 228 AND cod_campo = 'TIP_PRODUCTO' AND VAL_CAMPO = '2' 
AND num_poliza IN (SELECT num_poliza FROM a2000030 WHERE cod_cia = 7 AND cod_ramo = 228 AND TRUNC(fec_efec_spto) <= to_date('01/01/2023','dd/mm/yyyy') AND num_renovaciones = 1)
ORDER BY num_poliza DESC;


SELECT * FROM a2000020 WHERE cod_cia = 7 AND cod_ramo = 228 AND cod_campo = 'TIP_PRODUCTO' AND VAL_CAMPO = '2' 
AND num_poliza IN (SELECT num_poliza FROM a2000030 WHERE cod_cia = 7 AND cod_ramo = 228 AND TRUNC(fec_efec_spto) <= to_date('01/01/2023','dd/mm/yyyy') AND num_renovaciones = 1)
ORDER BY num_poliza DESC;



POLIZAS NUEVAS EN DES
COBERTURA TOTAL: 2282300000338    EM_K_JRP_POLIZA_228_PS_TR_MSV  : todo riesgo o cobertura total
TRADICIONAL    = 2282300000339    EM_K_JRP_POLIZA_228_PS_MSV     : TRADICIONAL (EL DEL PROBLEMA)
cotizaciones
COBERTURA TOTAL: 2322800010024        TODO RIESGO O COBERTURA TOTAL
TRADICIONAL 


linea 7881                pp_agrega_tbl('T', 'titulo_22', fp_txt_reporte(24)); -- v1.15
