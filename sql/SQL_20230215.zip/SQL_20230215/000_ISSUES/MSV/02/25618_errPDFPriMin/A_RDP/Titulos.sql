         IF g_tip_spto != g_k_rf
         THEN
               --
               pp_agrega_tbl('T', g_k_titulo_19, g_titulo);
               --
            --
            pp_agrega_tbl('T', 'titulo_1',  fp_txt_reporte(3) );
            pp_agrega_tbl('T', 'titulo_16', fp_txt_reporte(18));
            pp_agrega_tbl('T', 'titulo_17', fp_txt_reporte(19));
            pp_agrega_tbl('T', 'titulo_18', fp_txt_reporte(20));
            pp_agrega_tbl('T', 'titulo_20', fp_txt_reporte(22));
            pp_agrega_tbl('T', 'titulo_21', fp_txt_reporte(23));
            pp_agrega_tbl('T', 'titulo_28', fp_txt_reporte(28)); 
            pp_agrega_tbl('T', 'titulo_22', fp_txt_reporte(24));
            pp_agrega_tbl('T', 'titulo_27', fp_txt_reporte(27));
            pp_agrega_tbl('T', 'titulo_70', fp_txt_reporte(70)); -- v 1.10
            pp_agrega_tbl('T', 'titulo_71', fp_txt_reporte(71)); -- v 1.10
            pp_agrega_tbl('T', 'titulo_72', fp_txt_reporte(72)); -- v 1.10
            pp_agrega_tbl('T', 'titulo_73', fp_txt_reporte(73)); -- v 1.10
            --
         ELSE
            --
            IF g_cod_modalidad = g_k_cobertura_total
            THEN
               --
                     --
                     pp_agrega_tbl('T', g_k_titulo_19, fp_txt_reporte(g_k_21));
                     --
               --
               pp_agrega_tbl('T', 'titulo_16'  , fp_txt_reporte(18));
               pp_agrega_tbl('T', 'titulo_17'  , fp_txt_reporte(19));
               pp_agrega_tbl('T', 'titulo_18'  , fp_txt_reporte(20));
               pp_agrega_tbl('T', 'titulo_20'  , fp_txt_reporte(22));
               pp_agrega_tbl('T', 'titulo_21'  , fp_txt_reporte(23));  
               pp_agrega_tbl('T', 'titulo_22'  , fp_txt_reporte(24)); 
               pp_agrega_tbl('T', 'titulo_27'  , fp_txt_reporte(27)); 
               pp_agrega_tbl('T', 'titulo_70'  , fp_txt_reporte(70)); -- v 1.10
               pp_agrega_tbl('T', 'titulo_71'  , fp_txt_reporte(71)); -- v 1.10
               --
            ELSIF g_cod_modalidad = g_k_tradicional
            THEN
               --
                     --
                     pp_agrega_tbl('T', g_k_titulo_19, fp_txt_reporte(g_k_21));
                     --
               --
               pp_agrega_tbl('T', 'titulo_16'  , fp_txt_reporte(18));
               pp_agrega_tbl('T', 'titulo_17'  , fp_txt_reporte(19));
               pp_agrega_tbl('T', 'titulo_18'  , fp_txt_reporte(20));
               pp_agrega_tbl('T', 'titulo_20'  , fp_txt_reporte(22));
               pp_agrega_tbl('T', 'titulo_21'  , fp_txt_reporte(23));   
               pp_agrega_tbl('T', 'titulo_22'  , fp_txt_reporte(24)); 
               pp_agrega_tbl('T', 'titulo_22'  , fp_txt_reporte(24)); 
               pp_agrega_tbl('T', 'titulo_27'  , fp_txt_reporte(27));
               pp_agrega_tbl('T', 'titulo_72'  , fp_txt_reporte(72)); -- v 1.10
               pp_agrega_tbl('T', 'titulo_73'  , fp_txt_reporte(73)); -- v 1.10
               --
               --v 1.08}
               --
            END IF;
            --            
            --
         END IF;
