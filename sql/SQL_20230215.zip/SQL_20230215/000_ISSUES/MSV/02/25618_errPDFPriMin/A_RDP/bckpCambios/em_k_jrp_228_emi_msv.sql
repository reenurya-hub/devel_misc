CREATE OR REPLACE PACKAGE BODY em_k_jrp_228_emi_msv
AS
   --
   /* ---------------------- DESCRIPCION ---------------------
   || Procedimientos y funciones para imprimir caratula
   */ --------------------------------------------------------
   --
   /* ---------------------- VERSION 1.15 ------------------*/
   --
   /* ---------------------- MODIFICACIONES ------------------
   || INFORCOL - RURQUIJO - 2023/01/12 - v 1.15 - Issue 25618
   || se realiza un ajuste en el area otras condiciones de la 
   || caratula de la poliza para que muestre la tarifa
   || vigente actualmente
   /* ---------------------- MODIFICACIONES ------------------
   || INFORCOL - DPATINO - 2023/01/04 - v 1.14 - Issue 25600
   || se realiza un ajuste en el area otras condiciones de la 
   || caratula de las cotizaciones para que muestre la tarifa
   || vigente actualmente
   || --------------------------------------------------------
   || INFORCOL - JBEDOYA - 2023/01/04 - v 1.13 - Issue 25477
   || Ajuste para imprimir carta de renovacion a partir del 
   || 01/01/2023, se crea funcion fp_fec_nueva_tarifa, y se 
   || modifica el procedimiento pp_gen_xml_ps.
   || --------------------------------------------------------
   || INFORCOL - GOROZCO - 2022/12/04 - v 1.12 - Issue 24432
   || Ajuste para importe de cesionario
   || --------------------------------------------------------
   || INFORCOL - VMUNOZ - 2022/07/22 - v 1.11 - Issue 24068
   || Se modifica cursor para recuperar el IVA y el IGSCI de 
   || manera correcta.
   || --------------------------------------------------------
   || INFORCOL - LDUARTE - 2022/06/10 - v 1.10 - Issue 23564
   || Se modifica condiciones de reporte en la cotizacion
   || cobertura general indicado el numeral 9 y 10. se agrega
   || cobertura tradicional indicado el numeral 10 y 11
   || --------------------------------------------------------
   || INFORCOL - VMUNOZ - 2022/05/09 - v 1.09 - Issue 23395
   || Se modifica condicion para que se impriman los recibos
   || en las cotizaciones.
   || --------------------------------------------------------
   || INFORCOL - VMUNOZ - 2022/05/09 - v 1.08 - Issue 23178
   || Se modifica cursor para el importe de la prima base y 
   || para que se muestre importe de cesion de beneficio.
   || --------------------------------------------------------
   || INFORCOL - GOROZCO - 2022/04/07 - v 1.07 - Issue 22976
   || Se modifica cursores para los recibos en las polizas
   || renovadas.
   || --------------------------------------------------------
   || INFORCOL - GOROZCO - 2022/03/25 - v 1.06 - Issue 22908
   || Se carga global id_report al final del proceso.
   || --------------------------------------------------------
   || INFORCOL - KARDILA 2022/03/15 - v 1.05 - 22739
   || Se modifica el procedimiento pi_cambio_plan_pagos para 
   || que cuando no se encuentren movimientos de cambio de 
   || plan de pago en la tabla a2000032 retorne la variable
   || l_num_mvto_cv en cero en vez de NULL.
   || --------------------------------------------------------   
   || INFORCOL - PLATRAN 2022/01/12 - v 1.04
   || Se modifica operador de la funcion fp_bien_cedido
   || --------------------------------------------------------
   || INFORCOL - JHOWER 2021/10/01 - v 1.03
   || Se carga global id_report para la generacion del email
   || --------------------------------------------------------
   || INFORCOL - YPEREA 2021/07/27 - v 1.02
   || Modificacion del IF donde se valida el campo 
   || p_ph_alt_holder_name para ver si no es mismo asegurado
   || e la linea 9173   
   || --------------------------------------------------------
   || INFORCOL - YPEREA 2021/07/09 - v 1.01
   || MOdificacion del begin donde se reucpera el cod_canal 
   || en la linea 4236
   || --------------------------------------------------------
   || INFORCOL - EBETANCOURT 2020/10/01 - v 1.00
   || Creacion del Paquete
   */ --------------------------------------------------------
   --
   /* --------------------------------------------------------
   || Aqui comienza la declaracion de variables GLOBALES
   */ --------------------------------------------------------
   --
   g_tip_scope VARCHAR2(1) := trn_k_global.ref_f_global('tip_scope');
   --
   g_k_separador_col       CONSTANT VARCHAR2(1)  := '~'                           ;
   g_signo_moneda          CONSTANT VARCHAR2(1)  := '$'                           ;   
   g_k_scope_foto          CONSTANT VARCHAR2(1)  := 'F'                           ;
   g_k_scope_spto          CONSTANT VARCHAR2(1)  := 'E'                           ;
   g_k_rep_cotizacion      CONSTANT VARCHAR2(1)  := 'C'                           ;
   g_k_rep_poliza          CONSTANT VARCHAR2(1)  := 'P'                           ; --v1.15
   g_k_s                   CONSTANT VARCHAR2(1)  := 'S'                           ;
   g_k_yes                 CONSTANT VARCHAR2(1)  := 'Y'                           ;
   g_k_binario             CONSTANT VARCHAR2(1)  := 'B'                           ;
   g_k_importe             CONSTANT VARCHAR2(1)  := 'I'                           ;
   g_k_fecha               CONSTANT VARCHAR2(1)  := 'F'                           ;
   g_k_texto               CONSTANT VARCHAR2(1)  := 'T'                           ;
   g_k_dv                  CONSTANT VARCHAR2(2)  := 'DV'                          ;
   g_k_situa_recib_ac      CONSTANT VARCHAR2(2)  := 'AC'                          ;
   g_k_rf                  CONSTANT VARCHAR2(2)  := 'RF'                          ; 
   g_k_ad                  CONSTANT VARCHAR2(2)  := 'AD'                          ;  
   g_k_xx                  CONSTANT VARCHAR2(2)  := 'XX'                          ;
   g_k_nominativo          CONSTANT VARCHAR2(2)  := 'SM'                          ;
   g_k_imp                 CONSTANT VARCHAR2(3)  := 'IMP'                         ;
   g_k_tip_doc             CONSTANT VARCHAR2(3)  := 'PAS'                         ;
   g_k_dolar               CONSTANT VARCHAR2(6)  := 'DOLAR%'                      ;
   g_k_fecha_hora          CONSTANT VARCHAR2(6)  := 'F_hora'                      ;
   g_k_fecha_mes           CONSTANT VARCHAR2(7)  := 'F_month'                     ;
   g_k_fecha_abr           CONSTANT VARCHAR2(7)  := 'F_m_abr'                     ;
   g_k_fecha_ordinal       CONSTANT VARCHAR2(9)  := 'F_ordinal'                   ;
   g_k_renovacion          CONSTANT VARCHAR2(10) := 'RENOVACION'                  ;
   g_k_formato_fec_xml     CONSTANT VARCHAR2(10) := 'dd/mm/yyyy'                  ;
   g_k_formato_fech_hyphen CONSTANT VARCHAR2(10) := 'DD-MM-YYYY'                  ;
   g_k_titulo_18           CONSTANT VARCHAR2(10) := 'titulo_18'                   ; --v1.15
   g_k_titulo_19           CONSTANT VARCHAR2(10) := 'titulo_19'                   ;
   g_k_nombre_web_tmp      CONSTANT VARCHAR2(16) := 'NOMBRE_WEB_TMP'              ;   
   g_k_nueva_produccion    CONSTANT VARCHAR2(16) := 'NUEVA PRODUCCION'            ;
   g_k_num_pol_anterior    CONSTANT VARCHAR2(16) := 'NUM_POL_ANTERIOR'            ;
   g_k_prima_minima        CONSTANT VARCHAR2(16) := 'PRIMA_MINIMA'                ; --v1.14
   g_k_fec_tarifa          CONSTANT VARCHAR2(16) := 'FEC_TARIFAS'                 ; --v1.14
   g_k_fec_enero           CONSTANT VARCHAR2(20) := 'FECHA_TARIFA_ENE'            ; --v1.14
   g_k_t_pminima           CONSTANT VARCHAR2(21) := 'TARIFA_PRIMA_MINIMA'         ; --v1.14
   g_k_formato_fech_xml    CONSTANT VARCHAR2(21) := 'dd/mm/yyyy hh24:mi:ss'       ;
   g_k_mascara             CONSTANT VARCHAR2(28) :='99999999999999999,999,990.99' ;
   g_k_directorio          CONSTANT VARCHAR2(200):= trn_k_global.mspool_dir       ;
   --
   g_k_mascara_tasa        CONSTANT VARCHAR2(30) :='99999999999999999,999,990.9999' ;
   --
   g_k_tip_emi_poliza_grupo   CONSTANT VARCHAR2(1)  := 'G'                        ; --RB
   g_k_total                  CONSTANT VARCHAR2(5)  := 'TOTAL'                    ;
   g_k_provincia              CONSTANT VARCHAR2(8)  := 'COD_PROV'                 ;   
   g_k_num_pisos              CONSTANT VARCHAR2(9)  := 'NUM_PISOS'                ;
   g_k_poliza                 CONSTANT VARCHAR2(8)  := '[poliza]'                 ;   
   g_k_fecha_1                CONSTANT VARCHAR2(9)  := '[fecha_1]'                ;
   g_k_fecha_2                CONSTANT VARCHAR2(9)  := '[fecha_2]'                ;
   g_k_cod_tarifa             CONSTANT VARCHAR2(22) := 'COD_TARIFA'               ;
   g_k_contenido              CONSTANT VARCHAR2(9)  := 'CONTENIDO'                ;
   g_k_cod_localidad          CONSTANT VARCHAR2(13) := 'COD_LOCALIDAD'            ;
   g_k_cod_modalidad          CONSTANT VARCHAR2(13) := 'COD_MODALIDAD'            ;
   g_k_num_dir                CONSTANT VARCHAR2(13) := 'NUM_DIRECCION'            ;
   g_k_construccion           CONSTANT VARCHAR2(12) := 'CONSTRUCCION'             ;   
   g_k_localidad              CONSTANT VARCHAR2(13) := 'COD_ESTADO'               ;   
   g_k_anio_construccion      CONSTANT VARCHAR2(17) := 'ANIO_CONSTRUCCION'        ;
   g_k_portal                 CONSTANT VARCHAR2(17) := 'PORTAL_DIRECCION'         ;         
   g_k_tip_cubierta_techo     CONSTANT VARCHAR2(18) := 'TIP_CUBIERTA_TECHO'       ;
   g_k_txt_cubierta_techo     CONSTANT VARCHAR2(18) := 'TXT_CUBIERTA_TECHO'       ;
   g_k_dir_calle              CONSTANT VARCHAR2(19) := 'TXT_DIRECCION_CALLE'      ;
   g_k_txt_direccion_mig_1    CONSTANT VARCHAR2(19) := 'TXT_DIRECCION_MIG_1'      ;
   g_k_txt_direccion_mig_2    CONSTANT VARCHAR2(19) := 'TXT_DIRECCION_MIG_2'      ;
   g_k_txt_direccion_mig_3    CONSTANT VARCHAR2(19) := 'TXT_DIRECCION_MIG_3'      ;      
   g_k_txt_estructura_techo   CONSTANT VARCHAR2(20) := 'TXT_ESTRUCTURA_TECHO'     ;
   g_k_tip_estructura_techo   CONSTANT VARCHAR2(20) := 'TIP_ESTRUCTURA_TECHO'     ;
   g_k_tip_construccion_muro  CONSTANT VARCHAR2(21) := 'TIP_CONSTRUCCION_MURO'    ;
   g_k_txt_construccion_muro  CONSTANT VARCHAR2(21) := 'TXT_CONSTRUCCION_MURO'    ;
   g_k_num_area_construccion  CONSTANT VARCHAR2(21) := 'NUM_AREA_CONSTRUCCION'    ;
   g_k_txt_construccion_piso  CONSTANT VARCHAR2(21) := 'TXT_CONSTRUCCION_PISO'    ;
   g_k_tip_construccion_piso  CONSTANT VARCHAR2(21) := 'TIP_CONSTRUCCION_PISO'    ;
   g_k_otro_seguro            CONSTANT VARCHAR2(21) := 'MCA_OTRO_SEGURO_HOGAR'    ;   
   g_k_tip_construccion_pared CONSTANT VARCHAR2(22) := 'TIP_CONSTRUCCION_PARED'   ;
   g_k_txt_construccion_pared CONSTANT VARCHAR2(22) := 'TXT_CONSTRUCCION_PARED'   ;
   -- v1.13{
   g_k_fec_carta_rf         CONSTANT VARCHAR2(12) := 'FEC_CARTA_RF'                        ;
   g_k_fec_carta_emi        CONSTANT VARCHAR2(13) := 'FEC_CARTA_EMI'                       ;
   g_k_fec_fin_carta_rf     CONSTANT VARCHAR2(16) := 'FEC_FIN_CARTA_RF'                    ;
   g_k_fec_ini_carta_rf     CONSTANT VARCHAR2(19) := 'FEC_INICIO_CARTA_RF'                 ;
   g_k_fec_ini_carta_emi    CONSTANT VARCHAR2(20) := 'FEC_INICIO_CARTA_EMI'                ;
   g_k_beneficios_carta_pol CONSTANT VARCHAR2(23) := 'beneficios_carta_poliza'             ;
   g_k_dir_complemento      CONSTANT VARCHAR2(25) := 'TXT_DIRECCION_COMPLEMENTO'           ;
   g_k_beneficios_carta_rf  CONSTANT VARCHAR2(27) := 'beneficios_carta_renovacion'         ;
   g_k_benef_carta_rf       CONSTANT VARCHAR2(36) := 'EM_K_JRP_POLIZA_CARTA_RENOVACION_MSV';
   -- v1.13}
   g_k_tip_benef_vida  CONSTANT a2000060.tip_benef          %TYPE := '6'              ;
   g_k_inf_cesionario  CONSTANT a2000060.tip_benef          %TYPE := '14'             ;
   g_k_tip_docum_gen   CONSTANT a2000060.tip_docum          %TYPE := 'PAS'            ;
   g_k_cod_ramo        CONSTANT a1001800.cod_ramo           %TYPE := 228              ;
   g_k_2201            CONSTANT a2000040.cod_cob            %TYPE := 2201             ;
   g_k_2241            CONSTANT a2000040.cod_cob            %TYPE := 2241             ;
   g_k_2252            CONSTANT a2000040.cod_cob            %TYPE := 2252             ;
   g_k_cobertura_total CONSTANT a2000020.val_campo          %TYPE := '2281'           ;
   g_k_tradicional     CONSTANT a2000020.val_campo          %TYPE := '2282'           ;
   g_k_cod_docum_gen   CONSTANT a2000060.cod_docum          %TYPE := '99999999'       ;   
   g_k_cod_clausulas   CONSTANT g2999003_msv.cod_campo      %TYPE := 'COD_CLAUSULA'   ;   
   g_k_nom_nemotecnico CONSTANT g2999003_msv.nom_nemotecnico%TYPE := 'CLAUSULAS_HOGAR';       
   --
   g_k_4           CONSTANT INTEGER:= 4       ;   
   g_k_11          CONSTANT INTEGER:= 11      ;
   g_k_20          CONSTANT INTEGER:= 20      ; --v1.15
   g_k_21          CONSTANT INTEGER:= 21      ;
   g_k_25          CONSTANT INTEGER:= 25      ;
   g_k_14          CONSTANT INTEGER:= 14      ;
   g_k_999         CONSTANT INTEGER:= 999     ;
   g_k_spto_actual CONSTANT INTEGER:= 9999    ;
   g_k_local_gen   CONSTANT INTEGER:= 9999    ;   
   g_k_doc_gen     CONSTANT INTEGER:= 99999999;
   --
   g_cod_cia            p1001331.cod_cia       %TYPE := trn_k_global.cod_cia   ;
   g_cod_idioma         g1010010.cod_idioma    %TYPE := trn_k_global.cod_idioma;
   g_cod_usr            a2000030.cod_usr       %TYPE := trn_k_global.cod_usr   ;
   g_num_apli           a2000031.num_apli      %TYPE := trn.CERO               ;
   g_num_spto_apli      a2000031.num_spto_apli %TYPE := trn.CERO               ;
   g_tot_imp_descuentos a2000161.imp_eco       %TYPE := trn.cero               ;
   g_tot_imp_recargos   a2000161.imp_eco       %TYPE := trn.cero               ;
   g_tot_imp_prima_neta a2000161.imp_eco       %TYPE := trn.cero               ;
   g_tot_imp_igsci      a2000161.imp_eco       %TYPE := trn.cero               ;
   g_tot_imp_emision    a2000161.imp_eco       %TYPE := trn.cero               ;
   g_tot_imp_iva        a2000161.imp_eco       %TYPE := trn.cero               ;
   g_tot_imp_total      a2000161.imp_eco       %TYPE := trn.cero               ;   
   g_num_periodo        a2000020.num_periodo   %TYPE := trn.UNO                ;
   g_tot_imp_prima_pol  a2000161.imp_eco       %TYPE := trn.cero              ;
   g_tot_sum_aseg_pol   a2000161.imp_eco       %TYPE := trn.cero              ;   
   --
   g_mca_impresion      a2000030.mca_impresion     %TYPE;
   g_jbcod_ramo         a2000030.cod_ramo          %TYPE;
   g_jbnum_poliza       a2000030.num_poliza        %TYPE;
   g_jbnum_poliza_grupo a2000030.num_poliza_grupo  %TYPE;
   g_jbnum_contrato     a2000030.num_contrato      %TYPE;
   g_jbcod_nivel1       a2000030.cod_nivel1        %TYPE;
   g_jbcod_nivel2       a2000030.cod_nivel2        %TYPE;
   g_jbcod_nivel3       a2000030.cod_nivel3        %TYPE;
   g_jbnum_spto_grp     a2000030.num_spto_grp      %TYPE;
   g_jbnum_spto         a2000031.num_spto          %TYPE;
   g_jbcod_agt          a2000030.cod_agt           %TYPE;
   g_jbtip_docum_aseg   a2000030.tip_docum         %TYPE;
   g_jbcod_docum_aseg   a2000030.cod_docum         %TYPE;
   g_jbtip_docum_hdr    a2000030.tip_docum         %TYPE;
   g_jbcod_docum_hdr    a2000030.cod_docum         %TYPE;
   g_jbfec_desde        a2000030.fec_efec_poliza   %TYPE;
   g_jbfec_hasta        a2000030.fec_vcto_poliza   %TYPE;
   g_cod_proceso        a1001800.cod_proceso       %TYPE;
   g_fec_tratamiento    a2000500.fec_tratamiento   %TYPE;
   g_num_proceso        a2000500_msv.num_proceso   %TYPE;
   g_decimales          A1000400.NUM_DECIMALES     %TYPE;
   g_cod_mensaje        g1010020.cod_mensaje       %TYPE;
   g_cod_ramo           a2000030.cod_ramo          %TYPE;
   g_cod_sector         a2000030.cod_sector        %TYPE;
   g_num_poliza         a2000030.num_poliza        %TYPE;
   g_num_poliza_grupo   a2000030.num_poliza_grupo  %TYPE;
   g_num_contrato       a2000030.num_contrato      %TYPE;
   g_num_subcontrato    a2000030.num_subcontrato   %TYPE;
   g_num_poliza_cliente a2000030.num_poliza_cliente%TYPE;
   g_cod_nivel1         a2000030.cod_nivel1        %TYPE;
   g_cod_nivel2         a2000030.cod_nivel2        %TYPE;
   g_cod_nivel3         a2000030.cod_nivel3        %TYPE;
   g_num_spto_grp       a2000030.num_spto_grp      %TYPE;
   g_num_riesgo         a2000031.num_riesgo        %TYPE;
   g_num_spto           a2000031.num_spto          %TYPE;
   g_cod_spto           a2000030.cod_spto          %TYPE;
   g_sub_cod_spto       a2000030.sub_cod_spto      %TYPE;
   g_tip_spto           a2000030.tip_spto          %TYPE;
   g_cod_agt            a2000030.cod_agt           %TYPE;
   g_tip_docum_aseg     a2000030.tip_docum         %TYPE;
   g_cod_docum_aseg     a2000030.cod_docum         %TYPE;
   g_tip_docum_hdr      a2000030.tip_docum         %TYPE;
   g_cod_docum_hdr      a2000030.cod_docum         %TYPE;
   g_tip_docum_alt_hdr  a2000030.tip_docum         %TYPE;
   g_cod_docum_alt_hdr  a2000030.cod_docum         %TYPE;
   g_fec_validez        a2000030.fec_validez       %TYPE;
   g_fec_emision_spto   a2000030.fec_emision_spto  %TYPE;
   g_fec_efec_poliza    a2000030.fec_efec_poliza   %TYPE;
   g_fec_vcto_poliza    a2000030.fec_vcto_poliza   %TYPE;
   g_fec_efec_spto      a2000030.fec_efec_spto     %TYPE;
   g_fec_enero          a2000030.fec_efec_spto     %TYPE;
   g_fec_vcto_spto      a2000030.fec_vcto_spto     %TYPE;
   g_num_orden          a2000500.num_orden         %TYPE;
   g_tip_mvto_batch     a2000500.tip_mvto_batch    %TYPE;
   g_email_report       a1001331.email             %TYPE;
   g_cod_modalidad      a2000020.val_campo         %TYPE;
   g_id_report          tronweb_reports.id_report  %TYPE;
   g_cod_report         tronweb_reports.cod_report %TYPE;
   g_nom_reporte        g1010031.nom_valor         %TYPE;
   g_cod_ejecutivo      a2000030.cod_ejecutivo     %TYPE;
   g_nom_ejecutivo      v1001390.nom_completo      %TYPE; 
   g_num_riesgos        a2000030.num_riesgos       %TYPE;
   g_imp_prima_base     a2000161.imp_eco           %TYPE;
   g_sum_aseg_const     a2000040.suma_aseg         %TYPE;
   g_sum_aseg_contenido a2000040.suma_aseg         %TYPE;
   g_sum_aseg_total     a2000040.suma_aseg         %TYPE;
   g_nom_ciudad         a1000702.nom_nivel3        %TYPE;       
   --
   g_cod_mon            VARCHAR2(01);
   g_jbprint_copies     VARCHAR (01);
   g_jbtip_emision      VARCHAR2(01);
   g_jbtip_soa          VARCHAR2(01);
   g_jbmca_corret_mod   VARCHAR2(01);
   g_mca_envio_email    VARCHAR2(01);
   g_mca_migracion      VARCHAR2(01);
   g_mca_gen_individual VARCHAR2(01);
   g_jbtip_scope        VARCHAR2(02);
   g_jbnum_factura      VARCHAR2(13);
   g_nom_log            VARCHAR2(50);
   --
   g_titulo      VARCHAR2(2000);
   g_anx_mensaje VARCHAR2(250);
   --
   g_aux_exc_trace VARCHAR2(2000);
   --
   g_count_cob NUMBER := trn.cero;
   --
   g_jbcod_agt_advisor NUMBER;
   g_n_error           NUMBER;
   --
   g_usa_spto_temporal BOOLEAN;
   g_quotation         BOOLEAN;
   g_pre_renewal       BOOLEAN;
   g_ncd               BOOLEAN;
   g_existe            BOOLEAN;
   g_existe_riesgo     BOOLEAN;
   g_existe_dv_r       BOOLEAN;
   g_existe_tercero    BOOLEAN;
   g_situacion_actual  BOOLEAN;
   g_del_report        BOOLEAN;
   g_abre_reporte      BOOLEAN;
   --
   g_jbchoose_report BINARY_INTEGER;
   g_idx_id_report   BINARY_INTEGER;
   g_cont_tabs       BINARY_INTEGER;
   g_cont_regs       BINARY_INTEGER;
   g_cont_tabs_aux   BINARY_INTEGER;
   g_cont_regs_aux   BINARY_INTEGER;
   --
   g_cadena_cab        CLOB;
   g_cadena_dat        CLOB;
   g_xml_impresion     CLOB;
   g_cadena_cab_aux    CLOB;
   g_cadena_dat_aux    CLOB;
   g_xml_impresion_aux CLOB;
   --
   g_road_license_exc EXCEPTION;
   g_ncd_a2000030_exc EXCEPTION;
   --
   g_id_fichero UTL_FILE.FILE_TYPE;
   --
   g_k_sysdate CONSTANT DATE := TRUNC(SYSDATE);
   --
   TYPE reg30 IS RECORD
   (cod_cia               a2000030.cod_cia               %TYPE,
    cod_sector            a2000030.cod_sector            %TYPE,
    cod_ramo              a2000030.cod_ramo              %TYPE,
    num_poliza            a2000030.num_poliza            %TYPE,
    num_spto              a2000030.num_spto              %TYPE,
    num_apli              a2000030.num_apli              %TYPE,
    num_spto_apli         a2000030.num_spto_apli         %TYPE,
    fec_validez           a2000030.fec_validez           %TYPE,
    fec_emision           a2000030.fec_emision           %TYPE,
    fec_efec_poliza       a2000030.fec_efec_poliza       %TYPE,
    fec_vcto_poliza       a2000030.fec_vcto_poliza       %TYPE,
    fec_efec_spto         a2000030.fec_efec_spto         %TYPE,
    fec_vcto_spto         a2000030.fec_vcto_spto         %TYPE,
    num_poliza_cliente    a2000030.num_poliza_cliente    %TYPE,
    num_contrato          a2000030.num_contrato          %TYPE,
    num_poliza_grupo      a2000030.num_poliza_grupo      %TYPE,
    cod_spto              a2000030.cod_spto              %TYPE,
    sub_cod_spto          a2000030.sub_cod_spto          %TYPE,
    tip_spto              a2000030.tip_spto              %TYPE,
    tip_docum             a2000030.tip_docum             %TYPE,
    cod_docum             a2000030.cod_docum             %TYPE,
    cod_mon               a2000030.cod_mon               %TYPE,
    cod_fracc_pago        a2000030.cod_fracc_pago        %TYPE,
    tip_gestor            a2000030.tip_gestor            %TYPE,
    cod_agt               a2000030.cod_agt               %TYPE,
    cod_nivel1            a2000030.cod_nivel1            %TYPE,
    cod_nivel2            a2000030.cod_nivel2            %TYPE,
    cod_nivel3            a2000030.cod_nivel3            %TYPE,
    mca_impresion         a2000030.mca_impresion         %TYPE,
    cod_usr               a2000030.cod_usr               %TYPE,
    fec_actu              a2000030.fec_actu              %TYPE,
    hora_desde            a2000030.hora_desde            %TYPE,
    num_subcontrato       a2000030.num_subcontrato       %TYPE,
    fec_vcto_spto_publico a2000030.fec_vcto_spto_publico %TYPE,
    num_spto_grp          a2000030.num_spto_grp          %TYPE,
    tip_coaseguro         a2000030.tip_coaseguro         %TYPE,
    cod_ejecutivo         a2000030.cod_ejecutivo         %TYPE,
    num_riesgos           a2000030.num_riesgos           %TYPE);
   --
   TYPE reg_clau_espc IS RECORD
   (cod_cob        a2000040.cod_cob               %TYPE,
    nom_cob        a1002050.nom_cob               %TYPE,
    suma_aseg      VARCHAR2(30)                        ,    
    cod_clausula   g2999003_msv.txt_valor_maximo  %TYPE,
    txt_clausula   a9990010.nom_clausula          %TYPE,
    cod_franquicia VARCHAR2(10)                        ,
    val_franquicia_min VARCHAR2(50)                    ,
    aplica_porcentaje CHAR,
    aplica_deducible  CHAR);
   --
   TYPE reg_clau_cob IS TABLE OF reg_clau_espc 
      INDEX BY BINARY_INTEGER;
   --
   g_reg_clau_espc reg_clau_cob;
   --   
   TYPE reg_list_cob IS RECORD
   (cod_cob   a2000040.cod_cob  %TYPE,
    suma_aseg a2000040.suma_aseg%TYPE);
   --
   TYPE reg_list_tbl IS TABLE OF reg_list_cob
      INDEX BY BINARY_INTEGER;
   --
   g_l_list_cob reg_list_tbl;
   --
   TYPE reg_riesgo IS RECORD
   (num_riesgo       a2000031.num_riesgo    %TYPE ,
    nom_riesgo       a2000031.nom_riesgo    %TYPE ,
    tip_docum        a2000060.tip_docum     %TYPE ,
    cod_docum        a2000060.cod_docum     %TYPE ,
    cod_modalidad    a2000031.cod_modalidad %TYPE);
   --
   TYPE REG_ENVIO_EMAIL IS RECORD
   (tip_docum   a1001331.tip_docum        %TYPE,
    cod_docum   a1001331.cod_docum        %TYPE,
    num_poliza  a2000030.num_poliza       %TYPE,
    num_spto    a2000030.num_spto         %TYPE,
    email       a1001331.email            %TYPE,
    id_report   tronweb_reports.id_report %TYPE,
    cod_report  tronweb_reports.cod_report%TYPE);
   --
   TYPE t_tbl_envio_email IS TABLE OF REG_ENVIO_EMAIL
      INDEX BY BINARY_INTEGER;
   --
   g_tbl_envio_email T_TBL_ENVIO_EMAIL;
   --
   g_tbl_datos_var em_k_a2000020.TABLE_DATOS_VARIABLES;
   --
   TYPE G_T_DAT_TERCERO IS RECORD
    (nom_completo        v1001390.nom_completo           %TYPE,
     fec_nacimiento      a1001331.fec_nacimiento         %TYPE,
     nom_domicilio1      a1001331.nom_domicilio1         %TYPE,
     nom_domicilio2      a1001331.nom_domicilio2         %TYPE,
     nom_domicilio3      a1001331.nom_domicilio3         %TYPE,
     nom_localidad       a1001331.nom_localidad          %TYPE,
     nom_estado          a1000104.nom_estado             %TYPE,
     nom_prov            a1000100.nom_prov               %TYPE,
     cp                  a1001331.cod_postal             %TYPE,
     email               a1001331.email                  %TYPE,
     cod_nacionalidad    a1001331.cod_nacionalidad       %TYPE,
     tip_sufijo_nombre   a1001399.tip_sufijo_nombre      %TYPE,
     tlf_numero          a1001331.tlf_numero             %TYPE,
     tlf_movil           a1001399.tlf_movil              %TYPE,
     nom_profesion       g1000100.nom_profesion          %TYPE,
     tip_prefijo_nombre  a1001399.tip_prefijo_nombre     %TYPE,
     ape1_tercero        a1001399.ape1_tercero           %TYPE,
     nom_domicilio1_com  a1001331.nom_domicilio1_com     %TYPE,
     nom_domicilio2_com  a1001331.nom_domicilio2_com     %TYPE,
     nom_domicilio3_com  a1001331.nom_domicilio3_com     %TYPE,
     nom_empresa_com     a1001331.nom_empresa_com        %TYPE,        
     atr_domicilio1_com  a1001331.atr_domicilio1_com     %TYPE,     
     atr_domicilio2_com  a1001331.atr_domicilio2_com     %TYPE,     
     atr_domicilio3_com  a1001331.atr_domicilio3_com     %TYPE,          
     txt_etiqueta1       a1001331.txt_etiqueta1          %TYPE,
     txt_etiqueta2       a1001331.txt_etiqueta2          %TYPE,
     txt_etiqueta3       a1001331.txt_etiqueta3          %TYPE,
     txt_etiqueta4       a1001331.txt_etiqueta4          %TYPE,
     txt_etiqueta5       a1001331.txt_etiqueta5          %TYPE,
     cod_tercero         a1001300.cod_tercero            %TYPE,
     atr_domicilio1      a1001300.atr_domicilio1         %TYPE,
     cod_pais            a1001300.cod_pais               %TYPE,
     cod_estado          a1001331.cod_estado             %TYPE,
     cod_estado_etiqueta p1001331_msv.cod_estado_etiqueta%TYPE,
     cod_prov_etiqueta   p1001331_msv.cod_prov_etiqueta  %TYPE
     );
   --
   TYPE registro_data IS RECORD
   (cod_campo VARCHAR2(250),
    val_campo CLOB);
   --
   TYPE tabla_xml_deta IS TABLE OF REGISTRO_DATA
        INDEX BY BINARY_INTEGER;
   --
   g_tbl_xml_deta     TABLA_XML_DETA;
   g_tbl_xml_deta_pol TABLA_XML_DETA;
   --
   TYPE reg_txt_reporte IS RECORD
   (num_secu         a1009012_msv.num_secu        %TYPE,
    contenido_objeto a1009012_msv.contenido_objeto%TYPE);
   --
   TYPE tbl_txt_reporte IS TABLE OF reg_txt_reporte
      INDEX BY PLS_INTEGER;
   --
   g_tbl_txt_reporte tbl_txt_reporte;
   --
   TYPE reg_clause IS RECORD
   (
    cod_clausula a2000265.cod_clausula%TYPE,
    num_riesgo   a2000265.num_riesgo  %TYPE
   );
   --
   TYPE reg_cob_pln_trad IS RECORD
   ( 
     cod_cob        a2000040.cod_cob%TYPE,
     nom_cob        a1002050.nom_cob%TYPE,
     nom_moneda     VARCHAR2(15)         ,
     cob_limite     VARCHAR2(30)         ,
     deducible_txt  VARCHAR2(60)         ,
     mca_imprime    VARCHAR2(2)
    );
   --
   TYPE reg_pln_trad IS TABLE OF reg_cob_pln_trad 
      INDEX BY BINARY_INTEGER;
   --
   g_reg_pln_trad  reg_pln_trad;      
   --
   TYPE reg_clau_por_cob IS RECORD
   (
     cod_clausula       g2999003_msv.txt_valor_maximo%TYPE,
     sum_aseg_const     a2000040.suma_aseg           %TYPE,
     sum_aseg_contenido a2000040.suma_aseg           %TYPE,
     sum_aseg_total     a2000040.suma_aseg           %TYPE,
     mca_imprime CHAR
   );   
   --
   TYPE g_reg_clau_por_cob IS TABLE OF reg_clau_por_cob 
      INDEX BY BINARY_INTEGER;
   --
   g_tbl_cob_clau g_reg_clau_por_cob;   
   --
   /* ----------------------------------------------------
   || Aqui comienza la declaracion de subprogramas LOCALES
   */ ----------------------------------------------------
   --
   /* --------------------------------------------------------
   || mx:
   || Genera la traza
   || Activa el g_trazas_activas para crear el identificador
   || de la sesion y poder mostrar quien procesa el registro
   */ --------------------------------------------------------
   --
   PROCEDURE mx(p_tit IN VARCHAR2,
                p_val IN VARCHAR2)
   IS
   --
   BEGIN
      --
      trn_k_global.asigna('fic_traza', g_cod_usr     );
      trn_k_global.asigna('cab_traza', 'ea_k_jrp_121');
      --
      em_k_traza.p_escribe(p_titulo => p_tit,
                           p_valor  => p_val);
      --
   END mx;
   --
   /* -----------------------------------------------------
   || pp_devuelve_error :
   || Devuelve un error
   */ -----------------------------------------------------
   --
   PROCEDURE pp_devuelve_error
   IS
   --
   BEGIN
      --
      --@mx('I','pp_devuelve_error');
      --
      IF g_cod_mensaje BETWEEN 20000
                           AND 20999
       THEN
        --
        RAISE_APPLICATION_ERROR(-20000,
                                '{'||
                                ss_k_mensaje.f_texto_idioma(g_cod_mensaje,
                                                            g_cod_idioma ) ||
                                g_anx_mensaje||
                                '}'
                               );
        --
       ELSE
        --
        trn_k_global.asigna('mca_ter_tar', trn.SI);
        --
        trn_k_global.asigna('TXT_TAREA', 'REPORTE NO GENERADO');
        --
        RAISE_APPLICATION_ERROR(-20000,
                                ss_k_mensaje.f_texto_idioma(g_cod_mensaje,
                                                            g_cod_idioma ) ||
                                g_anx_mensaje
                               );
        --
      END IF;
      --
      --@mx('F','pp_devuelve_error');
      --
   END pp_devuelve_error;
   --
   /* --------------------------------------------------------
   || pp_comprueba_error:
   || Comprueba que se haya leido informacion
   */ --------------------------------------------------------
   --
   PROCEDURE pp_comprueba_error(p_nom_tabla IN VARCHAR2)
   IS
   --
   BEGIN
      --
      --@mx('I','pp_comprueba_error');
      --
      IF NOT g_existe
      THEN
         --
         g_cod_mensaje := 20001;
         g_anx_mensaje := trn.INI_CORCHETE || p_nom_tabla || trn.FIN_CORCHETE;
         --
         pp_devuelve_error;
         --
      END IF;
      --
      --@mx('F','pp_comprueba_error');
      --
   END pp_comprueba_error;
   --
   /* -----------------------------------------
   || pp_recupera_globales:
   */ -----------------------------------------
   --
   PROCEDURE pp_recupera_globales
   IS
   --
   BEGIN
      --
      --@mx('I','pp_recupera_globales');
      --
      g_jbcod_ramo         := trn_k_global.ref_f_global('jbcod_ramo'        );
      g_jbcod_nivel1       := trn_k_global.ref_f_global('jbcod_nivel1'      );
      g_jbcod_nivel2       := trn_k_global.ref_f_global('jbcod_nivel2'      );
      g_jbcod_nivel3       := trn_k_global.ref_f_global('jbcod_nivel3'      );
      g_jbcod_agt          := trn_k_global.ref_f_global('jbcod_agt'         );
      g_cod_agt            := trn_k_global.ref_f_global('jbcod_agt'         );
      g_jbnum_poliza_grupo := trn_k_global.ref_f_global('JBNUM_POLIZA_GRUPO');
      g_jbnum_contrato     := trn_k_global.ref_f_global('JBNUM_CONTRATO'    );
      g_jbnum_spto_grp     := trn_k_global.ref_f_global('JBNUM_SPTO_GRUPO'  );
      g_jbtip_emision      := trn_k_global.ref_f_global('jbtip_emision'     );
      g_jbtip_docum_aseg   := trn_k_global.ref_f_global('jbtip_docum_i'     );
      g_jbcod_docum_aseg   := trn_k_global.ref_f_global('jbcod_docum_i'     );
      g_jbnum_poliza       := trn_k_global.ref_f_global('jbnum_poliza'      );
      g_jbnum_spto         := trn_k_global.ref_f_global('jbnum_spto'        );
      g_jbtip_soa          := trn_k_global.ref_f_global('jbtip_soa'         );
      g_jbcod_agt_advisor  := trn_k_global.ref_f_global('jbcod_agt_advisor' );
      g_jbtip_docum_hdr    := trn_k_global.ref_f_global('jbtip_docum_hdr'   );
      g_jbcod_docum_hdr    := trn_k_global.ref_f_global('jbcod_docum_hdr'   );
      g_jbchoose_report    := trn_k_global.ref_f_global('jbchoose_report'   );
      g_jbprint_copies     := trn_k_global.ref_f_global('jbprint_copies'    );
      g_jbnum_factura      := trn_k_global.ref_f_global('jbinvoice_number'  );
      g_jbmca_corret_mod   := trn_k_global.ref_f_global('mca_brokerage_mod' );
      g_jbtip_scope        := trn_k_global.ref_f_global('tip_scope'         );
      g_num_apli           := trn_k_global.ref_f_global('jbnum_apli'        );
      g_num_spto_apli      := trn_k_global.ref_f_global('jbnum_spto_apli'   );      
      --
      g_jbfec_desde        := TO_DATE(trn_k_global.ref_f_global('jbfec_desde')   ,trn.FORMATO_FECHA);
      g_jbfec_hasta        := TO_DATE(trn_k_global.ref_f_global('jbfec_hasta')   ,trn.FORMATO_FECHA);
      g_mca_envio_email    := NVL(trn_k_global.ref_f_global('mca_envio_email')   , trn.NO          );
      g_mca_migracion      := NVL(trn_k_global.ref_f_global('mca_migracion')     , trn.SI          );
      g_mca_gen_individual := NVL(trn_k_global.ref_f_global('mca_gen_individual'), trn.NO          );
      g_cod_proceso        := NVL(trn_k_global.ref_f_global('cod_proceso')       , trn.BLANCO      );
      --
      g_num_proceso        := trn_k_global.ref_f_global('num_proceso');
      g_fec_tratamiento    := TO_DATE(trn_k_global.ref_f_global('fec_tratamiento'),trn.FORMATO_FECHA);
      g_num_orden          := trn_k_global.ref_f_global('num_orden');
      g_tip_mvto_batch     := trn_k_global.ref_f_global('tip_mvto_batch');
      --
      --@mx('F','pp_recupera_globales');
      --
   END pp_recupera_globales;
   --
   /* --------------------------------------------------------
   || pp_inicia_variables:
   || Reinicia aquellas variables necesarias.
   || p_quotation: TRUE si estamos imprimiendo un Request. FALSE
   || si es una poliza.
   */ --------------------------------------------------------
   --
   PROCEDURE pp_inicia_variables(p_quotation IN BOOLEAN          ,
                                 p_ncd       IN BOOLEAN := FALSE )
   IS
   --
   BEGIN
      --
      --@mx('I','pp_inicia_variables');
      --
      g_cont_regs   := trn.cero   ;
      g_num_poliza  := trn.nulo   ;
      g_num_riesgo  := trn.nulo   ;
      g_quotation   := p_quotation;
      g_ncd         := p_ncd      ;
      g_cod_report  := trn.nulo   ;
      g_del_report  := TRUE       ;
      g_pre_renewal := FALSE      ;
      --
      g_usa_spto_temporal := FALSE;
      --
      --@mx('F','pp_inicia_variables');
      --
   END pp_inicia_variables;
   --
   /* --------------------------------------------------------
   || fp_separador:
   || Devuelve el separador a utilizar cuando se
   || concatenan dos textos
   */ --------------------------------------------------------
   --
   FUNCTION fp_separador(p_txt1      IN VARCHAR2,
                         p_txt2      IN VARCHAR2,
                         p_separador IN VARCHAR2)
      RETURN VARCHAR2
   IS
      --
      l_resultado VARCHAR2(20);
      --
   BEGIN
      --
      --@mx('I','fp_separador');
      --
      IF     p_txt1 IS NOT NULL AND LENGTH(TRIM(p_txt1)) > trn.CERO
         AND p_txt2 IS NOT NULL AND LENGTH(TRIM(p_txt2)) > trn.CERO
      THEN
         --
         l_resultado := p_separador;
         --
      END IF;
      --
      --@mx('F','fp_separador');
      --
      RETURN l_resultado;
      --
   END fp_separador;
   --
   /* --------------------------------------------------------
   || fp_format:
   || Formatea el numero decimal.
   */ --------------------------------------------------------
   --
   FUNCTION fp_format(p_importe      IN VARCHAR2         ,
                      p_valida_error IN BOOLEAN := TRUE  ,
                      p_anyade_euro  IN BOOLEAN := FALSE ,
                      p_coma         IN BOOLEAN := FALSE ,
                      p_tasa         IN BOOLEAN := FALSE )
      RETURN VARCHAR2
   IS
      --
      l_resultado VARCHAR2(100)                                ;
      l_mascara   VARCHAR2(35)  := '99999999999999999999990.99';
      --
   BEGIN
      --
      --@mx('I','fp_format');
      --
      IF p_coma
      THEN
         --
         l_mascara := '99999999999999999999,990.99';
         --
      END IF;
      --
      IF p_anyade_euro
      THEN
         --
         l_resultado := ';' || ' ' || TRIM(TO_CHAR(TRIM(p_importe), l_mascara));
         --
      ELSE
         --
         IF p_importe IS NULL
         THEN 
            --
            RETURN NULL;
            --
         ELSE
            --
            IF p_tasa 
            THEN
               --
               l_resultado := TRIM(TO_CHAR(TRIM(p_importe), g_k_mascara_tasa));
               --
            ELSE
               --
               l_resultado := TRIM(TO_CHAR(TRIM(p_importe), g_k_mascara));
               --
            END IF;                        
            --
         END IF;         
         --
      END IF;
      --
      --@mx('F','fp_format');
      --
      RETURN l_resultado;
      --
   EXCEPTION
      --
      WHEN OTHERS
      THEN
         --
         IF p_valida_error
         THEN
            --
            RAISE;
            --
         END IF;
   --
   RETURN p_importe;
   --
   END fp_format;
   --
   /* --------------------------------------------------------
   || fp_format_fec:
   || Formatea la fecha con el patron de fecha mas comun
   */ --------------------------------------------------------
   --
   FUNCTION fp_format_fec(p_fecha IN DATE)
      RETURN VARCHAR2
   IS
   --
   BEGIN
      --
      --@mx('I','fp_format');
      --
      RETURN TO_CHAR(p_fecha, g_k_formato_fec_xml);
      --
   END fp_format_fec;
   --
   /* --------------------------------------------------------
   || fp_tabs:
   || Tabulaciones para los tag xml del reporte
   */ --------------------------------------------------------
   --
   FUNCTION fp_tabs
      RETURN VARCHAR2
   IS
      --
      l_tabs VARCHAR2(25);
      --
   BEGIN
      --
      --@mx('I','fp_tabs');
      --
      IF g_cont_tabs > g_k_25
      THEN
         --
         g_cod_mensaje := 20000;
         g_anx_mensaje := ' Demasiados tabuladores. Maximo 25 act:'||g_cont_tabs;
         --
         pp_devuelve_error;
         --
      END IF;
      --
      FOR i IN  1 .. g_cont_tabs
      LOOP
        --
        l_tabs := l_tabs || CHR(9);
        --
      END LOOP;
      --
      --@mx('F','fp_tabs');
      --
      RETURN l_tabs;
      --
   END fp_tabs;
   --
   /* --------------------------------------------------------
   || fp_nom_mon:
   || devuelve el nombre de la moneda
   */ --------------------------------------------------------
   --
   FUNCTION fp_nom_mon(p_cod_mon a1000400.cod_mon%TYPE)
      RETURN VARCHAR2
   IS
      --
      l_nom_mon a1000400.cod_mon_iso%TYPE;
      --
   BEGIN
      --
      --@mx('I','fp_nom_mon');
      --
      IF p_cod_mon = trn.UNO
      THEN
         --
         l_nom_mon := '$';
         --
      ELSIF p_cod_mon = g_k_14
      THEN
         --
         l_nom_mon := 'US$';
         --
      ELSE
         --
         l_nom_mon := p_cod_mon;
         --
      END IF;
      --
      --@mx('F','fp_nom_mon');
      --
      RETURN l_nom_mon;
      --
   END fp_nom_mon;
   --
   /* --------------------------------------------------------
   || fp_ter_nom_ocupacion:
   || Devuelve el nombre de la ocupacion del tercero
   */ --------------------------------------------------------
   --
   FUNCTION fp_ter_nom_ocupacion(p_cod_ocupacion IN a1001331.cod_ocupacion%TYPE)
      RETURN g1000100.nom_profesion%TYPE
   IS
      --
      l_nom_ocupacion g1000100.nom_profesion%TYPE;
       --
   BEGIN
      --
      --@mx('I','fp_ter_nom_ocupacion');
      --
      IF dc_k_terceros.f_cod_ocupacion IS NOT NULL
      THEN
         --
         dc_k_g1000100.p_lee(p_cod_profesion => p_cod_ocupacion,
                             p_cod_idioma    => g_cod_idioma   );
         --
         l_nom_ocupacion := dc_k_g1000100.f_nom_profesion;
         --
      END IF;
      --
      --@mx('F','fp_ter_nom_ocupacion');
      --
      RETURN l_nom_ocupacion;
      --
   EXCEPTION
      --
      WHEN trn.E_NO_EXISTE
      THEN
         --
         RETURN ' ';
         --
   END fp_ter_nom_ocupacion;
   --
   /* --------------------------------------------------------
   || fp_fec_vcto_poliza_publico:
   || Devuelve fecha de vencimiento de la p0liza
   */ --------------------------------------------------------
   --
   FUNCTION fp_fec_vcto_poliza_publico(p_cod_cia               a2000030.cod_cia               %TYPE,
                                       p_num_poliza            a2000030.num_poliza            %TYPE,
                                       p_hora_desde            a2000030.hora_desde            %TYPE,
                                       p_cod_spto              a2000030.cod_spto              %TYPE,
                                       p_sub_cod_spto          a2000030.sub_cod_spto          %TYPE,
                                       p_fec_vcto_poliza       a2000030.fec_vcto_poliza       %TYPE,
                                       p_fec_vcto_spto_publico a2000030.fec_vcto_spto_publico %TYPE)
      RETURN a2000030.fec_vcto_spto_publico%TYPE
   IS
      --
      l_mca_spto_tmp     a2991800.mca_temporal         %TYPE;
      l_fec_vcto_pub_aux a2000030.fec_vcto_spto_publico%TYPE;
      l_pd_fec_exp       a2000030.fec_vcto_spto_publico%TYPE;
      --
      PROCEDURE pi_cal_fec_quo
      IS
         --
         CURSOR c_fec_vcto
         IS
            --
            SELECT pol.fec_vcto_spto_publico
              FROM p2000030 pol
             WHERE pol.cod_cia    = p_cod_cia
               AND pol.num_poliza = p_num_poliza
               AND pol.num_spto   = (SELECT MAX(num_spto)
                                       FROM p2000030 aux
                                      WHERE aux.cod_cia    = p_cod_cia
                                        AND aux.num_poliza = p_num_poliza
                                        AND aux.tip_spto IN ('XX', 'RF'))
               AND pol.num_apli      = 0
               AND pol.num_spto_apli = 0;
      BEGIN
         --
         IF     p_cod_spto IS NOT NULL
            AND p_sub_cod_spto IS NOT NULL
         THEN
            --
            em_k_a2991800.p_lee(p_cod_cia         => p_cod_cia     ,
                                p_cod_spto        => p_cod_spto    ,
                                p_sub_cod_spto    => p_sub_cod_spto,
                                p_tip_ambito_spto => NULL          );
            --
            l_mca_spto_tmp := em_k_a2991800.f_mca_temporal;
            --
         ELSE
            --
            l_mca_spto_tmp := 'N';
            --
         END IF;
         --
         IF     l_mca_spto_tmp = trn.SI
            AND p_fec_vcto_spto_publico IS NOT NULL
         THEN
            -- Se ejecuta aqui la sentencia para evitar errores en suplementos de nueva producci????????????????????A?n
            OPEN c_fec_vcto;
            FETCH c_fec_vcto INTO l_fec_vcto_pub_aux;
            CLOSE c_fec_vcto;
            --
            l_pd_fec_exp := NVL( l_fec_vcto_pub_aux, TO_DATE(TO_CHAR(p_fec_vcto_poliza, g_k_formato_fech_hyphen)||' '||'23:59:59', 'DD-MM-yyyy HH24:MI:SS') );
            --
         ELSE
            --
            l_pd_fec_exp := NVL(p_fec_vcto_spto_publico, TO_DATE(TO_CHAR(p_fec_vcto_poliza, g_k_formato_fech_hyphen)||' '||'23:59:59', 'DD-MM-yyyy HH24:MI:SS'));
            --
         END IF;
         --
      END pi_cal_fec_quo;
      --
   BEGIN
      --
      --@mx('I','fp_fec_vcto_poliza_publico');
      --
      IF NOT g_quotation
      THEN
         --
         l_pd_fec_exp := em_k_cons_datos_fijos.f_fec_vcto_poliza_publico(p_cod_cia               => p_cod_cia              ,
                                                                         p_num_poliza            => p_num_poliza           ,
                                                                         p_hora_desde            => p_hora_desde           ,
                                                                         p_cod_spto              => p_cod_spto             ,
                                                                         p_sub_cod_spto          => p_sub_cod_spto         ,
                                                                         p_fec_vcto_poliza       => p_fec_vcto_poliza      ,
                                                                         p_fec_vcto_spto_publico => p_fec_vcto_spto_publico);
         --
         l_pd_fec_exp := NVL( l_pd_fec_exp, TO_DATE(TO_CHAR(p_fec_vcto_poliza, g_k_formato_fech_hyphen)||' '||'23:59:59', 'DD-MM-yyyy HH24:MI:SS') );
         --
      ELSE
         --
         pi_cal_fec_quo;
         --
      END IF;
      --
      --@mx('F','fp_fec_vcto_poliza_publico');
      --
      RETURN l_pd_fec_exp;
      --
   END fp_fec_vcto_poliza_publico;
   --
   /* --------------------------------------------------------
   || fp_obtiene_datos_tercero:
   || Devuelve la informacion del tercero
   */ --------------------------------------------------------
   --
   FUNCTION fp_obtiene_datos_tercero(p_cod_cia         IN a1001300.cod_cia        %TYPE,
                                     p_tip_docum       IN a2000060.tip_docum      %TYPE,
                                     p_cod_docum       IN a2000030.cod_docum      %TYPE,
                                     p_num_poliza      IN a2000030.num_poliza     %TYPE,
                                     p_num_spto        IN a2000030.num_spto       %TYPE,
                                     p_fec_efec_spto   IN a1001300.fec_validez    %TYPE,
                                     p_num_riesgo      IN a1000802.num_riesgo     %TYPE,
                                     p_cod_act_tercero IN a1001331.cod_act_tercero%TYPE := dc.ACT_ASEGURADO,
                                     p_cod_tercero     IN a1001300.cod_tercero    %TYPE := NULL)
      RETURN G_T_DAT_TERCERO
   IS
      --
      l_nom_localidad a1000102.nom_localidad %TYPE;
      l_nom_estado    a1000104.nom_estado    %TYPE;
      l_nom_prov      a1000100.nom_prov      %TYPE;
      --
      l_reg_dom G_T_DAT_TERCERO;
      --
      l_nom_tercero  v1001390.nom_tercero  %TYPE;
      l_nom2_tercero v1001390.nom2_tercero %TYPE;
      l_ape1_tercero v1001390.ape1_tercero %TYPE;
      l_ape2_tercero v1001390.ape2_tercero %TYPE;
      l_cod_tercero  v1001390.cod_tercero  %TYPE;
   --
   BEGIN
      --
      --@mx('I','fp_obtiene_datos_tercero');
      --
      g_existe_tercero := FALSE;
      --
      dc_k_terceros.p_lee_con_poliza(p_cod_cia         => p_cod_cia        ,
                                     p_tip_docum       => p_tip_docum      ,
                                     p_cod_docum       => p_cod_docum      ,
                                     p_cod_tercero     => p_cod_tercero    ,
                                     p_fec_validez     => p_fec_efec_spto  ,
                                     p_cod_act_tercero => p_cod_act_tercero,
                                     p_num_poliza      => p_num_poliza     ,
                                     p_num_spto        => p_num_spto       ,
                                     p_num_riesgo      => p_num_riesgo     );
      --
      dc_k_v1001390.p_lee(p_cod_cia         => p_cod_cia        ,
                          p_cod_act_tercero => p_cod_act_tercero,
                          p_tip_docum       => p_tip_docum      ,
                          p_cod_docum       => p_cod_docum      ,
                          p_cod_tercero     => p_cod_tercero    );
      --
      g_existe_tercero := TRUE;
      --
      BEGIN
         --
         dc_k_a1000104.p_lee(p_cod_pais        => dc_k_terceros.f_cod_pais  ,
                             p_cod_estado      => dc_k_terceros.f_cod_estado,
                             p_mca_estado_real => trn.SI                    );
         --
         l_nom_estado := dc_k_a1000104.f_nom_estado;
         --
      EXCEPTION
         --
         WHEN trn.E_NO_EXISTE
         THEN
            --
            l_nom_estado := ' ';
         --
      END;
      --
      BEGIN
         --
         dc_k_a1000100.p_lee(p_cod_pais => dc_k_terceros.f_cod_pais,
                             p_cod_prov => dc_k_terceros.f_cod_prov);
         --
         l_nom_prov := dc_k_a1000100.f_nom_prov;
         --
      EXCEPTION
         --
         WHEN trn.E_NO_EXISTE
         THEN
            --
            l_nom_prov := ' ';
         --
      END;
      --
      BEGIN
         --
         dc_k_a1000102.p_lee(p_cod_pais      => dc_k_terceros.f_cod_pais,
                             p_cod_localidad => dc_k_terceros.f_cod_localidad,
                             p_cod_prov      => dc_k_terceros.f_cod_prov);
         --
         l_nom_localidad := dc_k_a1000102.f_nom_localidad;
         --
      EXCEPTION
         --
         WHEN trn.E_NO_EXISTE
         THEN
            --
            l_nom_localidad := ' ' ;
         --
      END;
      --
      l_nom_tercero  := dc_k_v1001390.f_nom_tercero ;
      l_nom2_tercero := dc_k_v1001390.f_nom2_tercero;
      l_ape1_tercero := dc_k_v1001390.f_ape1_tercero;
      l_ape2_tercero := dc_k_v1001390.f_ape2_tercero;
      l_cod_tercero  := dc_k_v1001390.f_cod_tercero ;
      --
      l_reg_dom.nom_completo := '';
      --
      IF l_cod_tercero IS NOT NULL
      THEN
         --
         l_reg_dom.cod_tercero := l_cod_tercero;
         --
      END IF;      
      --
      IF l_nom_tercero IS NOT NULL
      THEN
         --
         l_reg_dom.nom_completo := l_nom_tercero;
         --
      END IF;
      --
      IF l_nom2_tercero IS NOT NULL
      THEN
         --
         l_reg_dom.nom_completo := TRIM ( l_reg_dom.nom_completo || ' ' || l_nom2_tercero );
         --
      END IF;
      --
      IF l_ape1_tercero IS NOT NULL
      THEN
         --
         l_reg_dom.nom_completo := TRIM ( l_reg_dom.nom_completo || ' ' || l_ape1_tercero );
         --
      END IF;
      --
      IF l_ape2_tercero IS NOT NULL
      THEN
         --
         l_reg_dom.nom_completo := TRIM ( l_reg_dom.nom_completo || ' ' || l_ape2_tercero );
         --
      END IF;
      --
      l_reg_dom.fec_nacimiento     := dc_k_terceros.f_fec_nacimiento    ;
      l_reg_dom.nom_domicilio1     := dc_k_terceros.f_nom_domicilio1    ;--1
      l_reg_dom.nom_domicilio2     := dc_k_terceros.f_nom_domicilio2    ;--2
      l_reg_dom.atr_domicilio1     := dc_k_terceros.f_atr_domicilio1    ;--3      
      l_reg_dom.nom_domicilio3     := dc_k_terceros.f_nom_domicilio3    ;--4
      l_reg_dom.cod_pais           := dc_k_terceros.f_cod_pais          ;--5
      l_reg_dom.cod_estado         := dc_k_terceros.f_cod_estado        ;--6
      l_reg_dom.cod_prov_etiqueta  := dc_k_terceros.f_cod_prov_etiqueta ;--7
      --      
      l_reg_dom.nom_domicilio1_com := dc_k_terceros.f_nom_domicilio1_com;
      l_reg_dom.nom_domicilio2_com := dc_k_terceros.f_nom_domicilio2_com;
      l_reg_dom.nom_domicilio3_com := dc_k_terceros.f_nom_domicilio3_com;
      l_reg_dom.nom_empresa_com    := dc_k_terceros.f_nom_empresa_com   ;
      l_reg_dom.atr_domicilio1_com := dc_k_terceros.f_atr_domicilio1_com;
      l_reg_dom.atr_domicilio2_com := dc_k_terceros.f_atr_domicilio2_com;
      l_reg_dom.atr_domicilio3_com := dc_k_terceros.f_atr_domicilio3_com;      
      l_reg_dom.txt_etiqueta1      := dc_k_terceros.f_txt_etiqueta1     ;
      l_reg_dom.txt_etiqueta2      := dc_k_terceros.f_txt_etiqueta2     ;
      l_reg_dom.txt_etiqueta3      := dc_k_terceros.f_txt_etiqueta3     ;
      l_reg_dom.txt_etiqueta4      := dc_k_terceros.f_txt_etiqueta4     ;
      l_reg_dom.txt_etiqueta5      := dc_k_terceros.f_txt_etiqueta5     ;
      l_reg_dom.nom_localidad      := l_nom_localidad                   ;
      l_reg_dom.nom_estado         := l_nom_estado                      ;
      l_reg_dom.nom_prov           := l_nom_prov                        ;
      l_reg_dom.cp                 := dc_k_terceros.f_cod_postal        ;
      l_reg_dom.email              := dc_k_terceros.f_email             ;
      l_reg_dom.tlf_numero         := dc_k_terceros.f_tlf_numero        ;
      l_reg_dom.tlf_movil          := dc_k_v1001390.f_tlf_movil         ;
      l_reg_dom.cod_nacionalidad   := dc_k_terceros.f_cod_nacionalidad  ;
      l_reg_dom.tip_sufijo_nombre  := dc_k_v1001390.f_tip_sufijo_nombre ;
      --
      l_reg_dom.nom_profesion      := fp_ter_nom_ocupacion(dc_k_terceros.f_cod_ocupacion);
      l_reg_dom.tip_prefijo_nombre := dc_k_v1001390.f_tip_prefijo_nombre                 ;
      l_reg_dom.ape1_tercero       := l_ape1_tercero                                     ;
      --
      --@mx('F','fp_obtiene_datos_tercero');
      --
      RETURN l_reg_dom;
      --
   END fp_obtiene_datos_tercero;
   --
   /* --------------------------------------------------------
   || fp_txt_reporte_param:
   || Formatea el texto de la tabla de objetos de reportes sustituyendo
   || los textos por el valor de las cadenas de entrada
   */ --------------------------------------------------------
   --
   FUNCTION fp_txt_reporte_param(p_contenido_objeto IN a1009012_msv.contenido_objeto%TYPE,
                                 p_cadena1          IN VARCHAR2 := NULL                  ,
                                 p_cadena2          IN VARCHAR2 := NULL                  ,
                                 p_cadena3          IN VARCHAR2 := NULL                  ,
                                 p_cadena4          IN VARCHAR2 := NULL                  )
      RETURN VARCHAR2
   IS
      --
      l_texto   CLOB;
      --
   BEGIN
      --
      --@mx('I','fp_txt_reporte_param');
      --
      l_texto := p_contenido_objeto;
      l_texto := REPLACE (l_texto, '[p_ciudad]', p_cadena1);
      l_texto := REPLACE (l_texto, '[p_dias]', p_cadena2);
      l_texto := REPLACE (l_texto, '[p_mes]', p_cadena3);
      l_texto := REPLACE (l_texto, '[p_anio]', p_cadena4);
      --
      --@mx('F','fp_txt_reporte_param');
      --
      RETURN l_texto;
      --
   END fp_txt_reporte_param;
   --
   --
   /* --------------------------------------------------------
   || fp_txt_opcion:
   || Obtiene el texto de una lista de opciones del reporte
   */ --------------------------------------------------------
   --
   FUNCTION fp_txt_opcion(p_num_secu     IN a1009012_msv.num_secu%TYPE             ,
                          p_sufijo_lista IN VARCHAR2                               ,
                          p_nom_reporte  IN g1010031.nom_valor   %TYPE DEFAULT NULL)
      RETURN a1009012_msv.contenido_objeto%TYPE
   IS
      --
      l_nom_reporte g1010031.nom_valor                          %TYPE;
      l_txt_opcion  a1009012_msv.contenido_objeto               %TYPE;
      --
      CURSOR c_a1009012_msv(c_num_secu     a1009012_msv.num_secu%TYPE,
                            c_sufijo_lista VARCHAR2                  ,
                            c_nom_reporte  g1010031.nom_valor   %TYPE) 
      IS
         SELECT a.contenido_objeto
           FROM a1009012_msv a
          WHERE a.cod_report  = UPPER(c_nom_reporte)
            AND a.num_secu    = c_num_secu
            AND a.cod_ramo    = g_jbcod_ramo
            AND a.mca_inh     = trn.NO
            AND a.fec_validez = (SELECT MAX(a1.fec_validez)
                                   FROM a1009012_msv a1
                                  WHERE a1.cod_report   = a.cod_report
                                    AND a1.num_secu     = a.num_secu
                                    AND a1.cod_ramo     = a.cod_ramo
                                    AND a1.mca_inh      = trn.NO
                                    AND a1.fec_validez <= g_k_sysdate)
       ORDER BY a.num_secu;
      --
   BEGIN
      --
      IF p_nom_reporte IS NULL
      THEN
         --
         l_nom_reporte := g_nom_reporte;
         --
      ELSE
         --
         l_nom_reporte := p_nom_reporte;
         --
      END IF;
      --
      OPEN  c_a1009012_msv(c_num_secu     => p_num_secu    ,
                           c_sufijo_lista => p_sufijo_lista,
                           c_nom_reporte  => l_nom_reporte );
      --                     
      FETCH c_a1009012_msv INTO l_txt_opcion;
      --
      CLOSE c_a1009012_msv;
      --
      RETURN l_txt_opcion;
      --
   EXCEPTION
      --
      WHEN NO_DATA_FOUND 
      THEN
         --
         l_txt_opcion := NULL;
         --
         RETURN l_txt_opcion; -- Si no se encuentra el registro, no se informa valor
         --
      --
   END fp_txt_opcion;
   --
   /* -----------------------------------------------------
   || fp_forma_pago
   || Funcion que retorna el nombre de la forma de pago
   */ -----------------------------------------------------
   --
   FUNCTION fp_forma_pago(p_cod_fracc_pago a1001402.cod_fracc_pago %TYPE)
      RETURN VARCHAR2
   IS
      --
      l_forma_pago a1001402.nom_fracc_pago %TYPE;
      --
      CURSOR c_fracc_pago
      IS
         --
         SELECT nom_fracc_pago
           FROM a1001402
          WHERE cod_fracc_pago = p_cod_fracc_pago
       ORDER BY nom_fracc_pago;
   BEGIN
      --
      --@mx('I','fp_forma_pago');
      --
      OPEN c_fracc_pago;
      --
      FETCH c_fracc_pago INTO l_forma_pago;
      CLOSE c_fracc_pago;
      --
      --@mx('F','fp_forma_pago');
      --
      RETURN l_forma_pago;
      --
   END fp_forma_pago;
   --
   /* --------------------------------------------------------
   || fp_txt_reporte:
   || Obtiene un texto de la tabla de objetos de reportes
   */ --------------------------------------------------------
   --
   FUNCTION fp_txt_reporte(p_num_secu IN  a1009012_msv.num_secu%TYPE)
      RETURN a1009012_msv.contenido_objeto%TYPE
   IS
      --
      l_reg_txt_reporte reg_txt_reporte;
      --
   BEGIN
      --
      --@mx('I','fp_txt_reporte');
      --
      FOR l_cont_lvl1 IN g_tbl_txt_reporte.FIRST .. g_tbl_txt_reporte.LAST
      LOOP
         --
         IF g_tbl_txt_reporte(l_cont_lvl1).num_secu = p_num_secu
         THEN
            --
            l_reg_txt_reporte := g_tbl_txt_reporte(l_cont_lvl1);
            EXIT;
            --
         END IF;
         --
      END LOOP;
      --
      --@mx('F','fp_txt_reporte');
      --
      RETURN l_reg_txt_reporte.contenido_objeto;
      --
   END fp_txt_reporte;
   --
   /* --------------------------------------------------------
   || fp_es_spto_tmp:
   || es suplemento temporal
   */ --------------------------------------------------------
   --
   FUNCTION fp_es_spto_tmp(p_cod_cia       IN a2000030.cod_cia       %TYPE ,
                           p_num_poliza    IN a2000030.num_poliza    %TYPE ,
                           p_num_spto      IN a2000030.num_spto      %TYPE ,
                           p_num_apli      IN a2000030.num_apli      %TYPE ,
                           p_num_spto_apli IN a2000030.num_spto_apli %TYPE )
      RETURN BOOLEAN
   IS
      --
      l_mca_spto_tmp a2000030.mca_spto_tmp %TYPE;
      --
      l_resultado BOOLEAN;
      --
   BEGIN
      --
      --@mx('I','fp_es_spto_tmp');
      --
      em_k_a2000030.p_lee(p_cod_cia       => p_cod_cia      ,
                          p_num_poliza    => p_num_poliza   ,
                          p_num_spto      => p_num_spto     ,
                          p_num_apli      => p_num_apli     ,
                          p_num_spto_apli => p_num_spto_apli);
      --
      l_mca_spto_tmp := em_k_a2000030.f_mca_spto_tmp;
      --
      l_resultado := l_mca_spto_tmp = trn.SI;
      --
      --@mx('F','fp_es_spto_tmp');
      --
      RETURN l_resultado;
      --
   EXCEPTION
      --
      WHEN OTHERS
      THEN
         --
         RETURN FALSE;
      --
   END fp_es_spto_tmp;
   --
   /* --------------------------------------------------------
   || fp_abre_riesgos:
   || consulta datos del riesgo
   */ --------------------------------------------------------
   --
   FUNCTION fp_abre_riesgos(p_mca_tabla_p IN VARCHAR2 := trn.NO ,
                            p_mca_tabla_r IN VARCHAR2 := trn.NO ,
                            p_num_riesgo  IN a2000031.num_riesgo%TYPE := NULL )
      RETURN CV_RESULTS
   IS
      --
      l_txt_query CLOB;
      --
      l_cv_riesgos  CV_RESULTS;
      --
      PROCEDURE pi_ad_txt_query(p_txt_query VARCHAR2)
      IS
      --
      BEGIN
         --
         l_txt_query := l_txt_query || p_txt_query;
         --
      END pi_ad_txt_query;
      --
   BEGIN
      --
      --@mx('I','fp_abre_riesgos');
      --
      IF    g_jbtip_scope = G_K_SCOPE_FOTO
         OR g_quotation
         OR g_pre_renewal
      THEN
         --
         l_txt_query := ' SELECT a.num_riesgo, '         ;
         l_txt_query := l_txt_query || ' a.nom_riesgo,'  ;
         l_txt_query := l_txt_query || ' b.tip_docum ,'  ;
         l_txt_query := l_txt_query || ' b.cod_docum ,'  ;
         l_txt_query := l_txt_query || ' a.cod_modalidad';
         --
         IF p_mca_tabla_p IN (g_k_yes, trn.SI)
         THEN
            --
            l_txt_query := l_txt_query || ' FROM p2000031 a,';
            l_txt_query := l_txt_query || ' p2000060 b';
            --
         ELSIF p_mca_tabla_r IN (g_k_yes, trn.SI)
         THEN
            --
            l_txt_query := l_txt_query || ' FROM r2000031 a,';
            l_txt_query := l_txt_query || ' a2000060 b'      ; -- Tabla A en lugar de R
            --
         ELSE
            --
            l_txt_query := l_txt_query || ' FROM a2000031 a,';
            l_txt_query := l_txt_query || ' a2000060 b'      ;
            --
         END IF;
         --
         l_txt_query := l_txt_query || '  WHERE a.cod_cia      = ' || g_cod_cia             ;
         l_txt_query := l_txt_query || ' AND a.num_poliza      = ''' || g_num_poliza || '''';
         l_txt_query := l_txt_query || ' AND a.mca_vigente     = ' || '''' || trn.SI ||'''' ;
         l_txt_query := l_txt_query || ' AND a.mca_baja_riesgo = ' || '''' || trn.NO ||'''' ;
         l_txt_query := l_txt_query || ' AND b.cod_cia         = a.cod_cia'                 ;
         l_txt_query := l_txt_query || ' AND b.num_poliza      = a.num_poliza'              ;
         --
         IF p_num_riesgo IS NOT NULL
         THEN
            --
            l_txt_query := l_txt_query || ' AND b.num_riesgo   = ' || p_num_riesgo;
            --
         END IF;
         --
         l_txt_query := l_txt_query || ' AND b.num_riesgo      = a.num_riesgo '            ;
         l_txt_query := l_txt_query || ' AND b.mca_baja        = ' || '''' || trn.NO ||'''';
         l_txt_query := l_txt_query || ' AND b.mca_vigente     = ' || '''' || trn.SI ||'''';
         --
         IF g_jbtip_docum_aseg IS NOT NULL
         THEN
            --
            l_txt_query := l_txt_query || ' AND b.tip_docum  = ''' || g_jbtip_docum_aseg || '''';
            --
         END IF;
         --
         IF g_jbcod_docum_aseg IS NOT NULL
         THEN
            --
            l_txt_query := l_txt_query || ' AND b.cod_docum  = ''' || g_jbcod_docum_aseg || '''';
            --
         END IF;
         --
         l_txt_query := l_txt_query || ' AND b.tip_benef = ''' || em.TIP_BENEF_ASEGURADO || '''';
         --
         pi_ad_txt_query(' ORDER BY a.num_riesgo ASC, '  ||
                                  ' b.mca_principal DESC');
         --
      ELSE
         --
         l_txt_query :=
         ' SELECT x.num_riesgo, x.nom_riesgo, z.tip_docum, z.cod_docum, x.cod_modalidad ' ||
          ' FROM a2000031 x, -- Todos los riesgos.
                  a2000060 z, -- Terceros de la p????????????????????A?liza.
                  ( SELECT a.num_riesgo        ,
                           a.tip_spto          ,
                           a.mca_baja_riesgo   ,
                           a.fec_efec_riesgo   ,
                           a.num_spto ' ||
                     ' FROM (-- Seleccion de riesgos en alta
                            SELECT MAX(a.num_spto) num_spto ,
                                   MAX(a.tip_spto) tip_spto ,
                                   a.num_riesgo             ,
                                   a.mca_baja_riesgo        ,
                                   MAX(a.fec_efec_riesgo) fec_efec_riesgo ,
                                   a.cod_cia
                              FROM a2000031 a, a2000030 b
                             WHERE a.cod_cia         = ' || g_cod_cia ||
                             ' AND a.num_poliza      = ''' || g_num_poliza || '''' ||
                             ' AND a.num_apli        = ' || g_num_apli ||
                             ' AND a.num_spto_apli   = ' || g_num_spto_apli ||
                             ' AND a.mca_baja_riesgo = ' || '''' || trn.NO ||'''' ||
                             ' AND a.num_spto  <= ' || g_num_spto ||
                             ' AND b.cod_cia        = a.cod_cia ' ||
                             ' AND b.num_poliza     = a.num_poliza ' ||
                             ' AND b.num_spto       = a.num_spto ' ||
                             ' AND b.num_apli       = a.num_apli ' ||
                             ' AND b.num_spto_apli  = a.num_spto_apli ' ||
                             ' AND b.mca_spto_anulado = ' || '''' || trn.NO ||'''' ||
                            ' GROUP BY a.num_riesgo      ,
                                       a.mca_baja_riesgo ,
                                       a.cod_cia
                           ) a ' ||
                    ' WHERE a.num_riesgo NOT IN (-- Riesgos dados de baja
                         SELECT a.num_riesgo
                           FROM a2000031 a,
                               (
                                SELECT t.num_riesgo, ' ||
                                     ' MAX(t.num_spto) num_spto ' ||
                                ' FROM a2000031 t, a2000030 w ' ||
                               ' WHERE t.cod_cia       = ' || g_cod_cia ||
                                 ' AND t.num_poliza    = ''' || g_num_poliza || '''' ||
                                 ' AND t.num_spto     <= ' || g_num_spto ||
                                 ' AND t.num_apli      = ' || g_num_apli ||
                                 ' AND t.num_spto_apli = ' || g_num_spto_apli ||
                                 ' AND w.cod_cia = t.cod_cia ' ||
                                 ' AND w.num_poliza = t.num_poliza ' ||
                                 ' AND w.num_spto = t.num_spto ' ||
                                 ' AND w.num_apli = t.num_apli ' ||
                                 ' AND w.num_spto_apli = t.num_spto_apli ' ||
                                 ' AND w.mca_spto_anulado = ' || '''' || trn.NO ||'''' ||
                               ' GROUP BY t.num_riesgo
                              ) b ' ||
                        ' WHERE a.cod_cia         = ' || g_cod_cia ||
                          ' AND a.num_poliza      = ''' || g_num_poliza || '''' ||
                          ' AND a.num_spto        = b.num_spto ' ||
                          ' AND a.num_apli        = ' || g_num_apli ||
                          ' AND a.num_spto_apli   = ' || g_num_spto_apli ||
                          ' AND a.num_riesgo      = b.num_riesgo
                           AND ( a.mca_baja_riesgo IN ( ''S'', ''Y'' )
                                 OR a.tip_spto IN (''AT'')
                           )
                  )
                       AND a.num_spto <= ' || g_num_spto ||
                       ' ) y -- Riesgos que sn dados de alta.
            WHERE x.cod_cia         = ' || g_cod_cia ||
              ' AND x.num_poliza      = ''' || g_num_poliza || '''' ||
              ' AND x.num_apli        = ' || g_num_apli ||
              ' AND x.num_spto_apli   = ' || g_num_spto_apli ||
              ' AND x.num_riesgo      = y.num_riesgo ' ||
              ' AND x.num_spto        = y.num_spto ' ||
              ' AND z.cod_cia         = x.cod_cia ' ||
              ' AND z.num_poliza      = x.num_poliza ' ||
              ' AND z.num_spto        =
                 ( SELECT MAX(t.num_spto)
                     FROM a2000060 t
                    WHERE t.cod_cia       = z.cod_cia
                      AND t.num_poliza    = z.num_poliza
                      AND t.num_apli      = z.num_apli
                      AND t.num_spto_apli = z.num_spto_apli
                      AND t.num_riesgo    = z.num_riesgo
                      AND t.tip_benef     = z.tip_benef
                      AND t.tip_docum     = z.tip_docum
                      AND t.cod_docum     = z.cod_docum
                      AND t.num_spto     <= ' || g_num_spto ||
                  ' )
              AND z.num_riesgo      = x.num_riesgo
              AND z.mca_principal   = '   || '''' || trn.NO ||'''
              AND z.tip_benef       = ''' || em.TIP_BENEF_ASEGURADO || '''';
              --
         IF g_jbtip_docum_aseg IS NOT NULL
         THEN
            --
            l_txt_query := l_txt_query || ' AND z.tip_docum  = ' || g_jbtip_docum_aseg;
            --
         END IF;
         --
         IF g_jbcod_docum_aseg IS NOT NULL
         THEN
            --
            l_txt_query := l_txt_query || ' AND z.cod_docum = ' || g_jbcod_docum_aseg;
            --
         END IF;
         --
         IF p_num_riesgo IS NOT NULL
         THEN
            --
            l_txt_query := l_txt_query || ' AND x.num_riesgo      = ' || p_num_riesgo;
            --
         END IF;
         --
         l_txt_query := l_txt_query || ' AND z.mca_baja        = ' || '''' || trn.NO ||'''';
         l_txt_query := l_txt_query || ' ORDER BY x.num_riesgo ASC, ';
         l_txt_query := l_txt_query || ' z.mca_principal DESC';
         --
      END IF;
      --
      OPEN l_cv_riesgos FOR l_txt_query;
      --
      --@mx('F','fp_abre_riesgos');
      --
      RETURN l_cv_riesgos;
      --
   END fp_abre_riesgos;
   --
   /* --------------------------------------------------------
   || fp_abre_query:
   || consulta deatos de la p0liza
   */ --------------------------------------------------------
   --
   FUNCTION fp_abre_query(p_qry_adic    IN VARCHAR2 := NULL                       ,
                          p_mca_tabla_p IN VARCHAR2 := trn.NO                     ,
                          p_mca_tabla_r IN VARCHAR2 := trn.NO                     ,
                          p_cod_ramo    IN a2000030.cod_ramo %TYPE := g_k_cod_ramo,
                          p_num_poliza  IN a2000030.num_poliza %TYPE := NULL      ,
                          p_tuition     IN BOOLEAN := FALSE)
      RETURN CV_RESULTS
   IS
      --
      l_txt_query         CLOB;
      --
      l_cv_a2000030       CV_RESULTS;
      --
      PROCEDURE pi_ad_txt_query(p_txt_query VARCHAR2)
      IS
      --
      BEGIN
         --
         l_txt_query := l_txt_query || p_txt_query;
         --
      END pi_ad_txt_query;
      --
   BEGIN
      --
      --@mx('I','fp_abre_query');
      --
      l_txt_query := ' SELECT ' ||
      'cod_cia, '               ||
      'cod_sector, '            ||
      'cod_ramo, '              ||
      'num_poliza, '            ||
      'num_spto, '              ||
      'num_apli, '              ||
      'num_spto_apli, '         ||
      'fec_validez, '           ||
      'fec_emision, '           ||
      'fec_efec_poliza, '       ||
      'fec_vcto_poliza, '       ||
      'fec_efec_spto, '         ||
      'fec_vcto_spto, '         ||
      'num_poliza_cliente, '    ||
      'num_contrato, '          ||
      'num_poliza_grupo, '      ||
      'cod_spto, '              ||
      'sub_cod_spto, '          ||
      'tip_spto, '              ||
      'tip_docum, '             ||
      'cod_docum, '             ||
      'cod_mon,'                ||
      'cod_fracc_pago,'         ||
      'tip_gestor,'             ||
      'cod_agt, '               ||
      'cod_nivel1, '            ||
      'cod_nivel2, '            ||
      'cod_nivel3, '            ||
      'mca_impresion, '         ||
      'cod_usr, '               ||
      'fec_actu, '              ||
      'hora_desde, '            ||
      'num_subcontrato, '       ||
      'fec_vcto_spto_publico, ' ||
      'num_spto_grp, '          ||
      'tip_coaseguro, '         ||
      'cod_ejecutivo, '         ||
      'num_riesgos'              ;
      --
      IF p_mca_tabla_p IN (g_k_yes, trn.SI)
      THEN
         --
         l_txt_query := l_txt_query || '   FROM p2000030 a ';
         --
      ELSIF p_mca_tabla_r IN (g_k_yes, trn.SI)
      THEN
         --
         l_txt_query := l_txt_query || '   FROM r2000030 a ';
         --
      ELSE
         --
         l_txt_query := l_txt_query || '   FROM a2000030 a ';
         --
      END IF;
      --
      l_txt_query := l_txt_query || '  WHERE a.cod_cia = ' || g_cod_cia;
      --
      IF p_cod_ramo IS NOT NULL
      THEN
         --
         pi_ad_txt_query(' AND a.cod_ramo = ' || p_cod_ramo);
         --
      END IF;
      --
      IF p_num_poliza IS NOT NULL
      THEN
         --
         pi_ad_txt_query(' AND a.num_poliza = ''' || p_num_poliza || '''');
         --
      ELSIF g_jbnum_poliza IS NOT NULL
      THEN
         --
         pi_ad_txt_query(' AND a.num_poliza = ''' || g_jbnum_poliza || '''');
         --
      END IF;
      --
      IF     ( p_num_poliza IS NOT NULL OR g_jbnum_poliza IS NOT NULL )
         AND ( g_jbnum_spto  IS NOT NULL )
         AND ( g_jbtip_scope = g_k_scope_spto )
      THEN
         --
         g_usa_spto_temporal := fp_es_spto_tmp(p_cod_cia       => g_cod_cia                        ,
                                               p_num_poliza    => NVL(g_jbnum_poliza, p_num_poliza),
                                               p_num_spto      => g_jbnum_spto                     ,
                                               p_num_apli      => g_num_apli                       ,
                                               p_num_spto_apli => g_num_spto_apli                  );
         --
      ELSE
         --
         g_usa_spto_temporal := FALSE;
         --
      END IF;
      --
      IF p_mca_tabla_p IN (g_k_yes, trn.SI)
      THEN
         -- Tabla p
         pi_ad_txt_query( ' AND a.num_spto = (SELECT MAX(a1.num_spto) '                         ||
                                                          '  FROM p2000030 a1      '            ||
                                                          ' WHERE a1.cod_cia    = a.cod_cia '   ||
                                                          '   AND a1.num_poliza = a.num_poliza '||
                                                          '   AND a1.num_apli   = 0 '           ||
                                                          '   AND a1.num_spto_apli = 0 '        ||
                                                          '   AND a1.mca_spto_tmp = ''N'''      ||
                                                          '   AND a1.mca_spto_anulado = ''N'')');
         --
      ELSIF p_mca_tabla_r IN (g_k_yes, trn.SI)
      THEN
         -- Tabla r
         IF    g_fec_tratamiento IS NOT NULL
            OR g_num_orden IS NOT NULL
         THEN
            --
            pi_ad_txt_query( ' AND a.num_poliza IN ( SELECT a2.num_poliza ' );
            pi_ad_txt_query( ' FROM a2000500 a2 ' );
            pi_ad_txt_query( ' WHERE a2.cod_cia = a.cod_cia ' );
            pi_ad_txt_query( ' AND a2.cod_ramo = a.cod_ramo ' );
            pi_ad_txt_query( ' AND a2.mca_pre_renovacion = ''S'' ' );
            pi_ad_txt_query( ' AND a2.fec_tratamiento = TO_DATE( NVL(''' || TO_CHAR(g_fec_tratamiento, g_k_formato_fec_xml) ||''', TO_CHAR(a2.fec_tratamiento,''' || g_k_formato_fec_xml || ''') ), ''' || g_k_formato_fec_xml || ''' ) ' );
            pi_ad_txt_query( ' AND a2.num_orden       = NVL(' || g_num_orden || ', a2.num_orden) ' );
            pi_ad_txt_query( ' AND a2.mca_pre_renovacion = ''S'' ' );
            pi_ad_txt_query( ' AND a2.tip_situ IN(' || dc.SITU_TERMINACION_NORMAL || ', ' || dc.SITU_RETENIDA_POR_CT || ' ) ' );
            pi_ad_txt_query( ' AND a2.tip_mvto_batch  = NVL(' || g_tip_mvto_batch || ', a2.tip_mvto_batch) ' );
            pi_ad_txt_query( ' ) ' );
            --
         END IF;
         --
      ELSIF p_tuition
      THEN
         --
         pi_ad_txt_query( ' AND a.num_spto = (SELECT MAX(a1.num_spto) '                                  ||
                                                             '  FROM a2000030 a1      '                  ||
                                                             ' WHERE a1.cod_cia    = a.cod_cia '         ||
                                                             '   AND a1.num_poliza = a.num_poliza '      ||
                                                             '   AND a1.num_apli   = 0 '                 ||
                                                             '   AND a1.num_spto_apli = 0 '              ||
                                                             '   AND a1.mca_spto_tmp IN ( ''S'', ''Y'')' ||
                                                             '   AND a1.mca_spto_anulado = ''N'')'        );
         --
      ELSIF g_usa_spto_temporal
      THEN
         --
         pi_ad_txt_query( ' AND a.num_spto = (SELECT MAX(a1.num_spto) '                            ||
                                                             '  FROM a2000030 a1 '                 ||
                                                             ' WHERE a1.cod_cia    = a.cod_cia '   ||
                                                             '   AND a1.num_poliza = a.num_poliza '||
                                                             '   AND a1.num_apli   = 0 '           ||
                                                             '   AND a1.num_spto_apli = 0 '        ||
                                                             '   AND a1.mca_spto_anulado = ''N'')'  );
         --
      ELSE
         -- Tabla A
         IF    g_jbnum_spto  IS NULL
            OR g_jbtip_scope  = G_K_SCOPE_FOTO
         THEN
            --
            pi_ad_txt_query( ' AND a.num_spto = (SELECT MAX(a1.num_spto) '                         ||
                                                             '  FROM a2000030 a1 '                 ||
                                                             ' WHERE a1.cod_cia    = a.cod_cia '   ||
                                                             '   AND a1.num_poliza = a.num_poliza '||
                                                             '   AND a1.num_apli   = 0 '           ||
                                                             '   AND a1.num_spto_apli = 0 '        ||
                                                             '   AND a1.mca_spto_tmp = ''N'' '     ||
                                                             '   AND a1.mca_spto_anulado = ''N'')' );
            --
         ELSIF g_jbnum_spto IS NOT NULL
         THEN
            --
            pi_ad_txt_query( ' AND a.num_spto = (SELECT MAX(a1.num_spto) '                             ||
                                                             '  FROM a2000030 a1      '                ||
                                                             ' WHERE a1.cod_cia    = a.cod_cia '       ||
                                                             '   AND a1.num_poliza = a.num_poliza '    ||
                                                             '   AND a1.num_spto  <= ' || g_jbnum_spto ||
                                                             '   AND a1.num_apli   = 0 '               ||
                                                             '   AND a1.num_spto_apli = 0 '            ||
                                                             '   AND a1.mca_spto_tmp = ''N'''          ||
                                                             '   AND a1.mca_spto_anulado = ''N'')'      );
            --
         END IF;
         --
      END IF;
      --
      IF     g_jbtip_docum_hdr IS NOT NULL
         AND LENGTH(TRIM(g_jbtip_docum_hdr)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND a.tip_docum = '''  || g_jbtip_docum_hdr || '''');
         --
      END IF;
      --
      IF     g_jbcod_docum_hdr IS NOT NULL
         AND LENGTH(TRIM(g_jbcod_docum_hdr)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND a.cod_docum = ''' || g_jbcod_docum_hdr || '''');
         --
      END IF;
      --
      IF     g_jbnum_poliza_grupo IS NOT NULL
         AND LENGTH(TRIM(g_jbnum_poliza_grupo)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND NVL(a.num_poliza_grupo,''gen'') = ''' || g_jbnum_poliza_grupo || '''');
         --
         pi_ad_txt_query(' AND a.mca_poliza_anulada =  ''N''');
         --
      END IF;
      --
      IF     g_jbnum_contrato IS NOT NULL
         AND LENGTH(TRIM(g_jbnum_contrato)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND NVL(a.num_contrato,-1) = ' || g_jbnum_contrato);
         --
      END IF;
      --
      IF     g_jbnum_spto_grp IS NOT NULL
         AND g_jbnum_spto_grp NOT IN (trn.cero)
         AND LENGTH(TRIM(g_jbnum_spto_grp)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND NVL(a.num_spto_grp,-1) = ' || g_jbnum_spto_grp);
         --
      END IF;
      --
      IF     g_jbcod_nivel1 IS NOT NULL
         AND LENGTH(TRIM(g_jbcod_nivel1)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND a.cod_nivel1 = ' || g_jbcod_nivel1);
         --
      END IF;
      --
      IF     g_jbcod_nivel2 IS NOT NULL
         AND LENGTH(TRIM(g_jbcod_nivel2)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND a.cod_nivel2 = ' || g_jbcod_nivel2);
         --
      END IF;
      --
      IF     g_jbcod_nivel3 IS NOT NULL
         AND LENGTH(TRIM(g_jbcod_nivel3)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND a.cod_nivel3 = ' || g_jbcod_nivel3);
         --
      END IF;
      --
      IF     g_jbcod_agt IS NOT NULL
         AND LENGTH(TRIM(g_jbcod_agt)) > trn.CERO
      THEN
         --
         pi_ad_txt_query(' AND a.cod_agt = ' || g_jbcod_agt);
         --
      END IF;
      --
      pi_ad_txt_query( p_qry_adic);
      --
      IF g_cod_proceso = trn.BLANCO
      THEN
         --
         pi_ad_txt_query(' AND a.mca_provisional = ''N''');
         --
      END IF;
      --
      pi_ad_txt_query(' ORDER BY a.cod_nivel1,'||
                     ' a.cod_nivel2,'          ||
                     ' a.cod_nivel3,'          ||
                     ' a.cod_agt,'             ||
                     ' a.cod_ramo,'            ||
                     ' a.num_poliza_grupo,'    ||
                     ' a.num_contrato,'        ||
                     ' a.num_poliza,'          ||
                     ' a.num_spto'              );
      --
      OPEN l_cv_a2000030 FOR l_txt_query;
      --
      --@mx('F','fp_abre_query');
      --
      RETURN l_cv_a2000030;
      --
   END fp_abre_query;
   --
   /* --------------------------------------------------------
   || fp_devuelve_aseg_principal:
   || Obtiene el asegurado principal de una p0liza y devuelve
   || un registro del tipo a2000060
   */ --------------------------------------------------------
   --
   FUNCTION fp_devuelve_aseg_principal(p_cod_cia       IN a2000060.cod_cia       %TYPE ,
                                       p_num_poliza    IN a2000060.num_poliza    %TYPE ,
                                       p_num_apli      IN a2000060.num_apli      %TYPE ,
                                       p_num_spto_apli IN a2000060.num_spto_apli %TYPE ,
                                       p_num_riesgo    IN a2000060.num_riesgo    %TYPE ,
                                       p_tip_benef     IN a2000060.tip_benef     %TYPE ,
                                       p_num_spto      IN a2000060.num_spto      %TYPE )
      RETURN a2000060 %ROWTYPE
   IS
      --
      CURSOR lc_a2000060
      IS
         --
         SELECT a.*
           FROM a2000060 a
          WHERE a.cod_cia       = p_cod_cia
            AND a.num_poliza    = p_num_poliza
            AND a.num_apli      = p_num_apli
            AND a.num_spto_apli = p_num_spto_apli
            AND a.num_riesgo    = p_num_riesgo
            AND a.tip_benef     = p_tip_benef
            AND a.mca_baja      = trn.no
            AND a.mca_principal IN (g_k_yes, trn.SI)
            AND a.num_spto      = ( SELECT MAX(b.num_spto)
                                      FROM a2000060 b
                                     WHERE b.cod_cia       = a.cod_cia
                                       AND b.num_poliza    = a.num_poliza
                                       AND b.num_apli      = a.num_apli
                                       AND b.num_spto_apli = a.num_spto_apli
                                       AND b.num_riesgo    = a.num_riesgo
                                       AND b.tip_benef     = a.tip_benef
                                       AND b.mca_baja      = trn.NO
                                       AND a.mca_principal IN (g_k_yes, trn.SI)
                                       AND b.num_spto     <= p_num_spto )
          ORDER BY TO_NUMBER( a.num_secu ) DESC,
                   a.tip_docum ASC             ,
                   a.cod_docum ASC             ;
      --
      l_reg_a2000060 a2000060 %ROWTYPE;
      --
   BEGIN
      --
      --@mx('I','fp_devuelve_aseg_principal');
      --
      IF lc_a2000060 %ISOPEN
      THEN
         --
         CLOSE lc_a2000060;
         --
      END IF;
      --
      OPEN lc_a2000060;
      --
      FETCH lc_a2000060 INTO l_reg_a2000060;
      CLOSE lc_a2000060;
      --
      --@mx('F','fp_devuelve_aseg_principal');
      --
      RETURN l_reg_a2000060;
      --
   END fp_devuelve_aseg_principal;
   --
   /* -------------------------------------------------------------------
   || fp_cober_incluida:
   || Devuelve TRUE si para el suplemento considerado existe la cobertura
   || en la p0liza. FALSE en otras situaciones.
   */ -------------------------------------------------------------------
   --
   FUNCTION fp_cober_incluida(p_cod_cia       IN a2000040.cod_cia       %TYPE,
                              p_num_poliza    IN a2000040.num_poliza    %TYPE,
                              p_num_spto      IN a2000040.num_spto      %TYPE,
                              p_num_apli      IN a2000040.num_apli      %TYPE,
                              p_num_spto_apli IN a2000040.num_spto_apli %TYPE,
                              p_num_riesgo    IN a2000040.num_riesgo    %TYPE,
                              p_num_periodo   IN a2000040.num_periodo   %TYPE,
                              p_cod_cob       IN a2000040.cod_cob       %TYPE)
      RETURN BOOLEAN
   IS
      --
      l_txt_query CLOB   ;
      lc_cover cv_results;
      --
      l_resultado NUMBER   ;
      --
   BEGIN
      --
      --@mx('I','fp_cober_incluida');
      --
      l_txt_query := ' SELECT COUNT(1) AS cantidad ';
      --
      IF g_quotation
      THEN
         --
         l_txt_query := l_txt_query || ' FROM p2000040 a ';
         --
      ELSE
         --
         l_txt_query := l_txt_query || ' FROM a2000040 a ';
         --
      END IF;
      --
      l_txt_query := l_txt_query || ' WHERE a.cod_cia     = ' || p_cod_cia;
      l_txt_query := l_txt_query || ' AND a.num_poliza    = ' || '''' || p_num_poliza || '''';
      l_txt_query := l_txt_query || ' AND a.num_spto      IN ( ';
      --
      l_txt_query := l_txt_query || ' SELECT MAX(b.num_spto) ';
      --
      IF g_quotation
      THEN
         --
         l_txt_query := l_txt_query || ' FROM p2000040 b ';
         --
      ELSE
         --
         l_txt_query := l_txt_query || ' FROM a2000040 b ';
         --
      END IF;
      --
      l_txt_query := l_txt_query || ' WHERE b.cod_cia        = a.cod_cia '           ;
      l_txt_query := l_txt_query || ' AND b.num_poliza     = a.num_poliza '          ;
      l_txt_query := l_txt_query || ' AND b.num_spto_apli  = a.num_spto_apli '       ;
      l_txt_query := l_txt_query || ' AND b.num_riesgo     = a.num_riesgo '          ;
      l_txt_query := l_txt_query || ' AND b.num_periodo    = a.num_periodo '         ;
      l_txt_query := l_txt_query || ' AND b.num_spto      <= ' || p_num_spto || ' ) ';
      --
      l_txt_query := l_txt_query || ' AND a.num_apli      = ' || p_num_apli               ;
      l_txt_query := l_txt_query || ' AND a.num_spto_apli = ' || p_num_spto_apli          ;
      l_txt_query := l_txt_query || ' AND a.num_riesgo    = ' || p_num_riesgo             ;
      l_txt_query := l_txt_query || ' AND a.num_periodo   = ' || p_num_periodo            ;
      l_txt_query := l_txt_query || ' AND a.cod_cob       = ' || '''' || p_cod_cob || '''';
      --
      IF lc_cover %ISOPEN
      THEN
         --
         CLOSE lc_cover;
         --
      END IF;
      --
      OPEN lc_cover FOR l_txt_query;
      --
      FETCH lc_cover INTO l_resultado;
      CLOSE lc_cover;
      --
      --@mx('F','fp_cober_incluida');
      --
      RETURN l_resultado > trn.cero;
      --
   END fp_cober_incluida;
   --
   /* -------------------- DESCRIPCION --------------------
   || Funcion que retorna nombre del departamento del
   || asegurado
   */ -----------------------------------------------------
   --
   FUNCTION fp_nom_departamento(p_cod_estado a1000104.cod_estado %TYPE)
      RETURN VARCHAR2
   IS
      --
      l_nom_dep a1000104.nom_estado %TYPE;
      --
      CURSOR c_nom_depto
      IS
         --
         SELECT nom_estado
           FROM a1000104
          WHERE cod_estado = p_cod_estado
       ORDER BY nom_estado;
   BEGIN
      --
      --@mx('I','fp_nom_departamento');
      --
      OPEN c_nom_depto;
      --
      FETCH c_nom_depto INTO l_nom_dep;
      CLOSE c_nom_depto;
      --
      --@mx('F','fp_nom_departamento');
      --
      RETURN l_nom_dep;
      --
   END fp_nom_departamento;
   --
   /* -------------------- DESCRIPCION --------------------
   || Funcion que retorna el nombre del municipio del
   || asegurado
   */ -----------------------------------------------------
   --
   FUNCTION fp_nom_municipio(p_cod_prov a1000100.cod_prov %TYPE)
      RETURN VARCHAR2
   IS
      --
      l_nom_mun a1000100.nom_prov %TYPE;
      --
      CURSOR c_nom_municipio
      IS
         --
         SELECT nom_prov
           FROM a1000100
          WHERE cod_prov = p_cod_prov
       ORDER BY nom_prov;
       --
   BEGIN
      --
      --@mx('I','fp_nom_municipio');
      --
      OPEN c_nom_municipio;
      --
      FETCH c_nom_municipio INTO l_nom_mun;
      CLOSE c_nom_municipio;
      --
      --@mx('F','fp_nom_municipio');
      --
      RETURN l_nom_mun;
      --
   END fp_nom_municipio;
   --
   /* -------------------- DESCRIPCION --------------------
   || Funcion que retorna el nombre de la localidad del
   || asegurado
   */ -----------------------------------------------------
   --
   FUNCTION fp_nom_localidad(p_cod_localidad a1000102.cod_localidad %TYPE)
      RETURN VARCHAR2
   IS
      --
      l_nom_localidad a1000102.nom_localidad %TYPE;
      --
      CURSOR c_nom_localidad
      IS
         --
         SELECT nom_localidad
           FROM a1000102
          WHERE cod_localidad = p_cod_localidad
       ORDER BY nom_localidad;
   BEGIN
      --
      --@mx('I','fp_nom_localidad');
      --
      OPEN c_nom_localidad;
      --
      FETCH c_nom_localidad INTO l_nom_localidad;
      CLOSE c_nom_localidad;
      --
      --@mx('F','fp_nom_localidad');
      --
      RETURN l_nom_localidad;
      --
   END fp_nom_localidad;
   --
   /* --------------------------------------------------------
   || fp_val_renovacion:
   || Valida si es la poliza es renovada
   */ --------------------------------------------------------
   --
   FUNCTION fp_val_renovacion
      RETURN BOOLEAN
   IS
      --
      CURSOR lc_2000020
      IS
         --
         SELECT a.val_campo
           FROM a2000020 a
          WHERE a.cod_cia    = g_cod_cia
            AND a.num_poliza = g_num_poliza
            AND a.cod_campo  = g_k_num_pol_anterior
            AND a.num_spto   = (SELECT MAX(b.num_spto)
                                  FROM a2000020 b
                                 WHERE b.cod_cia     = a.cod_cia
                                   AND b.num_poliza  = a.num_poliza
                                   AND b.cod_campo   = a.cod_campo
                                   AND b.num_spto   <= g_num_spto)
          ORDER BY a.val_campo;
      --
      CURSOR lc_2000030
      IS
         --
         SELECT a.num_poliza
           FROM a2000030 a
          WHERE a.cod_cia     = g_cod_cia
            AND a.num_poliza  = g_num_poliza
            AND a.tip_spto    = em.RENOVACION
            AND a.num_spto   <= g_num_spto
          ORDER BY a.num_poliza;
      --
      l_val_campo  a2000020.val_campo %TYPE;
      l_num_poliza a2000030.num_poliza%TYPE;
      --
      l_renovacion BOOLEAN := FALSE;
      --
   BEGIN
      --
      --@mx('I','fp_val_renovacion');
      --
      OPEN lc_2000020;
      --
      FETCH lc_2000020 INTO l_val_campo;
      --
      CLOSE lc_2000020;
      --
      IF     l_val_campo IS NOT NULL
         AND l_val_campo <> trn.CERO
      THEN
         --
         l_renovacion := TRUE;
         --
      ELSE
         --
         OPEN lc_2000030;
         --
         FETCH lc_2000030 INTO l_num_poliza;
         --
         l_renovacion := lc_2000030%FOUND;
         --
         CLOSE lc_2000030;
         --
      END IF;
      --
      --@mx('F','fp_val_renovacion');
      --
      RETURN l_renovacion;
      --
      EXCEPTION
         --
         WHEN OTHERS
         THEN
            --
            RETURN FALSE;
            --
      --
   END fp_val_renovacion;
   --
   /* --------------------------------------------------------
   || fp_dev_cod_clau:
   || devuelve codigo de clausula
   */ --------------------------------------------------------
   --   
   FUNCTION fp_dev_cod_clau(p_cod_cob a2000040.cod_cob%TYPE)
      RETURN g2999003_msv.txt_valor_maximo%TYPE
   IS
      --
      l_txt_valor_maximo g2999003_msv.txt_valor_maximo%TYPE;
      --
      CURSOR l_c_g2999003_msv
      IS
         --
         SELECT a.txt_valor_maximo
           FROM g2999003_msv a
          WHERE a.cod_cia         = g_cod_cia
            AND a.cod_ramo        = g_cod_ramo
            AND a.nom_nemotecnico = g_k_nom_nemotecnico
            AND a.cod_campo       = g_k_cod_clausulas
            AND a.cod_cob         = p_cod_cob;
      --
   BEGIN
      --
      OPEN  l_c_g2999003_msv;
      FETCH l_c_g2999003_msv INTO l_txt_valor_maximo;
      CLOSE l_c_g2999003_msv;
      --
      RETURN l_txt_valor_maximo;
      --
   EXCEPTION 
      WHEN OTHERS
      THEN 
         --
         RETURN NULL; 
      --
   END fp_dev_cod_clau;    
   /* --------------------------------------------------------
   || fp_bien_cedido:
   || devuelve el bien
   */ --------------------------------------------------------
   FUNCTION fp_bien_cedido(p_const BOOLEAN,
                           p_cont  BOOLEAN,
                           p_val_campo a2000025.val_campo%TYPE)
      RETURN VARCHAR2
   IS
      --      
      l_txt_desc VARCHAR2(100);
      --
      l_k_vacio         CONSTANT VARCHAR2(1)  := ''             ;
      l_k_cesionario_ed CONSTANT VARCHAR2(13) := 'CESIONARIO_ED';
      l_k_cesionario_co CONSTANT VARCHAR2(13) := 'CESIONARIO_CO';    
      --
      CURSOR l_c_a2000025(p_cod_campo a2000025.cod_campo%TYPE)
      IS
         --
         SELECT a.*
           FROM a2000025 a
          WHERE a.num_poliza    = g_num_poliza
            AND a.num_spto      = (SELECT MAX(b.num_spto) --v 1.08
                                     FROM a2000025 b
                                    WHERE a.cod_cia = b.cod_cia
                                      AND a.num_poliza = b.num_poliza
                                      AND a.num_riesgo = b.num_riesgo
                                      AND a.cod_campo  = b.cod_campo
                                      AND a.num_periodo = b.num_periodo
                                      AND a.cod_lista   = b.cod_lista
                                      AND a.num_ocurrencia = b.num_ocurrencia
                                      AND b.num_spto       <= g_num_spto) -- (v.1.04)
            AND a.num_apli      = trn.cero
            AND a.num_spto_apli = trn.cero
            AND a.num_riesgo    = g_num_riesgo
            AND a.cod_campo     = p_cod_campo 
            AND a.val_campo     = p_val_campo;  
      --
      CURSOR l_c_p2000025(p_cod_campo a2000025.cod_campo%TYPE)
      IS
         --
         SELECT a.*
           FROM p2000025 a
          WHERE a.num_poliza    = g_num_poliza
            AND a.num_spto      = g_num_spto
            AND a.num_apli      = trn.cero
            AND a.num_spto_apli = trn.cero
            AND a.num_riesgo    = g_num_riesgo
            AND a.cod_campo     = p_cod_campo
            AND a.val_campo     = p_val_campo;      
      --
      l_reg_a2000025 l_c_a2000025%ROWTYPE;
      l_reg_p2000025 l_c_p2000025%ROWTYPE;
      --
      FUNCTION fi_return_monto(p_val_campo a2000025.val_campo%TYPE,
                               p_cod_campo a2000025.cod_campo%TYPE,
                               p_oferta BOOLEAN)
         RETURN VARCHAR2
      IS
         --
         l_monto a2000025.val_campo%TYPE;
         --
         CURSOR l_ci_p2000025
         IS
            --  
            SELECT a.val_campo
              FROM p2000025 a
             WHERE a.num_poliza     = g_num_poliza
               AND a.num_spto       = g_num_spto 
               AND a.num_apli       = trn.cero
               AND a.num_spto_apli  = trn.cero
               AND a.num_riesgo     = g_num_riesgo
               AND a.num_ocurrencia = (SELECT MAX(b.num_ocurrencia)
                                         FROM p2000025 b
                                        WHERE b.num_poliza    = a.num_poliza
                                          AND b.num_spto      = a.num_spto
                                          AND b.num_apli      = a.num_apli
                                          AND b.num_spto_apli = a.num_spto_apli
                                          AND b.num_riesgo    = a.num_riesgo
                                          AND b.val_campo     = p_val_campo)
                                          AND a.cod_campo     = p_cod_campo;         
         --
         CURSOR l_ci_a2000025
         IS
            --  
            SELECT a.val_campo
              FROM a2000025 a
             WHERE a.num_poliza     = g_num_poliza
               AND a.num_spto       = (SELECT MAX(b.num_spto) --v 1.08
                                         FROM a2000025 b
                                        WHERE a.cod_cia = b.cod_cia
                                          AND a.num_poliza = b.num_poliza
                                          AND a.num_riesgo = b.num_riesgo
                                          AND a.cod_campo  = b.cod_campo
                                          AND a.num_periodo = b.num_periodo
                                          AND a.cod_lista   = b.cod_lista
                                          AND a.num_ocurrencia = b.num_ocurrencia
                                          AND b.num_spto       <= g_num_spto) -- (v.1.04)
               AND a.num_apli       = trn.cero
               AND a.num_spto_apli  = trn.cero
               AND a.num_riesgo     = g_num_riesgo
               AND a.num_ocurrencia = (SELECT MAX(b.num_ocurrencia)
                                         FROM a2000025 b
                                        WHERE b.num_poliza    = a.num_poliza
                                          AND b.num_spto      = a.num_spto
                                          AND b.num_apli      = a.num_apli
                                          AND b.num_spto_apli = a.num_spto_apli
                                          AND b.num_riesgo    = a.num_riesgo
                                          AND b.val_campo     = p_val_campo)
                                          AND a.cod_campo = p_cod_campo;
         
      --
      BEGIN
         --
         IF p_oferta
         THEN
            --
            OPEN l_ci_p2000025;
            FETCH l_ci_p2000025 INTO l_monto;
            CLOSE l_ci_p2000025;
            --
            IF l_monto IS NOT NULL
            THEN
               --
               RETURN l_monto;--g_cod_mon||' '||fp_format(l_monto);
               --
            ELSE
               --
               RETURN '';
               --
            END IF;            
            --
         ELSE
            --
            OPEN l_ci_a2000025;
            FETCH l_ci_a2000025 INTO l_monto;
            CLOSE l_ci_a2000025;
            --
            IF l_monto IS NOT NULL
            THEN
               --
               RETURN l_monto;--g_cod_mon||' '||fp_format(l_monto);
               --
            ELSE
               --
               RETURN '';
               --
            END IF;
            --
         END IF;
         --
      EXCEPTION
         WHEN OTHERS
         THEN
            --
         RETURN '';
         --
      END fi_return_monto;       
      --
   BEGIN
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         IF p_const
         THEN
            --
            OPEN l_c_p2000025(l_k_cesionario_ed);
            LOOP
               --
               FETCH l_c_p2000025 INTO l_reg_p2000025; 
               EXIT WHEN l_c_p2000025%NOTFOUND;
               --
               IF l_c_p2000025%FOUND
               THEN
                  --
                  IF fi_return_monto(p_val_campo,
                                     'MONTO_ED' ,
                                     TRUE) IS NULL
                  THEN
                     --
                     l_txt_desc := l_k_vacio;
                     --
                  ELSE
                     --                    
                     l_txt_desc := fi_return_monto(p_val_campo,
                                                   'MONTO_ED',
                                                   TRUE);                     
                     --
                  END IF;                    
                  --
                  RETURN l_txt_desc;
                  EXIT;
                  --
               END IF;   
               --
            END LOOP;
            --
            CLOSE l_c_p2000025;
            --
         ELSE
            --
            OPEN l_c_p2000025(l_k_cesionario_co);
            LOOP
               --
               FETCH l_c_p2000025 INTO l_reg_p2000025;
               EXIT WHEN l_c_p2000025%NOTFOUND;
               --
               IF l_c_p2000025%FOUND
               THEN
                  --
                  IF fi_return_monto(p_val_campo,
                                     'MONTO_CO',
                                     TRUE) IS NULL
                  THEN
                     -- 
                     l_txt_desc := l_k_vacio; 
                     -- 
                  ELSE
                     --
                     l_txt_desc := fi_return_monto(p_val_campo,
                                                   'MONTO_CO',
                                                   TRUE);                  
                     --            
                  END IF;                   
                  --
                  RETURN l_txt_desc;
                  EXIT;
                  --
               END IF;
               --
            END LOOP;   
         --
         CLOSE l_c_p2000025;
         --
         END IF;         
         --
      ELSE
         --
         IF p_const
         THEN
            --
            OPEN l_c_a2000025(l_k_cesionario_ed);
            LOOP
               --
               FETCH l_c_a2000025 INTO l_reg_a2000025; 
               --
               EXIT WHEN l_c_a2000025%NOTFOUND;
               --
               IF l_c_a2000025%FOUND
               THEN
                  --
                  IF fi_return_monto(p_val_campo,
                                     'MONTO_ED',
                                     FALSE) IS NULL 
                  THEN
                     --
                     l_txt_desc := l_k_vacio;
                     --
                  ELSE
                     --              
                     l_txt_desc := fi_return_monto(p_val_campo,
                                                   'MONTO_ED',
                                                   FALSE);                     
                     --
                  END IF;                  
                  --
                  RETURN l_txt_desc;
                  EXIT;
                  --
               END IF;   
               --
            END LOOP;
            --
            CLOSE l_c_a2000025;
            --
         ELSE
            --
            OPEN l_c_a2000025(l_k_cesionario_co);
            LOOP
               --
               FETCH l_c_a2000025 INTO l_reg_a2000025; 
               EXIT WHEN l_c_a2000025%NOTFOUND;
               --
               IF l_c_a2000025%FOUND
               THEN
                  --
                  IF fi_return_monto(p_val_campo,
                                     'MONTO_CO',
                                     FALSE) IS NULL
                  THEN
                     --
                     l_txt_desc := l_k_vacio; 
                     -- 
                  ELSE
                     --
                     l_txt_desc := fi_return_monto(p_val_campo,
                                                   'MONTO_CO',
                                                   FALSE);                  
                     --            
                  END IF; 
                  --                                
                RETURN l_txt_desc;
                EXIT;
                --
               END IF;   
               --
            END LOOP;
            --
         END IF;          
         --
      END IF;
      --
      RETURN NULL;
      --
   END fp_bien_cedido;   
   --
   /* --------------------------------------------------------
   || fp_dev_modalidad:
   || devuelve modalidad de la p0liza
   */ --------------------------------------------------------
   --
   FUNCTION fp_dev_modalidad
      RETURN a2000020.val_campo%TYPE
   IS 
      --
      l_val_campo a2000020.val_campo%TYPE;
      --
      CURSOR l_c_a2000020
      IS
         --
         SELECT DISTINCT a.val_campo
           FROM a2000020 a
          WHERE a.cod_cia       = g_cod_cia
            AND a.num_poliza    = g_num_poliza
            AND a.cod_campo     = g_k_cod_modalidad;               
      --
      CURSOR l_c_p2000020
      IS
         --
         SELECT DISTINCT a.val_campo
           FROM p2000020 a
          WHERE a.cod_cia       = g_cod_cia
            AND a.num_poliza    = g_num_poliza
            AND a.cod_campo     = g_k_cod_modalidad;      
      --
   BEGIN
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         OPEN l_c_p2000020;
         FETCH l_c_p2000020 INTO l_val_campo;
         CLOSE l_c_p2000020;         
         --
      ELSE
         --
         OPEN l_c_a2000020;
         FETCH l_c_a2000020 INTO l_val_campo;
         CLOSE l_c_a2000020;           
         --
      END IF;
      --
      RETURN l_val_campo;
      --
   EXCEPTION 
      WHEN OTHERS
      THEN
         --
         RETURN NULL;   
      --
   END fp_dev_modalidad;   
   --
   /* --------------------------------------------------------
   || fp_dev_riesgos:
   || devuelve cantidad de riesgos
   */ --------------------------------------------------------
   --
   FUNCTION fp_dev_riesgos(p_cotizacion BOOLEAN)
      RETURN NUMBER
   IS 
      --
      l_num_riesgos NUMBER;
      --
      CURSOR l_c_a2000031
      IS
         --
         SELECT MAX(a.num_riesgo)
           FROM a2000031 a
          WHERE a.cod_cia       = g_cod_cia
            AND a.num_poliza    = g_num_poliza
            --AND a.num_spto      = g_num_spto
            AND a.num_apli      = g_num_apli
            AND a.num_spto_apli = g_num_spto_apli;
      --            
      CURSOR l_c_p2000031
      IS
         --
         SELECT MAX(a.num_riesgo)
           FROM p2000031 a
          WHERE a.cod_cia       = g_cod_cia
            AND a.num_poliza    = g_num_poliza
            AND a.num_spto      = g_num_spto
            AND a.num_apli      = g_num_apli
            AND a.num_spto_apli = g_num_spto_apli;       
      --
   BEGIN
      --
      IF p_cotizacion
      THEN
         --
         OPEN l_c_p2000031;
         FETCH l_c_p2000031 INTO l_num_riesgos;
         CLOSE l_c_p2000031;
         --
      ELSE
         --
         OPEN l_c_a2000031;
         FETCH l_c_a2000031 INTO l_num_riesgos;
         CLOSE l_c_a2000031;
         --
      END IF;
      --
      IF l_num_riesgos IS NULL
      THEN 
         --
         l_num_riesgos := TRN.UNO;
         --      
      END IF;
      --
      RETURN l_num_riesgos;
      --
   END fp_dev_riesgos;   
   --
   /* --------------------------------------------------------
   || f_es_spto_anulado:
   || verifica si es suplemento anulado
   */ --------------------------------------------------------
   --
   FUNCTION f_es_spto_anulado(p_cod_cia       IN a2000030.cod_cia      %TYPE,
                              p_num_poliza    IN a2000030.num_poliza   %TYPE,
                              p_num_spto      IN a2000030.num_spto     %TYPE,
                              p_num_apli      IN a2000030.num_apli     %TYPE,
                              p_num_spto_apli IN a2000030.num_spto_apli%TYPE)
      RETURN VARCHAR2
   IS
      --
      l_resultado VARCHAR2(1) := trn.NO;
      --
   BEGIN
      --
      --@mx('I','f_es_spto_anulado');
      --
      IF ea_k_301_utils_msv.f_es_spto_anulado(p_cod_cia       => p_cod_cia      ,
                                           p_num_poliza    => p_num_poliza   ,
                                           p_num_spto      => p_num_spto     ,
                                           p_num_apli      => p_num_apli     ,
                                           p_num_spto_apli => p_num_spto_apli)
      THEN
         --
         l_resultado := trn.SI;
         --
      END IF;
      --
      --@mx('F','f_es_spto_anulado');
      --
      RETURN l_resultado;
      --
   END f_es_spto_anulado;
   --
   /* --------------------------------------------------------
   || fp_prima_tarifa:
   || devuelve prima para la tasa
   */ --------------------------------------------------------
   --   
   FUNCTION fp_prima_tarifa(p_ambito VARCHAR2)
      RETURN a2100170.imp_spto%TYPE
   IS
      --
      l_imp_prima_base a2100170.imp_spto%TYPE;
      --
      CURSOR l_c_p2100170_foto
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_spto, 0)), 0) prima_base
           FROM p2100170 a
          WHERE a.cod_cia       = g_cod_cia
            AND a.num_poliza    = g_num_poliza
            AND a.num_riesgo    = g_num_riesgo
            AND a.cod_desglose  = trn.uno
            AND a.num_spto     <= g_num_spto
            AND a.num_spto     >= (
                SELECT MAX (b.num_spto)
                  FROM p2000030 b
                 WHERE b.cod_cia       = g_cod_cia
                   AND b.num_poliza    = g_num_poliza
                   AND b.num_apli      = a.num_apli
                   AND b.num_spto_apli = a.num_spto_apli
                   AND b.tip_spto   IN ('RF', 'XX')
                   AND b.num_spto   <= trn.uno )
            AND a.num_apli      = trn.cero
            AND a.num_spto_apli = trn.cero
            AND a.cod_ramo      = g_cod_ramo;   
      --      
      CURSOR l_c_a2100170_foto
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_spto, 0)), 0) prima_base
           FROM a2100170 a
          WHERE a.cod_cia       = g_cod_cia
            AND a.num_poliza    = g_num_poliza
            AND a.num_riesgo    = g_num_riesgo
            AND a.cod_desglose  = trn.uno
            AND a.num_spto     <= g_num_spto
            AND a.num_spto     >= (
                SELECT MAX (b.num_spto)
                  FROM a2000030 b
                 WHERE b.cod_cia       = g_cod_cia
                   AND b.num_poliza    = g_num_poliza
                   AND b.num_apli      = a.num_apli
                   AND b.num_spto_apli = a.num_spto_apli
                   AND b.tip_spto   IN ('RF', 'XX')
                   AND b.num_spto   <= trn.uno )
            AND a.num_apli      = trn.cero
            AND a.num_spto_apli = trn.cero
            AND a.cod_ramo      = g_cod_ramo;   
      --
      CURSOR l_c_a2100170_sp
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_spto, 0)), 0) prima_base
           FROM a2100170 a
          WHERE a.cod_cia       = g_cod_cia
            AND a.num_poliza    = g_num_poliza
            AND a.num_riesgo    = g_num_riesgo
            AND a.cod_desglose  = trn.uno
            AND a.num_spto      <= g_num_spto
            AND a.num_apli      = trn.cero
            AND a.num_spto_apli = trn.cero
            AND a.cod_ramo      = g_cod_ramo;    
   BEGIN
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         OPEN l_c_p2100170_foto;
         FETCH l_c_p2100170_foto INTO l_imp_prima_base;
         CLOSE l_c_p2100170_foto;         
         --
      ELSE
         --
         IF p_ambito = G_K_SCOPE_FOTO
         THEN
            --
            OPEN l_c_a2100170_foto;
            FETCH l_c_a2100170_foto INTO l_imp_prima_base;
            CLOSE l_c_a2100170_foto;
            --
         ELSE
            --
            OPEN l_c_a2100170_sp;
            FETCH l_c_a2100170_sp INTO l_imp_prima_base;
            CLOSE l_c_a2100170_sp; 
            --
         END IF;
         --
      END IF;
      --
      RETURN l_imp_prima_base;
      --
   END fp_prima_tarifa;   
   --
   --
   /*---------------------------------------------------------
   || fp_fec_nueva_tarifa:
   || Funcion que retorna las fechas de validez de la nueva
   || tarifa.
   || -- v1.13
   */---------------------------------------------------------
   --
   FUNCTION fp_fec_nueva_tarifa (pc_nom_nemotecnico g2999003_msv.nom_nemotecnico%TYPE,
                                 pc_cod_campo       g2999003_msv.cod_campo      %TYPE)
      RETURN DATE
   IS
      --
      CURSOR lc_cartas_inflacion (p_nom_nemotecnico g2999003_msv.nom_nemotecnico%TYPE,
                                  p_cod_campo       g2999003_msv.cod_campo      %TYPE)
         IS
            --
            SELECT g.fec_validez
              FROM g2999003_msv g
             WHERE g.cod_cia         = g_cod_cia
               AND g.nom_nemotecnico = p_nom_nemotecnico
               AND g.cod_ramo        = g_cod_ramo
               AND g.cod_campo       = p_cod_campo
               AND g.cod_cob         = em.COD_COB_GEN;
      -- 
      l_fec_validez_tarifa g2999003_msv.fec_validez%TYPE;
      --
   BEGIN
      --
      IF lc_cartas_inflacion%ISOPEN
      THEN
         --
         CLOSE lc_cartas_inflacion;
         --
      END IF;
      --
      OPEN lc_cartas_inflacion (p_nom_nemotecnico => pc_nom_nemotecnico,
                                p_cod_campo       => pc_cod_campo      );
      --
      FETCH lc_cartas_inflacion INTO l_fec_validez_tarifa;
      --
      CLOSE lc_cartas_inflacion;
      --
      RETURN l_fec_validez_tarifa;
      --
   END fp_fec_nueva_tarifa;
   --
   /* --------------------------------------------------------
   || pp_clausulas_esp:
   || clausulas especiales
   */ --------------------------------------------------------
   --
   PROCEDURE pp_clausulas_esp(p_cod_clausula IN  a2000265.cod_clausula%TYPE   ,
                              p_nom_titulo   OUT g2999010_msv.nom_seccion%TYPE,
                              p_suma_aseg    OUT VARCHAR2)
   IS
      --
      l_cod_cob a2000040.cod_cob%TYPE;
      l_break BOOLEAN := FALSE;
      --
      CURSOR l_c_g2999003_msv
      IS
         --
         SELECT a.cod_cob
           FROM g2999003_msv a
          WHERE a.cod_cia          = g_cod_cia
            AND a.cod_ramo         = g_cod_ramo
            AND a.nom_nemotecnico  = g_k_nom_nemotecnico
            AND a.cod_campo        = g_k_cod_clausulas
            AND a.txt_valor_maximo = p_cod_clausula            
           ORDER BY a.cod_cob ASC;
      --
      PROCEDURE pi_retorna_sesion(p_cod_cob IN  a2000040.cod_cob        %TYPE,
                                  p_nom_sec OUT g2999010_msv.nom_seccion%TYPE)
      IS
         --
         CURSOR l_c_g2999010_msv
            IS
               --
               SELECT a.nom_seccion
                 FROM g2999010_msv a
                WHERE a.cod_cia     = g_cod_cia
                  AND a.cod_ramo    = g_cod_ramo
                  AND a.cob_rel_uno = p_cod_cob   
                ORDER BY a.num_secu ASC;
      
      BEGIN
         --
         OPEN l_c_g2999010_msv;
         FETCH l_c_g2999010_msv INTO p_nom_sec;
         CLOSE l_c_g2999010_msv;
         --
      EXCEPTION
         WHEN OTHERS
         THEN
            --
            p_nom_sec := trn.nulo;
            --
         --
      END pi_retorna_sesion;      
      --
   BEGIN
      --
      OPEN l_c_g2999003_msv;
      LOOP
         --
         FETCH l_c_g2999003_msv INTO l_cod_cob;
         EXIT WHEN l_c_g2999003_msv%NOTFOUND;
         --
         IF g_reg_clau_espc.COUNT > trn.cero
         THEN
            --
            FOR k IN g_reg_clau_espc.FIRST ..g_reg_clau_espc.LAST
            LOOP
               --               
               IF g_reg_clau_espc(k).cod_cob = l_cod_cob
               THEN
                  --                   
                  p_suma_aseg := g_reg_clau_espc(k).suma_aseg;
                  l_break := TRUE;
                  EXIT;
                  --
               END IF;               
               --
            END LOOP;     
            --
            IF l_break
            THEN
               --               
               pi_retorna_sesion(l_cod_cob,p_nom_titulo);
               l_break := FALSE;
               EXIT;
               --
            END IF;
            --
         END IF;
         --
      END LOOP;   
      --
   END pp_clausulas_esp;   
   --
   /* --------------------------------------------------------
   || Procedimiento privado pp_print_error_log :
   || - Realiza las operaciones para imprimir el log de errores.
   */ --------------------------------------------------------
   --
   PROCEDURE pp_print_error_log(p_report_name IN VARCHAR2        ,
                                p_add_info    IN VARCHAR2 := NULL)
   IS
      --
      l_error_date VARCHAR2(50);
      --
   BEGIN
      --
      --@mx('I','pp_print_error_log');
      --
      IF g_n_error < trn.UNO
      THEN
         --
         IF NOT UTL_FILE.IS_OPEN (g_id_fichero)
         THEN
            --
            l_error_date := TO_CHAR (SYSDATE, 'YYYYMMDD-HHMMSS');
            --
            g_nom_log    := l_error_date || '-MSVEMPRINT-LOGERROR.' || trn_k_lis.ext_mspool || '.log';
            --
            g_id_fichero   := UTL_FILE.FOPEN (g_k_directorio, g_nom_log, 'w');
            --
         END IF;
         --
         UTL_FILE.PUT_LINE (g_id_fichero,
                             'REPORT_TYPE; ERROR_DESCRIPTION; LINE');
         --
      END IF;
      --
      g_n_error := g_n_error + 1;
      --
      IF p_add_info IS NULL
      THEN
         --
         UTL_FILE.PUT_LINE (g_id_fichero                            ,
                            p_report_name                       || '; ' ||
                            SQLERRM                             || '; ' ||
                            g_aux_exc_trace                     || '; ' ||
                            DBMS_UTILITY.format_error_backtrace || ';'  ||
                            DBMS_UTILITY.format_call_stack);
         --
      ELSE
         --
         UTL_FILE.PUT_LINE ( g_id_fichero  ,
                             p_report_name   || '; ' || p_add_info || '; ' ||
                             SQLERRM                               || '; ' ||
                             g_aux_exc_trace                       || '; ' ||
                             DBMS_UTILITY.FORMAT_CALL_STACK        || '; ' ||
                             DBMS_UTILITY.format_error_backtrace            );
         --
      END IF;
      --
      g_aux_exc_trace := '';
      --
      --@mx('F','pp_print_error_log');
      --
   END pp_print_error_log;
   --
   /* --------------------------------------------------------
   || Private procedure pp_close_error_log :
   || - It closes the error log.
   */ --------------------------------------------------------
   --
   PROCEDURE pp_close_error_log
   IS
   --
   BEGIN
      --
      --@mx('I','pp_close_error_log');
      --
      IF g_n_error > trn.CERO
      THEN
         --
         UTL_FILE.FCLOSE (g_id_fichero);
         --
      END IF;
      --
      --@mx('F','pp_close_error_log');
      --
   END pp_close_error_log;
   --
   /* --------------------------------------------------------
   || pp_open_tag:
   || Abre un tag xml del reporte
   */ --------------------------------------------------------
   --
   PROCEDURE pp_open_tag(p_label       IN VARCHAR2,
                         p_nuevo_nivel IN BOOLEAN := TRUE)
   IS
   --
   BEGIN
      --
      --@mx('I','pp_open_tag');
      --
      IF p_nuevo_nivel
      THEN
         --
         g_cont_tabs := g_cont_tabs + trn.UNO;
         --
      END IF;
      --
      g_xml_impresion := concat(g_xml_impresion,
                             fp_tabs || '<' || p_label || '>' || CHR(13));
      --
      --@mx('F','pp_open_tag');
      --
   END pp_open_tag;
   --
   /* --------------------------------------------------------
   || pp_close_tag:
   || Cierra un tag xml del reporte
   */ --------------------------------------------------------
   --
   PROCEDURE pp_close_tag(p_label IN VARCHAR2)
   IS
   --
   BEGIN
      --
      --@mx('I','pp_close_tag');
      --
      g_xml_impresion := concat(g_xml_impresion,
                             fp_tabs || '</' || p_label || '>' || CHR(13));
      --
      g_cont_tabs := g_cont_tabs - trn.UNO;
      --
      --@mx('F','pp_close_tag');
      --
   END pp_close_tag;
   --
   /* --------------------------------------------------------
   || pp_close_report:
   || Cierra el reporte
   */ --------------------------------------------------------
   --
   PROCEDURE pp_close_report(p_id_fichero IN     BINARY_INTEGER,
                             p_clob_datos IN OUT CLOB)
   IS
   --
   BEGIN
      --
      --@mx('I','pp_close_report');
      --
      p_clob_datos := concat(p_clob_datos,
                             CHR(13) || '</report>' || CHR(13));
      --
      trn_k_report.p_update_data_clob(p_id_fichero, p_clob_datos);
      --
      --@mx('F','pp_close_report');
      --
   END pp_close_report;
   --
   /* --------------------------------------------------------
   || pp_traslada_tbl:
   || Concatena en un clob los campos previamente introducidos en pp_agrega_tbl
   || que mas adelante se guardaran en el clob xml del reporte con pp_write_clob
   */ --------------------------------------------------------
   --
   PROCEDURE pp_traslada_tbl
   IS
   --
   BEGIN
      --
      --@mx('I','pp_traslada_tbl');
      --
      FOR i IN NVL(g_tbl_xml_deta.FIRST,0) .. NVL(g_tbl_xml_deta.LAST, -1)
      LOOP
         --
         g_cadena_cab := CONCAT(g_cadena_cab, g_tbl_xml_deta(i).cod_campo);
         g_cadena_dat := CONCAT(g_cadena_dat, g_tbl_xml_deta(i).val_campo);
         --
      END LOOP;
      --
      g_tbl_xml_deta.DELETE;
      --
      --@mx('F','pp_traslada_tbl');
      --
   END pp_traslada_tbl;
   --
   /* --------------------------------------------------------
   || pp_write_clob:
   || Escribe en el clob xml del reporte los campos
   || previamente introducidos con pp_agrega_tbl
   */ --------------------------------------------------------
   --
   PROCEDURE pp_write_clob(p_nuevo_nivel IN BOOLEAN)
   IS
      --
      l_desde_cab BINARY_INTEGER := 1;
      l_hasta_cab BINARY_INTEGER     ;
      l_desde_dat BINARY_INTEGER := 1;
      l_hasta_dat BINARY_INTEGER     ;
      --
      l_trozo_cab CLOB;
      l_trozo_dat CLOB;
      --
   BEGIN
      --
      --@mx('I','pp_write_clob');
      --
      pp_traslada_tbl;
      --
      IF g_cadena_cab IS NULL
      THEN
         --
         RETURN;
         --
      END IF;
      --
      IF p_nuevo_nivel
      THEN
         --
         g_cont_tabs := g_cont_tabs + trn.UNO;
         --
      END IF;
      --
      LOOP
         --
         l_hasta_cab := INSTR(g_cadena_cab, g_k_separador_col, l_desde_cab);
         --
         EXIT WHEN NVL(l_hasta_cab,0) < 1;
         --
         l_hasta_dat := INSTR(g_cadena_dat, g_k_separador_col, l_desde_dat);
         --
         l_trozo_cab := SUBSTR(g_cadena_cab             ,
                               l_desde_cab              ,
                               l_hasta_cab - l_desde_cab);
         --
         l_trozo_dat := SUBSTR(g_cadena_dat             ,
                               l_desde_dat              ,
                               l_hasta_dat - l_desde_dat);
         --
         l_desde_cab := l_hasta_cab + 1;
         l_desde_dat := l_hasta_dat + 1;
         --
         g_xml_impresion := concat(g_xml_impresion,
                                  fp_tabs || '<' || l_trozo_cab || '>');
         --
         g_xml_impresion := concat(g_xml_impresion, TRIM(l_trozo_dat));
         --
         IF INSTR(l_trozo_cab,' ') = trn.CERO
         THEN
            --
            g_xml_impresion := concat(g_xml_impresion,
                                      '</' || l_trozo_cab || '>' ||
                                      CHR(13));
            --
         ELSE
            --
            g_xml_impresion := concat(g_xml_impresion,
                                      '</' || SUBSTR(l_trozo_cab,1,INSTR(l_trozo_cab,' ')-1) || '>' ||
                                      CHR(13));
            --
         END IF;
         --
      END LOOP;
      --
      IF p_nuevo_nivel
      THEN
         --
         g_cont_tabs := g_cont_tabs - trn.UNO;
         --
      END IF;
      --
      g_cadena_cab := trn.nulo;
      g_cadena_dat := trn.nulo;
      --
      --@mx('F','pp_write_clob');
      --
   END pp_write_clob;
   --
   /* --------------------------------------------------------
   || pp_agrega_tbl_clob:
   || Trata todas las llamadas a los pp_agrega_tbl.
   || Formatea el campo dependiendo del tipo de entrada
   */ --------------------------------------------------------
   --
   PROCEDURE pp_agrega_tbl_clob(p_tipo      IN VARCHAR2               ,
                                p_cod_campo IN VARCHAR2               ,
                                p_val_campo IN CLOB                   ,
                                p_initcap   IN BOOLEAN        := FALSE,
                                p_indice    IN BINARY_INTEGER := NULL )
   IS
      --
      l_num_reg   BINARY_INTEGER;
      l_val_campo CLOB;
      --
   BEGIN
      --
      --@mx('I','pp_agrega_tbl_clob');
      --
      l_num_reg   := NVL(p_indice, NVL(g_tbl_xml_deta.LAST, trn.CERO) + trn.UNO);
      --
      IF p_val_campo IS NOT NULL
      THEN
         --
         l_val_campo := p_val_campo;
         --
         BEGIN
            --
            IF p_tipo = g_k_binario -- Binary, Image as base64 text, Clob...
            THEN
               --
               g_tbl_xml_deta(l_num_reg).val_campo := l_val_campo;
               --
            ELSIF     p_tipo = g_k_importe -- Importe
            THEN
               --
               g_tbl_xml_deta(l_num_reg).val_campo := fp_format(p_importe      => l_val_campo ,
                                                                p_valida_error => TRUE        ,
                                                                p_anyade_euro  => FALSE       ,
                                                                p_coma         => TRUE        ,
                                                                p_tasa         => FALSE       );
               --
            ELSIF p_tipo = g_k_fecha
            THEN
               --
               g_tbl_xml_deta(l_num_reg).val_campo := TO_CHAR(TO_DATE(l_val_campo), G_K_FORMATO_FEC_XML);
               --
            ELSIF p_tipo = g_k_fecha_hora -- Date hour
            THEN
               --
               g_tbl_xml_deta(l_num_reg).val_campo := TO_CHAR(TO_DATE(l_val_campo), G_K_FORMATO_FECH_XML) || ' CET'; -- JGUIJA1. En HOME lo aplican a los campos INSTR('fec') y 'fec_vcto_pol','fec_vcto_spto'
               --
            ELSIF p_tipo = g_k_fecha_mes -- Date month as text
            THEN
               --
               g_tbl_xml_deta(l_num_reg).val_campo := TO_CHAR(TO_DATE(l_val_campo), 'DD Month YYYY', 'NLS_DATE_LANGUAGE=SPANISH');
               --
            ELSIF p_tipo = g_k_fecha_abr -- Date month as abr
            THEN
               --
               g_tbl_xml_deta(l_num_reg).val_campo := TO_CHAR(TO_DATE(l_val_campo), 'DD-Mon-YYYY', 'NLS_DATE_LANGUAGE=SPANISH');
               --
            ELSIF p_tipo = g_k_fecha_ordinal -- To build something like 22<sup>Nd</sup> December 2016
            THEN
               --
                  g_tbl_xml_deta(l_num_reg).val_campo := '<![CDATA[' ||
                  TO_CHAR( TO_DATE(l_val_campo, 'dd/MM/yyyy', 'NLS_DATE_LANGUAGE=AMERICAN'),'DD"<sup>"', 'NLS_DATE_LANGUAGE=AMERICAN') ||
                  LOWER(SUBSTR(TO_CHAR(TO_DATE(l_val_campo, 'dd/MM/yyyy', 'NLS_DATE_LANGUAGE=AMERICAN'),'DDth', 'NLS_DATE_LANGUAGE=AMERICAN'), 3, 2)) ||
                  TRIM(TO_CHAR(TO_DATE(l_val_campo, 'dd/MM/yyyy', 'NLS_DATE_LANGUAGE=AMERICAN'), '"</sup>" Month', 'NLS_DATE_LANGUAGE=AMERICAN')) ||
                  TO_CHAR(TO_DATE(l_val_campo, 'dd/MM/yyyy', 'NLS_DATE_LANGUAGE=AMERICAN'), ', YYYY', 'NLS_DATE_LANGUAGE=AMERICAN') ||
                  ']]>';
               --
            ELSIF p_tipo = g_k_dv
            --
            THEN
               --
               IF    INSTR(LOWER(p_cod_campo),'imp'      , 1) > trn.CERO
                  OR INSTR(LOWER(p_cod_campo),'value'    , 1) > trn.CERO
                  OR INSTR(LOWER(p_cod_campo),'suma_aseg', 1) > trn.CERO
               THEN
                  --
                  g_tbl_xml_deta(l_num_reg).val_campo := fp_format(l_val_campo);
                  --
               ELSIF INSTR(LOWER(p_cod_campo),'fec'      , 1) > trn.CERO
               THEN
                  --
                  g_tbl_xml_deta(l_num_reg).val_campo := TO_CHAR(TO_DATE(l_val_campo, G_K_FORMATO_FEC_XML));
                  --
               END IF;
               --
            ELSIF p_tipo = g_k_texto -- Text
            THEN
               --
               IF INSTR(l_val_campo,']]>',1) > trn.CERO
               THEN
                  --
                  l_val_campo := REPLACE(l_val_campo,'>',';');
                  --
               END IF;
               --
               IF p_initcap
               THEN
                  --
                  g_tbl_xml_deta(l_num_reg).val_campo := '<![CDATA[' || INITCAP(l_val_campo) || ' ]]>';
                  --
               ELSE
                  --
                  g_tbl_xml_deta(l_num_reg).val_campo := '<![CDATA[' || l_val_campo || ' ]]>';
                  --
               END IF;
               --
            END IF;
            --
         EXCEPTION
            --
            WHEN OTHERS
            THEN
               --
               g_tbl_xml_deta(l_num_reg).val_campo := l_val_campo;
            --
         END;
         --
      END IF;
      --
      g_tbl_xml_deta(l_num_reg).cod_campo := p_cod_campo                         || g_k_separador_col;
      g_tbl_xml_deta(l_num_reg).val_campo := g_tbl_xml_deta(l_num_reg).val_campo || g_k_separador_col;
      --
      --@mx('F','pp_agrega_tbl_clob');
      --
   END pp_agrega_tbl_clob;
   --
   /* --------------------------------------------------------
   || pp_agrega_tbl:
   || Llama a pp_agrega_tbl_clob para un p_val_campo de tipo VARCHAR2
   */ --------------------------------------------------------
   --
   PROCEDURE pp_agrega_tbl(p_tipo      IN VARCHAR2               ,
                           p_cod_campo IN VARCHAR2               ,
                           p_val_campo IN VARCHAR2               ,
                           p_initcap   IN BOOLEAN        := FALSE,
                           p_indice    IN BINARY_INTEGER := NULL )
   IS
      --
      l_clob CLOB;
      --
   BEGIN
      --
      --@mx('I','pp_agrega_tbl');
      --
      l_clob := p_val_campo;
      --
      pp_agrega_tbl_clob(p_tipo     ,
                         p_cod_campo,
                         l_clob     ,
                         p_initcap  ,
                         p_indice   );
      --
      --@mx('F','pp_agrega_tbl');
      --
   END pp_agrega_tbl;
   --
   /* --------------------------------------------------------
   || pp_agrega_tbl:
   || Llama a pp_agrega_tbl_clob para un p_val_campo de tipo CLOB
   */ --------------------------------------------------------
   --
   PROCEDURE pp_agrega_tbl(p_tipo      IN VARCHAR2               ,
                           p_cod_campo IN VARCHAR2               ,
                           p_val_campo IN CLOB                   ,
                           p_initcap   IN BOOLEAN        := FALSE,
                           p_indice    IN BINARY_INTEGER := NULL )
   IS
   --
   BEGIN
      --
      --@mx('I','pp_agrega_tbl');
      --
      pp_agrega_tbl_clob(p_tipo     ,
                         p_cod_campo,
                         p_val_campo,
                         p_initcap  ,
                         p_indice   );
      --
      --@mx('F','pp_agrega_tbl');
      --
   END pp_agrega_tbl;
   --
   /* --------------------------------------------------------
   || pp_write_clob_seg:
   || Almacena el estado del clob creando una copia de seguridad.
   */ --------------------------------------------------------
   --
   PROCEDURE pp_write_clob_seg
   IS
      --
   BEGIN
      --
      --@mx('I','pp_write_clob_seg');
      --
      g_cadena_cab_aux    := g_cadena_cab   ;
      g_cadena_dat_aux    := g_cadena_dat   ;
      g_cont_tabs_aux     := g_cont_tabs    ;
      g_cont_regs_aux     := g_cont_regs    ;
      g_xml_impresion_aux := g_xml_impresion;
      --
      --@mx('F','pp_write_clob_seg');
      --
   END pp_write_clob_seg;
   --
   /* --------------------------------------------------------
   || pp_restore_clob_seg:
   || Restaura el estado el clob usando la copia de seguridad.
   */ --------------------------------------------------------
   --
   PROCEDURE pp_restore_clob_seg
   IS
   --
   BEGIN
      --
      --@mx('I','pp_restore_clob_seg');
      --
      g_cadena_cab    := g_cadena_cab_aux   ;
      g_cadena_dat    := g_cadena_dat_aux   ;
      g_cont_tabs     := g_cont_tabs_aux    ;
      g_cont_regs     := g_cont_regs_aux    ;
      g_xml_impresion := g_xml_impresion_aux;
      --
      --@mx('F','pp_restore_clob_seg');
      --
   END pp_restore_clob_seg;
   --
   /* --------------------------------------------------------
   || pp_restore_clob_seg:
   || Restaura el estado el clob usando la copia de seguridad.
   */ --------------------------------------------------------
   --
   PROCEDURE pp_reset_clobs
   IS
   --
   BEGIN
      --
      --@mx('I','pp_reset_clobs');
      --
      g_cadena_cab        := trn.nulo;
      g_cadena_cab_aux    := trn.nulo;
      g_cadena_dat        := trn.nulo;
      g_cadena_dat_aux    := trn.nulo;
      g_cont_tabs         := trn.nulo;
      g_cont_tabs_aux     := trn.nulo;
      g_cont_regs         := trn.cero;
      g_cont_regs_aux     := trn.cero;
      g_xml_impresion     := trn.nulo;
      g_xml_impresion_aux := trn.nulo;
      --
      --@mx('F','pp_reset_clobs');
      --
   END pp_reset_clobs;
   --
   /* --------------------------------------------------------
   || pp_valor_dv:
   || DV
   */ --------------------------------------------------------
   --
   PROCEDURE pp_valor_dv(p_cod_campo         IN     a2000020.cod_campo%TYPE         ,
                         p_val_campo         IN OUT a2000020.val_campo%TYPE         ,
                         p_txt_campo         IN OUT a2000020.txt_campo%TYPE         ,
                         p_val_default_value IN     a2000020.val_campo%TYPE := NULL ,
                         p_txt_default_value IN     a2000020.txt_campo%TYPE := NULL ,
                         p_policy_level      IN     BOOLEAN                 := FALSE)
   IS
      --
      l_num_riesgo a2000020.num_riesgo %TYPE;
      --
      PROCEDURE pi_default_assignment
      IS
      --
      BEGIN
         --
         IF     p_val_default_value IS NOT NULL 
            AND p_val_campo IS NULL
         THEN
            --
            p_val_campo := p_val_default_value;
            --
         END IF;
         --
         IF     p_txt_default_value IS NOT NULL 
            AND p_txt_campo IS NULL
         THEN
            --
            p_txt_campo := p_txt_default_value;
            --
         END IF;
         --
      END pi_default_assignment;
      --
   BEGIN
      --
      --@mx('I','pp_valor_dv');
      --
      IF NOT p_policy_level
      THEN
         --
         l_num_riesgo := g_num_riesgo;
         --
      ELSE
         --
         l_num_riesgo := trn.CERO;
         --
      END IF;
      --
      IF g_quotation
      THEN
         --
         em_k_p2000020.p_lee_vigente(p_cod_cia       => g_cod_cia      ,
                                     p_num_poliza    => g_num_poliza   ,
                                     p_num_spto      => g_num_spto     ,
                                     p_num_apli      => g_num_apli     ,
                                     p_num_spto_apli => g_num_spto_apli,
                                     p_num_riesgo    => l_num_riesgo   ,
                                     p_num_periodo   => g_num_periodo  ,
                                     p_cod_campo     => p_cod_campo    ,
                                     p_cod_ramo      => g_cod_ramo     );
         --
         p_val_campo := em_k_p2000020.f_val_campo;
         p_txt_campo := em_k_p2000020.f_txt_campo;
         --
      ELSIF g_pre_renewal
      THEN
         --
         BEGIN
            --
            em_k_r2000020.p_lee_vigente(p_cod_cia     => g_cod_cia    ,
                                        p_num_poliza  => g_num_poliza ,
                                        p_num_apli    => g_num_apli   ,
                                        p_num_riesgo  => l_num_riesgo ,
                                        p_num_periodo => g_num_periodo,
                                        p_cod_campo   => p_cod_campo  ,
                                        p_cod_ramo    => g_cod_ramo   );
            --
            p_val_campo := em_k_r2000020.f_val_campo;
            p_txt_campo := em_k_r2000020.f_txt_campo;
            --
         EXCEPTION 
            --
            WHEN OTHERS 
            THEN
               --
               p_val_campo := ea_k_301_utils.f_valor_dv(p_cod_campo   => p_cod_campo     ,
                                                        p_busca_en_a  => NOT g_quotation ,
                                                        p_cod_cia     => g_cod_cia       ,
                                                        p_num_poliza  => g_num_poliza    ,
                                                        p_num_spto    => g_num_spto      ,
                                                        p_num_riesgo  => l_num_riesgo    ,
                                                        p_num_periodo => g_num_periodo   ,
                                                        p_cod_ramo    => g_cod_ramo      );
               --
               p_txt_campo := ea_k_301_utils.f_txt_dv(p_cod_campo     => p_cod_campo     ,
                                                      p_tip_nivel     => NULL            ,
                                                      p_busca_en_a    => NOT g_quotation ,
                                                      p_cod_cia       => g_cod_cia       ,
                                                      p_num_poliza    => g_num_poliza    ,
                                                      p_num_spto      => g_num_spto      ,
                                                      p_num_apli      => g_num_apli      ,
                                                      p_num_spto_apli => g_num_spto_apli ,
                                                      p_num_riesgo    => l_num_riesgo    ,
                                                      p_num_periodo   => g_num_periodo   ,
                                                      p_cod_ramo      => g_cod_ramo      );
               --
         END;
         --
      ELSE
         --
         p_val_campo := ea_k_301_utils.f_valor_dv(p_cod_campo   => p_cod_campo     ,
                                                  p_busca_en_a  => NOT g_quotation ,
                                                  p_cod_cia     => g_cod_cia       ,
                                                  p_num_poliza  => g_num_poliza    ,
                                                  p_num_spto    => g_num_spto      ,
                                                  p_num_riesgo  => l_num_riesgo    ,
                                                  p_num_periodo => g_num_periodo   ,
                                                  p_cod_ramo    => g_cod_ramo      );
         --
         p_txt_campo := ea_k_301_utils.f_txt_dv(p_cod_campo     => p_cod_campo     ,
                                                p_tip_nivel     => NULL            ,
                                                p_busca_en_a    => NOT g_quotation ,
                                                p_cod_cia       => g_cod_cia       ,
                                                p_num_poliza    => g_num_poliza    ,
                                                p_num_spto      => g_num_spto      ,
                                                p_num_apli      => g_num_apli      ,
                                                p_num_spto_apli => g_num_spto_apli ,
                                                p_num_riesgo    => l_num_riesgo    ,
                                                p_num_periodo   => g_num_periodo   ,
                                                p_cod_ramo      => g_cod_ramo      );
         --
      END IF;
      --
      pi_default_assignment;
      --
      --@mx('F','pp_valor_dv');
      --
   EXCEPTION
      -- 
      WHEN OTHERS 
      THEN
         --
         pi_default_assignment;
         --
   END pp_valor_dv;
   --
   /* --------------------------------------------------------
   || pp_task_ending:
   || Realiza las operaciones de finalizacion
   */ --------------------------------------------------------
   --
   PROCEDURE pp_task_ending
   IS
   --
   BEGIN
      --
      --@mx('I','pp_task_ending');
      --
      trn_k_global.asigna('mca_ter_tar', trn.SI);
      --
      IF g_n_error = trn.CERO
      THEN
         --
         trn_k_global.asigna('TXT_TAREA', 'CADA REGISTRO SOLICITADO FUE IMPRESO'); -- We assign the message to the textArea.
         --
      ELSIF g_cont_regs = trn.CERO
      THEN
         --
         trn_k_global.asigna('TXT_TAREA', 'REPORTE NO GENERADO. REVISAR ARCHIVO LOG');
         --
      ELSE
         --
         trn_k_global.asigna('TXT_TAREA', 'ALGUNOS REGISTROS NO PUEDEN IMPRIMIRSE. REVISAR ARCHIVO LOG');
         --
      END IF;
      --
      IF g_del_report
      THEN
         --
         DELETE FROM TRONWEB_REPORTS WHERE ID_REPORT = g_id_report;
         COMMIT;
         --
         trn_k_global.asigna('JBID_FICHERO', trn.nulo);
         --
      END IF;
      --
      --@mx('F','pp_task_ending');
      --
   END pp_task_ending;
   --
   /* --------------------------------------------------------
   || pp_inicializa_riesgo:
   || Resetea variables del riesgo
   */ --------------------------------------------------------
   --
   PROCEDURE pp_inicializa_riesgo
   IS
   --
   BEGIN
      --
      --@mx('I','pp_inicializa_riesgo');
      --
      g_existe_dv_r  := NULL;
      g_email_report := NULL;
      --
      g_tbl_datos_var.DELETE;
      --
      --@mx('F','pp_inicializa_riesgo');
      --
   END pp_inicializa_riesgo;      
   --
   /* --------------------------------------------------------
   || pp_dev_imp_spto_total:
   || Devuelve el importe del suplemento para la situacion de la poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_imp_spto_total(p_cod_cia        IN  a2000161.cod_cia      %TYPE,
                                   p_cod_ramo       IN  a2000161.cod_ramo     %TYPE,
                                   p_num_poliza     IN  a2000161.num_poliza   %TYPE,
                                   p_num_spto       IN  a2000161.num_spto     %TYPE,
                                   p_num_apli       IN  a2000161.num_apli     %TYPE,
                                   p_num_spto_apli  IN  a2000161.num_spto_apli%TYPE,
                                   p_prima_base     OUT a2000161.imp_eco      %TYPE,
                                   p_descuentos     OUT a2000161.imp_eco      %TYPE,
                                   p_recargos       OUT a2000161.imp_eco      %TYPE,
                                   p_iva            OUT a2000161.imp_eco      %TYPE,
                                   p_emision        OUT a2000161.imp_eco      %TYPE,
                                   p_igsci          OUT a2000161.imp_eco      %TYPE)
   IS
      --
      CURSOR c_a2000161
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_eco, trn.cero)), trn.cero) prima_base,
                  NVL(SUM(DECODE(cod_eco, 2 , imp_eco, trn.cero)), trn.cero) descuentos,
                  NVL(SUM(DECODE(cod_eco, 3 , imp_eco, trn.cero)), trn.cero) recargos  ,
                  NVL(SUM(DECODE(cod_eco, 4 , imp_eco, trn.cero)), trn.cero) iva       ,
                  NVL(SUM(DECODE(cod_eco, 5 , imp_eco, trn.cero)), trn.cero) emision   ,
                  NVL(SUM(DECODE(cod_eco, 11, imp_eco, trn.cero)), trn.cero) igsci 
           FROM a2000161 a
          WHERE a.cod_cia       = p_cod_cia
            AND a.num_poliza    = p_num_poliza
            AND a.num_spto     <= p_num_spto
            AND a.num_spto     >= (
                SELECT MAX (b.num_spto)
                  FROM a2000030 b
                 WHERE b.cod_cia       = p_cod_cia
                   AND b.num_poliza    = p_num_poliza
                   AND b.num_apli      = a.num_apli
                   AND b.num_spto_apli = a.num_spto_apli
                   AND b.tip_spto   IN ('RF', 'XX')
                   AND b.num_spto   <= p_num_spto )
            AND a.num_apli      = p_num_apli
            AND a.num_spto_apli = p_num_spto_apli
            AND a.cod_ramo      = p_cod_ramo;
         --
         l_reg161 c_a2000161%ROWTYPE;
      --
   BEGIN
      --
      --@mx('I','pp_dev_imp_spto_total');
      --
      OPEN  c_a2000161;
      --
      FETCH c_a2000161 INTO l_reg161;
      CLOSE c_a2000161;
      --
      p_prima_base  := l_reg161.prima_base;  
      p_descuentos  := l_reg161.descuentos;  
      p_recargos    := l_reg161.recargos;  
      p_iva         := l_reg161.iva;  
      p_emision     := l_reg161.emision;  
      p_igsci       := l_reg161.igsci;        
      --
      --@mx('F','pp_dev_imp_spto_total');
      --
   END pp_dev_imp_spto_total;  
   --
   /* --------------------------------------------------------
   || pp_dev_imp_spto_s_total:
   || Devuelve el importe del suplemento para la situacion del suplemento actual
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_imp_spto_s_total(p_cod_cia       IN  a2000161.cod_cia      %TYPE,
                                     p_cod_ramo      IN  a2000161.cod_ramo     %TYPE,
                                     p_num_poliza    IN  a2000161.num_poliza   %TYPE,
                                     p_num_spto      IN  a2000161.num_spto     %TYPE,
                                     p_num_apli      IN  a2000161.num_apli     %TYPE,
                                     p_num_spto_apli IN  a2000161.num_spto_apli%TYPE,
                                     p_num_periodo   IN  a2100170.num_periodo  %TYPE,
                                     p_prima_base    OUT a2000161.imp_eco      %TYPE,
                                     p_descuentos    OUT a2000161.imp_eco      %TYPE,
                                     p_recargos      OUT a2000161.imp_eco      %TYPE,
                                     p_iva           OUT a2000161.imp_eco      %TYPE,
                                     p_emision       OUT a2000161.imp_eco      %TYPE,
                                     p_igsci         OUT a2000161.imp_eco      %TYPE)
   IS
      --
      CURSOR c_a2000161
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_eco, trn.cero)), trn.cero) prima_base,
                NVL(SUM(DECODE(cod_eco, 2 , imp_eco, trn.cero)), trn.cero) descuentos,
                NVL(SUM(DECODE(cod_eco, 3 , imp_eco, trn.cero)), trn.cero) recargos  ,
                NVL(SUM(DECODE(cod_eco, 4 , imp_eco, trn.cero)), trn.cero) iva       ,
                NVL(SUM(DECODE(cod_eco, 5 , imp_eco, trn.cero)), trn.cero) emision   ,
                NVL(SUM(DECODE(cod_eco, 11, imp_eco, trn.cero)), trn.cero) igsci 
           FROM a2000161 a
          WHERE a.cod_cia       = p_cod_cia
            AND a.num_poliza    = p_num_poliza
            AND a.num_spto      <= p_num_spto
            AND a.num_spto     >= (SELECT MAX (b.num_spto)--v 1.11{
                                     FROM a2000030 b
                                    WHERE b.cod_cia       = p_cod_cia
                                      AND b.num_poliza    = p_num_poliza
                                      AND b.num_apli      = a.num_apli
                                      AND b.num_spto_apli = a.num_spto_apli
                                      AND b.tip_spto   IN ('RF', 'XX')
                                      AND b.num_spto   <= p_num_spto )--v 1.11}
            AND a.num_apli      = p_num_apli
            AND a.num_spto_apli = p_num_spto_apli
            AND a.cod_ramo      = p_cod_ramo;
      --
      l_reg161 c_a2000161%ROWTYPE;
      --
      CURSOR c_a2100170
      IS
         --
         SELECT NVL(SUM(NVL(imp_anual, 0)), 0) imp_anual
           FROM a2100170
          WHERE cod_cia       = p_cod_cia
            AND num_poliza    = p_num_poliza
            AND num_spto      = p_num_spto
            AND num_apli      = p_num_apli
            AND num_spto_apli = p_num_spto_apli
            AND num_periodo   = p_num_periodo
            AND cod_eco       IN (1, 54)
            AND cod_ramo      = p_cod_ramo;
      --
   BEGIN
      --
      --@mx('I','pp_dev_imp_spto_s_total');
      --
      OPEN  c_a2000161;
      --
      FETCH c_a2000161 INTO l_reg161;
      CLOSE c_a2000161;
      --
      OPEN  c_a2100170;
      --
      FETCH c_a2100170 INTO l_reg161.prima_base;
      CLOSE c_a2100170;
      --
      p_prima_base  := l_reg161.prima_base;  
      p_descuentos  := l_reg161.descuentos;  
      p_recargos    := l_reg161.recargos;  
      p_iva         := l_reg161.iva;  
      p_emision     := l_reg161.emision;  
      p_igsci       := l_reg161.igsci; 
      --
      --@mx('F','pp_dev_imp_spto_s_total');
      --
   END pp_dev_imp_spto_s_total;   
   --   
   /* --------------------------------------------------------
   || pp_dev_imp_spto:
   || Devuelve el importe del suplemento para la situacion de la poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_imp_spto(p_cod_cia        IN  a2000161.cod_cia      %TYPE,
                             p_cod_ramo       IN  a2000161.cod_ramo     %TYPE,
                             p_num_poliza     IN  a2000161.num_poliza   %TYPE,
                             p_num_spto       IN  a2000161.num_spto     %TYPE,
                             p_num_apli       IN  a2000161.num_apli     %TYPE,
                             p_num_spto_apli  IN  a2000161.num_spto_apli%TYPE,
                             p_prima_base     OUT a2000161.imp_eco      %TYPE,
                             p_descuentos     OUT a2000161.imp_eco      %TYPE,
                             p_recargos       OUT a2000161.imp_eco      %TYPE,
                             p_iva            OUT a2000161.imp_eco      %TYPE,
                             p_emision        OUT a2000161.imp_eco      %TYPE,
                             p_igsci          OUT a2000161.imp_eco      %TYPE)
   IS
      --
      CURSOR c_a2000161
      IS
         --v 1.08
         SELECT NVL(SUM(DECODE(cod_eco     , 1 , imp_spto, trn.cero)), trn.cero) prima_base,
                NVL(SUM(DECODE(cod_eco     , 2 , imp_spto, trn.cero)), trn.cero) descuentos,
                NVL(SUM(DECODE(cod_eco     , 3 , imp_spto, trn.cero)), trn.cero) recargos  ,
                NVL(SUM(DECODE(cod_eco     , 4 , imp_spto, trn.cero)), trn.cero) iva       ,
                NVL(SUM(DECODE(cod_eco     , 5 , imp_spto, trn.cero)), trn.cero) emision   ,
                NVL(SUM(DECODE(cod_eco     , 11, imp_spto, trn.cero)), trn.cero) igsci 
           FROM a2100170 a
          WHERE a.cod_cia       = p_cod_cia
            AND a.num_poliza    = p_num_poliza
            AND a.num_riesgo    = g_num_riesgo
            AND a.num_spto     <= p_num_spto
            AND a.num_spto     >= (
                SELECT MAX (b.num_spto)
                  FROM a2000030 b
                 WHERE b.cod_cia       = p_cod_cia
                   AND b.num_poliza    = p_num_poliza
                   AND b.num_apli      = a.num_apli
                   AND b.num_spto_apli = a.num_spto_apli
                   AND b.tip_spto   IN ('RF', 'XX')
                   AND b.num_spto   <= p_num_spto )
            AND a.num_apli      = p_num_apli
            AND a.num_spto_apli = p_num_spto_apli
            AND a.cod_ramo      = p_cod_ramo;         
         --
         l_reg161 c_a2000161%ROWTYPE;
      --
   BEGIN
      --
      --@mx('I','pp_dev_imp_spto');
      --
      OPEN  c_a2000161;
      --
      FETCH c_a2000161 INTO l_reg161;
      CLOSE c_a2000161;
      --
      p_prima_base  := l_reg161.prima_base;  
      p_descuentos  := l_reg161.descuentos;  
      p_recargos    := l_reg161.recargos;  
      p_iva         := l_reg161.iva;  
      p_emision     := l_reg161.emision;  
      p_igsci       := l_reg161.igsci;        
      --
      --@mx('F','pp_dev_imp_spto');
      --
   END pp_dev_imp_spto;
   --
   /* --------------------------------------------------------
   || pp_dev_imp_spto_s:
   || Devuelve el importe del suplemento para la situacion del suplemento actual
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_imp_spto_s(p_cod_cia       IN  a2000161.cod_cia      %TYPE,
                               p_cod_ramo      IN  a2000161.cod_ramo     %TYPE,
                               p_num_poliza    IN  a2000161.num_poliza   %TYPE,
                               p_num_spto      IN  a2000161.num_spto     %TYPE,
                               p_num_apli      IN  a2000161.num_apli     %TYPE,
                               p_num_spto_apli IN  a2000161.num_spto_apli%TYPE,
                               p_num_periodo   IN  a2100170.num_periodo  %TYPE,
                               p_prima_base    OUT a2000161.imp_eco      %TYPE,
                               p_descuentos    OUT a2000161.imp_eco      %TYPE,
                               p_recargos      OUT a2000161.imp_eco      %TYPE,
                               p_iva           OUT a2000161.imp_eco      %TYPE,
                               p_emision       OUT a2000161.imp_eco      %TYPE,
                               p_igsci         OUT a2000161.imp_eco      %TYPE)
   IS
      --
      CURSOR c_a2000161
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_spto, trn.cero)), trn.cero) prima_base,
                NVL(SUM(DECODE(cod_eco, 2 , imp_spto, trn.cero)), trn.cero) descuentos,
                NVL(SUM(DECODE(cod_eco, 3 , imp_spto, trn.cero)), trn.cero) recargos  ,
                NVL(SUM(DECODE(cod_eco, 4 , imp_spto, trn.cero)), trn.cero) iva       ,
                NVL(SUM(DECODE(cod_eco, 5 , imp_spto, trn.cero)), trn.cero) emision   ,
                NVL(SUM(DECODE(cod_eco, 11, imp_spto, trn.cero)), trn.cero) igsci 
           FROM a2100170 a
          WHERE a.cod_cia       = p_cod_cia
            AND a.num_poliza    = p_num_poliza
            AND a.num_riesgo    = g_num_riesgo
            AND a.num_spto      <= p_num_spto
            AND a.num_apli      = p_num_apli
            AND a.num_spto_apli = p_num_spto_apli
            AND a.cod_ramo      = p_cod_ramo;      
      --
      l_reg161 c_a2000161%ROWTYPE;
      --
      CURSOR c_a2100170
      IS
         --
         SELECT NVL(SUM(NVL(imp_anual, 0)), 0) imp_anual
           FROM a2100170
          WHERE cod_cia       = p_cod_cia
            AND num_poliza    = p_num_poliza
            AND num_spto      = p_num_spto
            AND num_apli      = p_num_apli
            AND num_spto_apli = p_num_spto_apli
            AND num_periodo   = p_num_periodo
            AND cod_eco       IN (1, 54)
            AND cod_ramo      = p_cod_ramo;
      --
   BEGIN
      --
      --@mx('I','pp_dev_imp_spto_s');
      --
      OPEN  c_a2000161;
      --
      FETCH c_a2000161 INTO l_reg161;
      CLOSE c_a2000161;
      --
      OPEN  c_a2100170;
      --
      FETCH c_a2100170 INTO l_reg161.prima_base;
      CLOSE c_a2100170;
      --
      p_prima_base  := l_reg161.prima_base;  
      p_descuentos  := l_reg161.descuentos;  
      p_recargos    := l_reg161.recargos;  
      p_iva         := l_reg161.iva;  
      p_emision     := l_reg161.emision;  
      p_igsci       := l_reg161.igsci; 
      --
      --@mx('F','pp_dev_imp_spto_s');
      --
   END pp_dev_imp_spto_s;
   --
   /* --------------------------------------------------------
   || pp_dev_imp_spto_p:
   || Devuelve el importe del suplemento para un presupuesto
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_imp_spto_p(p_cod_cia        IN  a2000161.cod_cia      %TYPE,
                               p_cod_ramo       IN  a2000161.cod_ramo     %TYPE,
                               p_num_poliza     IN  a2000161.num_poliza   %TYPE,
                               p_num_spto       IN  a2000161.num_spto     %TYPE,
                               p_num_apli       IN  a2000161.num_apli     %TYPE,
                               p_num_spto_apli  IN  a2000161.num_spto_apli%TYPE,
                               p_prima_base     OUT a2000161.imp_eco      %TYPE,
                               p_descuentos     OUT a2000161.imp_eco      %TYPE,
                               p_recargos       OUT a2000161.imp_eco      %TYPE,
                               p_iva            OUT a2000161.imp_eco      %TYPE,
                               p_emision        OUT a2000161.imp_eco      %TYPE,
                               p_igsci          OUT a2000161.imp_eco      %TYPE)
   IS
      --
      CURSOR c_p2000161
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_eco, trn.cero)), trn.cero) prima_base,
                NVL(SUM(DECODE(cod_eco, 2 , imp_eco, trn.cero)), trn.cero) descuentos,
                NVL(SUM(DECODE(cod_eco, 3 , imp_eco, trn.cero)), trn.cero) recargos  ,
                NVL(SUM(DECODE(cod_eco, 4 , imp_eco, trn.cero)), trn.cero) iva       ,
                NVL(SUM(DECODE(cod_eco, 5 , imp_eco, trn.cero)), trn.cero) emision   ,
                NVL(SUM(DECODE(cod_eco, 11, imp_eco, trn.cero)), trn.cero) igsci 
           FROM p2000161 a
          WHERE a.cod_cia    = g_cod_cia
            AND a.num_poliza = g_num_poliza
            AND a.cod_ramo   = g_cod_ramo;
      --
      l_reg161 c_p2000161%ROWTYPE;
      --    
   BEGIN
      --
      --@mx('I','pp_dev_imp_spto_p');
      --
      OPEN  c_p2000161;
      --
      FETCH c_p2000161 INTO l_reg161;
      CLOSE c_p2000161;
      --
      p_prima_base  := l_reg161.prima_base;  
      p_descuentos  := l_reg161.descuentos;  
      p_recargos    := l_reg161.recargos;  
      p_iva         := l_reg161.iva;  
      p_emision     := l_reg161.emision;  
      p_igsci       := l_reg161.igsci;  
      --
      --@mx('F','pp_dev_imp_spto_p');
      --
   END pp_dev_imp_spto_p;
   --
   /* --------------------------------------------------------
   || pp_dev_imp_spto_cot:
   || Devuelve el importe del suplemento para la situacion de la poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_imp_spto_cot(p_cod_cia        IN  a2000161.cod_cia      %TYPE,
                                 p_cod_ramo       IN  a2000161.cod_ramo     %TYPE,
                                 p_num_poliza     IN  a2000161.num_poliza   %TYPE,
                                 p_num_spto       IN  a2000161.num_spto     %TYPE,
                                 p_num_apli       IN  a2000161.num_apli     %TYPE,
                                 p_num_spto_apli  IN  a2000161.num_spto_apli%TYPE,
                                 p_prima_base     OUT a2000161.imp_eco      %TYPE,
                                 p_descuentos     OUT a2000161.imp_eco      %TYPE,
                                 p_recargos       OUT a2000161.imp_eco      %TYPE,
                                 p_iva            OUT a2000161.imp_eco      %TYPE,
                                 p_emision        OUT a2000161.imp_eco      %TYPE,
                                 p_igsci          OUT a2000161.imp_eco      %TYPE)
   IS
      --
      CURSOR c_a2100170
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_spto, trn.cero)), trn.cero) prima_base,
                NVL(SUM(DECODE(cod_eco, 2 , imp_spto, trn.cero)), trn.cero) descuentos,
                NVL(SUM(DECODE(cod_eco, 3 , imp_spto, trn.cero)), trn.cero) recargos  ,
                NVL(SUM(DECODE(cod_eco, 4 , imp_spto, trn.cero)), trn.cero) iva       ,
                NVL(SUM(DECODE(cod_eco, 5 , imp_spto, trn.cero)), trn.cero) emision   ,
                NVL(SUM(DECODE(cod_eco, 11, imp_spto, trn.cero)), trn.cero) igsci 
           FROM p2100170 a
          WHERE a.cod_cia       = p_cod_cia
            AND a.num_poliza    = p_num_poliza
            AND a.num_riesgo    = g_num_riesgo
            AND a.num_spto     <= p_num_spto
            AND a.num_spto     >= (
                SELECT MAX (b.num_spto)
                  FROM p2000030 b
                 WHERE b.cod_cia       = p_cod_cia
                   AND b.num_poliza    = p_num_poliza
                   AND b.num_apli      = a.num_apli
                   AND b.num_spto_apli = a.num_spto_apli
                   AND b.tip_spto   IN ('RF', 'XX')
                   AND b.num_spto   <= p_num_spto )
            AND a.num_apli      = p_num_apli
            AND a.num_spto_apli = p_num_spto_apli
            AND a.cod_ramo      = p_cod_ramo;         
         --
         l_reg161 c_a2100170%ROWTYPE;
      --
   BEGIN
      --
      --@mx('I','pp_dev_imp_spto_cot');
      --
      OPEN  c_a2100170;
      --
      FETCH c_a2100170 INTO l_reg161;
      CLOSE c_a2100170;
      --
      p_prima_base  := l_reg161.prima_base;  
      p_descuentos  := l_reg161.descuentos;  
      p_recargos    := l_reg161.recargos;  
      p_iva         := l_reg161.iva;  
      p_emision     := l_reg161.emision;  
      p_igsci       := l_reg161.igsci;        
      --
      --@mx('F','pp_dev_imp_spto_cot');
      --
   END pp_dev_imp_spto_cot;   
   --
   /* --------------------------------------------------------
   || pp_dev_imp_spto_r:
   || Devuelve el importe del suplemento para la
   || situacion de la renovacion previa
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_imp_spto_r(p_cod_cia        IN  a2000161.cod_cia   %TYPE,
                               p_cod_ramo       IN  a2000161.cod_ramo  %TYPE,
                               p_num_poliza     IN  a2000161.num_poliza%TYPE,
                               p_prima_base     OUT a2000161.imp_eco   %TYPE,
                               p_recargos       OUT a2000161.imp_eco   %TYPE,
                               p_derechos_admin OUT a2000161.imp_eco   %TYPE,
                               p_bonificaciones OUT a2000161.imp_eco   %TYPE,
                               p_impuestos      OUT a2000161.imp_eco   %TYPE,
                               p_int_frac_pago  OUT a2000161.imp_eco   %TYPE,
                               p_desc_tecnico   OUT a2000161.imp_eco   %TYPE,
                               p_desc_comercial OUT a2000161.imp_eco   %TYPE)
   IS
      --
      CURSOR c_r2000161
      IS
         --
         SELECT NVL(SUM(DECODE(cod_eco, 1 , imp_eco, trn.cero)), trn.cero) prima_base    ,
                NVL(SUM(DECODE(cod_eco, 2 , imp_eco, trn.cero)), trn.cero) recargos      ,
                NVL(SUM(DECODE(cod_eco, 3 , imp_eco, trn.cero)), trn.cero) derechos_admin,
                NVL(SUM(DECODE(cod_eco, 4 , imp_eco, trn.cero)), trn.cero) bonificaciones,
                NVL(SUM(DECODE(cod_eco, 5 , imp_eco, trn.cero)), trn.cero) impuestos     ,
                NVL(SUM(DECODE(cod_eco, 6 , imp_eco, trn.cero)), trn.cero) int_frac_pago ,
                NVL(SUM(DECODE(cod_eco, 7 , imp_eco, trn.cero)), trn.cero) desc_tecnico  ,
                NVL(SUM(DECODE(cod_eco, 8 , imp_eco, trn.cero)), trn.cero) desc_comercial
           FROM r2000161 a
          WHERE a.cod_cia    = p_cod_cia
            AND a.num_poliza = p_num_poliza
            AND a.cod_ramo   = p_cod_ramo;
      --
      l_reg161 c_r2000161%ROWTYPE;
      --
   BEGIN
      --
      --@mx('I','pp_dev_imp_spto_r');
      --
      OPEN  c_r2000161;
      --
      FETCH c_r2000161 INTO l_reg161;
      CLOSE c_r2000161;
      --
      p_prima_base      := l_reg161.prima_base    ;
      p_recargos        := l_reg161.recargos      ;
      p_derechos_admin  := l_reg161.derechos_admin;
      p_bonificaciones  := l_reg161.bonificaciones;
      p_impuestos       := l_reg161.impuestos     ;
      p_int_frac_pago   := l_reg161.int_frac_pago ;
      p_desc_tecnico    := l_reg161.desc_tecnico  ;
      p_desc_comercial  := l_reg161.desc_comercial;
      --
      --@mx('F','pp_dev_imp_spto_r');
      --
   END pp_dev_imp_spto_r;
   --
   /* --------------------------------------------------------
   || pp_dev_info_holder:
   || Obtiene la informacion del policy holder
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_info_holder(p_cod_cia            IN  v1001390.cod_cia           %TYPE,
                                p_tip_docum          IN  v1001390.tip_docum         %TYPE,
                                p_cod_docum          IN  v1001390.cod_docum         %TYPE,
                                p_num_poliza         IN  a2000030.num_poliza        %TYPE,
                                p_num_spto           IN  a2000030.num_spto          %TYPE,
                                p_fec_efec_spto      IN  a1001300.fec_validez       %TYPE,
                                p_nom_completo       OUT v1001390.nom_completo      %TYPE,
                                p_fec_nacimiento     OUT a1001331.fec_nacimiento    %TYPE,
                                p_dom1               OUT a1001300.nom_domicilio1    %TYPE,
                                p_dom2               OUT a1001300.nom_domicilio2    %TYPE,
                                p_dom3               OUT a1001300.nom_domicilio3    %TYPE,
                                p_pob                OUT a1001300.nom_localidad     %TYPE,
                                p_edo                OUT a1000104.nom_estado        %TYPE,
                                p_prov               OUT a1000100.nom_prov          %TYPE,
                                p_cp                 OUT a1001300.cod_postal        %TYPE,
                                p_nom_profesion      OUT g1000100.nom_profesion     %TYPE,
                                p_address            OUT VARCHAR2                        ,
                                p_ape1_tercero       OUT v1001390.ape1_tercero      %TYPE,
                                p_tip_prefijo_nombre OUT v1001390.tip_prefijo_nombre%TYPE,
                                p_cod_tercero        OUT a1001300.cod_tercero       %TYPE)
   IS
      --
      l_reg_dom G_T_DAT_TERCERO;
      --
   BEGIN
      --
      --@mx('I','pp_dev_info_holder');
      --
      l_reg_dom := fp_obtiene_datos_tercero(p_cod_cia       => p_cod_cia       ,
                                            p_tip_docum     => p_tip_docum     ,
                                            p_cod_docum     => p_cod_docum     ,
                                            p_num_poliza    => p_num_poliza    ,
                                            p_num_spto      => p_num_spto      ,
                                            p_fec_efec_spto => p_fec_efec_spto ,
                                            p_num_riesgo    => em.RIESGO_POLIZA);
      --
      p_nom_completo       := l_reg_dom.nom_completo      ;
      p_fec_nacimiento     := l_reg_dom.fec_nacimiento    ;
      p_dom1               := l_reg_dom.nom_domicilio1    ;
      p_dom2               := l_reg_dom.nom_domicilio2    ;
      p_dom3               := l_reg_dom.nom_domicilio3    ;
      p_pob                := l_reg_dom.nom_localidad     ;
      p_edo                := l_reg_dom.nom_estado        ;
      p_prov               := l_reg_dom.nom_prov          ;
      p_cp                 := l_reg_dom.cp                ;
      p_nom_profesion      := l_reg_dom.nom_profesion     ;
      p_tip_prefijo_nombre := l_reg_dom.tip_prefijo_nombre;
      p_ape1_tercero       := l_reg_dom.ape1_tercero      ;
      p_cod_tercero        := l_reg_dom.cod_tercero       ;
      --
      IF     p_dom1 IS NOT NULL
         AND LENGTH(TRIM(p_dom1)) > trn.CERO
      THEN
         --
         p_address    := SUBSTR(p_address || p_dom1, 0, 500);
         --
      END IF;
      --
      IF     p_dom2 IS NOT NULL
         AND LENGTH(TRIM(p_dom2)) > trn.CERO
      THEN
         --
         p_address    := SUBSTR(p_address || fp_separador(p_address, p_dom2, ', ') || p_dom2, 0, 500);
         --
      END IF;
      --
      IF     p_dom3 IS NOT NULL
         AND LENGTH(TRIM(p_dom3)) > trn.CERO
      THEN
         --
         p_address := SUBSTR(p_address || fp_separador(p_address, p_dom3, ', ') || p_dom3, 0, 500);
         --
      END IF;
      --
      IF     p_pob IS NOT NULL
         AND LENGTH(TRIM(p_pob)) > trn.CERO
      THEN
         --
         p_address := SUBSTR(p_address || fp_separador(p_address, p_pob, ', ') || p_pob, 0, 500);
         --
      END IF;
      --
      IF     p_edo IS NOT NULL
         AND LENGTH(TRIM(p_edo)) > trn.CERO
      THEN
         --
         p_address := SUBSTR(p_address || fp_separador(p_address, p_edo, ', ') || p_edo, 0, 500);
         --
      END IF;
      --
      IF     p_prov IS NOT NULL
         AND LENGTH(TRIM(p_prov)) > trn.CERO
      THEN
         --
         p_address := SUBSTR(p_address || fp_separador(p_address, p_prov, ', ') || p_prov, 0, 500);
         --
      END IF;
      --
      IF     p_cp IS NOT NULL
         AND LENGTH(TRIM(p_cp)) > trn.CERO
      THEN
         --
         p_address := SUBSTR(p_address || fp_separador(p_address, p_cp, ', ') || p_cp, 0, 500);
         --
      END IF;
   --
   --@mx('F','pp_dev_info_holder');
   --
   EXCEPTION
      --
      WHEN trn.E_NO_EXISTE
      THEN
         --
         p_nom_completo := ' ';
         --
   END pp_dev_info_holder;
   --
   /* --------------------------------------------------------
   || pp_dev_info_agente:
   || Obtiene la informacion del agente
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_info_agente(p_cod_cia       IN  v1001390.cod_cia     %TYPE,
                                p_num_poliza    IN  a2000030.num_poliza  %TYPE,
                                p_num_spto      IN  a2000030.num_spto    %TYPE,
                                p_fec_efec_spto IN  a1001300.fec_validez %TYPE,
                                p_cod_agt       IN  a1001300.cod_tercero %TYPE,
                                p_nom_completo  OUT v1001390.nom_completo%TYPE,
                                p_nom_canal     OUT a1000723.des_canal3  %TYPE,
                                p_tel_agt       OUT a1001332.tlf_numero  %TYPE,
                                p_email_agt     OUT a1001332.email       %TYPE)
   IS
      --
      l_reg_dom G_T_DAT_TERCERO           ;
      l_cod_canal a1001332.cod_canal3%TYPE;
      --
      FUNCTION fi_nom_canal3(pi_cod_canal3 a1000723.cod_canal3%TYPE)
         RETURN a1000723.des_canal3%TYPE
      IS
         --
         l_nom_canal3 a1000723.des_canal3%TYPE;
         --
         CURSOR c_a1000723
         IS
            --
            SELECT des_canal3
              FROM a1000723 a
             WHERE a.cod_canal3 = pi_cod_canal3
          ORDER BY des_canal3;
         --
      BEGIN
         --
         OPEN c_a1000723;
         --
         FETCH c_a1000723 INTO l_nom_canal3;
         CLOSE c_a1000723;
         --
         RETURN l_nom_canal3;
         --
      END fi_nom_canal3;
      --
   BEGIN
      --
      --@mx('I','pp_dev_info_agente');
      --
      l_reg_dom := fp_obtiene_datos_tercero(p_cod_cia         => p_cod_cia      ,
                                            p_tip_docum       => NULL           ,
                                            p_cod_docum       => NULL           ,
                                            p_num_poliza      => p_num_poliza   ,
                                            p_num_spto        => p_num_spto     ,
                                            p_fec_efec_spto   => p_fec_efec_spto,
                                            p_num_riesgo      => NULL           ,
                                            p_cod_act_tercero => dc.ACT_AGENTE  ,
                                            p_cod_tercero     => p_cod_agt      );
      --
      BEGIN
         --
         dc_k_a1001332.p_lee(p_cod_cia     => p_cod_cia     ,
                             p_cod_agt     => p_cod_agt     ,
                             p_fec_validez => TRUNC(SYSDATE));
         --
         l_cod_canal    := dc_k_a1001332.f_cod_canal3;
         --
      EXCEPTION
         WHEN OTHERS
         THEN
            --
            l_cod_canal := trn.NULO;
            --
         --
      END;
      --
      p_nom_completo := l_reg_dom.nom_completo;
      --
      IF l_cod_canal IS NOT NULL
      THEN
         --
         p_nom_canal     := fi_nom_canal3(l_cod_canal);
         --
      ELSE
         --
         p_nom_canal := trn.nulo;
         --
      END IF;
      --
      p_tel_agt          := l_reg_dom.tlf_numero  ;
      p_email_agt        := l_reg_dom.email       ;
      --
   --@mx('F','pp_dev_info_agente');
   --
   EXCEPTION
      --
      WHEN trn.E_NO_EXISTE
      THEN
         --
         p_nom_completo := ' ';
         --
   END pp_dev_info_agente;
   --
   /* --------------------------------------------------------
   || pp_dev_info_aseg:
   || Obtiene la informacion del asegurado
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_info_aseg(p_cod_cia             IN  v1001390.cod_cia                %TYPE,
                              p_tip_docum           IN  v1001390.tip_docum              %TYPE,
                              p_cod_docum           IN  v1001390.cod_docum              %TYPE,
                              p_num_poliza          IN  a2000030.num_poliza             %TYPE,
                              p_num_spto            IN  a2000030.num_spto               %TYPE,
                              p_fec_efec_spto       IN  a1001300.fec_validez            %TYPE,
                              p_num_riesgo          IN  a1000802.num_riesgo             %TYPE,
                              p_nom_completo        OUT v1001390.nom_completo           %TYPE,
                              p_dom1                OUT a1001300.nom_domicilio1         %TYPE,
                              p_dom2                OUT a1001300.nom_domicilio2         %TYPE,
                              p_dom3                OUT a1001300.nom_domicilio3         %TYPE,
                              p_pob                 OUT a1001300.nom_localidad          %TYPE,
                              p_edo                 OUT a1000104.nom_estado             %TYPE,
                              p_prov                OUT a1000100.nom_prov               %TYPE,
                              p_cp                  OUT a1001300.cod_postal             %TYPE,
                              p_tel                 OUT a1001331.tlf_numero             %TYPE,
                              p_movil               OUT a1001331.tlf_movil              %TYPE,
                              p_dom1_com            OUT a1001331.nom_domicilio1_com     %TYPE,
                              p_dom2_com            OUT a1001331.nom_domicilio2_com     %TYPE,
                              p_dom3_com            OUT a1001331.nom_domicilio3_com     %TYPE,
                              p_email               OUT a1001331.email                  %TYPE,
                              p_txt_1               OUT a1001331.txt_etiqueta1          %TYPE,
                              p_txt_2               OUT a1001331.txt_etiqueta2          %TYPE,
                              p_txt_3               OUT a1001331.txt_etiqueta3          %TYPE,
                              p_txt_4               OUT a1001331.txt_etiqueta4          %TYPE,
                              p_txt_5               OUT a1001331.txt_etiqueta5          %TYPE,
                              p_nom_empresa_com     OUT a1001331.nom_empresa_com        %TYPE,
                              p_atr_domicilio1_com  OUT a1001331.atr_domicilio1_com     %TYPE,
                              p_atr_domicilio2_com  OUT a1001331.atr_domicilio2_com     %TYPE,
                              p_atr_domicilio3_com  OUT a1001331.atr_domicilio3_com     %TYPE, 
                              p_atr_domicilio1      OUT a1001300.atr_domicilio1         %TYPE,
                              p_cod_pais            OUT a1001300.cod_pais               %TYPE,
                              p_cod_estado          OUT a1001331.cod_estado             %TYPE,
                              p_cod_estado_etiqueta OUT p1001331_msv.cod_estado_etiqueta%TYPE,
                              p_cod_prov_etiqueta   OUT p1001331_msv.cod_prov_etiqueta  %TYPE)
   IS
      --
      l_reg_dom G_T_DAT_TERCERO;
      --
   BEGIN
      --
      --@mx('I','pp_dev_info_aseg');
      --
      l_reg_dom := fp_obtiene_datos_tercero(p_cod_cia       => p_cod_cia      ,
                                            p_tip_docum     => p_tip_docum    ,
                                            p_cod_docum     => p_cod_docum    ,
                                            p_num_poliza    => p_num_poliza   ,
                                            p_num_spto      => p_num_spto     ,
                                            p_fec_efec_spto => p_fec_efec_spto,
                                            p_num_riesgo    => p_num_riesgo   );
      --
      p_nom_completo        := l_reg_dom.nom_completo       ;
      p_dom1                := l_reg_dom.nom_domicilio1     ;
      p_dom2                := l_reg_dom.nom_domicilio2     ;
      p_dom3                := l_reg_dom.nom_domicilio3     ;
      p_pob                 := l_reg_dom.nom_localidad      ;
      p_edo                 := l_reg_dom.nom_estado         ;
      p_prov                := l_reg_dom.nom_prov           ;
      p_cp                  := l_reg_dom.cp                 ;
      p_tel                 := l_reg_dom.tlf_numero         ;
      p_movil               := l_reg_dom.tlf_movil          ;
      p_dom1_com            := l_reg_dom.nom_domicilio1_com ;
      p_dom2_com            := l_reg_dom.nom_domicilio2_com ;
      p_dom3_com            := l_reg_dom.nom_domicilio3_com ;
      p_email               := l_reg_dom.email              ;
      p_txt_1               := l_reg_dom.txt_etiqueta1      ;
      p_txt_2               := l_reg_dom.txt_etiqueta2      ;
      p_txt_3               := l_reg_dom.txt_etiqueta3      ;
      p_txt_4               := l_reg_dom.txt_etiqueta4      ;
      p_txt_5               := l_reg_dom.txt_etiqueta5      ;
      p_nom_empresa_com     := l_reg_dom.nom_empresa_com    ;
      p_atr_domicilio1_com  := l_reg_dom.atr_domicilio1_com ;
      p_atr_domicilio2_com  := l_reg_dom.atr_domicilio2_com ;
      p_atr_domicilio3_com  := l_reg_dom.atr_domicilio3_com ;
      p_atr_domicilio1      := l_reg_dom.atr_domicilio1     ; 
      p_cod_pais            := l_reg_dom.cod_pais           ;
      p_cod_estado          := l_reg_dom.cod_estado         ;
      p_cod_estado_etiqueta := l_reg_dom.cod_estado_etiqueta; 
      p_cod_prov_etiqueta   := l_reg_dom.cod_prov_etiqueta  ;       
      --
      g_email_report     := l_reg_dom.email;
      --
   --@mx('F','pp_dev_info_aseg');
   --
   EXCEPTION
      --
      WHEN trn.E_NO_EXISTE
      THEN
         --
         p_nom_completo := ' ';
         --
   END pp_dev_info_aseg;
   --
   /* --------------------------------------------------------
   || pp_dev_info_handler:
   || Obtiene la informacion del usuario que trata la poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_info_benef(p_cod_cia           IN  a2000060.cod_cia           %TYPE,
                               p_num_poliza        IN  a2000060.num_poliza        %TYPE,
                               p_num_spto          IN  a2000060.num_spto          %TYPE,
                               p_num_apli          IN  a2000060.num_apli          %TYPE,
                               p_num_spto_apli     IN  a2000060.num_spto_apli     %TYPE,
                               p_fec_efec_spto     IN  a1001300.fec_validez       %TYPE,
                               p_num_riesgo        IN  a1000802.num_riesgo        %TYPE,
                               p_nom_completo      OUT v1001390.nom_completo      %TYPE,
                               p_pct_participacion OUT a2000060.pct_participacion %TYPE,
                               p_parentesco        OUT a1001344.nom_relac         %TYPE)
   IS
      l_cod_docum a1001399.cod_docum %TYPE;
      l_tip_docum a1001399.tip_docum %TYPE;
      --
      l_reg_benef G_T_DAT_TERCERO;
      --
      CURSOR c_benef_oferta
      IS
         --
         SELECT z.tip_docum, z.cod_docum, z.pct_participacion, (SELECT UPPER(SUBSTR(NOM_RELAC,0,1))||''||
                                                                       LOWER(SUBSTR(NOM_RELAC,2,100)) AS NOM_RELAC
                                                                  FROM A1001344
                                                                 WHERE TIP_RELAC = z.TIP_RELAC)
         FROM p2000031 x, -- Todos los riesgos.
              p2000060 z, -- Terceros de la pO.
                 (SELECT a.num_riesgo        ,
                         a.tip_spto          ,
                         a.mca_baja_riesgo   ,
                         a.fec_efec_riesgo   ,
                         a.num_spto  FROM (-- Seleccion de riesgos en alta
                          SELECT MAX(a.num_spto) num_spto ,
                                 MAX(a.tip_spto) tip_spto ,
                                 a.num_riesgo             ,
                                 a.mca_baja_riesgo        ,
                                 MAX(a.fec_efec_riesgo) fec_efec_riesgo ,
                                 a.cod_cia
                            FROM p2000031 a, p2000030 b
                           WHERE a.cod_cia          = p_cod_cia
                             AND a.num_poliza       = p_num_poliza
                             AND a.num_apli         = p_num_apli
                             AND a.num_spto_apli    = p_num_spto_apli
                             AND a.mca_baja_riesgo  = trn.NO
                             AND a.num_spto        <= p_num_spto
                             AND b.cod_cia          = a.cod_cia
                             AND b.num_poliza       = a.num_poliza
                             AND b.num_spto         = a.num_spto
                             AND b.num_apli         = a.num_apli
                             AND b.num_spto_apli    = a.num_spto_apli
                             AND b.mca_spto_anulado = trn.NO
                            GROUP BY a.num_riesgo      ,
                                     a.mca_baja_riesgo ,
                                     a.cod_cia
                         ) a  WHERE a.num_riesgo NOT IN (-- Riesgos dados de baja
                       SELECT a.num_riesgo
                         FROM p2000031 a,
                             (
                              SELECT t.num_riesgo,  MAX(t.num_spto) num_spto
                                FROM p2000031 t, p2000030 w
                               WHERE t.cod_cia          = p_cod_cia
                                 AND t.num_poliza       = p_num_poliza
                                 AND t.num_spto        <= p_num_spto
                                 AND t.num_apli         = p_num_apli
                                 AND t.num_spto_apli    = p_num_spto_apli
                                 AND w.cod_cia          = t.cod_cia
                                 AND w.num_poliza       = t.num_poliza
                                 AND w.num_spto         = t.num_spto
                                 AND w.num_apli         = t.num_apli
                                 AND w.num_spto_apli    = t.num_spto_apli
                                 AND w.mca_spto_anulado = trn.NO
                            GROUP BY t.num_riesgo
                            ) b  WHERE a.cod_cia         = p_cod_cia
                                   AND a.num_poliza      = p_num_poliza
                                   AND a.num_spto        = p_num_spto
                                   AND a.num_apli        = p_num_apli
                                   AND a.num_spto_apli   = p_num_spto_apli
                                   AND a.num_riesgo      = b.num_riesgo
                         AND  a.mca_baja_riesgo IN (trn.SI, g_k_yes ))
                     AND a.num_spto <= p_num_spto ) y -- Riesgos.
         WHERE x.cod_cia         = p_cod_cia
           AND x.num_poliza      = p_num_poliza
           AND x.num_apli        = p_num_apli
           AND x.num_spto_apli   = p_num_spto_apli
           AND x.num_riesgo      = y.num_riesgo
           AND x.num_spto        = y.num_spto
           AND z.cod_cia         = x.cod_cia
           AND z.num_poliza      = x.num_poliza
           AND z.num_spto        = ( SELECT MAX(t.num_spto)
                                       FROM p2000060 t
                                      WHERE t.cod_cia       = z.cod_cia
                                        AND t.num_poliza    = z.num_poliza
                                        AND t.num_apli      = z.num_apli
                                        AND t.num_spto_apli = z.num_spto_apli
                                        AND t.num_riesgo    = z.num_riesgo
                                        AND t.tip_benef     = z.tip_benef
                                        AND t.tip_docum     = z.tip_docum
                                        AND t.cod_docum     = z.cod_docum
                                        AND t.num_spto     <= p_num_spto )
            AND z.num_riesgo      = x.num_riesgo
            AND z.mca_principal   = trn.NO
            AND z.tip_benef       IN (g_k_tip_benef_vida)
            AND z.num_riesgo      = p_num_riesgo
            AND z.mca_baja        = trn.NO
            AND z.tip_docum       != g_k_tip_doc
            AND z.cod_docum       != g_k_doc_gen             
        ORDER BY x.num_riesgo ASC,  z.mca_principal DESC;      
      --
      CURSOR c_benef
      IS
         --
         SELECT z.tip_docum, z.cod_docum, z.pct_participacion, (SELECT UPPER(SUBSTR(NOM_RELAC,0,1))||''||
                                                                       LOWER(SUBSTR(NOM_RELAC,2,100)) AS NOM_RELAC
                                                                  FROM A1001344
                                                                 WHERE TIP_RELAC = z.TIP_RELAC)
         FROM a2000031 x, -- Todos los riesgos.
              a2000060 z, -- Terceros de la pO.
                 (SELECT a.num_riesgo        ,
                         a.tip_spto          ,
                         a.mca_baja_riesgo   ,
                         a.fec_efec_riesgo   ,
                         a.num_spto  FROM (-- Seleccion de riesgos en alta
                          SELECT MAX(a.num_spto) num_spto ,
                                 MAX(a.tip_spto) tip_spto ,
                                 a.num_riesgo             ,
                                 a.mca_baja_riesgo        ,
                                 MAX(a.fec_efec_riesgo) fec_efec_riesgo ,
                                 a.cod_cia
                            FROM a2000031 a, a2000030 b
                           WHERE a.cod_cia          = p_cod_cia
                             AND a.num_poliza       = p_num_poliza
                             AND a.num_apli         = p_num_apli
                             AND a.num_spto_apli    = p_num_spto_apli
                             AND a.mca_baja_riesgo  = trn.NO
                             AND a.num_spto        <= p_num_spto
                             AND b.cod_cia          = a.cod_cia
                             AND b.num_poliza       = a.num_poliza
                             AND b.num_spto         = a.num_spto
                             AND b.num_apli         = a.num_apli
                             AND b.num_spto_apli    = a.num_spto_apli
                             AND b.mca_spto_anulado = trn.NO
                            GROUP BY a.num_riesgo      ,
                                     a.mca_baja_riesgo ,
                                     a.cod_cia
                         ) a  WHERE a.num_riesgo NOT IN (-- Riesgos dados de baja
                       SELECT a.num_riesgo
                         FROM a2000031 a,
                             (
                              SELECT t.num_riesgo,  MAX(t.num_spto) num_spto
                                FROM a2000031 t, a2000030 w
                               WHERE t.cod_cia          = p_cod_cia
                                 AND t.num_poliza       = p_num_poliza
                                 AND t.num_spto        <= p_num_spto
                                 AND t.num_apli         = p_num_apli
                                 AND t.num_spto_apli    = p_num_spto_apli
                                 AND w.cod_cia          = t.cod_cia
                                 AND w.num_poliza       = t.num_poliza
                                 AND w.num_spto         = t.num_spto
                                 AND w.num_apli         = t.num_apli
                                 AND w.num_spto_apli    = t.num_spto_apli
                                 AND w.mca_spto_anulado = trn.NO
                            GROUP BY t.num_riesgo
                            ) b  WHERE a.cod_cia         = p_cod_cia
                                   AND a.num_poliza      = p_num_poliza
                                   AND a.num_spto        = p_num_spto
                                   AND a.num_apli        = p_num_apli
                                   AND a.num_spto_apli   = p_num_spto_apli
                                   AND a.num_riesgo      = b.num_riesgo
                         AND  a.mca_baja_riesgo IN (trn.SI, g_k_yes ))
                     AND a.num_spto <= p_num_spto ) y -- Riesgos.
         WHERE x.cod_cia         = p_cod_cia
           AND x.num_poliza      = p_num_poliza
           AND x.num_apli        = p_num_apli
           AND x.num_spto_apli   = p_num_spto_apli
           AND x.num_riesgo      = y.num_riesgo
           AND x.num_spto        = y.num_spto
           AND z.cod_cia         = x.cod_cia
           AND z.num_poliza      = x.num_poliza
           AND z.num_spto        = ( SELECT MAX(t.num_spto)
                                       FROM a2000060 t
                                      WHERE t.cod_cia       = z.cod_cia
                                        AND t.num_poliza    = z.num_poliza
                                        AND t.num_apli      = z.num_apli
                                        AND t.num_spto_apli = z.num_spto_apli
                                        AND t.num_riesgo    = z.num_riesgo
                                        AND t.tip_benef     = z.tip_benef
                                        AND t.tip_docum     = z.tip_docum
                                        AND t.cod_docum     = z.cod_docum
                                        AND t.num_spto     <= p_num_spto )
            AND z.num_riesgo      = x.num_riesgo
            AND z.mca_principal   = trn.NO
            AND z.tip_benef       IN (g_k_tip_benef_vida)
            AND z.num_riesgo      = p_num_riesgo
            AND z.mca_baja        = trn.NO
            AND z.tip_docum       != g_k_tip_doc
            AND z.cod_docum       != g_k_doc_gen             
        ORDER BY x.num_riesgo ASC,  z.mca_principal DESC;
   BEGIN
      --
      --@mx('I','pp_dev_info_benef');
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         OPEN c_benef_oferta;
         --
      ELSE
         --
         OPEN c_benef;
         --
      END IF;         
      --
      pp_open_tag('beneficiarios');
      --
      LOOP
         --
         IF g_jbtip_emision = g_k_rep_cotizacion
         THEN
            --
            FETCH c_benef_oferta INTO l_tip_docum        ,
                                      l_cod_docum        ,
                                      p_pct_participacion,
                                      p_parentesco       ;
            --
            EXIT WHEN c_benef_oferta%NOTFOUND;            
            --
         ELSE
            --
            FETCH c_benef INTO l_tip_docum        ,
                               l_cod_docum        ,
                               p_pct_participacion,
                               p_parentesco       ;
            --
            EXIT WHEN c_benef%NOTFOUND;            
            --
         END IF;
         --         
         l_reg_benef := fp_obtiene_datos_tercero(p_cod_cia       => p_cod_cia      ,
                                                 p_tip_docum     => l_tip_docum    ,
                                                 p_cod_docum     => l_cod_docum    ,
                                                 p_num_poliza    => p_num_poliza   ,
                                                 p_num_spto      => p_num_spto     ,
                                                 p_fec_efec_spto => p_fec_efec_spto,
                                                 p_num_riesgo    => p_num_riesgo   );
         --
         p_nom_completo     := l_reg_benef.nom_completo;
         --
         pp_open_tag('beneficiario');
         --
         pp_agrega_tbl('T', 'l_nom_benef'  , p_nom_completo     , TRUE);
         pp_agrega_tbl('T', 'l_porcentaje' , p_pct_participacion, TRUE);
         pp_agrega_tbl('T', 'l_parentesco' , p_parentesco       );
         --
         pp_write_clob(TRUE);
         pp_close_tag('beneficiario');
         --
      END LOOP;
      --
      pp_write_clob(TRUE);
      --
      pp_close_tag('beneficiarios');
      --
      IF c_benef%ISOPEN
      THEN
         --
         CLOSE c_benef;
         --
      END IF;
      --
      IF c_benef_oferta%ISOPEN
      THEN
         --
         CLOSE c_benef_oferta;
         --
      END IF;      
      --
   --@mx('F','pp_dev_info_benef');
   --
   END pp_dev_info_benef;
   --
   /* --------------------------------------------------------
   || pp_dev_inf_cesionario:
   || Obtiene la informacion del cesionario
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_inf_cesionario(p_cod_cia       IN a2000060.cod_cia      %TYPE,
                                   p_num_poliza    IN a2000060.num_poliza   %TYPE,
                                   p_num_spto      IN a2000060.num_spto     %TYPE,
                                   p_num_apli      IN a2000060.num_apli     %TYPE,
                                   p_num_spto_apli IN a2000060.num_spto_apli%TYPE,
                                   p_fec_efec_spto IN a1001300.fec_validez  %TYPE,
                                   p_num_riesgo    IN a1000802.num_riesgo   %TYPE)
   IS
      --
      l_bien_cedido VARCHAR2(100);
      --
      l_cod_docum a1001399.cod_docum %TYPE;
      l_tip_docum a1001399.tip_docum %TYPE;
      --
      l_nom_completo      v1001390.nom_completo      %TYPE;
      l_pct_participacion a2000060.pct_participacion %TYPE;
      l_parentesco        a1001344.nom_relac         %TYPE;
      l_imp_cesion        a2000060.imp_cesion        %TYPE;
      l_fec_vcto_cesion   a2000060.fec_vcto_cesion   %TYPE;
      --
      l_k_txt_costr     CONSTANT VARCHAR2(50) := 'Construcciones por la suma de';
      l_k_txt_contenido CONSTANT VARCHAR2(50) := 'Contenido por la suma de'   ;
      --
      l_bien_construccion VARCHAR2(100);
      l_bien_contenido    VARCHAR2(100);
      --
      l_tot_importe NUMBER;
      --   
      l_reg_benef G_T_DAT_TERCERO;
      --
      CURSOR c_benef_oferta
      IS
         --
         SELECT z.tip_docum, z.cod_docum, z.pct_participacion,z.imp_cesion,z.fec_vcto_cesion, (SELECT NOM_RELAC
                                                                                                 FROM A1001344
                                                                                                WHERE TIP_RELAC = z.TIP_RELAC)
         FROM p2000031 x, -- Todos los riesgos.
              p2000060 z, -- Terceros de la pO.
                 (SELECT a.num_riesgo        ,
                         a.tip_spto          ,
                         a.mca_baja_riesgo   ,
                         a.fec_efec_riesgo   ,
                         a.num_spto  FROM (-- Seleccion de riesgos en alta
                          SELECT MAX(a.num_spto) num_spto ,
                                 MAX(a.tip_spto) tip_spto ,
                                 a.num_riesgo             ,
                                 a.mca_baja_riesgo        ,
                                 MAX(a.fec_efec_riesgo) fec_efec_riesgo ,
                                 a.cod_cia
                            FROM p2000031 a, p2000030 b
                           WHERE a.cod_cia          = p_cod_cia
                             AND a.num_poliza       = p_num_poliza
                             AND a.num_apli         = p_num_apli
                             AND a.num_spto_apli    = p_num_spto_apli
                             AND a.mca_baja_riesgo  = trn.NO
                             AND a.num_spto        <= p_num_spto
                             AND b.cod_cia          = a.cod_cia
                             AND b.num_poliza       = a.num_poliza
                             AND b.num_spto         = a.num_spto
                             AND b.num_apli         = a.num_apli
                             AND b.num_spto_apli    = a.num_spto_apli
                             AND b.mca_spto_anulado = trn.NO
                            GROUP BY a.num_riesgo      ,
                                     a.mca_baja_riesgo ,
                                     a.cod_cia
                         ) a  WHERE a.num_riesgo NOT IN (-- Riesgos dados de baja
                       SELECT a.num_riesgo
                         FROM p2000031 a,
                             (
                              SELECT t.num_riesgo,  MAX(t.num_spto) num_spto
                                FROM p2000031 t, p2000030 w
                               WHERE t.cod_cia          = p_cod_cia
                                 AND t.num_poliza       = p_num_poliza
                                 AND t.num_spto        <= p_num_spto
                                 AND t.num_apli         = p_num_apli
                                 AND t.num_spto_apli    = p_num_spto_apli
                                 AND w.cod_cia          = t.cod_cia
                                 AND w.num_poliza       = t.num_poliza
                                 AND w.num_spto         = t.num_spto
                                 AND w.num_apli         = t.num_apli
                                 AND w.num_spto_apli    = t.num_spto_apli
                                 AND w.mca_spto_anulado = trn.NO
                            GROUP BY t.num_riesgo
                            ) b  WHERE a.cod_cia         = p_cod_cia
                                   AND a.num_poliza      = p_num_poliza
                                   AND a.num_spto        = p_num_spto
                                   AND a.num_apli        = p_num_apli
                                   AND a.num_spto_apli   = p_num_spto_apli
                                   AND a.num_riesgo      = b.num_riesgo
                         AND  a.mca_baja_riesgo IN (trn.SI, g_k_yes ))
                     AND a.num_spto <= p_num_spto ) y -- Riesgos.
         WHERE x.cod_cia         = p_cod_cia
           AND x.num_poliza      = p_num_poliza
           AND x.num_apli        = p_num_apli
           AND x.num_spto_apli   = p_num_spto_apli
           AND x.num_riesgo      = y.num_riesgo
           AND x.num_spto        = y.num_spto
           AND z.cod_cia         = x.cod_cia
           AND z.num_poliza      = x.num_poliza
           AND z.num_spto        = ( SELECT MAX(t.num_spto)
                                       FROM p2000060 t
                                      WHERE t.cod_cia       = z.cod_cia
                                        AND t.num_poliza    = z.num_poliza
                                        AND t.num_apli      = z.num_apli
                                        AND t.num_spto_apli = z.num_spto_apli
                                        AND t.num_riesgo    = z.num_riesgo
                                        AND t.tip_benef     = z.tip_benef
                                        AND t.tip_docum     = z.tip_docum
                                        AND t.cod_docum     = z.cod_docum
                                        AND t.num_spto     <= p_num_spto )
            AND z.num_riesgo      = x.num_riesgo
            AND z.mca_principal   = trn.NO
            AND z.tip_benef       IN (g_k_inf_cesionario)
            AND z.num_riesgo      = p_num_riesgo
            AND z.mca_baja        = trn.NO
            AND z.cod_docum       != g_k_doc_gen
        ORDER BY x.num_riesgo ASC,  z.mca_principal DESC;      
      --
      CURSOR c_benef
      IS
         --
         SELECT z.tip_docum, z.cod_docum, z.pct_participacion,z.imp_cesion,z.fec_vcto_cesion, (SELECT NOM_RELAC
                                                                                                 FROM A1001344
                                                                                                WHERE TIP_RELAC = z.TIP_RELAC)
         FROM a2000031 x, -- Todos los riesgos.
              a2000060 z, -- Terceros de la pO.
                 (SELECT a.num_riesgo        ,
                         a.tip_spto          ,
                         a.mca_baja_riesgo   ,
                         a.fec_efec_riesgo   ,
                         a.num_spto  FROM (-- Seleccion de riesgos en alta
                          SELECT MAX(a.num_spto) num_spto ,
                                 MAX(a.tip_spto) tip_spto ,
                                 a.num_riesgo             ,
                                 a.mca_baja_riesgo        ,
                                 MAX(a.fec_efec_riesgo) fec_efec_riesgo ,
                                 a.cod_cia
                            FROM a2000031 a, a2000030 b
                           WHERE a.cod_cia          = p_cod_cia
                             AND a.num_poliza       = p_num_poliza
                             AND a.num_apli         = p_num_apli
                             AND a.num_spto_apli    = p_num_spto_apli
                             AND a.mca_baja_riesgo  = trn.NO
                             AND a.num_spto        <= p_num_spto
                             AND b.cod_cia          = a.cod_cia
                             AND b.num_poliza       = a.num_poliza
                             AND b.num_spto         = a.num_spto
                             AND b.num_apli         = a.num_apli
                             AND b.num_spto_apli    = a.num_spto_apli
                             AND b.mca_spto_anulado = trn.NO
                            GROUP BY a.num_riesgo      ,
                                     a.mca_baja_riesgo ,
                                     a.cod_cia
                         ) a  WHERE a.num_riesgo NOT IN (-- Riesgos dados de baja
                       SELECT a.num_riesgo
                         FROM a2000031 a,
                             (
                              SELECT t.num_riesgo,  MAX(t.num_spto) num_spto
                                FROM a2000031 t, a2000030 w
                               WHERE t.cod_cia          = p_cod_cia
                                 AND t.num_poliza       = p_num_poliza
                                 AND t.num_spto        <= p_num_spto
                                 AND t.num_apli         = p_num_apli
                                 AND t.num_spto_apli    = p_num_spto_apli
                                 AND w.cod_cia          = t.cod_cia
                                 AND w.num_poliza       = t.num_poliza
                                 AND w.num_spto         = t.num_spto
                                 AND w.num_apli         = t.num_apli
                                 AND w.num_spto_apli    = t.num_spto_apli
                                 AND w.mca_spto_anulado = trn.NO
                            GROUP BY t.num_riesgo
                            ) b  WHERE a.cod_cia         = p_cod_cia
                                   AND a.num_poliza      = p_num_poliza
                                   AND a.num_spto        = p_num_spto
                                   AND a.num_apli        = p_num_apli
                                   AND a.num_spto_apli   = p_num_spto_apli
                                   AND a.num_riesgo      = b.num_riesgo
                         AND  a.mca_baja_riesgo IN (trn.SI, g_k_yes ))
                     AND a.num_spto <= p_num_spto ) y -- Riesgos.
         WHERE x.cod_cia         = p_cod_cia
           AND x.num_poliza      = p_num_poliza
           AND x.num_apli        = p_num_apli
           AND x.num_spto_apli   = p_num_spto_apli
           AND x.num_riesgo      = y.num_riesgo
           AND x.num_spto        = y.num_spto
           AND z.cod_cia         = x.cod_cia
           AND z.num_poliza      = x.num_poliza
           AND z.num_spto        = ( SELECT MAX(t.num_spto)
                                       FROM a2000060 t
                                      WHERE t.cod_cia       = z.cod_cia
                                        AND t.num_poliza    = z.num_poliza
                                        AND t.num_apli      = z.num_apli
                                        AND t.num_spto_apli = z.num_spto_apli
                                        AND t.num_riesgo    = z.num_riesgo
                                        AND t.tip_benef     = z.tip_benef
                                        AND t.tip_docum     = z.tip_docum
                                        AND t.cod_docum     = z.cod_docum
                                        AND t.num_spto     <= p_num_spto )
            AND z.num_riesgo      = x.num_riesgo
            AND z.mca_principal   = trn.NO
            AND z.tip_benef       IN (g_k_inf_cesionario)
            AND z.num_riesgo      = p_num_riesgo
            AND z.mca_baja        = trn.NO
            AND z.cod_docum       != g_k_doc_gen            
        ORDER BY x.num_riesgo ASC,  z.mca_principal DESC;
      --
   BEGIN
      --
      --@mx('I','pp_dev_inf_cesionario');
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         OPEN c_benef_oferta;
         --
      ELSE
         --
         OPEN c_benef;
         --
      END IF;
      --
      pp_open_tag('nom_cesionario');
      --
      LOOP
         --
         IF g_jbtip_emision = g_k_rep_cotizacion
         THEN
            --
            FETCH c_benef_oferta INTO l_tip_docum        ,
                                      l_cod_docum        ,
                                      l_pct_participacion,
                                      l_imp_cesion       ,
                                      l_fec_vcto_cesion  ,
                                      l_parentesco       ;
            --
            EXIT WHEN c_benef_oferta%NOTFOUND;
            --
         ELSE
            --
            FETCH c_benef INTO l_tip_docum        ,
                               l_cod_docum        ,
                               l_pct_participacion,
                               l_imp_cesion       ,
                               l_fec_vcto_cesion  ,
                               l_parentesco       ;
            --
            EXIT WHEN c_benef%NOTFOUND;
            --
         END IF;         
         --
         l_bien_construccion := fp_bien_cedido(p_const     => TRUE     , 
                                               p_cont      => FALSE      , 
                                               p_val_campo => l_cod_docum);                                               
         --
         l_bien_contenido := fp_bien_cedido(p_const     => FALSE    ,
                                            p_cont      => TRUE       , 
                                            p_val_campo => l_cod_docum);
         --                     
         l_tot_importe := TO_NUMBER(NVL(l_bien_construccion,0)) +
                          TO_NUMBER(NVL(l_bien_contenido,0));                                
         --
         l_reg_benef := fp_obtiene_datos_tercero(p_cod_cia       => p_cod_cia      ,
                                                 p_tip_docum     => l_tip_docum    ,
                                                 p_cod_docum     => l_cod_docum    ,
                                                 p_num_poliza    => p_num_poliza   ,
                                                 p_num_spto      => p_num_spto     ,
                                                 p_fec_efec_spto => p_fec_efec_spto,
                                                 p_num_riesgo    => p_num_riesgo   );
         --
         l_nom_completo     := l_reg_benef.nom_completo;
         --
         pp_open_tag('cesionario');
         --
         pp_agrega_tbl('T', 'l_nom_cesionario', l_nom_completo          , FALSE);
         pp_agrega_tbl('T', 'l_porcentaje'    , l_pct_participacion     , TRUE);
         --
         pp_agrega_tbl('T', 'l_parentesco'    , UPPER(SUBSTR(l_parentesco,0,1))||''||
                                                LOWER(SUBSTR(l_parentesco,2,100)), TRUE);
         --                                       
         pp_agrega_tbl('T', 'l_fec_vcto_sec'  , l_fec_vcto_cesion       , TRUE);
         --
         IF l_bien_construccion IS NOT NULL
         THEN
            --
            pp_agrega_tbl('T', 'bien_constr_txt', l_k_txt_costr, FALSE);
            pp_agrega_tbl('T', 'bien_constr'    , g_cod_mon||' '||fp_format(l_bien_construccion) , TRUE);
            --
         END IF;
         --
         IF l_bien_contenido IS NOT NULL
         THEN
            --
            pp_agrega_tbl('T', 'bien_contenido_txt',l_k_txt_contenido , FALSE);
            --
            pp_agrega_tbl('T', 'bien_contenido'    ,g_cod_mon||' '||fp_format(l_bien_contenido), TRUE);
            --
         END IF;         
         --{v 1.12
         pp_agrega_tbl('T', 'imp_cesion', '$ '||fp_format(l_imp_cesion) , TRUE);
         --
         pp_agrega_tbl('T', 'imp_total', g_cod_mon||' '||fp_format(l_tot_importe),TRUE);
         --
         pp_write_clob(TRUE);
         --
         pp_close_tag('cesionario');
         --v 1.12}
      END LOOP;
      --
      pp_write_clob(TRUE);
      --
      pp_close_tag('nom_cesionario');
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         CLOSE c_benef_oferta;
         --
      ELSE
         --
         CLOSE c_benef;
         --
      END IF;
      --
   --@mx('F','pp_dev_inf_cesionario');
   --
   END pp_dev_inf_cesionario;
   --
   /* --------------------------------------------------------
   || pp_dev_info_handler:
   || Obtiene la informacion del usuario que trata la poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_info_handler(p_cod_usr IN  g1010120.cod_usr%TYPE,
                                 p_nom_usr OUT g1010120.nom_usr%TYPE)
   IS
   --
   BEGIN
      --
      --@mx('I','pp_dev_info_handler');
      --
      p_nom_usr := ss_f_g1010120(p_cod_usr).nom_usr;
      --
      --@mx('F','pp_dev_info_handler');
      --
   EXCEPTION
      --
      WHEN trn.E_NO_EXISTE
      THEN
         --
         p_nom_usr := ' ';
         --
   END pp_dev_info_handler;
   --
   /* --------------------------------------------------------
   || pp_dev_clauses:
   || Devuelve las clausulas, primero las de poliza y despues las de riesgo
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_clauses
   IS
      --
      l_count_clausula NUMBER(3) := trn.cero;
      l_index_clasula NUMBER     := trn.cero;
      --
      l_cur_clau  CV_RESULTS;
      l_reg_clau  reg_clause;
      --
      l_nom_clausula     a9990010.nom_clausula    %TYPE;
      l_mca_nivel_poliza a9990010.mca_nivel_poliza%TYPE;
      l_cod_clausula     a9990010.cod_clausula    %TYPE;
      l_nom_seccion      g2999010_msv.nom_seccion %TYPE;
      --
      l_suma_asegurada VARCHAR2(30);
      --
      l_txt_clausula CLOB;
      l_ingresa BOOLEAN := TRUE;
      --
      CURSOR l_c_g2999012_msv(p_mca_sec_clau g2999012_msv.mca_sec_clau%TYPE)
      IS
         --
         SELECT a.*
           FROM g2999012_msv a
          WHERE a.cod_cia      = g_cod_cia
            AND a.cod_ramo     = g_cod_ramo
            AND a.mca_sec_clau = p_mca_sec_clau
          ORDER BY num_secu ASC;      
      --
      l_reg_g2999012 l_c_g2999012_msv%rowtype; 
      --
      CURSOR c_a9990010(p_cod_clausula a9990010.cod_clausula%TYPE)
      IS
         --
         SELECT nom_clausula,
                mca_nivel_poliza,
                cod_clausula
           FROM a9990010
          WHERE cod_clausula = p_cod_clausula
       ORDER BY nom_clausula;
      --
      FUNCTION fi_abre_query
         RETURN CV_RESULTS
      IS
         --
         l_consulta CLOB;
         l_cv_cur   CV_RESULTS;
         --
      BEGIN
         --
         l_consulta := 'SELECT a.cod_clausula, a.num_riesgo ';
         --
         IF g_quotation
         THEN
            --
            l_consulta := l_consulta || ' FROM p2000265 a ';
            --
         ELSE
            --
            l_consulta := l_consulta || ' FROM a2000265 a ';
            --
         END IF;
         --
         l_consulta := l_consulta ||
                       'WHERE a.cod_cia      =  ' || g_cod_cia       ||
                       ' AND a.num_poliza    =  ' || CHR(39) || g_num_poliza || CHR(39) ||
                       ' AND a.num_apli      =  ' || g_num_apli      ||
                       ' AND a.num_spto_apli =  ' || g_num_spto_apli ||
                       ' AND a.num_riesgo    IN ' || '(0, '  || g_num_riesgo  || ')' ||
                       ' AND a.num_spto      =  (SELECT MAX(b.num_spto) ';
         --
         IF g_quotation
         THEN
            --
            l_consulta := l_consulta || ' FROM p2000265 b ';
            --
         ELSE
            --
            l_consulta := l_consulta || ' FROM a2000265 b ';
            --
         END IF;
         --
         l_consulta := l_consulta ||
                       ' WHERE b.cod_cia     = a.cod_cia '       ||
                       ' AND b.num_poliza    = a.num_poliza '    ||
                       ' AND b.num_apli      = a.num_apli '      ||
                       ' AND b.num_spto_apli = a.num_spto_apli ' ||
                       ' AND b.num_riesgo    = a.num_riesgo '    ||
                       ' AND b.num_spto     <= ' || g_num_spto;
         --
         IF NOT g_quotation
         THEN
            --
            l_consulta := l_consulta ||
                          ' AND ''N'' = em_k_jrp_228_emi_msv.f_es_spto_anulado( p_cod_cia   => b.cod_cia    ,' ||
                                                                          ' p_num_poliza    => b.num_poliza ,' ||
                                                                          ' p_num_spto      => b.num_spto   ,' ||
                                                                          ' p_num_apli      => b.num_apli   ,' ||
                                                                          ' p_num_spto_apli => b.num_spto_apli  ) ';
            --
         END IF;
         --
         l_consulta := l_consulta || ' ) ORDER BY a.num_riesgo, a.cod_clausula';
         --
         OPEN l_cv_cur FOR l_consulta;
         --
         RETURN l_cv_cur;
         --
      END fi_abre_query;
      --
      PROCEDURE pi_txt_clausula(p_cod_clausula IN g2999003_msv.txt_valor_maximo%TYPE,
                                p_txt_clausula IN a9990010.nom_clausula        %TYPE)
      IS
      --
      BEGIN
         --
         IF g_reg_clau_espc.COUNT > trn.cero
         THEN
            --
            FOR k IN g_reg_clau_espc.FIRST ..g_reg_clau_espc.LAST
            LOOP
               --
               IF g_reg_clau_espc(k).cod_clausula = p_cod_clausula
               THEN
                  --
                  g_reg_clau_espc(k).txt_clausula := p_txt_clausula;
                  --
                  EXIT;
               --
               END IF;
                --
            END LOOP;
            --
         END IF;
         --
      EXCEPTION 
         WHEN OTHERS 
         THEN
            --
            NULL;
            --
      END pi_txt_clausula;
      --
      PROCEDURE pi_texto_variable(p_cod_clausula  IN  a9990011.cod_clausula  %TYPE,
                                  p_num_poliza    IN  a2990320.num_poliza    %TYPE,
                                  p_num_spto      IN  a2990320.num_spto      %TYPE,
                                  p_num_apli      IN  a2990320.num_apli      %TYPE,
                                  p_num_spto_apli IN  a2990320.num_spto_apli %TYPE,
                                  p_num_riesgo    IN  a2990320.num_riesgo    %TYPE,
                                  p_txt_clausula  OUT CLOB                        )
      IS
         --
         l_nom_tabla_320 VARCHAR2(8);
         l_consulta      CLOB;
         --
         l_num_secu      a9990011.num_secu    %TYPE;
         l_txt_clausula  a9990011.txt_clausula%TYPE;
         --
         l_txt_clausula_salida CLOB;
         --
         c_011_320 CV_RESULTS;
         --
      BEGIN
         --
         IF g_quotation
         THEN
            --
            l_nom_tabla_320 := 'p2990320';
            --
         ELSE
            --
            l_nom_tabla_320 := 'a2990320';
            --
         END IF;
         --
         l_consulta := 'SELECT num_secu, txt_clausula FROM ('                 ||
                       '    SELECT num_secu, txt_clausula'                    ||
                       '      FROM a9990011'                                  ||
                       '     WHERE cod_clausula     = ''' || p_cod_clausula   || '''' ||
                       '       AND mca_txt_variable = ''N'''                  ||
                       '    UNION'                                            ||
                       '    SELECT num_secu, txt_clausula'                    ||
                       '      FROM ' || l_nom_tabla_320                       ||
                       '     WHERE cod_clausula     = ''' || p_cod_clausula   || '''' ||
                       '       AND num_poliza       = ''' || p_num_poliza     || '''' ||
                       '       AND num_spto         = '   || p_num_spto       ||
                       '       AND num_apli         = '   || p_num_apli       ||
                       '       AND num_spto_apli    = '   || p_num_spto_apli  ||
                       '       AND num_riesgo       = '   || p_num_riesgo     ||
                       '   ) ORDER BY num_secu';
         --
         OPEN c_011_320 FOR l_consulta;
         --
         LOOP
            --
            FETCH c_011_320 INTO l_num_secu, l_txt_clausula;
            --
            EXIT WHEN c_011_320%NOTFOUND;
            --
            l_txt_clausula_salida := l_txt_clausula_salida || l_txt_clausula||' ';
            --
         END LOOP;
         --
         CLOSE c_011_320;
         --
         p_txt_clausula := l_txt_clausula_salida;
         p_txt_clausula := REPLACE(p_txt_clausula,CHR(9),' ');
         --
      END pi_texto_variable;
      --
   BEGIN
      --
      --@mx('I','pp_dev_clauses');
      --
      l_cur_clau := fi_abre_query;
      --
      FETCH l_cur_clau INTO l_reg_clau;
      --
      IF l_cur_clau%FOUND
      THEN
         --
         --pp_open_tag('clausulas');
         --
         FOR k in g_l_list_cob.first ..g_l_list_cob.last
         LOOP
            --
            IF g_l_list_cob(k).cod_cob = g_k_2201
            THEN               
               --
               g_sum_aseg_const := g_l_list_cob(k).suma_aseg;               
               --
            ELSE
               --
               g_sum_aseg_contenido := g_l_list_cob(k).suma_aseg;               
               --
            END IF;
            --
         END LOOP;          
         --
         g_sum_aseg_total := nvl(g_sum_aseg_contenido,0)+nvl(g_sum_aseg_const,0);         
         --
         WHILE l_cur_clau%FOUND
         LOOP
            --
            -- Obtener el nombre de Clausula de a9990010
            OPEN  c_a9990010(l_reg_clau.cod_clausula);
            --
            FETCH c_a9990010 INTO l_nom_clausula, l_mca_nivel_poliza,l_cod_clausula;
            CLOSE c_a9990010;
            --
            IF    (l_reg_clau.num_riesgo = trn.CERO AND l_mca_nivel_poliza NOT LIKE trn.NO)
               OR (l_reg_clau.num_riesgo > trn.CERO AND l_mca_nivel_poliza     LIKE trn.NO)
            THEN
               --
               -- Obtener el texto de la clausula
               pi_texto_variable(l_reg_clau.cod_clausula,
                                 g_num_poliza           ,
                                 g_num_spto             ,
                                 g_num_apli             ,
                                 g_num_spto_apli        ,
                                 g_num_riesgo           ,
                                 l_txt_clausula         );
               --
               -- Guarda por separado los textos de las clausulas segun sean a nivel de poliza o de riesgo
               IF     l_reg_clau.num_riesgo = trn.CERO
                  AND l_mca_nivel_poliza NOT LIKE trn.NO
               THEN
                  --
                  l_index_clasula := l_index_clasula+trn.uno;
                  --
                  g_tbl_cob_clau(l_index_clasula).cod_clausula       := l_reg_clau.cod_clausula;
                  g_tbl_cob_clau(l_index_clasula).sum_aseg_const     := NVL(g_sum_aseg_const,0);
                  g_tbl_cob_clau(l_index_clasula).sum_aseg_contenido := NVL(g_sum_aseg_contenido,0);
                  g_tbl_cob_clau(l_index_clasula).sum_aseg_total     := NVL(g_sum_aseg_contenido,0)+NVL(g_sum_aseg_const,0);
                  g_tbl_cob_clau(l_index_clasula).mca_imprime        := trn.si;
                  --
                  pp_clausulas_esp(l_reg_clau.cod_clausula,l_nom_seccion,l_suma_asegurada);
                  --
                  IF g_cod_modalidad = g_k_cobertura_total
                  THEN
                     --
                     pi_txt_clausula(p_cod_clausula => l_cod_clausula,
                                     p_txt_clausula => l_txt_clausula);
                     --
                  END IF;
                  --
               ELSIF   l_reg_clau.num_riesgo > 0
                   AND l_mca_nivel_poliza LIKE trn.NO
               THEN
                  --
                  l_index_clasula := l_index_clasula+trn.uno;
                  --
                  g_tbl_cob_clau(l_index_clasula).cod_clausula       := l_reg_clau.cod_clausula;
                  g_tbl_cob_clau(l_index_clasula).sum_aseg_const     := NVL(g_sum_aseg_const,0);
                  g_tbl_cob_clau(l_index_clasula).sum_aseg_contenido := NVL(g_sum_aseg_contenido,0);
                  g_tbl_cob_clau(l_index_clasula).sum_aseg_total     := NVL(g_sum_aseg_contenido,0)+NVL(g_sum_aseg_const,0);
                  g_tbl_cob_clau(l_index_clasula).mca_imprime        := trn.si;
                  --
                  pp_clausulas_esp(l_reg_clau.cod_clausula,l_nom_seccion,l_suma_asegurada);
                  --
                  IF g_cod_modalidad = g_k_cobertura_total
                  THEN
                     --
                     pi_txt_clausula(p_cod_clausula => l_cod_clausula,
                                     p_txt_clausula => l_txt_clausula); 
                     --
                  END IF;              
                  --
               END IF;
               --
            END IF;
            --
            FETCH l_cur_clau INTO l_reg_clau;
            --
         END LOOP;
         --
      END IF;
      --
      CLOSE l_cur_clau;
      --
      pp_open_tag('clausulas');
      --
      IF g_tbl_cob_clau.COUNT > trn.cero
      THEN
         --
         OPEN l_c_g2999012_msv('S');
         LOOP
            --
            FETCH l_c_g2999012_msv INTO l_reg_g2999012;
            EXIT WHEN l_c_g2999012_msv%NOTFOUND;
            --
            FOR k in g_tbl_cob_clau.first.. g_tbl_cob_clau.last
            LOOP
               --
               IF g_tbl_cob_clau(k).cod_clausula = l_reg_g2999012.cod_clausula
               THEN
                  --
                  l_count_clausula := l_count_clausula + trn.uno;
                  --
                  pp_open_tag('clausula'||' cod="'||l_reg_g2999012.cod_clausula||' "');
                  pp_agrega_tbl('T' , 'index_clau'   , l_count_clausula);     
                  --             
                  IF l_reg_g2999012.cod_clausula = 'TRON228-020'
                  THEN
                     --
                     pp_agrega_tbl('T' , 'nom_clausula' , l_reg_g2999012.txt_seccion, TRUE);
                     --
                  ELSE
                     -- 
                     pp_agrega_tbl('T' , 'nom_clausula' , l_reg_g2999012.txt_seccion);
                     --
                  END IF;
                  --
                  IF l_reg_g2999012.mca_aplica_calculo = trn.NO
                  THEN
                     --
                     pp_agrega_tbl('T' , 'sum_aseg' ,l_reg_g2999012.vlr_fijo);
                     --
                  ELSE
                     --
                     IF l_reg_g2999012.COBERTURA = g_k_total
                     THEN
                        --
                        pp_agrega_tbl('T' , 'sum_aseg' ,'$'||fp_format((g_tbl_cob_clau(k).sum_aseg_total*l_reg_g2999012.pct_cal)/100));
                        --
                     ELSIF l_reg_g2999012.COBERTURA = g_k_construccion
                     THEN
                        --
                        pp_agrega_tbl('T' , 'sum_aseg' ,'$'||fp_format((g_tbl_cob_clau(k).sum_aseg_const*l_reg_g2999012.pct_cal)/100));
                        --
                     ELSIF l_reg_g2999012.COBERTURA = g_k_contenido
                     THEN
                        --
                        pp_agrega_tbl('T' , 'sum_aseg' ,'$'||fp_format((g_tbl_cob_clau(k).sum_aseg_contenido*l_reg_g2999012.pct_cal)/100));                           
                        --
                     ELSE
                        --
                        pp_agrega_tbl('T' , 'sum_aseg' ,'');
                        --
                     END IF;
                     --
                  END IF;
                  --
                  --pp_agrega_tbl('T' , 'sum_aseg' ,l_suma_asegurada);
                  --
                  pp_write_clob(TRUE);
                  pp_close_tag('clausula');
                  --
                  EXIT;
                  --
               END IF;
               --
            END LOOP; 
            --
         END LOOP;
         --
         CLOSE l_c_g2999012_msv;
         --
         l_count_clausula := trn.cero;
         --   
         OPEN l_c_g2999012_msv('N');
         LOOP
            --
            FETCH l_c_g2999012_msv INTO l_reg_g2999012;
            EXIT WHEN l_c_g2999012_msv%NOTFOUND;
            --
            IF  l_reg_g2999012.num_secu = trn.UNO
            AND (g_sum_aseg_contenido = TRN.CERO OR g_sum_aseg_contenido IS NULL)
            THEN
               --
               NULL;
               --
            ELSE
               --
               pp_open_tag('clausula');
               --
               IF l_ingresa
               THEN
                  --
                  l_nom_seccion := l_reg_g2999012.nom_seccion; 
                  pp_agrega_tbl('T' , 'nom_seccion' ,UPPER(l_nom_seccion));              
                  l_ingresa := FALSE;
                  --
               END IF;
               --
               IF l_nom_seccion != l_reg_g2999012.nom_seccion
               THEN
                  --
                  l_nom_seccion := l_reg_g2999012.nom_seccion;
                  --
                  pp_agrega_tbl('T' , 'nom_seccion' ,UPPER(l_nom_seccion));
                  --
                  l_count_clausula := trn.cero;
                  --
               END IF;
               --
               l_count_clausula := l_count_clausula+trn.uno;
               --
               pp_agrega_tbl('T' , 'index_clau'   ,l_count_clausula);
               pp_agrega_tbl('T' , 'nom_clausula' ,l_reg_g2999012.txt_seccion);                        
               --
               IF l_reg_g2999012.mca_aplica_calculo = trn.NO
               THEN
                  --
                  pp_agrega_tbl('T' , 'sum_aseg' ,l_reg_g2999012.vlr_fijo);
                  --
               ELSE
                  --
                  IF  l_reg_g2999012.num_secu = trn.UNO
                  THEN
                     --
                      pp_agrega_tbl('T' , 'sum_aseg' ,'$'||fp_format((g_sum_aseg_contenido*l_reg_g2999012.pct_cal)/100)); 
                     --
                  ELSE
                     --
                      pp_agrega_tbl('T' , 'sum_aseg' ,'$'||fp_format((g_sum_aseg_total*l_reg_g2999012.pct_cal)/100)); 
                     --
                  END IF;                              
                  --
               END IF;                                    
               --
               pp_write_clob(TRUE);
               pp_close_tag('clausula'); 
               --              
            END IF;
            --
         END LOOP;
         --
      END IF;
      --
      g_sum_aseg_const     := trn.cero;
      g_sum_aseg_contenido := trn.cero;
      g_sum_aseg_total     := trn.cero;                 
      --      
      pp_write_clob(TRUE);
      pp_close_tag('clausulas');           
      --
      --@mx('F','pp_dev_clauses');
      --
   END pp_dev_clauses;
   --
   /* --------------------------------------------------------
   || pp_dev_coberturas_pln_tr:
   || Busca las coberturas de la p0liza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_coberturas_pln_tr(p_num_riesgo a2000060.num_riesgo%TYPE)
   IS
      --
      l_vlr_fijo         VARCHAR2(15);
      l_txt_suma_aseg    VARCHAR2(50);
      l_deducible_txt    VARCHAR2(60);
      l_txt_nombre_sec   VARCHAR2(80);
      l_deducible_pln_tr VARCHAR2(80);
      --
      l_val_franquicia_min  a2000040.val_franquicia_min %TYPE;
      l_val_franquicia_max  a2000040.val_franquicia_max %TYPE;
      l_tip_cob             a1002050.tip_cob            %TYPE;
      l_cod_mon_cap         a2000040.cod_mon_capital    %TYPE;
      l_cod_cob             a1002050.cod_cob            %TYPE;
      l_tasa_cob            a2000040.tasa_cob           %TYPE;
      l_nom_cob             a1002050.nom_cob            %TYPE;
      l_num_secu            a2000040.num_secu           %TYPE;      
      l_suma_aseg           x2000040.suma_aseg          %TYPE;
      l_suma_aseg_spto      x2000040.suma_aseg          %TYPE;
      l_num_poliza_anterior a2000030.num_poliza_anterior%TYPE;
      --
      l_tasa_cob_total  a2000040.tasa_cob%TYPE  := trn.cero; 
      l_suma_aseg_total a2000040.suma_aseg%TYPE := trn.cero;      
      --
      l_cod_franquicia a2000040.cod_franquicia %TYPE;
      l_tip_franquicia A2100700.tip_franquicia %TYPE;
      l_cod_ramo       a2000040.cod_ramo       %TYPE;
      l_deducible      a2000040.suma_aseg      %TYPE;
      l_pre_valor      g1010031.nom_valor      %TYPE;
      --
      l_count_cob_2     NUMBER := trn.cero;
      l_count_cob       NUMBER := trn.cero;
      l_suma_cob_pln_tr NUMBER := trn.cero;
      l_index_count     NUMBER := trn.cero;
      l_index_clau      NUMBER := trn.cero;
      l_secuencia       NUMBER := trn.cero;
      l_cod_mod         NUMBER := 99999   ;
      --
      l_mca_baja_ries a2000031.mca_baja_riesgo%TYPE;
      --
      l_cur_riesgo CV_RESULTS;
      l_consulta   CLOB      ;
      l_cur_cob    CV_RESULTS;
      --
      l_existe_riesgo BOOLEAN;
      --
      l_ingresa       BOOLEAN := TRUE;
      --
      C_TIP_FRAN_DIAS A2100700.tip_franquicia %TYPE  := trn.uno;
      --
      CURSOR l_c_g2999010_msv
      IS
         --
         SELECT * 
           FROM g2999010_msv a
          ORDER BY a.num_orden ASC;
      --     
      l_reg_g2999010_msv l_c_g2999010_msv%ROWTYPE;      
      --
      CURSOR l_c_franquicia(p_cod_franquicia a2100700.cod_franquicia%TYPE)
      IS
         --
         SELECT b.nom_valor
           FROM a2100700 a,
                g1010031 b
          WHERE a.cod_franquicia = p_cod_franquicia
            AND a.cod_mon   = (SELECT cod_mon
                                 FROM a2000030 c
                                WHERE c.num_poliza    = g_num_poliza
                                  AND c.cod_cia       = g_cod_cia
                                  AND c.num_spto      = g_num_spto
                                  AND c.num_apli      = g_num_apli
                                  AND c.num_spto_apli = g_num_spto_apli
                                  AND c.cod_ramo      = g_cod_ramo)
           AND b.cod_valor  = TO_CHAR(a.tip_franquicia)
           AND b.cod_campo  = 'TIP_FRANQUICIA'
           AND b.cod_idioma = g_cod_idioma;
      --
      CURSOR l_c_franquicia_p(p_cod_franquicia a2100700.cod_franquicia%TYPE)
      IS
         --
         SELECT b.nom_valor
           FROM a2100700 a,
                g1010031 b
          WHERE a.cod_franquicia = p_cod_franquicia
            AND a.cod_mon   = (SELECT cod_mon
                                 FROM p2000030 c
                                WHERE c.num_poliza    = g_num_poliza
                                  AND c.cod_cia       = g_cod_cia
                                  AND c.num_spto      = g_num_spto
                                  AND c.num_apli      = g_num_apli
                                  AND c.num_spto_apli = g_num_spto_apli
                                  AND c.cod_ramo      = g_cod_ramo)
           AND b.cod_valor  = TO_CHAR(a.tip_franquicia)
           AND b.cod_campo  = 'TIP_FRANQUICIA'
           AND b.cod_idioma = g_cod_idioma;      
      --
      FUNCTION fi_estado_riesgo(pi_cod_cia       a2000031.cod_cia      %TYPE,
                                pi_num_poliza    a2000031.num_poliza   %TYPE,
                                pi_num_spto      a2000031.num_spto     %TYPE,
                                pi_num_apli      a2000031.num_apli     %TYPE,
                                pi_num_spto_apli a2000031.num_spto_apli%TYPE,
                                pi_num_riesgo    a2000031.num_riesgo   %TYPE)
         RETURN CV_RESULTS
      IS
         --
         li_consulta CLOB      ;
         li_cv_cob   CV_RESULTS;
         --
      BEGIN
         --
         li_consulta := 'select mca_baja_riesgo';
         --
         IF g_quotation
         THEN
            --
            li_consulta := li_consulta || ' FROM p2000031 a ';
            --
         ELSE
            --
            li_consulta := li_consulta || ' FROM a2000031 a ';
            --
         END IF;
         --
         li_consulta := li_consulta ||
                       'WHERE a.cod_cia     = '   ||pi_cod_cia    ||''                                                        ||
                            '  AND a.num_poliza  = ''' ||pi_num_poliza || ''' '                                                   ||
                            '  AND (a.num_spto)  = (SELECT MAX(c.num_spto)'                                                       ||
                                                   ' FROM a2000031 c '                                                           ||
                                                   'WHERE a.cod_cia          = c.cod_cia '                                       ||
                                                      ' AND a.num_poliza       = c.num_poliza '                                    ||
                                                      ' AND a.num_apli         = c.num_apli '                                      ||
                                                      ' AND a.num_riesgo       = c.num_riesgo '                                    ||
                                                      ' AND c.num_spto        <= NVL('||pi_num_spto      ||'     ,c.num_spto     )'||
                                                      ' AND c.num_spto_apli   <= NVL('||pi_num_spto_apli ||',c.num_spto_apli)     '||
                                                      ') '                                                                         ||
                            '  AND a.num_apli     = NVL('||pi_num_apli   ||'   ,a.num_apli     )  '                               ||
                            '  AND a.num_riesgo   = '|| pi_num_riesgo ||'   '                                                     ||
                            ' '
                              ;
         OPEN li_cv_cob FOR li_consulta;
         --
         RETURN li_cv_cob;
         --
      END fi_estado_riesgo;
      --
      FUNCTION fp_ver_spto_riesgo
         RETURN BOOLEAN      
      IS
         CURSOR l_c_a2000031
         IS
            --
            SELECT *
              FROM a2000031 a
             WHERE a.num_poliza      = g_num_poliza
               AND a.num_spto        = g_num_spto
               AND a.num_apli        = trn.cero
               AND a.num_spto_apli   = trn.cero
               AND a.mca_baja_riesgo = trn.no
               AND a.mca_vigente     = trn.si
               AND a.tip_spto        = g_k_ad
               AND a.num_riesgo      = g_num_riesgo
               and a.num_spto        > trn.cero;
            --
         --
         l_reg_a2000031 l_c_a2000031%ROWTYPE;
         l_existe BOOLEAN;
         --   
      BEGIN
         --
         OPEN l_c_a2000031; 
         FETCH l_c_a2000031 INTO l_reg_a2000031;
         --
         l_existe := l_c_a2000031%FOUND;
         CLOSE l_c_a2000031;
         --
         RETURN l_existe; 
         --
      END fp_ver_spto_riesgo;       
      --
   BEGIN
      --
      --@mx('I','pp_dev_coberturas_pln_tr');
      --
      l_cur_riesgo := fi_estado_riesgo(g_cod_cia      ,
                                       g_num_poliza   ,
                                       g_num_spto     ,
                                       g_num_apli     ,
                                       g_num_spto_apli,
                                       g_num_riesgo   );
      --
      FETCH l_cur_riesgo INTO l_mca_baja_ries;
      --
      l_consulta := 'SELECT DISTINCT a.cod_mon_capital,a.cod_cob, b.nom_cob,NVL(a.suma_aseg,0),' ||
                              'val_franquicia_min,val_franquicia_max,a.tasa_cob,a.num_secu, NVL(a.cod_franquicia,0), a.cod_ramo, b.tip_cob,' ||
                              'NVL(a.suma_aseg_spto,0) ';
      --
      IF g_quotation
      THEN
         --
         l_consulta := l_consulta || ' FROM p2000040 a, a1002050 b';
         --
      ELSE
         --
         l_consulta := l_consulta || ' FROM a2000040 a, a1002050 b';
         --
      END IF;
      --   
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         l_consulta := l_consulta || ' WHERE a.cod_cia   = b.cod_cia'                                  ||
                                 ' AND a.cod_cob         = b.cod_cob'                                  ||
                                 ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                 ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                 ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                               'FROM p2000040 c                       '||
                                                             'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                               'AND ' ||g_num_spto||' >= c.num_spto)   '||
                                 ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                 ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                 ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ||
                                 ' AND a.mca_baja_riesgo = '''||trn.NO||''''                           ||
                                 ' AND a.mca_baja_cob    = '''||trn.NO||''''                           ;   
         --
      ELSE
         --
         l_existe_riesgo := fp_ver_spto_riesgo;
         --
         IF     l_mca_baja_ries  = trn.SI
            AND l_existe_riesgo
         THEN
            --
            l_consulta := l_consulta ||' WHERE a.cod_cia    = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                  'AND ' ||g_num_spto||' >= c.num_spto)   '||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ;
         --
         ELSIF NOT l_existe_riesgo 
           AND l_mca_baja_ries = trn.SI
           AND g_tip_spto = g_k_ad
           AND g_num_riesgos > 1           
         THEN
            --
            l_consulta := l_consulta ||' WHERE a.cod_cia    = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                 'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                   'AND c.num_spto < ' ||g_num_spto||'  ) '||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ;       
         --
         ELSIF NOT l_existe_riesgo 
           AND l_mca_baja_ries = trn.no
           AND g_tip_spto = g_k_ad
           AND g_num_riesgos > 1
         THEN
            --
            l_consulta := l_consulta || ' WHERE a.cod_cia   = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                  'AND c.num_spto < ' ||g_num_spto||'   )'||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ||
                                    ' AND a.mca_baja_riesgo = '''||trn.NO||''''                           ||
                                    ' AND a.mca_baja_cob    = '''||trn.NO||''''                           ;        
         ELSE
            --         
            l_consulta := l_consulta || ' WHERE a.cod_cia   = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                  'AND ' ||g_num_spto||' >= c.num_spto)   '||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ||
                                    ' AND a.mca_baja_riesgo = '''||trn.NO||''''                           ||
                                    ' AND a.mca_baja_cob    = '''||trn.NO||''''                           ;
            --
         END IF;
         --
      END IF;  
      --
      l_consulta := l_consulta || ' ORDER BY a.num_secu ';
      --
      OPEN l_cur_cob FOR l_consulta;
      --
      g_reg_clau_espc.DELETE;
      g_reg_pln_trad.DELETE;
      --
      LOOP
         --
         FETCH l_cur_cob INTO l_cod_mon_cap       ,
                              l_cod_cob           ,
                              l_nom_cob           ,
                              l_suma_aseg         ,
                              l_val_franquicia_min,
                              l_val_franquicia_max,
                              l_tasa_cob          ,
                              l_num_secu          ,
                              l_cod_franquicia    ,
                              l_cod_ramo          ,
                              l_tip_cob           ,
                              l_suma_aseg_spto    ;
         --
         EXIT WHEN l_cur_cob%NOTFOUND;        
         --
         l_deducible := 0.00;
         --
         IF l_cod_franquicia > trn.CERO
         THEN
            --
            l_cod_mod := g_cod_modalidad;
            --
            EM_K_A2100700.p_lee( g_cod_cia, l_cod_mon_cap, l_cod_franquicia);
            l_tip_franquicia := EM_K_A2100700.f_tip_franquicia              ;
            l_deducible      := em_k_a2100700.f_val_franquicia              ;
            --
            BEGIN
               --
               IF g_jbtip_emision = g_k_rep_cotizacion
               THEN
                  --
                  OPEN  l_c_franquicia_p(l_cod_franquicia);
                  FETCH l_c_franquicia_p INTO l_pre_valor;
                  CLOSE l_c_franquicia_p;                  
                  --
               ELSE
                  --
                  OPEN  l_c_franquicia(l_cod_franquicia);
                  FETCH l_c_franquicia INTO l_pre_valor;
                  CLOSE l_c_franquicia;
                  --
               END IF;
               --
            EXCEPTION
               --
               WHEN OTHERS
               THEN
                  --
                  l_pre_valor := '%';
            END;
            --
         ELSE
            --
            l_deducible := trn.nulo;
            --
         END IF;
         --
         dc_k_a1000400.p_lee(l_cod_mon_cap);
         --
         dc_k_a1001800.p_lee(p_cod_cia => g_cod_cia  ,
                             p_cod_ramo => g_cod_ramo);
         --
         IF l_mca_baja_ries = trn.SI
         THEN
            --
            l_suma_aseg := l_suma_aseg_spto * 1;
            --
         END IF;
         --
         l_txt_suma_aseg := l_suma_aseg;--'INCLUIDA';
         --
         IF    l_suma_aseg <> trn.CERO
            OR l_tip_cob = em.TIP_COB_SERVICIO
         THEN
            --
            l_index_clau := l_index_clau+trn.uno;
            --
            g_reg_clau_espc(l_index_clau).cod_cob := l_cod_cob;
            g_reg_clau_espc(l_index_clau).nom_cob := l_nom_cob;
            --
            g_reg_pln_trad(l_index_clau).cod_cob := l_cod_cob;
            g_reg_pln_trad(l_index_clau).nom_cob := l_nom_cob;
            --
            IF l_cod_cob IN(g_k_2201,g_k_2241)
            THEN
               --
               l_index_count := l_index_count+trn.uno;
               --
               g_l_list_cob(l_index_count).cod_cob   := l_cod_cob  ;
               g_l_list_cob(l_index_count).suma_aseg := l_suma_aseg;
               --
            END IF;
            --
            IF l_tip_cob = em.TIP_COB_SERVICIO
            THEN
               --
               g_reg_pln_trad(l_index_clau).nom_moneda := '';
               g_reg_pln_trad(l_index_clau).cob_limite := 'INCLUIDA';             
               --
            ELSE
               --
               IF dc_k_a1000400.f_nom_mon LIKE g_k_dolar
               THEN
                  --
                  g_reg_pln_trad(l_index_clau).nom_moneda := dc_k_a1000400.f_cod_mon_iso;
                  --
                  g_reg_clau_espc(l_index_clau).suma_aseg := g_signo_moneda||'.'|| fp_format(l_txt_suma_aseg);
                  --
                  g_reg_clau_espc(l_index_clau).cod_clausula := fp_dev_cod_clau(l_cod_cob);
                  --
                  g_reg_pln_trad(l_index_clau).cob_limite := l_txt_suma_aseg;--g_signo_moneda||'.'|| dc_k_a1000400.f_importe_fmt_dec(l_txt_suma_aseg);
                  --
                  IF l_deducible IS NOT NULL
                  THEN
                     --
                     IF l_pre_valor = g_k_imp
                     THEN 
                        --
                        l_deducible_txt := l_deducible_txt||g_signo_moneda||' '||l_deducible;
                        --
                     ELSE
                        --
                        l_deducible_txt := l_deducible_txt||l_deducible||' '||l_pre_valor;
                        --
                     END IF;                     
                     --
                     g_reg_clau_espc(l_index_clau).cod_franquicia   := l_deducible||' '||l_pre_valor;
                     g_reg_clau_espc(l_index_clau).aplica_deducible := TRN.SI;
                     --
                  END IF;
                  --
                  IF l_val_franquicia_min IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);
                     --
                     g_reg_clau_espc(l_index_clau).val_franquicia_min := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);
                     --
                  END IF;
                  --
                  IF l_val_franquicia_max IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' max $ '||fp_format(l_val_franquicia_max);
                     --
                  END IF;                    
                  --
                  IF l_deducible_txt IS NULL                  
                  THEN
                     --                     
                     l_deducible_txt := 'Ninguno';
                     --
                  END IF;
                  -- 
                  g_reg_pln_trad(l_index_clau).deducible_txt := l_deducible_txt;                                 
                  --
                  l_deducible_txt := trn.nulo;
                  --
               ELSIF dc_k_a1000400.f_nom_mon LIKE g_k_dolar
               THEN
                  --
                  g_reg_pln_trad(l_index_clau).nom_moneda := dc_k_a1000400.f_cod_mon_iso;
                  --
                  g_reg_clau_espc(l_index_clau).suma_aseg := g_signo_moneda||'.'|| fp_format(l_txt_suma_aseg);
                  --
                  g_reg_clau_espc(l_index_clau).cod_clausula := fp_dev_cod_clau(l_cod_cob);                  
                  --
                  g_reg_pln_trad(l_index_clau).cob_limite := l_txt_suma_aseg;
                  --
                  IF l_deducible IS NOT NULL
                  THEN
                     --
                     IF l_pre_valor = g_k_imp
                     THEN 
                        --
                        l_deducible_txt := l_deducible_txt||g_signo_moneda||' '||l_deducible;
                        --
                     ELSE
                        --
                        l_deducible_txt := l_deducible_txt||l_deducible||' '||l_pre_valor;
                        --
                     END IF;
                     --
                     g_reg_clau_espc(l_index_clau).cod_franquicia   := l_deducible||' '||l_pre_valor;
                     g_reg_clau_espc(l_index_clau).aplica_deducible := TRN.SI;                     
                     --
                  END IF;
                  --
                  IF l_val_franquicia_min IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);
                     --
                     g_reg_clau_espc(l_index_clau).val_franquicia_min := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);                     
                     --
                  END IF;
                  --
                  IF l_val_franquicia_max IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' max $ '||fp_format(l_val_franquicia_max);
                     --
                  END IF;                    
                  --
                  IF l_deducible_txt IS NULL
                  THEN
                     --
                     l_deducible_txt := 'Ninguno';
                     --
                  END IF;
                  --
                  g_reg_pln_trad(l_index_clau).deducible_txt := l_deducible_txt;                   
                  --
                  l_deducible_txt := trn.nulo;
                  --
                  l_tip_franquicia := TRN.NULO;
                  l_pre_valor      := TRN.NULO;
                  --
               END IF;
               --
               l_suma_aseg_total := l_suma_aseg_total+l_txt_suma_aseg;
               --
               l_tasa_cob_total := l_tasa_cob_total+l_tasa_cob;
               --
            END IF;
            --
         END IF;
         --
         g_reg_pln_trad(l_index_clau).mca_imprime := TRN.SI;
         --
      END LOOP;
      --
      CLOSE l_cur_cob;
      --
      FOR k in g_l_list_cob.first ..g_l_list_cob.last
      LOOP
         --
         IF g_l_list_cob(k).cod_cob = g_k_2201
         THEN               
            --
            g_sum_aseg_const := g_l_list_cob(k).suma_aseg;               
            --
         ELSE
            --
            g_sum_aseg_contenido := g_l_list_cob(k).suma_aseg;               
            --
         END IF;
         --
      END LOOP;          
      --
      g_sum_aseg_total := nvl(g_sum_aseg_contenido,0)+nvl(g_sum_aseg_const,0);      
      --
      l_index_clau  := trn.cero;
      l_index_count := trn.cero; 
      --
      pp_open_tag('coberturas');
      --
      IF g_reg_pln_trad.COUNT > trn.cero
      THEN
         --
         OPEN l_c_g2999010_msv;
         LOOP
            --
            FETCH l_c_g2999010_msv INTO l_reg_g2999010_msv;
            EXIT WHEN l_c_g2999010_msv%NOTFOUND;
            --
            FOR i IN g_reg_pln_trad.FIRST ..g_reg_pln_trad.LAST
            LOOP             
               --
               IF g_reg_pln_trad(i).cod_cob IN (l_reg_g2999010_msv.cob_rel_uno,l_reg_g2999010_msv.cob_rel_dos)
               THEN
                  --
                  IF g_reg_pln_trad(i).cob_limite = 'INCLUIDA'
                  THEN
                     --
                     g_reg_pln_trad(i).mca_imprime := trn.no;
                     --
                  ELSE
                     --
                     IF l_reg_g2999010_msv.mca_aplica_calculo = trn.si
                     THEN
                        --
                        IF l_reg_g2999010_msv.cobertura = g_k_construccion
                        THEN
                           --
                           l_suma_cob_pln_tr := ((g_sum_aseg_const * l_reg_g2999010_msv.pct_cal)/100);
                           --
                        ELSIF l_reg_g2999010_msv.cobertura = g_k_contenido
                        THEN
                           --
                           l_suma_cob_pln_tr := ((g_sum_aseg_contenido * l_reg_g2999010_msv.pct_cal)/100);
                           --
                        ELSIF l_reg_g2999010_msv.cobertura = g_k_total
                        THEN
                           --
                           l_suma_cob_pln_tr := ((g_sum_aseg_total * l_reg_g2999010_msv.pct_cal)/100);
                           --
                        END IF;
                        --
                     ELSE
                        --
                        l_vlr_fijo := l_reg_g2999010_msv.vlr_fijo;
                        --
                     END IF;
                     --
                     --l_suma_cob_pln_tr  := l_suma_cob_pln_tr + TO_NUMBER(g_reg_pln_trad(i).cob_limite);
                     l_deducible_pln_tr := l_reg_g2999010_msv.txt_deducible;--g_reg_pln_trad(i).deducible_txt;
                     g_reg_pln_trad(i).mca_imprime := trn.no;                     
                     --
                  END IF;
                  --
                  EXIT;
                  --
               END IF;                 
               --
            END LOOP;            
            --
            IF l_deducible_pln_tr IS NOT NULL               
            THEN
               --
               IF l_secuencia <= l_reg_g2999010_msv.num_secu
               THEN
                  --
                  l_secuencia := l_reg_g2999010_msv.num_secu;
                  --
               END IF;               
               --
               l_count_cob := l_count_cob + trn.uno;
               --
               IF l_ingresa
               THEN
                  --
                  l_secuencia := l_reg_g2999010_msv.num_secu;
                  l_ingresa := FALSE;
                  --
               END IF;
               --
               IF l_secuencia = l_reg_g2999010_msv.num_secu
               THEN 
                  --
                  pp_agrega_tbl('T' ,'nom_seccion',UPPER(l_reg_g2999010_msv.nom_seccion),FALSE);
                  l_secuencia := l_secuencia +trn.uno;
                  l_count_cob := trn.uno;
                  --
               END IF;
               --
               pp_open_tag('pol_cob');
               --
               pp_agrega_tbl('I' , 'index_cob'   , l_count_cob||') ');
               pp_agrega_tbl('T' , 'nombre_cob'   ,l_reg_g2999010_msv.txt_nom_cob, FALSE);
               --
               IF l_vlr_fijo IS NULL
               THEN 
                  --
                  BEGIN
                     --
                     em_k_a2000030.p_lee(p_cod_cia       => g_cod_cia      ,
                                         p_num_apli      => g_num_apli     ,
                                         p_num_spto_apli => g_num_spto_apli,
                                         p_num_poliza    => g_num_poliza   ,
                                         p_num_spto      => g_num_spto     );
                     --
                     l_num_poliza_anterior := em_k_a2000030.f_num_poliza_anterior;
                     --
                  EXCEPTION
                     WHEN OTHERS
                     THEN
                        --
                        l_num_poliza_anterior := NULL;
                        --     
                     --
                  END;
                  --
                  IF     l_reg_g2999010_msv.cob_rel_uno = g_k_2252
                     AND l_num_poliza_anterior IS NOT NULL
                  THEN
                     --
                     em_k_a2000040.p_lee(p_cod_cia       => g_cod_cia                     ,
                                         p_cod_cob       => l_reg_g2999010_msv.cob_rel_uno,
                                         p_cod_ramo      => g_cod_ramo                    ,
                                         p_num_apli      => g_num_apli                    ,
                                         p_num_periodo   => g_num_periodo                 ,
                                         p_num_poliza    => g_num_poliza                  ,
                                         p_num_riesgo    => g_num_riesgo                  ,
                                         p_num_spto      => g_num_spto                    ,
                                         p_num_spto_apli => g_num_spto_apli               );  
                     --
                     pp_agrega_tbl('I','cob_limite', g_signo_moneda||' '||fp_format(em_k_a2000040.f_suma_aseg));
                     --
                  ELSE
                     --
                     pp_agrega_tbl('I','cob_limite', g_signo_moneda||' '||fp_format(l_suma_cob_pln_tr));
                     --
                  END IF;
                  --
               ELSE
                  --
                  pp_agrega_tbl('I','cob_limite', l_vlr_fijo);
                  --
               END IF;
               --
               pp_agrega_tbl('T' , 'deducible_txt',l_deducible_pln_tr);
               --
               pp_write_clob(TRUE)    ;
               pp_close_tag('pol_cob');               
               --
            ELSE
               --
               IF l_secuencia <= l_reg_g2999010_msv.num_secu
               THEN
                  --
                  l_secuencia := l_reg_g2999010_msv.num_secu;
                  --
               END IF;
               --
            END IF;
            --
            --l_valida_seccion := FALSE;
            --
            l_suma_cob_pln_tr  := TRN.CERO;
            l_deducible_pln_tr := TRN.NULO;
            l_vlr_fijo         := TRN.NULO;
            --
            IF l_reg_g2999010_msv.num_secu = 5
            THEN
               --
               l_count_cob_2 := l_count_cob_2+trn.uno;
               --
               IF l_secuencia <= l_reg_g2999010_msv.num_secu
               THEN
                  --
                  l_secuencia := l_reg_g2999010_msv.num_secu;
                  --
               END IF;                
               --
               IF l_secuencia = l_reg_g2999010_msv.num_secu
               THEN 
                  --
                  pp_agrega_tbl('T' ,'nom_seccion',UPPER(l_reg_g2999010_msv.nom_seccion),FALSE);
                  l_secuencia := l_secuencia +trn.uno;                  
                  --
               END IF;               
               --
               pp_open_tag('pol_cob');
               --                            
               pp_agrega_tbl('I' , 'index_cob'   , l_count_cob_2||') ');
               pp_agrega_tbl('T' , 'nombre_cob'   ,l_reg_g2999010_msv.txt_nom_cob, FALSE);
               pp_agrega_tbl('I' , 'cob_limite'   ,'******');
               pp_agrega_tbl('T' , 'deducible_txt', l_reg_g2999010_msv.txt_deducible);
               --
               pp_write_clob(TRUE)    ;
               pp_close_tag('pol_cob');                 
               --
            END IF;
            --
         END LOOP;         
         --
      END IF;    
      --
      pp_write_clob(TRUE);
      pp_close_tag('coberturas');
      --
      --@mx('F','pp_dev_coberturas_pln_tr');
      --
   END pp_dev_coberturas_pln_tr;   
   --
   /* --------------------------------------------------------
   || pp_dev_coberturas:
   || Busca las coberturas de la p0liza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_coberturas(p_num_riesgo a2000060.num_riesgo%TYPE)
   IS
      --
      l_txt_suma_aseg VARCHAR2(50);
      l_deducible_txt VARCHAR2(60);
      --
      l_val_franquicia_min a2000040.val_franquicia_min%TYPE;
      l_val_franquicia_max a2000040.val_franquicia_max%TYPE;
      l_tip_cob            a1002050.tip_cob           %TYPE;
      l_cod_mon_cap        a2000040.cod_mon_capital   %TYPE;
      l_cod_cob            a1002050.cod_cob           %TYPE;
      l_tasa_cob           a2000040.tasa_cob          %TYPE;
      l_nom_cob            a1002050.nom_cob           %TYPE;
      l_num_secu           a2000040.num_secu          %TYPE;      
      l_suma_aseg          x2000040.suma_aseg         %TYPE;
      l_suma_aseg_spto     x2000040.suma_aseg         %TYPE;
      --
      l_tasa_cob_total  a2000040.tasa_cob%TYPE  := trn.cero; 
      l_suma_aseg_total a2000040.suma_aseg%TYPE := trn.cero;      
      --
      l_cod_franquicia a2000040.cod_franquicia %TYPE;
      l_tip_franquicia A2100700.tip_franquicia %TYPE;
      l_cod_ramo       a2000040.cod_ramo       %TYPE;
      l_deducible      a2000040.suma_aseg      %TYPE;
      l_pre_valor      g1010031.nom_valor      %TYPE;
      --
      l_index_count NUMBER := trn.cero;
      l_index_clau  NUMBER := trn.cero;
      l_cod_mod     NUMBER := 99999   ;
      --
      l_mca_baja_ries a2000031.mca_baja_riesgo%TYPE;
      --
      l_cur_riesgo CV_RESULTS;
      l_consulta   CLOB      ;
      l_cur_cob    CV_RESULTS;
      --
      l_existe_riesgo BOOLEAN;
      --
      C_TIP_FRAN_DIAS A2100700.tip_franquicia %TYPE  := trn.uno;
      --
      CURSOR l_c_franquicia(p_cod_franquicia a2100700.cod_franquicia%TYPE)
      IS
         --
         SELECT b.nom_valor
           FROM a2100700 a,
                g1010031 b
          WHERE a.cod_franquicia = p_cod_franquicia
            AND a.cod_mon   = (SELECT cod_mon
                                 FROM a2000030 c
                                WHERE c.num_poliza    = g_num_poliza
                                  AND c.cod_cia       = g_cod_cia
                                  AND c.num_spto      = g_num_spto
                                  AND c.num_apli      = g_num_apli
                                  AND c.num_spto_apli = g_num_spto_apli
                                  AND c.cod_ramo      = g_cod_ramo)
           AND b.cod_valor  = TO_CHAR(a.tip_franquicia)
           AND b.cod_campo  = 'TIP_FRANQUICIA'
           AND b.cod_idioma = g_cod_idioma;
      --
      FUNCTION fi_estado_riesgo(pi_cod_cia       a2000031.cod_cia      %TYPE,
                                pi_num_poliza    a2000031.num_poliza   %TYPE,
                                pi_num_spto      a2000031.num_spto     %TYPE,
                                pi_num_apli      a2000031.num_apli     %TYPE,
                                pi_num_spto_apli a2000031.num_spto_apli%TYPE,
                                pi_num_riesgo    a2000031.num_riesgo   %TYPE)
         RETURN CV_RESULTS
      IS
         --
         li_consulta CLOB      ;
         li_cv_cob   CV_RESULTS;
         --
      BEGIN
         --
         li_consulta := 'select mca_baja_riesgo';
         --
         IF g_quotation
         THEN
            --
            li_consulta := li_consulta || ' FROM p2000031 a ';
            --
         ELSE
            --
            li_consulta := li_consulta || ' FROM a2000031 a ';
            --
         END IF;
         --
         li_consulta := li_consulta ||
                       'WHERE a.cod_cia     = '   ||pi_cod_cia    ||''                                                        ||
                            '  AND a.num_poliza  = ''' ||pi_num_poliza || ''' '                                                   ||
                            '  AND (a.num_spto)  = (SELECT MAX(c.num_spto)'                                                       ||
                                                   ' FROM a2000031 c '                                                           ||
                                                   'WHERE a.cod_cia          = c.cod_cia '                                       ||
                                                      ' AND a.num_poliza       = c.num_poliza '                                    ||
                                                      ' AND a.num_apli         = c.num_apli '                                      ||
                                                      ' AND a.num_riesgo       = c.num_riesgo '                                    ||
                                                      ' AND c.num_spto        <= NVL('||pi_num_spto      ||'     ,c.num_spto     )'||
                                                      ' AND c.num_spto_apli   <= NVL('||pi_num_spto_apli ||',c.num_spto_apli)     '||
                                                      ') '                                                                         ||
                            '  AND a.num_apli     = NVL('||pi_num_apli   ||'   ,a.num_apli     )  '                               ||
                            '  AND a.num_riesgo   = '|| pi_num_riesgo ||'   '                                                     ||
                            ' '
                              ;
         OPEN li_cv_cob FOR li_consulta;
         --
         RETURN li_cv_cob;
         --
      END fi_estado_riesgo;
      --
      FUNCTION fp_ver_spto_riesgo
         RETURN BOOLEAN      
      IS
         CURSOR l_c_a2000031
         IS
            --
            SELECT *
              FROM a2000031 a
             WHERE a.num_poliza      = g_num_poliza
               AND a.num_spto        = g_num_spto
               AND a.num_apli        = trn.cero
               AND a.num_spto_apli   = trn.cero
               AND a.mca_baja_riesgo = trn.no
               AND a.mca_vigente     = trn.si
               AND a.tip_spto        = g_k_ad
               AND a.num_riesgo      = g_num_riesgo
               and a.num_spto        > trn.cero;
            --
         --
         l_reg_a2000031 l_c_a2000031%ROWTYPE;
         l_existe BOOLEAN;
         --   
      BEGIN
         --
         OPEN l_c_a2000031; 
         FETCH l_c_a2000031 INTO l_reg_a2000031;
         --
         l_existe := l_c_a2000031%FOUND;
         CLOSE l_c_a2000031;
         --
         RETURN l_existe; 
         --
      END fp_ver_spto_riesgo;       
      --
   BEGIN
      --
      --@mx('I','pp_dev_coberturas');
      --
      l_cur_riesgo := fi_estado_riesgo(g_cod_cia      ,
                                       g_num_poliza   ,
                                       g_num_spto     ,
                                       g_num_apli     ,
                                       g_num_spto_apli,
                                       g_num_riesgo   );
      --
      FETCH l_cur_riesgo INTO l_mca_baja_ries;
      --
      l_consulta := 'SELECT DISTINCT a.cod_mon_capital,a.cod_cob, b.nom_cob,NVL(a.suma_aseg,0),' ||
                              'val_franquicia_min,val_franquicia_max,a.tasa_cob,a.num_secu, NVL(a.cod_franquicia,0), a.cod_ramo, b.tip_cob,' ||
                              'NVL(a.suma_aseg_spto,0) ';
      --
      IF g_quotation
      THEN
         --
         l_consulta := l_consulta || ' FROM p2000040 a, a1002050 b';
         --
      ELSE
         --
         l_consulta := l_consulta || ' FROM a2000040 a, a1002050 b';
         --
      END IF;
      --   
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         l_consulta := l_consulta || ' WHERE a.cod_cia   = b.cod_cia'                                  ||
                                 ' AND a.cod_cob         = b.cod_cob'                                  ||
                                 ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                 ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                 ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                               'FROM p2000040 c                       '||
                                                             'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                               'AND ' ||g_num_spto||' >= c.num_spto)   '||
                                 ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                 ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                 ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ||
                                 ' AND a.mca_baja_riesgo = '''||trn.NO||''''                           ||
                                 ' AND a.mca_baja_cob    = '''||trn.NO||''''                           ;   
         --
      ELSE
         --
         l_existe_riesgo := fp_ver_spto_riesgo;
         --
         IF     l_mca_baja_ries  = trn.SI
            AND l_existe_riesgo
         THEN
            --
            l_consulta := l_consulta ||' WHERE a.cod_cia    = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                  'AND ' ||g_num_spto||' >= c.num_spto)   '||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ;
         --
         ELSIF NOT l_existe_riesgo 
           AND l_mca_baja_ries = trn.SI
           AND g_tip_spto = g_k_ad
           AND g_num_riesgos > 1           
         THEN
            --
            l_consulta := l_consulta ||' WHERE a.cod_cia    = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                 'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                   'AND c.num_spto < ' ||g_num_spto||'  ) '||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ;       
         --
         ELSIF NOT l_existe_riesgo 
           AND l_mca_baja_ries = trn.no
           AND g_tip_spto = g_k_ad
           AND g_num_riesgos > 1
         THEN
            --
            l_consulta := l_consulta || ' WHERE a.cod_cia   = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                  'AND c.num_spto < ' ||g_num_spto||'   )'||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ||
                                    ' AND a.mca_baja_riesgo = '''||trn.NO||''''                           ||
                                    ' AND a.mca_baja_cob    = '''||trn.NO||''''                           ;        
         ELSE
            --         
            l_consulta := l_consulta || ' WHERE a.cod_cia   = b.cod_cia'                                  ||
                                    ' AND a.cod_cob         = b.cod_cob'                                  ||
                                    ' AND a.cod_cia         = '||g_cod_cia||''                            ||
                                    ' AND a.num_poliza      = ''' || g_num_poliza || ''''                 ||
                                    ' AND a.num_spto        = (SELECT MAX(c.num_spto)                   '||
                                                                  'FROM a2000040 c                       '||
                                                                'WHERE c.num_poliza = '''||g_num_poliza||''''||
                                                                  'AND ' ||g_num_spto||' >= c.num_spto)   '||
                                    ' AND a.num_apli        = NVL('||g_num_apli||',a.num_apli)          ' ||
                                    ' AND a.num_spto_apli   = NVL('||g_num_spto_apli||',a.num_spto_apli)' ||
                                    ' AND a.num_riesgo      = NVL('||g_num_riesgo||',a.num_riesgo)      ' ||
                                    ' AND a.mca_baja_riesgo = '''||trn.NO||''''                           ||
                                    ' AND a.mca_baja_cob    = '''||trn.NO||''''                           ;
            --
         END IF;
         --
      END IF;  
      --
      l_consulta := l_consulta || ' ORDER BY a.num_secu ';
      --
      OPEN l_cur_cob FOR l_consulta;
      --
      g_reg_clau_espc.DELETE;
      --
      pp_open_tag('coberturas');
      --
      LOOP
         --
         FETCH l_cur_cob INTO l_cod_mon_cap       ,
                              l_cod_cob           ,
                              l_nom_cob           ,
                              l_suma_aseg         ,
                              l_val_franquicia_min,
                              l_val_franquicia_max,
                              l_tasa_cob          ,
                              l_num_secu          ,
                              l_cod_franquicia    ,
                              l_cod_ramo          ,
                              l_tip_cob           ,
                              l_suma_aseg_spto    ;
         --
         EXIT WHEN l_cur_cob%NOTFOUND;
         --         
         pp_open_tag('pol_cob');
         --
         l_deducible := 0.00;
         --
         IF l_cod_franquicia > trn.CERO
         THEN
            --
            l_cod_mod := g_cod_modalidad;
            --
            EM_K_A2100700.p_lee( g_cod_cia, l_cod_mon_cap, l_cod_franquicia);
            l_tip_franquicia := EM_K_A2100700.f_tip_franquicia              ;
            l_deducible      := em_k_a2100700.f_val_franquicia              ;
            --
            BEGIN
               --
               OPEN  l_c_franquicia(l_cod_franquicia);
               FETCH l_c_franquicia INTO l_pre_valor;
               CLOSE l_c_franquicia;
            --
            EXCEPTION
               --
               WHEN OTHERS
               THEN
                  --
                  l_pre_valor := '%';
            END;
            --
         ELSE
            --
            l_deducible := trn.nulo;
            --
         END IF;
         --
         dc_k_a1000400.p_lee(l_cod_mon_cap);
         --
         dc_k_a1001800.p_lee(p_cod_cia => g_cod_cia  ,
                             p_cod_ramo => g_cod_ramo);
         --
         IF l_mca_baja_ries = trn.SI
         THEN
            --
            l_suma_aseg := l_suma_aseg_spto * 1;
            --
         END IF;
         --
         l_txt_suma_aseg := l_suma_aseg;--'INCLUIDA';
         --
         IF    l_suma_aseg <> trn.CERO
            OR l_tip_cob = em.TIP_COB_SERVICIO
         THEN
            --
            l_index_clau := l_index_clau+trn.uno;
            --
            g_reg_clau_espc(l_index_clau).cod_cob := l_cod_cob;
            g_reg_clau_espc(l_index_clau).nom_cob := l_nom_cob;
            --
            pp_agrega_tbl('T', 'nombre_cob' ,l_nom_cob, FALSE);
            --
            IF l_cod_cob IN(g_k_2201,g_k_2241)
            THEN
               --
               l_index_count := l_index_count+trn.uno;
               --
               g_l_list_cob(l_index_count).cod_cob   := l_cod_cob  ;
               g_l_list_cob(l_index_count).suma_aseg := l_suma_aseg;
               --
            END IF;
            --
            IF l_tip_cob = em.TIP_COB_SERVICIO
            THEN
               --
               pp_agrega_tbl('T', 'nom_moneda'     , ''        );
               pp_agrega_tbl('T', 'moneda_sum_aseg', ''        );
               pp_agrega_tbl('T', 'cob_limite'     , 'INCLUIDA');
               --
            ELSE
               --
               IF dc_k_a1000400.f_nom_mon LIKE g_k_dolar
               THEN
                  --
                  pp_agrega_tbl('T' , 'nom_moneda', dc_k_a1000400.f_cod_mon_iso);
                  --
                  IF  l_tip_franquicia = C_TIP_FRAN_DIAS
                  THEN
                     --
                     pp_agrega_tbl('T' , 'sim_moneda', '');
                     pp_agrega_tbl('T' , 'deducible'     , l_deducible || ' Dia(s)');
                     --
                  ELSE
                     --
                     pp_agrega_tbl('T' , 'sim_moneda', l_pre_valor);
                     pp_agrega_tbl('I' , 'deducible' , l_deducible);
                     --
                  END IF;
                  --
                  g_reg_clau_espc(l_index_clau).suma_aseg := g_signo_moneda||'.'|| fp_format(l_txt_suma_aseg);
                  --
                  g_reg_clau_espc(l_index_clau).cod_clausula := fp_dev_cod_clau(l_cod_cob);
                  --
                  pp_agrega_tbl('T' , 'moneda_sum_aseg','$' );
                  pp_agrega_tbl('I' , 'cob_limite',g_signo_moneda||' '|| dc_k_a1000400.f_importe_fmt_dec(l_txt_suma_aseg));
                  pp_agrega_tbl('T' , 'val_franquicia_min',fp_format(l_val_franquicia_min));
                  pp_agrega_tbl('T' , 'val_franquicia_max',fp_format(l_val_franquicia_max));
                  --
                  IF l_deducible IS NOT NULL
                  THEN
                     --
                     IF l_pre_valor = g_k_imp
                     THEN 
                        --
                        g_reg_clau_espc(l_index_clau).aplica_porcentaje := trn.no;
                        l_deducible_txt := l_deducible_txt||g_signo_moneda||' '||l_deducible;
                        g_reg_clau_espc(l_index_clau).cod_franquicia := g_signo_moneda||' '||l_deducible;
                        --
                     ELSE
                        --
                        g_reg_clau_espc(l_index_clau).aplica_porcentaje := trn.si;
                        l_deducible_txt := l_deducible_txt||l_deducible||' '||l_pre_valor;
                        g_reg_clau_espc(l_index_clau).cod_franquicia   := l_deducible||' '||l_pre_valor;
                        --
                     END IF; 
                     --                     
                     g_reg_clau_espc(l_index_clau).aplica_deducible := TRN.SI;
                     --
                  END IF;
                  --
                  IF l_val_franquicia_min IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);
                     --
                     g_reg_clau_espc(l_index_clau).val_franquicia_min := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);
                     --
                  END IF;
                  --
                  IF l_val_franquicia_max IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' max $ '||fp_format(l_val_franquicia_max);
                     --
                  END IF;                    
                  --
                  IF l_deducible_txt IS NULL                  
                  THEN
                     --
                     l_deducible_txt := 'Ninguno';
                     --
                  END IF;
                  --                  
                  pp_agrega_tbl('T' , 'deducible_txt',l_deducible_txt);
                  --
                  l_deducible_txt := trn.nulo;
                  --
               ELSIF dc_k_a1000400.f_nom_mon LIKE g_k_dolar
               THEN
                  --
                  pp_agrega_tbl('T' , 'nom_moneda' , dc_k_a1000400.f_cod_mon_iso);
                  --
                  IF  l_tip_franquicia = C_TIP_FRAN_DIAS
                  THEN
                     --
                     pp_agrega_tbl('T' , 'sim_moneda', '');
                     pp_agrega_tbl('T' , 'deducible'     , l_deducible || ' Dia(s)');
                     --
                  ELSE
                     --
                     pp_agrega_tbl('T' , 'sim_moneda' ,l_pre_valor);
                     pp_agrega_tbl('I' , 'deducible' , l_deducible);
                     --
                  END IF;
                  --
                  g_reg_clau_espc(l_index_clau).suma_aseg := g_signo_moneda||'.'|| fp_format(l_txt_suma_aseg);
                  --
                  g_reg_clau_espc(l_index_clau).cod_clausula := fp_dev_cod_clau(l_cod_cob);                  
                  --
                  pp_agrega_tbl('T' , 'moneda_sum_aseg','$.' );
                  pp_agrega_tbl('I' , 'cob_limite' , g_signo_moneda||' '||fp_format(l_txt_suma_aseg));
                  pp_agrega_tbl('T' , 'val_franquicia_min',fp_format(l_val_franquicia_min));
                  pp_agrega_tbl('T' , 'val_franquicia_max',fp_format(l_val_franquicia_max));
                  --
                  IF l_deducible IS NOT NULL
                  THEN
                     --
                     IF l_pre_valor = g_k_imp
                     THEN 
                        --
                        g_reg_clau_espc(l_index_clau).aplica_porcentaje := trn.no;
                        l_deducible_txt := l_deducible_txt||g_signo_moneda||' '||l_deducible;
                        g_reg_clau_espc(l_index_clau).cod_franquicia   := g_signo_moneda||' '||l_deducible;
                        --
                     ELSE
                        --
                        g_reg_clau_espc(l_index_clau).aplica_porcentaje := trn.si;
                        l_deducible_txt := l_deducible_txt||l_deducible||' '||l_pre_valor;
                        g_reg_clau_espc(l_index_clau).cod_franquicia   := l_deducible||' '||l_pre_valor;
                        --
                     END IF;                      
                     --
                     g_reg_clau_espc(l_index_clau).aplica_deducible := TRN.SI;                     
                     --
                  END IF;
                  --
                  IF l_val_franquicia_min IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);
                     --
                     g_reg_clau_espc(l_index_clau).val_franquicia_min := l_deducible_txt||' min $ '||fp_format(l_val_franquicia_min);                     
                     --
                  END IF;
                  --
                  IF l_val_franquicia_max IS NOT NULL
                  THEN
                     --
                     l_deducible_txt := l_deducible_txt||' max $ '||fp_format(l_val_franquicia_max);
                     --
                  END IF;                    
                  --
                  IF l_deducible_txt IS NULL
                  THEN
                     --
                     l_deducible_txt := 'Ninguno';
                     --
                  END IF;
                  --                  
                  pp_agrega_tbl('T' , 'deducible_txt',l_deducible_txt);
                  --
                  l_deducible_txt := trn.nulo;
                  --
                  l_tip_franquicia := TRN.NULO;
                  l_pre_valor      := TRN.NULO;
                  --
               END IF;
               --
               l_suma_aseg_total := l_suma_aseg_total+l_txt_suma_aseg;
               --
               l_tasa_cob_total := l_tasa_cob_total+l_tasa_cob;
               --
            END IF;
            --
         END IF;
         --
         pp_write_clob(TRUE)    ;
         pp_close_tag('pol_cob');
         --
      END LOOP;
      --
      CLOSE l_cur_cob;
      --
      l_index_count := trn.cero;      
      --
      pp_write_clob(TRUE);
      --
      pp_open_tag('pol_sum_aseg_tot');
      --
      pp_agrega_tbl('T' ,'det_sum_aseg',g_cod_mon||' '||TRIM(TO_CHAR(TRIM(l_suma_aseg_total), g_k_mascara)));
      --
      pp_agrega_tbl('T' ,'tasa_cob',fp_format(l_tasa_cob_total));
      --
      pp_write_clob(TRUE);
      --
      pp_close_tag('pol_sum_aseg_tot');
      --
      pp_close_tag('coberturas');
      --
      --@mx('F','pp_dev_coberturas');
      --
   END pp_dev_coberturas;
   --
   /* --------------------------------------------------------
   || pp_dev_conceptos:
   || Conceptos de desgloce
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_conceptos(p_prima_tarifa OUT c2109170_msv.imp_spto%TYPE,
                              p_descuentos   OUT c2109170_msv.imp_spto%TYPE,
                              p_recargos     OUT c2109170_msv.imp_spto%TYPE,
                              p_iva          OUT c2109170_msv.imp_spto%TYPE,
                              p_emision      OUT c2109170_msv.imp_spto%TYPE,
                              p_igsci        OUT c2109170_msv.imp_spto%TYPE,
                              p_cod_cob      IN  c2109170_msv.cod_cob%TYPE )
   IS
      --
      CURSOR l_c_c2109170_msv
      IS
         --
         SELECT NVL(SUM(DECODE(a.cod_desglose, 1  , imp_spto, trn.cero)), trn.cero) prima_base,
                NVL(SUM(DECODE(a.cod_desglose, 25 , imp_spto, trn.cero)), trn.cero) descuentos,
                NVL(SUM(DECODE(a.cod_desglose, 27 , imp_spto, trn.cero)), trn.cero) recargos  ,
                NVL(SUM(DECODE(a.cod_desglose, 28 , imp_spto, trn.cero)), trn.cero) iva       ,
                NVL(SUM(DECODE(a.cod_desglose, 11 , imp_spto, trn.cero)), trn.cero) emision   ,
                NVL(SUM(DECODE(a.cod_desglose, 24 , imp_spto, trn.cero)), trn.cero) igsci     
           FROM c2109170_msv a
          WHERE a.cod_cia        = g_cod_cia
            AND a.num_cotizacion = g_jbnum_poliza
            AND a.num_riesgo     = g_num_riesgo            
            AND a.cod_ramo       = g_jbcod_ramo
            AND a.cod_cob        = p_cod_cob;
       --
       l_reg170 l_c_c2109170_msv%ROWTYPE;
       -- 
   BEGIN
      --
      OPEN l_c_c2109170_msv;
      FETCH l_c_c2109170_msv INTO l_reg170;
      CLOSE l_c_c2109170_msv;
      --
      p_prima_tarifa := l_reg170.prima_base;
      p_descuentos   := l_reg170.descuentos;
      p_recargos     := l_reg170.recargos  ;
      p_iva          := l_reg170.iva       ;
      p_emision      := l_reg170.emision   ;
      p_igsci        := l_reg170.igsci     ; 
      --
   END pp_dev_conceptos;      
   --
   /* --------------------------------------------------------
   || pp_dev_cob_oferta:
   || coberturas de la oferta
   */ --------------------------------------------------------   
   PROCEDURE pp_dev_cob_oferta
   IS
      --
      l_tot_prima_tarifa c2109170_msv.imp_spto%TYPE := trn.cero;
      l_tot_descuentos   c2109170_msv.imp_spto%TYPE := trn.cero;
      l_tot_recargos     c2109170_msv.imp_spto%TYPE := trn.cero;
      l_tot_iva          c2109170_msv.imp_spto%TYPE := trn.cero;
      l_tot_emision      c2109170_msv.imp_spto%TYPE := trn.cero;
      l_tot_igsci        c2109170_msv.imp_spto%TYPE := trn.cero;
      l_total_pago       c2109170_msv.imp_spto%TYPE := trn.cero;
      --
      l_prima_tarifa   c2109170_msv.imp_spto  %TYPE;      
      l_descuentos     c2109170_msv.imp_spto  %TYPE;      
      l_recargos       c2109170_msv.imp_spto  %TYPE;      
      l_iva            c2109170_msv.imp_spto  %TYPE;      
      l_emision        c2109170_msv.imp_spto  %TYPE;      
      l_igsci          c2109170_msv.imp_spto  %TYPE;                  
      l_sim_moneda     g1010031.nom_valor     %TYPE;
      l_deducible      a2000040.suma_aseg     %TYPE;
      l_pre_valor      g1010031.nom_valor     %TYPE; 
      l_tip_franquicia a2100700.tip_franquicia%TYPE;
      --
      l_index_count NUMBER := trn.cero;
      --
      CURSOR l_c_franquicia(p_cod_franquicia a2100700.cod_franquicia%TYPE)
      IS
         --
         SELECT b.nom_valor
           FROM a2100700 a,
                g1010031 b
          WHERE a.cod_franquicia = p_cod_franquicia
            AND a.cod_mon   = (SELECT cod_mon
                                 FROM p2000030 c
                                WHERE c.num_poliza    = g_jbnum_poliza
                                  AND c.cod_cia       = g_cod_cia
                                  AND c.num_spto      = trn.cero
                                  AND c.num_apli      = trn.cero
                                  AND c.num_spto_apli = trn.cero
                                  AND c.cod_ramo      = g_jbcod_ramo)
           AND b.cod_valor  = TO_CHAR(a.tip_franquicia)
           AND b.cod_campo  = 'TIP_FRANQUICIA'
           AND b.cod_idioma = g_cod_idioma;   
      --
      CURSOR l_c_c2009040_msv
      IS
         --
         SELECT a.cod_cob,a.nom_cob,a.cod_franquicia,a.suma_aseg
           FROM c2009040_msv a
          WHERE a.num_cotizacion = g_jbnum_poliza
            AND a.cod_ramo       = g_jbcod_ramo
            AND a.cod_cia        = g_cod_cia
            AND a.num_riesgo     = g_num_riesgo;
      --
      l_reg_c2009040_msv l_c_c2009040_msv%ROWTYPE;
      --
   BEGIN
      --
      pp_open_tag('coberturas' );
      --
      OPEN l_c_c2009040_msv;
      LOOP
         --
         FETCH l_c_c2009040_msv INTO l_reg_c2009040_msv;
         EXIT WHEN l_c_c2009040_msv%NOTFOUND;
         --
         pp_open_tag('pol_cob');
         --
         IF l_reg_c2009040_msv.cod_franquicia > trn.CERO
         THEN
            --
            em_k_a2100700.p_lee(g_cod_cia                        , 
                                g_cod_mon                        , 
                                l_reg_c2009040_msv.cod_franquicia);
            --
            l_tip_franquicia := EM_K_A2100700.f_tip_franquicia;
            l_deducible      := em_k_a2100700.f_val_franquicia;
            --
            BEGIN
               --
               OPEN  l_c_franquicia(l_reg_c2009040_msv.cod_franquicia);
               FETCH l_c_franquicia INTO l_pre_valor;
               CLOSE l_c_franquicia;
            --
            EXCEPTION
               --
               WHEN OTHERS
               THEN
                  --
                  l_pre_valor := '%';
            END;
            --
         ELSE
            --
            l_deducible := 0.00;
            --
         END IF; 
         --
         IF l_reg_c2009040_msv.cod_cob IN(g_k_2201,g_k_2241)
         THEN
            --
            l_index_count := l_index_count+trn.uno;
            --
            g_l_list_cob(l_index_count).cod_cob   := l_reg_c2009040_msv.cod_cob  ;
            g_l_list_cob(l_index_count).suma_aseg := l_reg_c2009040_msv.suma_aseg;
            --
         END IF;         
         --
         pp_dev_conceptos(l_prima_tarifa            ,  
                          l_descuentos              ,  
                          l_recargos                ,  
                          l_iva                     ,  
                          l_emision                 ,  
                          l_igsci                   ,
                          l_reg_c2009040_msv.cod_cob);           
         --
         l_tot_prima_tarifa := l_tot_prima_tarifa + l_prima_tarifa;                     
         l_tot_descuentos   := l_tot_descuentos   + l_descuentos  ;                    
         l_tot_recargos     := l_tot_recargos     + l_recargos    ;                    
         l_tot_iva          := l_tot_iva          + l_iva         ;                    
         l_tot_emision      := l_tot_emision      + l_emision     ;                    
         l_tot_igsci        := l_tot_igsci        + l_igsci       ;                              
         --
         pp_agrega_tbl('T','cod_cob'   , l_reg_c2009040_msv.cod_cob             ,TRUE);
         pp_agrega_tbl('T','nom_cob'   , l_reg_c2009040_msv.nom_cob             ,TRUE);
         pp_agrega_tbl('T','cob_limite', fp_format(l_reg_c2009040_msv.suma_aseg),TRUE);
         --
         IF l_deducible = trn.cero
         THEN
            --
            pp_agrega_tbl('T','deducible','Ninguno',TRUE);
            --
         ELSE
            --
            pp_agrega_tbl('T','deducible',l_deducible||l_pre_valor,TRUE);
            --
         END IF;  
         --
         pp_write_clob(TRUE);
         pp_close_tag('pol_cob'); 
         --
         l_prima_tarifa := trn.cero;
         l_descuentos   := trn.cero;       
         l_recargos     := trn.cero;       
         l_iva          := trn.cero;      
         l_emision      := trn.cero;       
         l_igsci        := trn.cero;           
         --
      END LOOP;
      CLOSE l_c_c2009040_msv;
      --
      l_total_pago := l_tot_prima_tarifa+
                      l_tot_descuentos  + 
                      l_tot_recargos    +
                      l_tot_iva         +
                      l_tot_emision     +
                      l_tot_igsci       ;
      --
      pp_agrega_tbl('T','prima_tarifa',fp_format(l_tot_prima_tarifa),TRUE);
      pp_agrega_tbl('T','descuentos'  ,fp_format(l_tot_descuentos  ),TRUE);
      pp_agrega_tbl('T','recargos'    ,fp_format(l_tot_recargos    ),TRUE);
      pp_agrega_tbl('T','iva'         ,fp_format(l_tot_iva         ),TRUE);
      pp_agrega_tbl('T','emision'     ,fp_format(l_tot_emision     ),TRUE);
      pp_agrega_tbl('T','igsci'       ,fp_format(l_tot_igsci       ),TRUE);
      pp_agrega_tbl('T','total_pago'  ,fp_format(l_total_pago      ),TRUE);
      --
      pp_write_clob(TRUE);
      pp_close_tag('coberturas'); 
      --
   END pp_dev_cob_oferta;    
   --
   /* --------------------------------------------------------
   || pp_forma_de_pago:
   || Retorna forma de pago
   */ --------------------------------------------------------
   --   
   PROCEDURE pp_forma_de_pago
   IS
      --
      l_nom_mon        VARCHAR2(5) ;
      l_txt_forma_pago VARCHAR2(20);
      --
      l_k_mensual    CONSTANT VARCHAR2(7) := 'Mensual'   ;
      l_k_semestral  CONSTANT VARCHAR2(9) := 'Semestral' ;
      l_k_trimestral CONSTANT VARCHAR2(10):= 'Trimestral';               
      --      
      l_k_12 CONSTANT NUMBER(2) := 12;
      l_k_22 CONSTANT NUMBER(2) := 22;
      l_k_44 CONSTANT NUMBER(2) := 44;      
      --   
      l_cuota_1 c2990700.imp_recibo%TYPE;
      l_cuota_2 c2990700.imp_recibo%TYPE; 
      l_cuota_3 c2990700.imp_recibo%TYPE;   
      --
      CURSOR l_c_c2990700
      IS
         --
         SELECT a.cod_fracc_pago
           FROM c2990700 a
          WHERE a.cod_ramo       = g_jbcod_ramo
            AND a.num_cotizacion = g_jbnum_poliza
            AND a.cod_cia        = g_cod_cia
         GROUP BY a.cod_fracc_pago
         ORDER BY a.cod_fracc_pago;
         --
         l_reg_c2990700 l_c_c2990700%ROWTYPE;   
      --
      PROCEDURE pi_calcula_cuotas(p_cod_fracc_pago IN c2990700.cod_fracc_pago%TYPE,
                                  p_cuota_1        OUT c2990700.imp_recibo   %TYPE,
                                  p_cuota_2        OUT c2990700.imp_recibo   %TYPE,
                                  p_cuota_3        OUT c2990700.imp_recibo   %TYPE)
      IS
         --
         l_text_cuotas VARCHAR2(500);
         --
         l_cuota_3 c2990700.imp_recibo%TYPE := trn.cero; 
         --     
         CURSOR l_c_c2990700_cuota
         IS
            --
            SELECT a.cod_fracc_pago,a.imp_recibo,COUNT(*) cuotas
              FROM c2990700 a
             WHERE a.cod_ramo       = g_jbcod_ramo
               AND a.num_cotizacion = g_jbnum_poliza
               AND a.cod_cia        = g_cod_cia
               AND a.cod_fracc_pago = p_cod_fracc_pago
               GROUP BY a.cod_fracc_pago,a.imp_recibo
             ORDER BY cuotas ASC;                
         --
         l_reg_c2990700_cuota l_c_c2990700_cuota%ROWTYPE;
         --
      BEGIN
         --
         OPEN l_c_c2990700_cuota;
         LOOP
            --
            FETCH l_c_c2990700_cuota INTO l_reg_c2990700_cuota;
            EXIT WHEN l_c_c2990700_cuota%NOTFOUND;    
            --
            IF l_c_c2990700_cuota%ROWCOUNT = trn.uno
            THEN
               --
               pp_open_tag('num_cuotas');
               --
               pp_agrega_tbl('T', 'cuota_1'   ,l_reg_c2990700_cuota.cuotas||' Cuota de '||l_nom_mon||
                                               fp_format(l_reg_c2990700_cuota.imp_recibo) );
               --
               pp_write_clob(TRUE);
               pp_close_tag('num_cuotas');              
               --
            ELSE
               --
               l_text_cuotas := l_text_cuotas ||' '||l_reg_c2990700_cuota.cuotas|| ' Cuota de '||l_nom_mon||
                                fp_format(l_reg_c2990700_cuota.imp_recibo)||',';
               --
            END IF;
            --       
        END LOOP;
        --
        IF l_text_cuotas IS NOT NULL
        THEN
           --
           l_text_cuotas := SUBSTR(l_text_cuotas,trn.uno,(LENGTH(l_text_cuotas)-trn.uno));
           --
           pp_open_tag('num_cuotas');
           --
           pp_agrega_tbl('T', 'cuota_2'   ,l_text_cuotas);
           --
           pp_write_clob(TRUE);
           pp_close_tag('num_cuotas'); 
           --
           l_text_cuotas := trn.nulo;
           --
        END IF;
        --        
      END pi_calcula_cuotas;
      --
   BEGIN
      --
      pp_open_tag('forma_pago');
      --
      IF g_cod_mon = trn.UNO
      THEN
         --
         l_nom_mon := '$';
         --
      ELSE
         --
         l_nom_mon := 'US$';
         --
      END IF;      
      --
      OPEN l_c_c2990700;   
      LOOP
         --
         FETCH l_c_c2990700 INTO l_reg_c2990700;
         EXIT WHEN l_c_c2990700%NOTFOUND;
         --
         pp_open_tag('cuotas');
         --
         pi_calcula_cuotas(l_reg_c2990700.cod_fracc_pago,
                           l_cuota_1                    ,
                           l_cuota_2                    ,
                           l_cuota_3                    );
         --
         CASE l_reg_c2990700.cod_fracc_pago
         --
         WHEN l_k_44 THEN l_txt_forma_pago := l_k_trimestral;
         WHEN l_k_22 THEN l_txt_forma_pago := l_k_semestral;
         WHEN l_k_12 THEN l_txt_forma_pago := l_k_mensual;
         ELSE l_txt_forma_pago := l_reg_c2990700.cod_fracc_pago||' contado';
         --
         END CASE;                 
         --
         pp_agrega_tbl('T', 'contado',l_txt_forma_pago);                
         --
         pp_write_clob(TRUE);
         pp_close_tag('cuotas'); 
         --  
      END LOOP;   
      --
      pp_write_clob(TRUE);
      pp_close_tag('forma_pago'); 
      --
   END pp_forma_de_pago;   
   --
   /* --------------------------------------------------------
   || pp_actualiza_mca_impresion:
   || Actualiza la marca de impresion
   */ --------------------------------------------------------
   --
   PROCEDURE pp_actualiza_mca_impresion
   IS
   --
   BEGIN
      --
      --@mx('I','pp_actualiza_mca_impresion');
      --
      IF g_jbchoose_report IN (G_K_REP_PS)
      THEN
         --
         UPDATE a2000030 a
            SET a.mca_impresion   = trn.SI
          WHERE a.cod_cia         = g_cod_cia
            AND a.num_poliza      = NVL(g_num_poliza,    a.num_poliza)
            AND a.num_apli        = NVL(g_num_apli,      a.num_apli)
            AND a.num_spto        = NVL(g_num_spto,      a.num_spto)
            AND a.num_spto_apli   = NVL(g_num_spto_apli, a.num_spto_apli);
         --
      END IF;
      --
      --@mx('F','pp_actualiza_mca_impresion');
      --
   END pp_actualiza_mca_impresion;
   --
   /* --------------------------------------------------------
   || pp_inicializa_rep:
   */ --------------------------------------------------------
   --
   PROCEDURE pp_inicializa_rep(p_num_report IN g1010031.cod_valor%TYPE  ,
                               p_sufijo_rep     IN VARCHAR2             ,
                               p_sufijo_formato IN VARCHAR2 DEFAULT NULL)
   IS
      --
      l_k_99999      CONSTANT NUMBER(5)   := 99999; 
      --      
      l_k_a2000500   CONSTANT VARCHAR2(8) := 'a2000500'  ;
      l_k_cod_nivel3 CONSTANT VARCHAR2(10):= 'cod_nivel3';   
      --
      l_cod_ciudad a2000030.cod_nivel3 %TYPE;
      l_nom_ciudad a1000702.nom_nivel3 %TYPE;
      --
      l_nom_reporte a1009012_msv.cod_report%TYPE;
      --
      l_fec_emision DATE ;
      --
      l_dia       VARCHAR2(5)    ;
      l_mes       VARCHAR2(15)   ;
      l_fecha_imp VARCHAR2(50)   ;
      l_anio      VARCHAR2(5)    ;
      l_texto     VARCHAR2(3000) ;
      --
      l_texto_1   a1009012_msv.contenido_objeto%TYPE;
      l_texto_2   a1009012_msv.contenido_objeto%TYPE;
      l_texto_3   a1009012_msv.contenido_objeto%TYPE;
      l_texto_4   a1009012_msv.contenido_objeto%TYPE;
      l_texto_5   a1009012_msv.contenido_objeto%TYPE;
      l_texto_6   a1009012_msv.contenido_objeto%TYPE;
      l_texto_7   a1009012_msv.contenido_objeto%TYPE;
      l_texto_8   a1009012_msv.contenido_objeto%TYPE;
      l_texto_9   a1009012_msv.contenido_objeto%TYPE;                        
      --
      CURSOR c_a1009012_msv(p_nom_reporte a1009012_msv.cod_report%TYPE)
      IS
         --
         SELECT a.num_secu,
                a.contenido_objeto
           FROM a1009012_msv a
          WHERE a.cod_report  = UPPER(p_nom_reporte)
            AND a.cod_ramo    = g_jbcod_ramo
            AND a.mca_inh     = trn.NO
            AND a.fec_validez = (SELECT MAX(a1.fec_validez)
                                   FROM a1009012_msv a1
                                  WHERE a1.cod_report   = a.cod_report
                                    AND a1.cod_ramo     = a.cod_ramo
                                    AND a1.mca_inh      = trn.NO
                                    AND a1.fec_validez <= G_K_SYSDATE)
          ORDER BY a.num_secu;
      --
      CURSOR c_fecha_emision(pc_fec_emision  DATE)
      IS
         --
         SELECT EXTRACT (YEAR  FROM to_date(pc_fec_emision,'dd/mm/yy')),
                TO_CHAR(TO_DATE(pc_fec_emision,'dd/mm/yyyy'),'MONTH','nls_date_language=spanish'),
                EXTRACT (DAY   FROM to_date(pc_fec_emision,'dd/mm/yyyy'))
           FROM dual;
      --
   BEGIN
      --
      --@mx('I','pp_inicializa_rep');
      --
      g_tbl_txt_reporte.DELETE;
      ---
      BEGIN
         --
         g_cod_report := ss_f_nom_valor( p_cod_campo  => 'JBCHOOSE_REPORT',
                                         p_cod_ramo   => g_jbcod_ramo     ,
                                         p_cod_valor  => p_num_report     ,
                                         p_cod_idioma => g_cod_idioma     );
         --
      EXCEPTION
         --
         WHEN OTHERS
         THEN
            --
            NULL;
            --
      END;
      --
      IF g_num_spto = g_k_spto_actual
      THEN
         --
         g_situacion_actual := TRUE;
         --
      ELSE
         --
         g_situacion_actual := FALSE;
         --
      END IF;
      --
      IF g_jbtip_emision != g_k_rep_cotizacion 
      THEN
         --
         em_k_a2000030.p_lee(p_cod_cia       => g_cod_cia              ,
                             p_num_poliza    => g_num_poliza           ,
                             p_num_spto      => g_num_spto             ,
                             p_num_apli      => nvl(g_num_apli,0)      ,
                             p_num_spto_apli => nvl(g_num_spto_apli,0));
         --
         l_fec_emision := TO_DATE(em_k_a2000030.f_fec_emision_spto, 'DD-MM-YYYY');
         --
         l_cod_ciudad  := em_k_a2000030.f_cod_nivel3;
         --
         IF l_cod_ciudad IS NOT NULL
         THEN
            --
            dc_k_a1000702.p_lee(p_cod_cia    => g_cod_cia   ,
                                p_cod_nivel3 => l_cod_ciudad);
            --
            l_nom_ciudad := dc_k_a1000702.f_nom_nivel3;
         ELSE
            --
            l_nom_ciudad := trn.nulo;
            --
         END IF;
         --
         OPEN c_fecha_emision(l_fec_emision);
         --
         FETCH c_fecha_emision INTO l_anio, l_mes, l_dia;
         CLOSE c_fecha_emision;
         --
      ELSE
         --
         BEGIN
            --         
            em_k_c2000000.p_lee(p_cod_cia        => g_cod_cia     ,
                                p_cod_ramo       => g_jbcod_ramo  ,
                                p_num_cotizacion => g_jbnum_poliza,
                                p_nom_tabla      => l_k_a2000500  ,
                                p_nom_columna    => l_k_cod_nivel3,
                                p_cod_fila       => l_k_99999     );
            --
            l_cod_ciudad := em_k_c2000000.f_val_columna;                    
            --
            IF l_cod_ciudad IS NOT NULL
            THEN
               --
               dc_k_a1000702.p_lee(p_cod_cia    => g_cod_cia   ,
                                   p_cod_nivel3 => l_cod_ciudad);
               --
               l_nom_ciudad := dc_k_a1000702.f_nom_nivel3;
            ELSE
               --
               l_nom_ciudad := trn.nulo;
               --
            END IF;
            --
         EXCEPTION
            --
            WHEN OTHERS
            THEN
               --
               l_nom_ciudad := trn.nulo;
               --            
         END;
         --        
      END IF;
      --
      g_nom_ciudad := l_nom_ciudad;
      --
      g_xml_impresion := trn.NULO;
      --
      g_tbl_xml_deta.DELETE;
      --
      g_cont_tabs := trn.UNO;
      --
      IF    g_mca_gen_individual = trn.SI
         OR g_jbnum_poliza IS NOT NULL
       THEN
         --
         g_cod_report := g_cod_report||'.'|| NVL(g_num_poliza, g_num_poliza_grupo) || '.' || g_num_spto || '.' || trn_k_lis.ext_java;
         --
      ELSE
         --
         g_cod_report := g_cod_report||'.'|| g_num_poliza_grupo || '.' || trn_k_lis.ext_java;
         --
      END IF;
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         IF g_cod_modalidad = g_k_cobertura_total  
         THEN
            --      
            IF g_num_riesgos = trn.uno
            THEN
               --                                 
               g_nom_reporte :=  'em_k_jrp_oferta_228_tr_'||p_sufijo_rep||'_msv';
               l_nom_reporte := g_nom_reporte;            
               --
            ELSE
               --
               g_nom_reporte := 'em_k_jrp_oft_mlt_228_'||p_sufijo_rep||'_tr_msv';
               l_nom_reporte := 'em_k_jrp_oferta_228_tr_'||p_sufijo_rep||'_msv'; 
               --            
            END IF;            
            --
         ELSE
            --
            IF g_num_riesgos = trn.uno
            THEN
               --
               g_nom_reporte :=  'em_k_jrp_oferta_228_'||p_sufijo_rep||'_msv';
               l_nom_reporte := g_nom_reporte;            
               --
            ELSE
               --
               g_nom_reporte := 'em_k_jrp_ofrta_mlt_228_'||p_sufijo_rep||'_msv';
               l_nom_reporte := 'em_k_jrp_oferta_228_'||p_sufijo_rep||'_msv';            
               --            
            END IF;   
            --
         END IF;
      ELSE
         --
         IF g_cod_modalidad = g_k_cobertura_total  
         THEN
            --
            IF g_num_riesgos = trn.uno
            THEN
               --
               g_nom_reporte := 'em_k_jrp_poliza_228_'||p_sufijo_rep||'_tr_msv';
               l_nom_reporte := g_nom_reporte;
               --
               IF trn_k_global.f_devuelve_n('jbchoose_report') = G_K_REP_PC
               THEN
                  --
                  g_nom_reporte := 'em_k_jrp_poliza_cge_228_'||p_sufijo_rep||'_tr_comp_msv';                                                                      
                  --                  
               END IF;                               
               --
            ELSE
               --
               g_nom_reporte :='em_k_jrp_poliza_mlt_228_'||p_sufijo_rep||'_tr_msv'; 
               l_nom_reporte :='em_k_jrp_poliza_228_'||p_sufijo_rep||'_tr_msv';              
               --
               IF trn_k_global.f_devuelve_n('jbchoose_report') = G_K_REP_PC
               THEN
                  --                  
                  g_nom_reporte := 'em_k_jrp_poliza_cge_mlt_228_'||p_sufijo_rep||'_tr_comp_msv';                                                                      
                  --                  
               END IF;                
               --
            END IF;             
            --
         ELSE
            --
            IF g_num_riesgos = trn.uno
            THEN
               --
               g_nom_reporte := 'em_k_jrp_poliza_228_'||p_sufijo_rep||'_msv';
               l_nom_reporte := g_nom_reporte;
               --
               IF trn_k_global.f_devuelve_n('jbchoose_report') = G_K_REP_PC
               THEN
                  --                 
                  g_nom_reporte := 'em_k_jrp_poliza_228_'||p_sufijo_rep||'_completa_msv';                  
                  --                  
               END IF;
               --
            ELSE
               --
               l_nom_reporte := 'em_k_jrp_poliza_228_'    ||p_sufijo_rep||'_msv';
               g_nom_reporte := 'em_k_jrp_poliza_mlt_228_'||p_sufijo_rep||'_msv';
               --
               IF trn_k_global.f_devuelve_n('jbchoose_report') = G_K_REP_PC
               THEN
                  -- 
                  g_nom_reporte := 'em_k_jrp_poliza_mlt_228_'||p_sufijo_rep||'_comp_msv';                
                  --                  
               END IF;               
               --
            END IF;            
            --
         END IF;         
         --
      END IF;      
      --
      g_id_report := trn_k_report.f_open_report(p_clob_datos  => g_xml_impresion      ,
                                                p_nom_fichero => g_cod_report         ,
                                                p_cod_modelo  => 'msv,'||g_nom_reporte,
                                                p_label       => 'param'              );
      --
      trn_k_global.p_asigna('JBID_FICHERO',g_id_report);
      --
      OPEN  c_a1009012_msv(l_nom_reporte);
      --
      FETCH c_a1009012_msv BULK COLLECT INTO g_tbl_txt_reporte;
      CLOSE c_a1009012_msv;
      --
      IF p_sufijo_rep IN (G_K_REP_PS_TEXT,G_K_REP_CT_TEXT) 
      THEN
         -- Cabecera
         pp_open_tag('cabecera');
         --
         pp_agrega_tbl('T', 'cabeceraIzq'  ,fp_txt_reporte(1) );
         pp_agrega_tbl('T', 'cabeceraDer'  ,fp_txt_reporte(2) );
         pp_agrega_tbl('T', 'logo_carta'   ,fp_txt_reporte(40));
         pp_agrega_tbl('T', 'firma_carta'  ,fp_txt_reporte(41));
         pp_agrega_tbl('T', 'firma_poliza' ,fp_txt_reporte(65));
         --
         pp_write_clob(TRUE);
         pp_close_tag('cabecera');
         --Textos
         pp_open_tag('texto_fijo');
         --
         pp_agrega_tbl('T', 'titulo_2',  fp_txt_reporte(4) );
         pp_agrega_tbl('T', 'titulo_3',  fp_txt_reporte(5) );
         pp_agrega_tbl('T', 'titulo_4',  fp_txt_reporte(6) );
         pp_agrega_tbl('T', 'titulo_5',  fp_txt_reporte(7) );
         pp_agrega_tbl('T', 'titulo_6',  fp_txt_reporte(8) );
         pp_agrega_tbl('T', 'titulo_7',  fp_txt_reporte(9) );
         pp_agrega_tbl('T', 'titulo_8',  fp_txt_reporte(10));
         pp_agrega_tbl('T', 'titulo_9',  fp_txt_reporte(11));
         pp_agrega_tbl('T', 'titulo_10', fp_txt_reporte(12));
         pp_agrega_tbl('T', 'titulo_15', fp_txt_reporte(17));
         --
         IF g_tip_spto != g_k_rf
         THEN
            --
            -- --v1.14 {
            --
            BEGIN 
               --
               g_titulo := fp_txt_reporte(g_k_20); --v1.15
               --
               ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                        p_nom_nemotecnico => g_k_fec_tarifa      ,
                                        p_cod_ramo        => g_cod_ramo          ,
                                        p_cod_campo       => g_k_fec_enero       ,
                                        p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                        p_cod_cob         => em.COD_COB_GEN      ,
                                        p_fec_efec_spto   => g_fec_efec_spto     );
               --
               g_fec_enero := to_date(ea_k_g2999003_msv.f_txt_campo_alterno, 'ddmmyyyy');
               --
               ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                        p_nom_nemotecnico => g_k_t_pminima       ,
                                        p_cod_ramo        => g_cod_ramo          ,
                                        p_cod_campo       => g_k_prima_minima    ,
                                        p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                        p_cod_cob         => em.COD_COB_GEN      ,
                                        p_fec_efec_spto   => g_fec_efec_spto     );
               --
               IF g_fec_efec_spto >= g_fec_enero
               THEN
                  --
                  g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_maximo);
                  --
               ELSE
                  --
                  g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_minimo);
                  --
               END IF;
               --
               pp_agrega_tbl('T', g_k_titulo_18, g_titulo); --v1.15
               --
            EXCEPTION
            WHEN OTHERS
               THEN
                  --
                  pp_agrega_tbl('T', g_k_titulo_18, fp_txt_reporte(g_k_20)); -- v 1.15
                  --
            END;
            --
            -- } v1.14
            --
            pp_agrega_tbl('T', 'titulo_1',  fp_txt_reporte(3) );
            pp_agrega_tbl('T', 'titulo_16', fp_txt_reporte(18));
            pp_agrega_tbl('T', 'titulo_17', fp_txt_reporte(19));
            pp_agrega_tbl('T', 'titulo_19', fp_txt_reporte(21)); -- v1.15
            pp_agrega_tbl('T', 'titulo_20', fp_txt_reporte(22)); -- v1.15
            pp_agrega_tbl('T', 'titulo_21', fp_txt_reporte(23)); -- v1.15
            pp_agrega_tbl('T', 'titulo_24', fp_txt_reporte(24)); -- v1.15
            pp_agrega_tbl('T', 'titulo_70', fp_txt_reporte(70)); -- v 1.10
            pp_agrega_tbl('T', 'titulo_71', fp_txt_reporte(71)); -- v 1.10
            pp_agrega_tbl('T', 'titulo_72', fp_txt_reporte(72)); -- v 1.10
            pp_agrega_tbl('T', 'titulo_73', fp_txt_reporte(73)); -- v 1.10
            --
            l_texto   := fp_txt_reporte(15);
            --
            IF g_cod_modalidad = g_k_cobertura_total
            THEN
               --
               pp_agrega_tbl('T', 'titulo_24', fp_txt_reporte(16));
               --
            ELSE
               --
               pp_agrega_tbl('T', 'titulo_24', fp_txt_reporte(25));
               --
            END IF;
            --
         ELSE
            --
            IF g_cod_modalidad = g_k_cobertura_total
            THEN
               --
               --v1.15 {
               IF g_jbtip_emision = g_k_rep_poliza 
               THEN
                  --
                  BEGIN 
                     --
                     g_titulo := fp_txt_reporte(g_k_20); -- v1.15
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_fec_tarifa      ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_fec_enero       ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     g_fec_enero := to_date(ea_k_g2999003_msv.f_txt_campo_alterno, 'ddmmyyyy');
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_t_pminima       ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_prima_minima    ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     IF g_fec_efec_spto >= g_fec_enero
                     THEN
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_maximo);
                        --
                     ELSE
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_minimo);
                     --
                     END IF;
                     --
                     pp_agrega_tbl('T', 'titulo_18', g_titulo);
                     --
                  EXCEPTION
                  WHEN OTHERS
                     THEN
                        --
                        pp_agrega_tbl('T', 'titulo_18', fp_txt_reporte(g_k_20)); -- v1.15
                        --
                  END;
                  --
                  -- } v1.15
                  --v1.14 {
               ELSIF g_jbtip_emision = g_k_rep_cotizacion 
               THEN -- v1.15
                  --
                  BEGIN 
                     --
                     g_titulo := fp_txt_reporte(g_k_21);
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_fec_tarifa      ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_fec_enero       ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     g_fec_enero := to_date(ea_k_g2999003_msv.f_txt_campo_alterno, 'ddmmyyyy');
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_t_pminima       ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_prima_minima    ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     IF g_fec_efec_spto >= g_fec_enero
                     THEN
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_maximo);
                        --
                     ELSE
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_minimo);
                        --
                     END IF;
                     --
                     pp_agrega_tbl('T', g_k_titulo_19, g_titulo);
                     --
                  EXCEPTION
                  WHEN OTHERS
                     THEN
                        --
                        pp_agrega_tbl('T', g_k_titulo_19, fp_txt_reporte(g_k_21));
                        --
                  END;
                  --
               END IF;-- v1.15
               --
               -- } v1.14
               pp_agrega_tbl('T', 'titulo_16'  , fp_txt_reporte(18));
               pp_agrega_tbl('T', 'titulo_17'  , fp_txt_reporte(19));
               pp_agrega_tbl('T', 'titulo_19'  , fp_txt_reporte(21)); -- v1.15
               pp_agrega_tbl('T', 'titulo_20'  , fp_txt_reporte(22)); -- v1.15
               pp_agrega_tbl('T', 'titulo_21'  , fp_txt_reporte(23)); -- v1.15
               pp_agrega_tbl('T', 'titulo_24'  , fp_txt_reporte(24)); -- v1.15
               pp_agrega_tbl('T', 'titulo_70'  , fp_txt_reporte(70)); -- v 1.10
               pp_agrega_tbl('T', 'titulo_71'  , fp_txt_reporte(71)); -- v 1.10
               --
            ELSIF g_cod_modalidad = g_k_tradicional
            THEN
               --
               -- --v1.14 {
               --
               IF g_jbtip_emision = g_k_rep_poliza 
               THEN -- v 1.15
                  --
                  BEGIN 
                     g_titulo := fp_txt_reporte(g_k_20);
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_fec_tarifa      ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_fec_enero       ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     g_fec_enero := to_date(ea_k_g2999003_msv.f_txt_campo_alterno, 'ddmmyyyy');
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_t_pminima       ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_prima_minima    ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     IF g_fec_efec_spto >= g_fec_enero
                     THEN
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_maximo);
                        --
                     ELSE
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_minimo);
                        --
                     END IF;
                     --
                     pp_agrega_tbl('T', 'titulo_18', g_titulo);
                     --
                  EXCEPTION
                  WHEN OTHERS
                     THEN
                        --
                        pp_agrega_tbl('T', 'titulo_18', fp_txt_reporte(g_k_20)); -- v1.15
                        --
                  END;
                  --
               -- } v1.14
               -- v 1.15 {
               ELSIF g_jbtip_emision = g_k_rep_cotizacion 
               THEN
                  --
                  BEGIN 
                     --
                     g_titulo := fp_txt_reporte(g_k_21);
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_fec_tarifa      ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_fec_enero       ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     g_fec_enero := to_date(ea_k_g2999003_msv.f_txt_campo_alterno, 'ddmmyyyy');
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_t_pminima       ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_prima_minima    ,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_spto     );
                     --
                     IF g_fec_efec_spto >= g_fec_enero
                     THEN
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_maximo);
                        --
                     ELSE
                        --
                        g_titulo := REPLACE(g_titulo, g_k_prima_minima, ea_k_g2999003_msv.f_txt_valor_minimo);
                        --
                     END IF;
                     --
                     pp_agrega_tbl('T', g_k_titulo_19, g_titulo);
                     --
                  EXCEPTION
                  WHEN OTHERS
                     THEN
                        --
                        pp_agrega_tbl('T', g_k_titulo_19, fp_txt_reporte(g_k_21));
                        --
                  END;
                  --
               END IF;-- } v1.15
               --
               --v 1.08{
               --
               pp_agrega_tbl('T', 'titulo_16'  , fp_txt_reporte(18));
               pp_agrega_tbl('T', 'titulo_17'  , fp_txt_reporte(19));
               pp_agrega_tbl('T', 'titulo_19'  , fp_txt_reporte(21)); -- v1.15
               pp_agrega_tbl('T', 'titulo_20'  , fp_txt_reporte(22)); -- v1.15
               pp_agrega_tbl('T', 'titulo_21'  , fp_txt_reporte(23)); -- v1.15
               pp_agrega_tbl('T', 'titulo_24'  , fp_txt_reporte(24)); -- v1.15
               pp_agrega_tbl('T', 'titulo_70'  , fp_txt_reporte(70)); -- v 1.10
               pp_agrega_tbl('T', 'titulo_71'  , fp_txt_reporte(71)); -- v 1.10
               --
               --v 1.08}
               --
            END IF;
            --            
            l_texto := fp_txt_reporte(13);
            --
            pp_agrega_tbl('T', 'titulo_1',  fp_txt_reporte(14));
            pp_agrega_tbl('T', 'titulo_24', fp_txt_reporte(16));
            --
         END IF;
         --
         l_texto   := REPLACE(l_texto,'[ciudad]',l_nom_ciudad);
         --  
         l_fecha_imp := TO_CHAR(SYSDATE,'dd')|| ' de '||
                        REPLACE(TO_CHAR(SYSDATE,'month','nls_date_language=spanish'),' ','')|| ' de '||
                        TO_CHAR(SYSDATE,'yyyy');                                  
         --         
         l_texto := REPLACE(l_texto,'[fecha]',l_fecha_imp);
         --
         pp_agrega_tbl('T', 'titulo_13',l_texto);         
         --
         pp_agrega_tbl('T', 'titulo_56', fp_txt_reporte(60));
         --
         pp_agrega_tbl('T', 'titulo_23', fp_txt_reporte(26));
         --
         IF g_jbtip_emision = g_k_rep_cotizacion
         THEN
            --
            pp_agrega_tbl('T', 'titulo_29', fp_txt_reporte(29)); 
            l_texto_2 := fp_txt_reporte(17);
            l_texto_2 := REPLACE(l_texto_2,'[ciudad]',l_nom_ciudad);
            l_texto_2 := REPLACE(l_texto_2,'[fecha]' ,l_fecha_imp );
            pp_agrega_tbl('T', 'titulo_30', l_texto_2); 
            --
         END IF;                  
         --
         IF g_cod_modalidad = g_k_cobertura_total
         THEN
            --
            pp_agrega_tbl('T', 'deducible_1' , fp_txt_reporte(30));
            pp_agrega_tbl('T', 'deducible_2' , fp_txt_reporte(31));
            pp_agrega_tbl('T', 'deducible_3' , fp_txt_reporte(32));
            pp_agrega_tbl('T', 'deducible_4' , fp_txt_reporte(33));
            pp_agrega_tbl('T', 'deducible_5' , fp_txt_reporte(34));
            pp_agrega_tbl('T', 'deducible_6' , fp_txt_reporte(35));
            pp_agrega_tbl('T', 'deducible_7' , fp_txt_reporte(36));
            pp_agrega_tbl('T', 'deducible_8' , fp_txt_reporte(37));
            pp_agrega_tbl('T', 'deducible_9' , fp_txt_reporte(38));
            pp_agrega_tbl('T', 'deducible_10', fp_txt_reporte(39));
            --
         END IF; 
         --
         IF trn_k_global.f_devuelve_n('jbchoose_report') = G_K_REP_PC
         THEN
            --
            pp_agrega_tbl('T', 'titulo_42', fp_txt_reporte(42));
            pp_agrega_tbl('T', 'titulo_43', fp_txt_reporte(43));
            pp_agrega_tbl('T', 'titulo_44', fp_txt_reporte(44));
            pp_agrega_tbl('T', 'titulo_45', fp_txt_reporte(45));
            pp_agrega_tbl('T', 'titulo_46', fp_txt_reporte(46));
            pp_agrega_tbl('T', 'titulo_47', fp_txt_reporte(47));
            pp_agrega_tbl('T', 'titulo_48', fp_txt_reporte(48));
            --
            l_texto_1 := fp_txt_reporte(49);
            l_texto_1 := REPLACE(l_texto_1,g_k_fecha_1,l_fecha_imp);
            l_texto_1 := REPLACE(l_texto_1,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
            l_texto_1 := REPLACE(l_texto_1,g_k_poliza ,g_num_poliza);
            --
            l_texto_2 := fp_txt_reporte(51);
            l_texto_2 := REPLACE(l_texto_2,g_k_fecha_1,l_fecha_imp);
            l_texto_2 := REPLACE(l_texto_2,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
            l_texto_2 := REPLACE(l_texto_2,g_k_poliza ,g_num_poliza);            
            --
            l_texto_3 := fp_txt_reporte(53);
            l_texto_3 := REPLACE(l_texto_3,g_k_fecha_1,l_fecha_imp);
            l_texto_3 := REPLACE(l_texto_3,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
            l_texto_3 := REPLACE(l_texto_3,g_k_poliza ,g_num_poliza);              
            --
            l_texto_4 := fp_txt_reporte(55);
            l_texto_4 := REPLACE(l_texto_4,g_k_fecha_1,l_fecha_imp);
            l_texto_4 := REPLACE(l_texto_4,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
            l_texto_4 := REPLACE(l_texto_4,g_k_poliza ,g_num_poliza);  
            --
            IF g_cod_modalidad != g_k_cobertura_total
            THEN 
               --
               pp_agrega_tbl('B', 'titulo_49', l_texto_1); 
               --            
            ELSE
               --
               l_texto_5 := fp_txt_reporte(56);
               l_texto_5 := REPLACE(l_texto_5,g_k_fecha_1,l_fecha_imp);
               l_texto_5 := REPLACE(l_texto_5,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_5 := REPLACE(l_texto_5,g_k_poliza ,g_num_poliza);
               --
               l_texto_6 := fp_txt_reporte(57);
               l_texto_6 := REPLACE(l_texto_6,g_k_fecha_1,l_fecha_imp);
               l_texto_6 := REPLACE(l_texto_6,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_6 := REPLACE(l_texto_6,g_k_poliza ,g_num_poliza);                
               --
               l_texto_7 := fp_txt_reporte(58);
               l_texto_7 := REPLACE(l_texto_7,g_k_fecha_1,l_fecha_imp);
               l_texto_7 := REPLACE(l_texto_7,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_7 := REPLACE(l_texto_7,g_k_poliza ,g_num_poliza);                
               --
               l_texto_8 := fp_txt_reporte(59);
               l_texto_8 := REPLACE(l_texto_8,g_k_fecha_1,l_fecha_imp);
               l_texto_8 := REPLACE(l_texto_8,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_8 := REPLACE(l_texto_8,g_k_poliza ,g_num_poliza);                
               --                
               pp_agrega_tbl('B', 'titulo_49', l_texto_1||
                                               l_texto_5||
                                               l_texto_6||
                                               l_texto_7||
                                               l_texto_8);
               --
            END IF;
            --
            pp_agrega_tbl('T', 'titulo_50', fp_txt_reporte(50));
            pp_agrega_tbl('B', 'titulo_51', l_texto_2);
            pp_agrega_tbl('T', 'titulo_52', fp_txt_reporte(52));
            pp_agrega_tbl('B', 'titulo_53', l_texto_3);                                   
            pp_agrega_tbl('T', 'titulo_54', fp_txt_reporte(54));
            --
            IF g_cod_modalidad = g_k_cobertura_total
            THEN 
               --
               pp_agrega_tbl('B', 'titulo_55', l_texto_4);
               --
            ELSE
               --
               l_texto_5 := fp_txt_reporte(56);
               l_texto_5 := REPLACE(l_texto_5,g_k_fecha_1,l_fecha_imp);
               l_texto_5 := REPLACE(l_texto_5,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_5 := REPLACE(l_texto_5,g_k_poliza ,g_num_poliza); 
               --
               l_texto_6 := fp_txt_reporte(57);
               l_texto_6 := REPLACE(l_texto_6,g_k_fecha_1,l_fecha_imp);
               l_texto_6 := REPLACE(l_texto_6,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_6 := REPLACE(l_texto_6,g_k_poliza ,g_num_poliza);                
               --
               l_texto_7 := fp_txt_reporte(58);
               l_texto_7 := REPLACE(l_texto_7,g_k_fecha_1,l_fecha_imp);
               l_texto_7 := REPLACE(l_texto_7,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_7 := REPLACE(l_texto_7,g_k_poliza ,g_num_poliza);                
               --
               l_texto_8 := fp_txt_reporte(59);
               l_texto_8 := REPLACE(l_texto_8,g_k_fecha_1,l_fecha_imp);
               l_texto_8 := REPLACE(l_texto_8,g_k_fecha_2,(l_nom_ciudad||', '||l_fecha_imp));
               l_texto_8 := REPLACE(l_texto_8,g_k_poliza ,g_num_poliza);                
               --                               
               pp_agrega_tbl('B', 'titulo_55', l_texto_4||
                                               l_texto_5||
                                               l_texto_6||
                                               l_texto_7||
                                               l_texto_8);
               --
            END IF;
            --
         END IF;
         --
         pp_write_clob(TRUE);
         pp_close_tag('texto_fijo');
         -- firma
         pp_open_tag('firma');
         --
         pp_agrega_tbl('T', 'firma', 'fp_txt_reporte(14)');
         --
         pp_write_clob(TRUE);
         pp_close_tag('firma');
         --
      END IF;
      --
      pp_write_clob(TRUE);
      --
      pp_close_tag('param');
      --
      --@mx('F','pp_inicializa_rep');
      --
   END pp_inicializa_rep;
   --
   /* --------------------------------------------------------
   || pp_abre_reporte:
   */ --------------------------------------------------------
   --
   PROCEDURE pp_abre_reporte
   IS
   --
   BEGIN
      --
      --@mx('I','pp_abre_reporte');
      --
      IF g_cont_regs = trn.CERO AND g_abre_reporte
      THEN
         --
         CASE trn_k_global.f_devuelve_n('jbchoose_report')
         --
         WHEN G_K_REP_PS THEN pp_inicializa_rep(g_jbchoose_report, G_K_REP_PS_TEXT);
         --
         WHEN G_K_REP_CT THEN pp_inicializa_rep(g_jbchoose_report, G_K_REP_CT_TEXT);
         --
         WHEN G_K_REP_PC THEN pp_inicializa_rep(g_jbchoose_report, G_K_REP_PS_TEXT);
         --
         END CASE;
         --
         g_abre_reporte := FALSE;
         --
      END IF;
      --
      --@mx('F','pp_abre_reporte');
      --
   END pp_abre_reporte;
   --
   /* --------------------------------------------------------
   || pp_cal_anexos:
   || Calcula los anexos que deben mostrarse en los reportes
   || SCHEDULE y QUOTATION
   */ --------------------------------------------------------
   --
   PROCEDURE pp_cal_anexos(p_cod_cia       IN a2000030.cod_cia      %TYPE,
                           p_num_poliza    IN a2000030.num_poliza   %TYPE,
                           p_num_spto      IN a2000030.num_spto     %TYPE,
                           p_num_apli      IN a2000030.num_apli     %TYPE,
                           p_num_spto_apli IN a2000030.num_spto_apli%TYPE,
                           p_num_riesgo    IN a2000260.num_riesgo   %TYPE)
   IS
      --
      l_cod_anexo CONSTANT a2000260.cod_anexo%TYPE := 'ZZZZZZZZZZ';
      --
      l_cv_anexos  CV_RESULTS;
      l_txt_query  CLOB;
      --
      lreg_anexo a2000260 %ROWTYPE;
      --
      l_num_riesgo a2000260.num_riesgo %TYPE;
      --
      l_flag_continue BOOLEAN;
      --
      l_contador_riesgo INTEGER;
      l_contador_poliza INTEGER;
      --
      l_texto_riesgo CLOB;
      l_texto_poliza CLOB;
      --
   BEGIN
      --
      --@mx('I','pp_cal_anexos');
      --
      l_txt_query := 'SELECT a.cod_cia      ,
                             a.num_poliza   ,
                             a.num_spto     ,
                             a.num_apli     ,
                             a.num_spto_apli,
                             a.num_riesgo   ,
                             a.cod_anexo    ,
                             a.num_secu     ,
                             a.texto        ';
      IF g_quotation
      THEN
         --
         l_txt_query := l_txt_query || ' FROM p2000260 a ';
         --
      ELSE
         --
         l_txt_query := l_txt_query || ' FROM a2000260 a ';
         --
      END IF;
      --
      l_txt_query := l_txt_query || ' WHERE a.num_poliza    = ' || '''' || p_num_poliza || '''';
      l_txt_query := l_txt_query || ' AND a.num_riesgo    IN (''0'', ' || p_num_riesgo || ')'  ;
      l_txt_query := l_txt_query || ' AND a.num_apli      = ' || p_num_apli                    ;
      l_txt_query := l_txt_query || ' AND a.num_spto_apli = ' || p_num_spto_apli               ;
      l_txt_query := l_txt_query || ' AND a.cod_cia = '       || p_cod_cia                     ;
      l_txt_query := l_txt_query || ' AND a.cod_anexo     = ' || '''' || l_cod_anexo || ''''   ;
      l_txt_query := l_txt_query || ' AND a.num_spto   IN (SELECT MAX(b.num_spto) num_spto '   ;
      --
      IF g_quotation
      THEN
         --
         l_txt_query := l_txt_query || ' FROM p2000260 b ';
         --
      ELSE
         --
         l_txt_query := l_txt_query || ' FROM a2000260 b ';
         --
      END IF;
      --
      l_txt_query := l_txt_query || ' WHERE b.num_poliza    = a.num_poliza ' ;
      l_txt_query := l_txt_query || ' AND b.num_riesgo    = a.num_riesgo '   ;
      l_txt_query := l_txt_query || ' AND b.num_apli      = a.num_apli '     ;
      l_txt_query := l_txt_query || ' AND b.num_spto_apli = a.num_spto_apli ';
      l_txt_query := l_txt_query || ' AND b.num_spto     <= ' || p_num_spto  ;
      --
      IF NOT g_quotation
      THEN
         --
         l_txt_query := l_txt_query || ' AND ''N'' = em_k_jrp_228_emi_msv.f_es_spto_anulado( p_cod_cia => b.cod_cia ,';
         --
         l_txt_query := l_txt_query || ' p_num_poliza    => b.num_poliza ,'    ;
         l_txt_query := l_txt_query || ' p_num_spto      => b.num_spto   ,'    ;
         l_txt_query := l_txt_query || ' p_num_apli      => b.num_apli   ,'    ;
         l_txt_query := l_txt_query || ' p_num_spto_apli => b.num_spto_apli ) ';
         --
      END IF;
      --
      l_txt_query := l_txt_query || ' AND b.cod_anexo     = a.cod_anexo ) ';
      l_txt_query := l_txt_query || ' ORDER BY num_riesgo   ASC ,'         ;
      l_txt_query := l_txt_query || ' cod_anexo    DESC,'                  ;
      l_txt_query := l_txt_query || ' num_secu     ASC '                   ;
      --
      l_num_riesgo := '-1';
      --
      l_flag_continue := TRUE;
      --
      IF l_cv_anexos %ISOPEN
      THEN
         --
         CLOSE l_cv_anexos;
         --
      END IF;
      --
      OPEN l_cv_anexos FOR l_txt_query;
      --
      FETCH l_cv_anexos INTO lreg_anexo;
      --
      l_contador_riesgo := trn.cero;
      l_contador_poliza := trn.cero;
      --
      l_texto_riesgo := '';
      l_texto_poliza := '';
      --
      WHILE l_cv_anexos%FOUND
      LOOP
         --
         IF l_num_riesgo <> lreg_anexo.num_riesgo
         THEN
            --
            l_num_riesgo := lreg_anexo.num_riesgo;
            --
            IF SUBSTR(UPPER(TRIM(lreg_anexo.texto)), 1, 6) = 'REMOVE'
            THEN
               --
               l_flag_continue := FALSE;
               --
            ELSE
               --
               l_flag_continue := TRUE;
               --
            END IF;
            --
         END IF;
         --
         IF l_flag_continue
         THEN
            --
            IF l_num_riesgo = trn.CERO
            THEN
               --
               IF     l_texto_poliza IS NOT NULL
                  AND LENGTH(l_texto_poliza) > trn.CERO
               THEN
                  --
                  l_texto_poliza    := l_texto_poliza || '<br>'  || lreg_anexo.texto;
                  --
               ELSE
                  --
                  l_texto_poliza    := l_texto_poliza || lreg_anexo.texto;
                  --
               END IF;
               --
               l_contador_poliza := l_contador_poliza + 1;
               --
            ELSE
               --
               IF     l_texto_riesgo IS NOT NULL
                  AND LENGTH(l_texto_riesgo) > trn.CERO
               THEN
                  --
                  l_texto_riesgo    := l_texto_riesgo || '<br>' || lreg_anexo.texto;
                  --
               ELSE
                  --
                  l_texto_riesgo    := l_texto_riesgo || lreg_anexo.texto;
                  --
               END IF;
               --
               l_contador_riesgo := l_contador_riesgo + 1;
               --
            END IF;
            --
         END IF;
         --
         FETCH l_cv_anexos INTO lreg_anexo;
         --
      END LOOP;
      --
      CLOSE l_cv_anexos;
      --
      IF    l_contador_poliza > trn.CERO
         OR l_contador_riesgo > trn.CERO
      THEN
         --
         pp_open_tag('endorsement');
         --
      END IF;
      --
      IF l_contador_poliza > trn.CERO
      THEN
         --
         pp_agrega_tbl('T', 'type', 'Anexess')            ;
         pp_agrega_tbl('T', 'policy', 'Policy')           ;
         pp_agrega_tbl('T', 'policy_list', l_texto_poliza);
         --
         pp_write_clob(TRUE);
         --
      END IF;
      --
      IF l_contador_riesgo > trn.CERO
      THEN
         --
         pp_agrega_tbl('T', 'type'     , 'Anexess'     );
         pp_agrega_tbl('T', 'risk'     , 'Risk'        );
         pp_agrega_tbl('T', 'risk_list', l_texto_riesgo);
         --
         pp_write_clob(TRUE);
         --
      END IF;
      --
      IF    l_contador_poliza > trn.CERO
         OR l_contador_riesgo > trn.CERO
      THEN
         --
         pp_close_tag('endorsement');
         --
      END IF;
      --
      --@mx('F','pp_cal_anexos');
      --
   END pp_cal_anexos;
   --
   /* --------------------------------------------------------
   || pp_cal_sptos:
   || Se procesa el Tag <endorsements_applied_details>
   || que contiene la lista de suplementos
   */ --------------------------------------------------------
   --
   PROCEDURE pp_cal_sptos
   IS
   --
   BEGIN
      --
      --@mx('I','pp_cal_sptos');
      --
      pp_open_tag('endorsements_applied_details');
      --
      pp_cal_anexos( p_cod_cia       => g_cod_cia      ,
                     p_num_poliza    => g_num_poliza   ,
                     p_num_spto      => g_num_spto     ,
                     p_num_apli      => g_num_apli     ,
                     p_num_spto_apli => g_num_spto_apli,
                     p_num_riesgo    => g_num_riesgo   );
      --
      --IF  g_jbtip_emision != g_k_rep_cotizacion
      IF g_cod_modalidad != g_k_cobertura_total
      THEN
         --
         pp_dev_coberturas_pln_tr(p_num_riesgo => g_num_riesgo);
         --  
      ELSE
         --
         pp_dev_coberturas(p_num_riesgo => g_num_riesgo);
         --
      END IF;
      --
      pp_dev_clauses;      
      --
      pp_close_tag('endorsements_applied_details');
      --
      --@mx('F','pp_cal_sptos');
      --
   END pp_cal_sptos;
   --
   /* --------------------------------------------------------
   || pp_lee_riesgos_ncd:
   || Abre el cursor de riesgos para el reporte ncd
   */ --------------------------------------------------------
   --
   PROCEDURE pp_lee_riesgos_ncd(p_num_riesgo IN  a2000031.num_riesgo %TYPE,
                                p_reg_riesgo OUT reg_riesgo               )
   IS
      --
      l_cv_riesgos CV_RESULTS;
      --
   BEGIN
      --
      --@mx('I','pp_lee_riesgos_ncd');
      --
      IF l_cv_riesgos %ISOPEN
      THEN
        --
        CLOSE l_cv_riesgos;
        --
      END IF;
      --
      l_cv_riesgos := fp_abre_riesgos( p_mca_tabla_p => trn.NO       ,
                                       p_mca_tabla_r => trn.NO       ,
                                       p_num_riesgo  => p_num_riesgo );
      --
      FETCH l_cv_riesgos INTO p_reg_riesgo ;
      g_existe_riesgo := l_cv_riesgos%FOUND;
      --
      CLOSE l_cv_riesgos;
      --
      g_num_riesgo := p_reg_riesgo.num_riesgo;
      --
      --@mx('F','pp_lee_riesgos_ncd');
      --
   END pp_lee_riesgos_ncd;
   -- 
   /* --------------------------------------------------------
   || pp_dev_recibos:
   || Busca las recibos de la poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_dev_recibos
   IS
    --
      l_tip_situacion   a2990700.tip_situacion   %TYPE;
      l_fec_vcto_pago   a2990700.fec_vcto_pago   %TYPE;
      l_fec_efec_recibo a2990700.fec_efec_recibo %TYPE;
      l_fec_vcto_recibo a2990700.fec_vcto_recibo %TYPE;
      l_imp_neta        a2990700.imp_neta        %TYPE;
      l_imp_boni        a2990700.imp_boni        %TYPE;
      l_imp_imptos      a2990700.imp_imptos      %TYPE;
      l_costo_fracc     a2990700.imp_interes     %TYPE;
      l_cod_mon         a2990700.cod_mon         %TYPE;
      l_nom_mon         a1000400.cod_mon_iso     %TYPE;
      l_imp_recibo      a2990700.imp_recibo      %TYPE;
      l_num_recibo      a2990700.num_recibo      %TYPE;
      l_numero_cuotas   a2990700.num_cuota       %TYPE;
      l_cantidad_cuota  a1001402.cod_fracc_pago  %TYPE;
      l_gastos_emision  a2000161.imp_eco         %TYPE;
      l_num_mvto_cv     a2000032.num_mvto_cv     %TYPE;      
      --
      l_consulta        CLOB;
      --
      l_count_sptos     NUMBER;
      --
      l_mca_cambio_plan BOOLEAN;
      l_mca_cambio_pp   BOOLEAN;
      l_num_cuota       INTEGER;
      --
      l_fec_vcto_pago_txt VARCHAR(50);
      --
      l_cur_recibo      CV_RESULTS;
      --
      PROCEDURE pi_cambio_plan_pagos(p_num_poliza    IN a2000030.num_poliza   %TYPE,
                                     p_num_spto      IN a2000030.num_spto     %TYPE,
                                     p_num_apli      IN a2000030.num_apli     %TYPE,
                                     p_num_spto_apli IN a2000030.num_spto_apli%TYPE,                                     
                                     p_num_mvto_cv  OUT a2000032.num_mvto_cv  %TYPE,
                                     p_count_spto   OUT NUMBER                     ,
                                     p_aplica_pp    OUT BOOLEAN)
      IS
         --
         CURSOR l_c_aplica_pp
         IS
            --
            SELECT a.num_mvto_cv
              FROM a2000032 a
             WHERE a.num_poliza    = p_num_poliza       
               AND a.num_apli      = p_num_apli     
               AND a.num_spto_apli = p_num_spto_apli;
         --
         CURSOR l_c_a2000030
         IS
            --
            SELECT COUNT(*)
              FROM a2000030 a
             WHERE a.num_poliza = p_num_poliza;            
         --
      BEGIN
         --
         p_count_spto := TRN.CERO;
         --
         OPEN l_c_aplica_pp;
         FETCH l_c_aplica_pp INTO p_num_mvto_cv;
         CLOSE l_c_aplica_pp;
         --
         IF p_num_mvto_cv IS NOT NULL
         THEN
            --
            p_aplica_pp := TRUE;
            --
         ELSE
            --
            p_aplica_pp := FALSE;
            --
         END IF;
         --
         p_num_mvto_cv := NVL(p_num_mvto_cv, trn.CERO); -- v 1.05
         --
         OPEN l_c_a2000030;
         FETCH l_c_a2000030 INTO p_count_spto;
         CLOSE l_c_a2000030;                  
         --
      EXCEPTION 
         --
         WHEN OTHERS
         THEN
            --
            p_aplica_pp := FALSE;
            --
            p_num_mvto_cv := trn.CERO; -- v 1.05
         --      
      END pi_cambio_plan_pagos;      
      --
      FUNCTION fp_cant_cuotas(p_num_poliza    IN a2000030.num_poliza    %TYPE,
                              p_num_spto      IN a2000030.num_spto      %TYPE,
                              p_num_apli      IN a2000030.num_apli      %TYPE,
                              p_num_spto_apli IN a2000030.num_spto_apli %TYPE)
         RETURN VARCHAR2
      IS
         --
         l_cont_cuota a1001402.cod_fracc_pago %TYPE;
         --
         CURSOR c_cant_cuotas
         IS
            -- {- v 1.07
            SELECT COUNT(*)
              FROM a2990700 b
             WHERE cod_cia        = g_cod_cia
               AND num_poliza     = p_num_poliza
               AND num_spto       = p_num_spto
               AND num_apli       = p_num_apli
               AND num_spto_apli  = p_num_spto_apli
               AND tip_situacion != g_k_situa_recib_ac
               AND num_spto      >= (SELECT MAX(a.num_spto)
                                           FROM a2000030 a
                                          WHERE a.cod_cia          = b.cod_cia
                                            AND a.num_poliza       = b.num_poliza
                                            AND a.mca_spto_anulado = 'N'
                                            AND a.tip_spto        IN ('XX','RF'))
             ORDER BY num_recibo;
         -- - v 1.07}
      BEGIN
         --
         OPEN c_cant_cuotas;
         FETCH c_cant_cuotas INTO l_cont_cuota;
         CLOSE c_cant_cuotas;
         --
      RETURN l_cont_cuota;
      --
      END fp_cant_cuotas;
      -- gastos de emision de cada recibo
      FUNCTION fp_gastos_emision(p_num_cuota   a2000161.num_cuota  %TYPE,
                                 p_cambio_plan BOOLEAN                  )
         RETURN a2000161.imp_eco%TYPE
      IS
         --
         l_consulta   CLOB;
         --
         l_cur_gastos CV_RESULTS;
         --
         l_gastos     a2000161.imp_eco%TYPE;
      BEGIN
         --
         l_consulta := 'SELECT NVL(SUM(DECODE(cod_eco, 3 , imp_eco, 0)), 0)';
         --
         l_consulta := l_consulta || ' FROM a2000161 a';
         --
         l_consulta := l_consulta || ' WHERE a.cod_cia       = ' ||g_cod_cia||'            '||
                                     '   AND a.num_poliza    = ' || g_num_poliza || '      ';
         --
         IF p_cambio_plan
         THEN
            --
            l_consulta := l_consulta || ' AND a.num_spto     <= '|| g_num_spto || '        ';
            --
         ELSE
            --
            l_consulta := l_consulta || ' AND a.num_spto      = '|| g_num_spto || '        ';
            --
         END IF;
         --
         l_consulta := l_consulta || ' AND a.num_spto     >= (SELECT MAX (b.num_spto)
                                                                FROM a2000030 b
                                                               WHERE b.cod_cia       = ' || g_cod_cia    || ' '||
                                                               ' AND b.num_poliza    = ' || g_num_poliza || ' '||
                                                               ' AND b.num_apli      = a.num_apli             '||
                                                               ' AND b.num_spto_apli = a.num_spto_apli        '||
                                                               ' AND b.tip_spto     IN ('''||g_k_rf||''', '''||g_k_xx||''') '||
                                                               ' AND b.num_spto     <= ' || g_num_spto || ')  '||
                                     ' AND a.num_apli      = ' || g_num_apli || '                             '||
                                     ' AND a.num_spto_apli = ' || g_num_spto_apli|| '                         '||
                                     ' AND a.cod_ramo      = ' || g_cod_ramo ||'                              '||
                                     ' AND a.num_cuota     = ' || p_num_cuota ||'                             ';
         --
         l_consulta := l_consulta || ' GROUP BY a.num_cuota ';
         --
         OPEN l_cur_gastos FOR l_consulta;
         --
         FETCH l_cur_gastos INTO l_gastos;
         CLOSE l_cur_gastos;
         --
         RETURN NVL(l_gastos, trn.CERO);
         --
      END fp_gastos_emision;
      --
   BEGIN
      --
      --@mx('I','pp_dev_recibos');
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         l_consulta := 'SELECT b.tip_situacion,
                        MAX((SELECT MAX(a.fec_vcto_pago) FROM p2990700 a WHERE  a.num_recibo = b.num_recibo AND a.num_cuota = b.num_cuota AND a.num_poliza  = b.num_poliza)) AS fec_vcto_pago,
                        MAX((SELECT MAX(a.fec_efec_recibo) FROM p2990700 a WHERE  a.num_recibo = b.num_recibo AND a.num_cuota = b.num_cuota AND a.num_poliza  = b.num_poliza)) AS fec_efec_recibo,
                        MAX((SELECT MAX(a.fec_vcto_recibo) FROM p2990700 a WHERE  a.num_recibo = b.num_recibo AND a.num_cuota = b.num_cuota AND a.num_poliza  = b.num_poliza)) AS fec_vcto_recibo,
                        b.cod_mon,
                        b.num_recibo,
                        SUM(imp_neta),
                        SUM(imp_boni),
                        SUM(imp_imptos),
                        SUM(imp_interes),
                        SUM(imp_recibo)';
                        --b.num_cuota'
         --         
         l_consulta := l_consulta || ' FROM p2990700 b';
         --
      ELSE
         --
         pi_cambio_plan_pagos(p_num_poliza    => g_num_poliza   ,
                              p_num_spto      => g_num_spto     ,
                              p_num_apli      => g_num_apli     ,
                              p_num_spto_apli => g_num_spto_apli,
                              p_num_mvto_cv   => l_num_mvto_cv  ,
                              p_count_spto    => l_count_sptos  ,
                              p_aplica_pp     => l_mca_cambio_pp);          
         --
         l_consulta := 'SELECT b.tip_situacion,
                        MAX((SELECT MAX(a.fec_vcto_pago) FROM a2990700 a WHERE  a.num_recibo = b.num_recibo AND a.num_cuota = b.num_cuota AND a.num_poliza  = b.num_poliza)) AS fec_vcto_pago,
                        MAX((SELECT MAX(a.fec_efec_recibo) FROM a2990700 a WHERE  a.num_recibo = b.num_recibo AND a.num_cuota = b.num_cuota AND a.num_poliza  = b.num_poliza)) AS fec_efec_recibo,
                        MAX((SELECT MAX(a.fec_vcto_recibo) FROM a2990700 a WHERE  a.num_recibo = b.num_recibo AND a.num_cuota = b.num_cuota AND a.num_poliza  = b.num_poliza)) AS fec_vcto_recibo,
                        b.cod_mon,
                        b.num_recibo,
                        SUM(imp_neta),
                        SUM(imp_boni),
                        SUM(imp_imptos),
                        SUM(imp_interes),
                        SUM(imp_recibo)';--,
                        --b.num_cuota';         
         --
         l_consulta := l_consulta || ' FROM a2990700 b';
         --
      END IF;
      --
      IF     (g_cod_spto = g_k_999
         AND g_sub_cod_spto = g_k_4)
         OR  g_tip_spto = g_k_nominativo
      THEN
         --
         IF g_tip_scope = g_k_scope_spto 
         THEN
            --
            l_consulta := l_consulta ||' WHERE b.cod_cia        = '||g_cod_cia||'                              '||
                                       '   AND b.num_poliza     = ' || g_num_poliza || '                       '||
                                       '   AND b.num_spto      <= NVL('||g_num_spto||',b.num_spto     )        '||
                                       '   AND b.num_apli       = NVL('||g_num_apli||' ,b.num_apli     )       '||
                                       '   AND b.imp_recibo     > 0                                            '||
                                       '   AND NVL(num_mvto_cv,0) = '|| l_num_mvto_cv||'                       '||                                       
                                       '   AND b.num_spto_apli <= NVL('||g_num_spto_apli||',b.num_spto_apli)   ';                        
            --
         ELSE
            --{ v 1.07
            l_consulta := l_consulta ||' WHERE b.cod_cia        = '    ||g_cod_cia      ||'                    '||
                                       '   AND b.num_poliza     = '    ||g_num_poliza   ||'                    '||
                                       '   AND b.num_spto      <= NVL('||g_num_spto     ||',b.num_spto     )   '||
                                       '   AND b.num_apli       = NVL('||g_num_apli     ||' ,b.num_apli     )  '||
                                       '   AND b.num_spto_apli <= NVL('||g_num_spto_apli||',b.num_spto_apli)   '||
                                       '   AND b.num_spto      >= (SELECT MAX(a.num_spto)
                                                                     FROM a2000030 a
                                                                    WHERE a.cod_cia          = b.cod_cia
                                                                      AND a.num_poliza       = b.num_poliza
                                                                      AND a.mca_spto_anulado = ''N''
                                                                      AND a.tip_spto        IN (''XX'',''RF''))' ;
            -- v 1.07}                           
         END IF;
         l_mca_cambio_plan := TRUE;
         --
      ELSE
         --
         IF g_tip_spto = g_k_xx
            AND l_count_sptos > 0
            AND g_tip_scope = g_k_scope_spto
         THEN
            --
            l_consulta := l_consulta ||' WHERE b.cod_cia        = '||g_cod_cia||'                              '||
                                       '   AND b.num_poliza     = ' || g_num_poliza || '                       '||
                                       '   AND b.num_spto       <= NVL('||g_num_spto||',b.num_spto     )       '||
                                       '   AND b.num_apli       = NVL('||g_num_apli||' ,b.num_apli     )       '||
                                       '   AND b.imp_recibo     > 0                                            '||
                                       '   AND NVL(num_mvto_cv,0) < 1                                          '||
                                       '   AND b.num_spto_apli <= NVL('||g_num_spto_apli||',b.num_spto_apli)   ';            
            --
         ELSE
            --
            --v 1.09{
            --
            IF g_jbtip_emision = g_k_rep_cotizacion
            THEN 
               --
               l_consulta := l_consulta ||' WHERE b.cod_cia        = '    ||g_cod_cia      ||'                    '  ||
                                          '   AND b.num_poliza     = '    ||g_num_poliza   || '                   '  ||
                                          '   AND b.num_spto      <= NVL('||g_num_spto     ||',b.num_spto     )   '  ||
                                          '   AND b.num_apli       = NVL('||g_num_apli     ||' ,b.num_apli     )  '  ||
                                          '   AND b.num_spto_apli <= NVL('||g_num_spto_apli||',b.num_spto_apli)   '  ||
                                          '   AND b.num_spto      >= (SELECT MAX(a.num_spto)
                                                                           FROM p2000030 a
                                                                          WHERE a.cod_cia          = b.cod_cia
                                                                            AND a.num_poliza       = b.num_poliza
                                                                            AND a.mca_spto_anulado = ''N''
                                                                            AND a.tip_spto        IN (''XX'',''RF''))';
               --
            ELSE
               -- { v 1.07
               l_consulta := l_consulta ||' WHERE b.cod_cia        = '    ||g_cod_cia      ||'                    '  ||
                                          '   AND b.num_poliza     = '    ||g_num_poliza   || '                   '  ||
                                          '   AND b.num_spto      <= NVL('||g_num_spto     ||',b.num_spto     )   '  ||
                                          '   AND b.num_apli       = NVL('||g_num_apli     ||' ,b.num_apli     )  '  ||
                                          '   AND b.num_spto_apli <= NVL('||g_num_spto_apli||',b.num_spto_apli)   '  ||
                                          '   AND b.num_spto      >= (SELECT MAX(a.num_spto)
                                                                           FROM a2000030 a
                                                                          WHERE a.cod_cia          = b.cod_cia
                                                                            AND a.num_poliza       = b.num_poliza
                                                                            AND a.mca_spto_anulado = ''N''
                                                                            AND a.tip_spto        IN (''XX'',''RF''))';
            END IF;
            --
            --v 1.09}
            --
         END IF;
         -- v 1.07}                           
         l_mca_cambio_plan := FALSE;
         --
      END IF;
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         l_consulta := l_consulta ||' GROUP BY b.tip_situacion,b.cod_mon,b.num_recibo,b.num_cuota
                                     HAVING SUM(b.imp_recibo) != 0 ';         
         --
      ELSE         
         --                                  
         l_consulta := l_consulta ||' GROUP BY b.tip_situacion,b.cod_mon,b.num_recibo
                                     HAVING b.num_recibo   != ''-1''  AND SUM(b.imp_recibo) != 0 ';
         --
      END IF;
      --
      l_consulta := l_consulta ||' ORDER BY b.num_recibo ';
      --
      l_num_cuota      := trn.CERO;
      l_cantidad_cuota := trn.CERO;
      --   
      OPEN l_cur_recibo FOR l_consulta;
      --
      pp_open_tag('recibos');
      --
      LOOP
        --
         FETCH l_cur_recibo INTO l_tip_situacion  ,
                                 l_fec_vcto_pago  ,
                                 l_fec_efec_recibo,
                                 l_fec_vcto_recibo,
                                 l_cod_mon        ,
                                 l_num_recibo     ,
                                 l_imp_neta       ,
                                 l_imp_boni       ,
                                 l_imp_imptos     ,
                                 l_costo_fracc    ,
                                 l_imp_recibo     ;                                 
         --
         EXIT WHEN l_cur_recibo%NOTFOUND;
         --
         IF NOT l_mca_cambio_plan
            OR (l_mca_cambio_plan AND l_imp_recibo != trn.CERO)
         THEN
            --
            l_cantidad_cuota := l_num_cuota + trn.UNO;
            l_num_cuota      := l_num_cuota + trn.UNO;
            l_imp_neta       := l_imp_neta  + l_imp_boni;            
            --
            l_nom_mon := CASE WHEN l_cod_mon = trn.UNO THEN g_signo_moneda
                                          WHEN l_cod_mon= g_k_14 THEN g_signo_moneda
                                            ELSE fp_nom_mon(l_cod_mon) END;          
            --
            l_imp_recibo := l_imp_recibo;
            --
            pp_open_tag('recibo');
            --
            l_fec_vcto_pago_txt := TO_CHAR(l_fec_vcto_pago,'dd/mon/yyyy','nls_date_language=spanish');
            --
            pp_agrega_tbl('T', 'sim_moneda'      , l_nom_mon           );
            pp_agrega_tbl('T', 'num_recibo'      , l_num_recibo        );
            pp_agrega_tbl('T', 'num_cuotas'      , l_num_cuota         );
            pp_agrega_tbl('T', 'tip_situacion'   , l_tip_situacion     );
            pp_agrega_tbl('T', 'fec_vcto_pago'   , l_fec_vcto_pago_txt );
            pp_agrega_tbl('T', 'fec_efec_recibo' , l_fec_efec_recibo   );
            pp_agrega_tbl('T', 'fec_vcto_recibo' , l_fec_vcto_recibo   );
            --
            pp_agrega_tbl('T', 'imp_neta'        , TRIM(TO_CHAR(NVL(l_imp_neta,trn.CERO),g_k_mascara)));
            --
            pp_agrega_tbl('T', 'imp_imptos'     , TRIM(TO_CHAR(NVL(l_imp_imptos,trn.CERO),g_k_mascara)));
            --
            pp_agrega_tbl('T', 'prima_mas_g_i'  , TRIM(TO_CHAR(NVL(l_imp_recibo,trn.CERO),g_k_mascara)));
            --
            pp_agrega_tbl('T', 'costo_fracc'    , TRIM(TO_CHAR(NVL(l_costo_fracc,trn.CERO),g_k_mascara)));
            --
          pp_write_clob(TRUE);
          --
          pp_close_tag('recibo');
          --
         END IF;
         --
      END LOOP;
      CLOSE l_cur_recibo;
      --
      pp_agrega_tbl('T', 'cant_cuotas'    , l_cantidad_cuota );
      pp_write_clob(TRUE);
      pp_close_tag('recibos');
      --
      --@mx('F','pp_dev_recibos');
      --
   END pp_dev_recibos;   
   --
   /* --------------------------------------------------------
   || pp_cob_pln_tr:
   || genera las coberturas para modalidad todo riesgo
   */ --------------------------------------------------------
   -- 
   PROCEDURE pp_cob_pln_tr
   IS
      --
      l_index NUMBER := trn.cero;
      --
      l_txt_descripcion g2999003_msv.txt_descripcion%TYPE;
      --
      l_k_text_1 CONSTANT VARCHAR2(58) := 'sobre la suma asegurada total de la ubicacion afectada min';
      l_k_text_2 CONSTANT VARCHAR2(18) := 'sin participacion.';
      --
      FUNCTION fi_retorna_base_cal(p_cod_cob a2000040.cod_cob%TYPE)
         RETURN g2999003_msv.txt_descripcion%TYPE
      IS
         --
         l_txt_descripcion g2999003_msv.txt_descripcion%TYPE;
         --
         CURSOR l_c_g2999003_msv
         IS
            --
            SELECT a.txt_descripcion
              FROM g2999003_msv a
             WHERE a.cod_cia  = g_cod_cia
               AND a.cod_ramo = g_cod_ramo
               AND a.cod_cob  = p_cod_cob;   
         --
      BEGIN
         --
         OPEN l_c_g2999003_msv;
         FETCH l_c_g2999003_msv INTO l_txt_descripcion;
         CLOSE l_c_g2999003_msv;
         --
         RETURN l_txt_descripcion;
         --
      EXCEPTION 
         WHEN OTHERS 
         THEN 
            --
            RETURN NULL;
            --
         --
      END fi_retorna_base_cal;      
      --
   BEGIN
      --
      pp_open_tag('cob_todo_riesgo');
      --
      IF g_reg_clau_espc.COUNT > trn.cero
      THEN
         --
         FOR k IN g_reg_clau_espc.FIRST ..g_reg_clau_espc.LAST
         LOOP
            --
            IF g_reg_clau_espc(k).txt_clausula IS NOT NULL
            THEN
               --
               l_index := l_index+trn.uno;
               --
               pp_open_tag('cobertura');
               --
               pp_agrega_tbl('T','nom_cob' ,l_index||' '||g_reg_clau_espc(k).txt_clausula,TRUE);
               pp_agrega_tbl('T','sum_aseg',g_reg_clau_espc(k).suma_aseg   ,TRUE);
               --
               pp_write_clob(TRUE);
               pp_close_tag('cobertura');
               --
            END IF;
            --
         END LOOP;   
         --
      END IF;
      --
      pp_write_clob(TRUE);
      pp_close_tag('cob_todo_riesgo');
      --
      pp_open_tag('deducibles');
      --
      IF g_reg_clau_espc.COUNT > trn.cero
      THEN
         --
         FOR k IN g_reg_clau_espc.FIRST ..g_reg_clau_espc.LAST
         LOOP
            --
            l_txt_descripcion := fi_retorna_base_cal(g_reg_clau_espc(k).cod_cob);
            --
            IF     l_txt_descripcion IS NOT NULL
               AND g_reg_clau_espc(k).aplica_porcentaje = trn.si
            THEN           
               --
               pp_open_tag('deducible');
               --
               pp_agrega_tbl('T','nom_cob'   ,g_reg_clau_espc(k).nom_cob,TRUE);            
               pp_agrega_tbl('T','franquicia',l_txt_descripcion         ,TRUE);
               --
               pp_write_clob(TRUE);
               pp_close_tag('deducible');
               --
            END IF;
            --
         END LOOP;       
         --
      END IF;
      --
      pp_write_clob(TRUE);
      pp_close_tag('deducibles');      
      --
   END pp_cob_pln_tr;   
   --
   /* --------------------------------------------------------
   || pp_dv_oferta:
   || Caratula de oferta
   */ --------------------------------------------------------
   --   
   PROCEDURE pp_dev_oferta
   IS
      --
      CURSOR l_c_p2000030
      IS
         --
         SELECT a.num_riesgo,b.cod_mon,b.cod_agt
           FROM p2000031 a, 
                p2000030 b
          WHERE a.num_poliza      = b.num_poliza
            AND a.num_spto        = b.num_spto
            AND a.num_apli        = b.num_apli
            AND a.num_spto_apli   = b.num_spto_apli
            AND a.mca_vigente     = trn.si
            AND a.mca_baja_riesgo = trn.no
            AND b.cod_cia         = g_cod_cia
            AND b.num_poliza      = g_jbnum_poliza
            AND b.cod_ramo        = g_jbcod_ramo;      
      --
      l_k_num_pisos      CONSTANT VARCHAR2(9)  := 'NUM_PISOS'             ;
      l_k_cubierta_techo CONSTANT VARCHAR2(18) := 'TIP_CUBIERTA_TECHO'    ;
      l_k_estruc_techo   CONSTANT VARCHAR2(20) := 'TIP_ESTRUCTURA_TECHO'  ;
      l_k_cons_muro      CONSTANT VARCHAR2(21) := 'TIP_CONSTRUCCION_MURO' ;
      l_k_area_const     CONSTANT VARCHAR2(21) := 'NUM_AREA_CONSTRUCCION' ;
      l_k_cons_piso      CONSTANT VARCHAR2(21) := 'TIP_CONSTRUCCION_PISO' ;
      l_k_cons_pared     CONSTANT VARCHAR2(22) := 'TIP_CONSTRUCCION_PARED';   
      --      
      l_num_pisos          g2009201_msv.nom_campo%TYPE;
      l_val_cons_pared     g2009201_msv.nom_campo%TYPE;
      l_val_cons_muro      g2009201_msv.nom_campo%TYPE;
      l_val_area_const     g2009201_msv.nom_campo%TYPE;
      l_val_cubierta_techo g2009201_msv.nom_campo%TYPE;
      l_val_estruc_techo   g2009201_msv.nom_campo%TYPE;
      l_val_cons_piso      g2009201_msv.nom_campo%TYPE;
      l_nom_agt            v1001390.nom_completo %TYPE;
      l_nom_canal          a1000723.des_canal3   %TYPE;
      l_tel_agt            a1001332.tlf_numero   %TYPE;
      l_email_agt          a1001332.email        %TYPE;
      l_cod_agt            a2000030.cod_agt      %TYPE;      
      --
      l_suma_total_aseg    a2000040.suma_aseg%TYPE := TRN.CERO;
      --
      l_nom_mon   VARCHAR2(5);      
      l_fecha_imp VARCHAR2(50) ;
      l_texto     VARCHAR2(150);             
      --
      PROCEDURE pi_dv_oferta(p_nom_columna IN  c2000000.nom_columna%TYPE  ,                          
                             p_val_columna OUT g2009201_msv.nom_campo%TYPE,
                             p_lista_valor IN  BOOLEAN := FALSE           )
      IS
         --
         l_val_columna        g2009201_msv.nom_campo%TYPE;
         --
         CURSOR l_c_c2000000
         IS
            --                            
            SELECT a.val_columna
              FROM c2000000 a
             WHERE a.nom_columna    = p_nom_columna
               AND a.num_cotizacion = g_jbnum_poliza
               AND a.cod_cia        = g_cod_cia
               AND a.cod_ramo       = g_jbcod_ramo;
         --
         CURSOR l_c_g2009201_msv(p_val_columna_c g2009201_msv.nom_campo%TYPE)
         IS
            --
            SELECT a.nom_campo
              FROM g2009201_msv a
             WHERE a.tip_construccion = p_nom_columna
               AND a.val_campo        = p_val_columna_c;      
         --
      BEGIN
         --
         OPEN l_c_c2000000;
         FETCH l_c_c2000000 INTO p_val_columna;
         CLOSE l_c_c2000000;
         --
         IF p_val_columna IS NOT NULL
         THEN
            --
            g_cont_regs := g_cont_regs + trn.uno;
            --
         END IF;         
         --
         IF p_lista_valor
         THEN
            --
            OPEN l_c_g2009201_msv(p_val_columna);
            FETCH l_c_g2009201_msv INTO l_val_columna;
            CLOSE l_c_g2009201_msv;
            --
            p_val_columna := l_val_columna;
            --
         END IF;
         --
      EXCEPTION
         --
         WHEN OTHERS
         THEN
            --
            p_val_columna := trn.nulo;
            --
      END pi_dv_oferta;
      --
   BEGIN
      --
      g_cont_regs := trn.cero;
      --
      g_abre_reporte := TRUE;      
      --
      pp_abre_reporte;      
      --
      BEGIN
         --
         OPEN l_c_p2000030;
         FETCH l_c_p2000030 INTO g_num_riesgo,g_cod_mon,l_cod_agt;
         CLOSE l_c_p2000030;
         --
      EXCEPTION
         --
         WHEN OTHERS
         THEN
            --
            g_num_riesgo := trn.uno;
            g_cod_mon    := trn.uno;
            --
      END;
      --
      pi_dv_oferta(l_k_num_pisos     ,l_num_pisos         ,FALSE);
      pi_dv_oferta(l_k_cons_pared    ,l_val_cons_pared    ,TRUE );
      pi_dv_oferta(l_k_cons_muro     ,l_val_cons_muro     ,TRUE );
      pi_dv_oferta(l_k_area_const    ,l_val_area_const    ,FALSE);
      pi_dv_oferta(l_k_cubierta_techo,l_val_cubierta_techo,TRUE );
      pi_dv_oferta(l_k_estruc_techo  ,l_val_estruc_techo  ,TRUE );
      pi_dv_oferta(l_k_cons_piso     ,l_val_cons_piso     ,TRUE );      
      --
      pp_open_tag('letter');     
      --
      pp_open_tag('dv_oferta');
      --
      pp_agrega_tbl('T', 'num_pisos'     , l_num_pisos         , TRUE);
      pp_agrega_tbl('T', 'cons_pared'    , l_val_cons_pared    , TRUE);
      pp_agrega_tbl('T', 'cons_muro'     , l_val_cons_muro     , TRUE);
      pp_agrega_tbl('T', 'area_const'    , l_val_area_const    , TRUE);
      pp_agrega_tbl('T', 'cubierta_techo', l_val_cubierta_techo, TRUE);
      pp_agrega_tbl('T', 'estruc_techo'  , l_val_estruc_techo  , TRUE);
      pp_agrega_tbl('T', 'cons_piso'     , l_val_cons_piso     , TRUE);
      --
      pp_write_clob(TRUE);
      pp_close_tag('dv_oferta'); 
      --
      pp_dev_cob_oferta;
      --
      pp_forma_de_pago;           
      --
      BEGIN
         -- Obtiene la informacion del agente
         pp_dev_info_agente(p_cod_cia       => g_cod_cia  ,
                            p_num_poliza    => trn.nulo   ,
                            p_num_spto      => trn.nulo   ,
                            p_fec_efec_spto => trn.nulo   ,
                            p_cod_agt       => l_cod_agt  ,
                            p_nom_completo  => l_nom_agt  ,
                            p_nom_canal     => l_nom_canal,
                            p_tel_agt       => l_tel_agt  ,
                            p_email_agt     => l_email_agt);      
         --
         pp_open_tag('agente');
         --
         pp_agrega_tbl('T', 'nom_agente', l_cod_agt||' '||l_nom_agt);
         --
         pp_write_clob(TRUE);
         pp_close_tag('agente');
      --  
      EXCEPTION
         WHEN OTHERS
         THEN
            --
            NULL;      
            --
      END;
      --
      pp_open_tag('final_wording');
      --
      FOR k in g_l_list_cob.first ..g_l_list_cob.last
      LOOP
         --
         IF g_l_list_cob(k).cod_cob = g_k_2201
         THEN
            --
            pp_agrega_tbl('T', 'sum_aseg_const', fp_format(g_l_list_cob(k).suma_aseg));
            --
            l_suma_total_aseg := l_suma_total_aseg +g_l_list_cob(k).suma_aseg;
            --
         ELSE
            --
            pp_agrega_tbl('T', 'sum_aseg_contenido', fp_format(g_l_list_cob(k).suma_aseg));
            --
            l_suma_total_aseg := l_suma_total_aseg +g_l_list_cob(k).suma_aseg;            
            --
         END IF;
         --
      END LOOP;          
      --
      pp_agrega_tbl('T', 'sum_aseg_total', fp_format(l_suma_total_aseg));      
      --
      l_fecha_imp := REPLACE(TO_CHAR(SYSDATE,'day','nls_date_language=spanish'),' ','') || ' , ' || 
                     TO_CHAR(SYSDATE,'dd')|| ' de '||
                     REPLACE(TO_CHAR(SYSDATE,'month','nls_date_language=spanish'),' ','')|| ' de '||
                     TO_CHAR(SYSDATE,'yyyy');                 
      --
      pp_agrega_tbl('T', 'fw_date_txt'  , l_fecha_imp  );
      --
      IF g_cod_mon = trn.UNO
      THEN
         --
         l_nom_mon := g_signo_moneda;
         --
      ELSE
         --
         l_nom_mon := 'US$';
         --
      END IF;      
      --
      pp_agrega_tbl('T', 'cod_mon', l_nom_mon);
      --
      pp_write_clob(TRUE);
      pp_close_tag('final_wording');      
      --
      pp_close_tag('letter');
      --
      pp_task_ending;
      --      
   END pp_dev_oferta;   
   --
   /* --------------------------------------------------------
   || pp_gen_xml_ps:
   || Caratula de Poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_gen_xml_ps
   IS
      --
      l_fec_nueva_tarifa  g2999003_msv.fec_validez%TYPE;--v1.13{
      l_fec_ini_tarifa_rf g2999003_msv.fec_validez%TYPE;
      l_fec_fin_tarifa_rf g2999003_msv.fec_validez%TYPE;--v1.13}
      --
      l_es_migracion BOOLEAN;
      --
      l_cv_a2000030  CV_RESULTS;
      --
      l_reg30 reg30;
      --
      l_cont_polries BINARY_INTEGER := trn.CERO;
      --
      /* --------------------------------------------------------
      || pi_trata_datos_riesgos:
      || Procesa los riesgos de la poliza y
      || para cada uno de ellos genera un tag <letter>
      */ --------------------------------------------------------
      --
      PROCEDURE pi_trata_datos_riesgos(p_cab_report_type    a1009012_msv.contenido_objeto %TYPE,
                                       p_cab_nom_tomador    v1001390.nom_completo         %TYPE,
                                       p_cab_iden_tomador   VARCHAR2                           ,
                                       p_cab_dom1_tomador   a1001300.nom_domicilio1       %TYPE,
                                       p_cab_dom2_tomador   a1001300.nom_domicilio2       %TYPE,
                                       p_cab_dom3_tomador   a1001300.nom_domicilio3       %TYPE,
                                       p_cab_pob_tomador    a1001300.nom_localidad        %TYPE,
                                       p_cab_edo_tomador    a1000104.nom_estado           %TYPE,
                                       p_cab_prov_tomador   a1000100.nom_prov             %TYPE,
                                       p_cab_cp_tomador     a1001300.cod_postal           %TYPE,
                                       p_cab_email_tomador  a1001331.email                %TYPE,
                                       p_cod_agt            a2000030.cod_agt              %TYPE,
                                       p_nom_agt            v1001390.nom_completo         %TYPE,
                                       p_canal_agt          a1000723.des_canal3           %TYPE,
                                       p_tel_agt            a1001332.tlf_numero           %TYPE,
                                       p_email_agt          a1001332.email                %TYPE,
                                       p_cab_fec_efec_spto  a2000030.fec_efec_spto        %TYPE,
                                       p_cab_fec_vcto_spto  a2000030.fec_vcto_spto        %TYPE,
                                       p_cab_sched_pol      VARCHAR2                           ,
                                       p_nom_mon            a1000400.cod_mon_iso          %TYPE,
                                       p_concepto           VARCHAR2                           ,
                                       p_fec_emision        a2000030.fec_emision          %TYPE,
                                       p_pd_fec_inception   a2000030.fec_efec_poliza      %TYPE,
                                       p_pd_fec_exp         a2000030.fec_vcto_spto_publico%TYPE,
                                       p_pd_num_poliza      a2000030.num_poliza           %TYPE,
                                       p_pd_fec_issue       a2000030.fec_actu             %TYPE,
                                       p_pd_hor_issue       a2000030.hora_desde           %TYPE,
                                       p_forma_pago         a1001402.nom_fracc_pago       %TYPE,
                                       p_medio_pago         a5020200.nom_tip_gestor       %TYPE,                                       
                                       p_imp_prima_base     a2000161.imp_eco              %TYPE,
                                       p_imp_descuentos     a2000161.imp_eco              %TYPE,
                                       p_imp_recargos       a2000161.imp_eco              %TYPE,
                                       p_imp_iva            a2000161.imp_eco              %TYPE,
                                       p_imp_emision        a2000161.imp_eco              %TYPE,
                                       p_imp_igsci          a2000161.imp_eco              %TYPE,
                                       p_ph_alt_holder_name v1001390.nom_completo         %TYPE,
                                       p_ph_alt_holder_id   VARCHAR2                           ,
                                       p_ph_alt_birth       a1001331.fec_nacimiento       %TYPE,
                                       p_ph_alt_occupation  g1000100.nom_profesion        %TYPE,
                                       p_ph_alt_address     VARCHAR2                           ,
                                       p_pol_handler        g1010120.nom_usr              %TYPE,
                                       p_cod_tercero        a1001300.cod_tercero          %TYPE)
      IS
         --
         l_cv_riesgos CV_RESULTS;
         l_reg_riesgo reg_riesgo;
         --
         l_pol_mod VARCHAR2(1000) := '';
         --
         l_fecha_imp       VARCHAR2(50)  ;
         l_fecha_imp_2     VARCHAR2(50)  ;
         l_fecha_imp_3     VARCHAR2(50)  ;
         l_txt_direccion   VARCHAR2(2500);
         l_cab_nom_insured VARCHAR2(2500);
         l_nom_dir_cobro   VARCHAR2(2500);
         l_nom_dir_resi    VARCHAR2(2500);
         --
         l_suma_total_aseg a2000040.suma_aseg%TYPE := TRN.CERO;
         --
         l_lim_modality_tag    a2000020.txt_campo              %TYPE;
         l_cab_type            a2000020.txt_campo              %TYPE;         
         l_cab_dom1_insured    a1001300.nom_domicilio1         %TYPE;
         l_cab_dom2_insured    a1001300.nom_domicilio2         %TYPE;
         l_cab_dom3_insured    a1001300.nom_domicilio3         %TYPE;
         l_cab_dom1_com        a1001331.nom_domicilio1_com     %TYPE;
         l_cab_dom2_com        a1001331.nom_domicilio2_com     %TYPE;
         l_cab_dom3_com        a1001331.nom_domicilio3_com     %TYPE;
         l_cab_email_tomador   a1001331.email                  %TYPE;
         l_cab_pob_insured     a1001300.nom_localidad          %TYPE;
         l_cab_edo_insured     a1000104.nom_estado             %TYPE;
         l_cab_prov_insured    a1000100.nom_prov               %TYPE;
         l_cab_cp_insured      a1001300.cod_postal             %TYPE;
         l_cab_tel_insured     a1001331.tlf_numero             %TYPE;
         l_cab_movil_insured   a1001331.tlf_movil              %TYPE;
         l_nom_benef           v1001390.nom_completo           %TYPE;
         l_pct_participacion   a2000060.pct_participacion      %TYPE;
         l_parentesco          a1001344.nom_relac              %TYPE;
         l_txt_1               a1001331.txt_etiqueta1          %TYPE;
         l_txt_2               a1001331.txt_etiqueta2          %TYPE;
         l_txt_3               a1001331.txt_etiqueta3          %TYPE;
         l_txt_4               a1001331.txt_etiqueta4          %TYPE;
         l_txt_5               a1001331.txt_etiqueta5          %TYPE;
         l_nom_empresa_com     a1001331.nom_empresa_com        %TYPE;
         l_atr_domicilio1_com  a1001331.atr_domicilio1_com     %TYPE;
         l_atr_domicilio2_com  a1001331.atr_domicilio2_com     %TYPE;
         l_atr_domicilio3_com  a1001331.atr_domicilio3_com     %TYPE; 
         l_atr_domicilio1      a1001300.atr_domicilio1         %TYPE;         
         l_cod_pais            a1001300.cod_pais               %TYPE;         
         l_cod_estado          a1001331.cod_estado             %TYPE;         
         l_cod_estado_etiqueta p1001331_msv.cod_estado_etiqueta%TYPE;         
         l_cod_prov_etiqueta   p1001331_msv.cod_prov_etiqueta  %TYPE;
         --
         l_val_localidad              a2000020.val_campo%TYPE;
         l_val_provincia              a2000020.val_campo%TYPE;
         l_val_num_dir                a2000020.val_campo%TYPE;
         l_val_dir_calle              a2000020.val_campo%TYPE;
         l_val_dir_complemento        a2000020.val_campo%TYPE;
         l_val_tro_seguro             a2000020.val_campo%TYPE;         
         l_val_tip_construccion_muro  a2000020.val_campo%TYPE;
         l_val_txt_construccion_muro  a2000020.val_campo%TYPE;
         l_val_num_pisos              a2000020.val_campo%TYPE;
         l_val_tip_construccion_pared a2000020.val_campo%TYPE;
         l_val_txt_construccion_pared a2000020.val_campo%TYPE;
         l_val_num_area_construccion  a2000020.val_campo%TYPE;
         l_val_txt_cubierta_techo     a2000020.val_campo%TYPE;
         l_val_txt_estructura_techo   a2000020.val_campo%TYPE;
         l_val_tip_estructura_techo   a2000020.val_campo%TYPE;
         l_val_tip_cubierta_techo     a2000020.val_campo%TYPE;
         l_val_txt_construccion_piso  a2000020.val_campo%TYPE;
         l_val_tip_construccion_piso  a2000020.val_campo%TYPE;
         l_val_cod_modalidad          a2000020.val_campo%TYPE;
         l_val_cod_tarifa             a2000020.val_campo%TYPE;
         l_val_anio_construccion      a2000020.val_campo%TYPE;
         l_val_portal                 a2000020.val_campo%TYPE;
         l_val_nombre_web_tmp         a2000020.val_campo%TYPE;
         l_val_txt_direccion_mig_1    a2000020.val_campo%TYPE;
         l_val_txt_direccion_mig_2    a2000020.val_campo%TYPE;
         l_val_txt_direccion_mig_3    a2000020.val_campo%TYPE; 
         l_val_cod_localidad          a2000020.val_campo%TYPE;
         l_txt_cod_localidad          a2000020.txt_campo%TYPE;    
         l_txt_txt_direccion_mig_1    a2000020.txt_campo%TYPE;
         l_txt_txt_direccion_mig_2    a2000020.txt_campo%TYPE;
         l_txt_txt_direccion_mig_3    a2000020.txt_campo%TYPE; 
         l_txt_nombre_web_tmp         a2000020.txt_campo%TYPE;         
         l_txt_portal                 a2000020.txt_campo%TYPE;
         l_txt_localidad              a2000020.txt_campo%TYPE;
         l_txt_provincia              a2000020.txt_campo%TYPE;
         l_txt_num_dir                a2000020.txt_campo%TYPE;
         l_txt_dir_calle              a2000020.txt_campo%TYPE;
         l_txt_dir_complemento        a2000020.txt_campo%TYPE;
         l_txt_tro_seguro             a2000020.txt_campo%TYPE;         
         l_txt_cod_tarifa             a2000020.txt_campo%TYPE;
         l_txt_anio_construccion      a2000020.txt_campo%TYPE;
         l_txt_tip_construccion_muro  a2000020.txt_campo%TYPE;
         l_txt_txt_construccion_muro  a2000020.txt_campo%TYPE;
         l_txt_num_pisos              a2000020.txt_campo%TYPE;
         l_txt_tip_construccion_pared a2000020.txt_campo%TYPE;
         l_txt_txt_construccion_pared a2000020.txt_campo%TYPE;
         l_txt_num_area_construccion  a2000020.txt_campo%TYPE;
         l_txt_txt_cubierta_techo     a2000020.txt_campo%TYPE;
         l_txt_txt_estructura_techo   a2000020.txt_campo%TYPE;
         l_txt_tip_estructura_techo   a2000020.txt_campo%TYPE;
         l_txt_tip_cubierta_techo     a2000020.txt_campo%TYPE;
         l_txt_txt_construccion_piso  a2000020.txt_campo%TYPE;
         l_txt_tip_construccion_piso  a2000020.txt_campo%TYPE;
         l_txt_cod_modalidad          a2000020.txt_campo%TYPE;         
         --
         l_imp_prima_base a2000161.imp_eco%TYPE;
         l_imp_recargos   a2000161.imp_eco%TYPE;
         l_imp_emision    a2000161.imp_eco%TYPE;
         l_imp_iva        a2000161.imp_eco%TYPE;
         l_imp_descuentos a2000161.imp_eco%TYPE;
         l_imp_igsci      a2000161.imp_eco%TYPE;         
         --
         l_sched1_policy_handler g1010120.nom_usr%TYPE;
         l_fw_underwriter        g1010120.nom_usr%TYPE;
         --
         l_fw_date      DATE;
         --
      BEGIN
         --
         g_num_riesgo := trn.nulo;
         --
         IF l_cv_riesgos%ISOPEN
         THEN
            --
            CLOSE l_cv_riesgos;
            --
         END IF;
         --
         IF g_jbtip_emision = g_k_rep_cotizacion
         THEN
            --
            l_cv_riesgos := fp_abre_riesgos (p_mca_tabla_p => trn.SI,
                                             p_mca_tabla_r => trn.NO);            
            --
         ELSE
            --
            l_cv_riesgos := fp_abre_riesgos (p_mca_tabla_p => trn.NO,
                                             p_mca_tabla_r => trn.NO);             
            --
         END IF;         
         --
         FETCH l_cv_riesgos INTO l_reg_riesgo ;
         g_existe_riesgo := l_cv_riesgos%FOUND;
         --
         WHILE g_existe_riesgo
         LOOP
            --
            g_count_cob := g_count_cob+1;
            --
            pp_inicializa_riesgo;
            --
            l_cont_polries := l_cont_polries + trn.UNO;
            --
            g_num_riesgo     := l_reg_riesgo.num_riesgo;
            --
            g_tip_docum_aseg := l_reg_riesgo.tip_docum;
            g_cod_docum_aseg := l_reg_riesgo.cod_docum;
            -- Obtiene la informacion del asegurado
            IF  g_jbtip_emision  = g_k_rep_cotizacion
            AND g_tip_docum_aseg = g_k_tip_docum_gen
            AND g_cod_docum_aseg = g_k_cod_docum_gen
            THEN
               --
               pp_valor_dv(p_cod_campo => g_k_nombre_web_tmp  ,
                           p_val_campo => l_val_nombre_web_tmp,
                           p_txt_campo => l_txt_nombre_web_tmp);
               --
               l_cab_nom_insured := NVL(l_txt_nombre_web_tmp,l_val_nombre_web_tmp);
               --
            ELSE
               --
               pp_dev_info_aseg(g_cod_cia            ,
                                g_tip_docum_aseg     ,
                                g_cod_docum_aseg     ,
                                g_num_poliza         ,
                                g_num_spto           ,
                                g_fec_efec_spto      ,
                                g_num_riesgo         ,
                                l_cab_nom_insured    ,
                                l_cab_dom1_insured   ,
                                l_cab_dom2_insured   ,
                                l_cab_dom3_insured   ,
                                l_cab_pob_insured    ,
                                l_cab_edo_insured    ,
                                l_cab_prov_insured   ,
                                l_cab_cp_insured     ,
                                l_cab_tel_insured    ,
                                l_cab_movil_insured  ,
                                l_cab_dom1_com       ,
                                l_cab_dom2_com       ,
                                l_cab_dom3_com       ,
                                l_cab_email_tomador  ,
                                l_txt_1              ,
                                l_txt_2              ,
                                l_txt_3              ,
                                l_txt_4              ,
                                l_txt_5              ,
                                l_nom_empresa_com    ,
                                l_atr_domicilio1_com ,
                                l_atr_domicilio2_com ,
                                l_atr_domicilio3_com ,
                                l_atr_domicilio1     ,
                                l_cod_pais           ,
                                l_cod_estado         ,
                                l_cod_estado_etiqueta,
                                l_cod_prov_etiqueta  );                             
            END IF;
            --
            l_lim_modality_tag := INITCAP(l_cab_type);
            --
            l_sched1_policy_handler := p_pol_handler;
            l_fw_date               := TRUNC(SYSDATE);
            l_fw_underwriter        := p_pol_handler;
            --
            g_tbl_xml_deta := g_tbl_xml_deta_pol;
            --
            pp_open_tag('letter'||' num_riesgo="'||g_num_riesgo||'"'); 
            pp_open_tag('general');
            --
            pp_agrega_tbl('T', 'pol_mod'         , l_pol_mod         );
            pp_agrega_tbl('T', 'num_riesgo'      , g_num_riesgo      );
            pp_agrega_tbl('T', 'cod_user'        , g_cod_usr         );
            pp_agrega_tbl('T', 'nom_ejecutivo'   , g_nom_ejecutivo   );
            pp_agrega_tbl('T', 'lim_modality_tag', l_lim_modality_tag);
            --
            IF g_jbchoose_report = G_K_REP_PS
            THEN
               --
               pp_agrega_tbl('T', 'lim_show_excess', g_k_yes);
               --
            ELSE
               --
               pp_agrega_tbl('T', 'lim_show_excess', trn.NO);
               --
            END IF;
            --
            pp_agrega_tbl('T', 'policy_number', g_num_poliza);
            --
            pp_write_clob(TRUE)    ;
            pp_close_tag('general');            
            --
            pp_open_tag('data');
            --
            pp_open_tag('tomador');
            --
            IF p_ph_alt_holder_name IS NOT NULL 
               AND LENGTH(p_ph_alt_holder_name) > trn.UNO
               AND p_ph_alt_holder_name <> l_cab_nom_insured 
            THEN
               --
               l_cab_nom_insured := l_cab_nom_insured||' y/o '||p_ph_alt_holder_name;
               --
            END IF;
            --
            l_nom_dir_cobro := CASE NVL(l_cab_dom1_insured,'0') WHEN '0' THEN '' ELSE l_cab_dom1_insured||' ' END; 
            l_nom_dir_cobro := l_nom_dir_cobro || CASE NVL(l_cab_dom2_insured,'0') WHEN '0' THEN '' ELSE l_cab_dom2_insured||' ' END;
            l_nom_dir_cobro := l_nom_dir_cobro || CASE NVL(l_atr_domicilio1  ,'0') WHEN '0' THEN '' ELSE l_atr_domicilio1  ||' ' END;
            l_nom_dir_cobro := l_nom_dir_cobro || CASE NVL(l_cab_dom3_insured,'0') WHEN '0' THEN '' ELSE l_cab_dom3_insured||' ' END;
            --
            l_nom_dir_cobro := l_nom_dir_cobro || CASE NVL(l_cab_prov_insured,'0') WHEN '0' THEN '' ELSE l_cab_prov_insured||' ' END;                        
            l_nom_dir_cobro := l_nom_dir_cobro || CASE NVL(l_cab_edo_insured ,'0') WHEN '0' THEN '' ELSE l_cab_edo_insured ||' ' END;
            --
            IF l_cod_pais IS NOT NULL
            THEN
               --
               l_nom_dir_cobro := l_nom_dir_cobro || CASE NVL(dc_f_nom_pais(l_cod_pais),'0') WHEN '0' THEN '' ELSE dc_f_nom_pais(l_cod_pais)END;               
               --            
            END IF;
            --
            l_nom_dir_resi := CASE NVL(l_cab_dom1_com,'0') WHEN '0' THEN '' ELSE l_cab_dom1_com||' ' END;
            l_nom_dir_resi := l_nom_dir_resi|| CASE NVL(l_cab_dom2_com      ,'0') WHEN '0' THEN '' ELSE l_cab_dom2_com      ||' ' END;
            l_nom_dir_resi := l_nom_dir_resi|| CASE NVL(l_atr_domicilio1_com,'0') WHEN '0' THEN '' ELSE l_atr_domicilio1_com||' ' END;
            l_nom_dir_resi := l_nom_dir_resi|| CASE NVL(l_cab_dom3_com      ,'0') WHEN '0' THEN '' ELSE l_cab_dom3_com      ||' ' END;
            --
            l_nom_dir_resi := l_nom_dir_resi || CASE NVL(l_cab_prov_insured,'0') WHEN '0' THEN '' ELSE l_cab_prov_insured||' ' END;                        
            l_nom_dir_resi := l_nom_dir_resi || CASE NVL(l_cab_edo_insured ,'0') WHEN '0' THEN '' ELSE l_cab_edo_insured ||' ' END;
            --
            IF l_cod_pais IS NOT NULL
            THEN
               --
               l_nom_dir_resi := l_nom_dir_resi || CASE NVL(dc_f_nom_pais(l_cod_pais),'0') WHEN '0' THEN '' ELSE dc_f_nom_pais(l_cod_pais) END;               
               --            
            END IF;
            --                        
            pp_agrega_tbl('T', 'cab_report_type'  , p_cab_report_type)        ;
            pp_agrega_tbl('T', 'cab_nom_tomador'  , p_cab_nom_tomador, TRUE)  ;
            pp_agrega_tbl('T', 'cab_iden_tomador' , UPPER(p_cab_iden_tomador));
            pp_agrega_tbl('T', 'cab_dom1_tomador' , p_cab_dom1_tomador, TRUE) ;
            pp_agrega_tbl('T', 'cab_dom2_tomador' , p_cab_dom2_tomador, TRUE) ;
            pp_agrega_tbl('T', 'cab_dom3_tomador' , p_cab_dom3_tomador, TRUE) ;
            --
            pp_agrega_tbl('T', 'cab_dir_tomador'  , p_cab_dom1_tomador || ' ' || p_cab_dom2_tomador || ' ' || p_cab_dom3_tomador , TRUE);
            --
            pp_agrega_tbl('T', 'cab_pob_tomador'  , p_cab_pob_tomador ,TRUE);
            pp_agrega_tbl('T', 'cab_edo_tomador'  , p_cab_edo_tomador ,TRUE);
            pp_agrega_tbl('T', 'cab_prov_tomador' , p_cab_prov_tomador,TRUE);
            pp_agrega_tbl('T', 'cab_cp_tomador'   , p_cab_cp_tomador  ,TRUE); 
            --
            pp_agrega_tbl('T', 'cab_prov_tomador_coma' , p_cab_prov_tomador||',',TRUE);
            pp_agrega_tbl('T', 'cab_edo_tomador_coma'  , p_cab_edo_tomador ||',',TRUE);           
            --
            pp_agrega_tbl('T', 'cab_dom1_com', l_nom_dir_cobro,TRUE);
            pp_agrega_tbl('T', 'cab_dir_com' , l_nom_dir_resi ,TRUE);         
            --
            pp_agrega_tbl('T', 'cab_tel_tomador', l_cab_tel_insured  ,TRUE);
            pp_agrega_tbl('T', 'cab_tel_movil'  , l_cab_movil_insured,TRUE);
            --
            pp_agrega_tbl('T', 'cab_email_tomador', LOWER(l_cab_email_tomador), TRUE);
            pp_agrega_tbl('T', 'cab_nom_insured'  , l_cab_nom_insured        );
            pp_agrega_tbl('T', 'cab_type'         , l_cab_type         , TRUE);
            --
            pp_agrega_tbl('F_m_abr', 'cab_fec_efec_spto', p_cab_fec_efec_spto);
            pp_agrega_tbl('F_m_abr', 'cab_fec_vcto_spto', p_cab_fec_vcto_spto);
            pp_agrega_tbl('T', 'cab_sched_pol'          , p_cab_sched_pol    );
            pp_agrega_tbl('T', 'cod_tercero'            , p_cod_tercero      );            
            --
            pp_write_clob(TRUE)    ;
            pp_close_tag('tomador');
            --
            pp_open_tag('agente');
            --
            pp_agrega_tbl('T', 'nom_agt'  , UPPER(p_nom_agt)  , FALSE);
            pp_agrega_tbl('T', 'cod_agt'  , p_cod_agt        );
            pp_agrega_tbl('T', 'canal_agt', p_canal_agt, TRUE);
            pp_agrega_tbl('T', 'tel_agt'  , p_tel_agt  , TRUE);
            pp_agrega_tbl('T', 'email_agt', p_email_agt, TRUE);
            --
            pp_write_clob(TRUE);
            pp_close_tag('agente');
            --
            pp_dev_info_benef(g_cod_cia          ,
                              g_num_poliza       ,
                              g_num_spto         ,
                              g_num_apli         ,
                              g_num_spto_apli    ,
                              g_fec_efec_spto    ,
                              g_num_riesgo       ,
                              l_nom_benef        ,
                              l_pct_participacion,
                              l_parentesco       );
            --
            pp_dev_inf_cesionario(g_cod_cia      ,
                                  g_num_poliza   ,
                                  g_num_spto     ,
                                  g_num_apli     ,
                                  g_num_spto_apli,
                                  g_fec_efec_spto,
                                  g_num_riesgo   );
            --
            pp_open_tag('poliza');
            --
            -- v1.13{
            --
            l_es_migracion := ea_k_301_utils.f_es_migracion (p_cod_cia       => g_cod_cia      ,
                                                             p_num_poliza    => g_num_poliza   ,
                                                             p_num_spto      => trn.CERO       ,
                                                             p_num_apli      => g_num_apli     ,
                                                             p_num_spto_apli => g_num_spto_apli);
            --
            l_fec_nueva_tarifa := fp_fec_nueva_tarifa (pc_nom_nemotecnico => g_k_fec_carta_emi     ,
                                                       pc_cod_campo       =>  g_k_fec_ini_carta_emi);
            --
            IF g_fec_efec_poliza >= l_fec_nueva_tarifa
            THEN
               --
               l_fec_ini_tarifa_rf := fp_fec_nueva_tarifa (pc_nom_nemotecnico => g_k_fec_carta_rf    ,
                                                           pc_cod_campo       => g_k_fec_ini_carta_rf);
               --
               IF     g_tip_spto        = g_k_RF
                  AND g_fec_efec_spto  >= l_fec_ini_tarifa_rf
                  AND g_jbchoose_report = trn.UNO
                   OR (    g_jbchoose_report = 20
                       AND g_fec_efec_spto  >= l_fec_ini_tarifa_rf)
                   OR (    l_es_migracion
                       AND g_fec_efec_spto  >= l_fec_ini_tarifa_rf
                       AND g_jbchoose_report = trn.UNO)
               THEN
                  --
                  BEGIN
                     --
                     ea_k_g2999003_msv.p_lee (p_cod_cia         => g_cod_cia           ,
                                              p_nom_nemotecnico => g_k_fec_carta_rf    ,
                                              p_cod_ramo        => g_cod_ramo          ,
                                              p_cod_campo       => g_k_fec_fin_carta_rf,
                                              p_cod_modalidad   => em.COD_MODALIDAD_GEN,
                                              p_cod_cob         => em.COD_COB_GEN      ,
                                              p_fec_efec_spto   => g_fec_efec_poliza   );
                     --
                     l_fec_fin_tarifa_rf := ea_k_g2999003_msv.f_fec_baja;
                     --
                  EXCEPTION
                   WHEN OTHERS
                    THEN
                       --
                       l_fec_fin_tarifa_rf := NULL;
                       --
                  END;
                  --
                  IF g_fec_efec_spto <= l_fec_fin_tarifa_rf
                  THEN 
                     --
                     pp_open_tag(g_k_beneficios_carta_rf);
                     --
                     pp_agrega_tbl('T', 'pd_imprime_carta_rf', trn.SI);
                     --
                     pp_agrega_tbl('B', 'imagen_benef_rf_1', fp_txt_opcion(6 ,NULL,g_k_benef_carta_rf));
                     pp_agrega_tbl('T', 'texto_benef_rf_1' , fp_txt_opcion(1 ,NULL,g_k_benef_carta_rf));
                     pp_agrega_tbl('T', 'texto_benef_rf_2' , fp_txt_opcion(2 ,NULL,g_k_benef_carta_rf));
                     pp_agrega_tbl('T', 'texto_benef_rf_3' , fp_txt_opcion(3 ,NULL,g_k_benef_carta_rf));
                     pp_agrega_tbl('T', 'texto_benef_rf_4' , fp_txt_opcion(4 ,NULL,g_k_benef_carta_rf));
                     pp_agrega_tbl('T', 'texto_benef_rf_5' , fp_txt_opcion(5 ,NULL,g_k_benef_carta_rf));
                     pp_agrega_tbl('B', 'imagen_benef_rf_2', fp_txt_opcion(7 ,NULL,g_k_benef_carta_rf));
                     --
                     pp_write_clob(TRUE);
                     --
                     pp_close_tag(g_k_beneficios_carta_rf);
                     --
                  END IF;
                  --
               END IF;
               --
            END IF;
            --
            -- v1.13}
            --
            pp_open_tag('principal_poliza');
            --
            pp_agrega_tbl('T'      , 'pd_moneda'        , INITCAP(g_cod_mon) );
            pp_agrega_tbl('F_m_abr', 'pd_fec_emision'   , p_fec_emision      );
            pp_agrega_tbl('T'      , 'pd_concepto'      , INITCAP(p_concepto));
            pp_agrega_tbl('F_m_abr', 'pd_fec_inception' , p_pd_fec_inception );
            pp_agrega_tbl('F_m_abr', 'pd_fec_exp'       , p_pd_fec_exp       );
            pp_agrega_tbl('T'      , 'hora_exp'         , '12:00 m HORAS'    );
            pp_agrega_tbl('T'      , 'hora_inc'         , '12:00 m HORAS'    );
            pp_agrega_tbl('T'      , 'pd_num_poliza'    , p_pd_num_poliza    );
            --
            pp_agrega_tbl('T', 'pd_fec_issue', TO_CHAR(p_pd_fec_issue, g_k_formato_fec_xml) || ' ' || p_pd_hor_issue || ':00 CET');
            --
            pp_write_clob(TRUE);
            --
            pp_close_tag('principal_poliza');
            --
            pp_open_tag('datos_hogar');
            --
            pp_valor_dv(p_cod_campo => g_k_tip_construccion_muro  ,
                        p_val_campo => l_val_tip_construccion_muro,
                        p_txt_campo => l_txt_tip_construccion_muro);
            --
            pp_valor_dv(p_cod_campo => g_k_txt_construccion_muro  ,
                        p_val_campo => l_val_txt_construccion_muro,
                        p_txt_campo => l_txt_txt_construccion_muro);
            --
            pp_valor_dv(p_cod_campo => g_k_num_pisos  ,
                        p_val_campo => l_val_num_pisos,
                        p_txt_campo => l_txt_num_pisos);
            --
            pp_valor_dv(p_cod_campo => g_k_tip_construccion_pared  ,
                        p_val_campo => l_val_tip_construccion_pared,
                        p_txt_campo => l_txt_tip_construccion_pared);
            --
            pp_valor_dv(p_cod_campo => g_k_txt_construccion_pared  ,
                        p_val_campo => l_val_txt_construccion_pared,
                        p_txt_campo => l_txt_txt_construccion_pared);
            --
            pp_valor_dv(p_cod_campo => g_k_num_area_construccion  ,
                        p_val_campo => l_val_num_area_construccion,
                        p_txt_campo => l_txt_num_area_construccion);
            --
            pp_valor_dv(p_cod_campo => g_k_txt_cubierta_techo  ,
                        p_val_campo => l_val_txt_cubierta_techo,
                        p_txt_campo => l_txt_txt_cubierta_techo);
            --
            pp_valor_dv(p_cod_campo => g_k_txt_estructura_techo  ,
                        p_val_campo => l_val_txt_estructura_techo,
                        p_txt_campo => l_txt_txt_estructura_techo);
            --
            pp_valor_dv(p_cod_campo => g_k_tip_estructura_techo  ,
                        p_val_campo => l_val_tip_estructura_techo,
                        p_txt_campo => l_txt_tip_estructura_techo);
            --
            pp_valor_dv(p_cod_campo => g_k_tip_cubierta_techo  ,
                        p_val_campo => l_val_tip_cubierta_techo,
                        p_txt_campo => l_txt_tip_cubierta_techo);
            --
            pp_valor_dv(p_cod_campo => g_k_txt_construccion_piso  ,
                        p_val_campo => l_val_txt_construccion_piso,
                        p_txt_campo => l_txt_txt_construccion_piso);
            --
            pp_valor_dv(p_cod_campo => g_k_tip_construccion_piso  ,
                        p_val_campo => l_val_tip_construccion_piso,
                        p_txt_campo => l_txt_tip_construccion_piso);            
            --
            pp_valor_dv(p_cod_campo => g_k_cod_modalidad  ,
                        p_val_campo => l_val_cod_modalidad,
                        p_txt_campo => l_txt_cod_modalidad);                         
            --
            pp_valor_dv(p_cod_campo => g_k_cod_tarifa  ,
                        p_val_campo => l_val_cod_tarifa,
                        p_txt_campo => l_txt_cod_tarifa);             
            --
            pp_valor_dv(p_cod_campo => g_k_anio_construccion  ,
                        p_val_campo => l_val_anio_construccion,
                        p_txt_campo => l_txt_anio_construccion); 
            --            
            pp_valor_dv(p_cod_campo => g_k_localidad  ,
                        p_val_campo => l_val_localidad,
                        p_txt_campo => l_txt_localidad);                       
            --
            pp_valor_dv(p_cod_campo => g_k_provincia  ,
                        p_val_campo => l_val_provincia ,
                        p_txt_campo => l_txt_provincia );                                     
            --
            pp_valor_dv(p_cod_campo => g_k_num_dir  ,
                        p_val_campo => l_val_num_dir,
                        p_txt_campo => l_txt_num_dir); 
            --
            pp_valor_dv(p_cod_campo => g_k_dir_calle  ,
                        p_val_campo => l_val_dir_calle,
                        p_txt_campo => l_txt_dir_calle);
            --
            pp_valor_dv(p_cod_campo => g_k_portal  ,
                        p_val_campo => l_val_portal,
                        p_txt_campo => l_txt_portal);                                      
            --
            pp_valor_dv(p_cod_campo => g_k_dir_complemento  ,
                        p_val_campo => l_val_dir_complemento ,
                        p_txt_campo => l_txt_dir_complemento );
            --
            pp_valor_dv(p_cod_campo => g_k_otro_seguro ,
                        p_val_campo => l_val_tro_seguro ,
                        p_txt_campo => l_txt_tro_seguro );             
            --
            pp_valor_dv(p_cod_campo => g_k_cod_localidad   ,
                        p_val_campo => l_val_cod_localidad ,
                        p_txt_campo => l_txt_cod_localidad);            
            --
            pp_valor_dv(p_cod_campo => g_k_txt_direccion_mig_1  ,
                        p_val_campo => l_val_txt_direccion_mig_1,
                        p_txt_campo => l_txt_txt_direccion_mig_1);            
            --
            pp_valor_dv(p_cod_campo => g_k_txt_direccion_mig_2  ,
                        p_val_campo => l_val_txt_direccion_mig_2,
                        p_txt_campo => l_txt_txt_direccion_mig_2);            
            -- 
            pp_valor_dv(p_cod_campo => g_k_txt_direccion_mig_3  ,
                        p_val_campo => l_val_txt_direccion_mig_3,
                        p_txt_campo => l_txt_txt_direccion_mig_3);            
            --                                                                                                                   
            pp_agrega_tbl('T','tip_construccion_muro' ,COALESCE(l_txt_tip_construccion_muro ,l_val_tip_construccion_muro ,'N/A'));
            pp_agrega_tbl('T','txt_construccion_muro' ,COALESCE(l_txt_txt_construccion_muro ,l_val_txt_construccion_muro ,'N/A'));
            pp_agrega_tbl('T','num_pisos'             ,COALESCE(l_txt_num_pisos             ,l_val_num_pisos             ,'N/A'));
            pp_agrega_tbl('T','tip_construccion_pared',COALESCE(l_txt_tip_construccion_pared,l_val_tip_construccion_pared,'N/A'));
            pp_agrega_tbl('T','txt_construccion_pared',COALESCE(l_txt_txt_construccion_pared,l_val_txt_construccion_pared,'N/A'));
            pp_agrega_tbl('T','num_area_construccion' ,COALESCE(l_txt_num_area_construccion ,l_val_num_area_construccion ,'N/A'));
            pp_agrega_tbl('T','txt_cubierta_techo'    ,COALESCE(l_txt_txt_cubierta_techo    ,l_val_txt_cubierta_techo    ,'N/A'));
            pp_agrega_tbl('T','txt_estructura_techo'  ,COALESCE(l_txt_txt_estructura_techo  ,l_val_txt_estructura_techo  ,'N/A'));
            pp_agrega_tbl('T','tip_estructura_techo'  ,COALESCE(l_txt_tip_estructura_techo  ,l_val_tip_estructura_techo  ,'N/A'));
            pp_agrega_tbl('T','tip_cubierta_techo'    ,COALESCE(l_txt_tip_cubierta_techo    ,l_val_tip_cubierta_techo    ,'N/A'));
            pp_agrega_tbl('T','txt_construccion_piso' ,COALESCE(l_txt_txt_construccion_piso ,l_val_txt_construccion_piso ,'N/A'));
            pp_agrega_tbl('T','tip_construccion_piso' ,COALESCE(l_txt_tip_construccion_piso ,l_val_tip_construccion_piso ,'N/A')); 
            pp_agrega_tbl('T','cod_tarifa'            ,NVL(l_val_cod_tarifa,l_txt_cod_tarifa)||'% o por millar'      ); 
            pp_agrega_tbl('T','anio_construccion'     ,COALESCE(l_val_anio_construccion     ,l_txt_anio_construccion,'N/A'));             
            pp_agrega_tbl('T','tip_producto'          ,INITCAP(NVL(l_txt_cod_modalidad ,l_val_cod_modalidad)        ));
            --
            IF  NVL(l_val_cod_localidad,l_txt_cod_localidad) = g_k_local_gen
            AND g_jbtip_emision != g_k_rep_cotizacion 
            THEN
               --
               l_txt_direccion := NVL(l_txt_txt_direccion_mig_1,l_val_txt_direccion_mig_1)||' , '||
                                  NVL(l_txt_txt_direccion_mig_2,l_val_txt_direccion_mig_2)||' , '||
                                  NVL(l_txt_txt_direccion_mig_3,l_val_txt_direccion_mig_3);
               --
            ELSE
               --                                 
               l_txt_direccion := CASE COALESCE(l_txt_dir_complemento,l_val_dir_complemento,'0')
                                     WHEN '0' THEN ' '
                                     ELSE NVL(l_txt_dir_complemento ,l_val_dir_complemento)||', ' END;
               --
               l_txt_direccion := l_txt_direccion || CASE COALESCE(l_txt_dir_calle,l_val_dir_calle,'0')
                                     WHEN '0' THEN ' '
                                     ELSE NVL(l_txt_dir_calle,l_val_dir_calle)||', ' END;                                                 
               --
               l_txt_direccion := l_txt_direccion || CASE COALESCE(l_txt_portal,l_val_portal,'0')
                                     WHEN '0' THEN ' '
                                     ELSE NVL(l_txt_portal,l_val_portal)||', ' END;                 
               --
               l_txt_direccion := l_txt_direccion || CASE COALESCE(l_txt_num_dir,l_val_num_dir,'0')
                                     WHEN '0' THEN ' '
                                     ELSE NVL(l_txt_num_dir,l_val_num_dir)||', ' END;                
               --
               l_txt_direccion := l_txt_direccion || CASE COALESCE(l_txt_provincia,l_val_provincia,'0')
                                     WHEN '0' THEN ' '
                                     ELSE NVL(l_txt_provincia,l_val_provincia)||', ' END;                
               --
               l_txt_direccion := l_txt_direccion || CASE COALESCE(l_txt_localidad,l_val_localidad,'0')
                                     WHEN '0' THEN ' '
                                     ELSE NVL(l_txt_localidad,l_val_localidad) END;                
               --
            END IF;            
            --                                      
            pp_agrega_tbl('T','otro_seguro'    ,NVL(l_txt_tro_seguro,l_val_tro_seguro));
            pp_agrega_tbl('T','direccion_comp' ,INITCAP(NVL(l_txt_direccion,' ')));                       
            --
            -- Obtiene los importes de la poliza o suplemento
            --
            IF g_jbtip_emision = g_k_rep_cotizacion
            THEN
               --
               pp_dev_imp_spto_cot(g_cod_cia       ,
                                   g_cod_ramo      ,
                                   g_num_poliza    ,
                                   g_num_spto      ,
                                   g_num_apli      ,
                                   g_num_spto_apli ,
                                   l_imp_prima_base,
                                   l_imp_descuentos,
                                   l_imp_recargos  ,
                                   l_imp_iva       ,
                                   l_imp_emision   ,
                                   l_imp_igsci     );
            ELSE                                          
               --
               IF g_jbtip_scope = G_K_SCOPE_FOTO
               THEN
                  --
                  pp_dev_imp_spto(g_cod_cia           ,
                                  g_cod_ramo          ,
                                  g_num_poliza        ,
                                  g_num_spto          ,
                                  g_num_apli          ,
                                  g_num_spto_apli     ,
                                  l_imp_prima_base    ,
                                  l_imp_descuentos    ,
                                  l_imp_recargos      ,
                                  l_imp_iva           ,
                                  l_imp_emision       ,
                                  l_imp_igsci         );                                                                                                    
                  --
               ELSIF g_jbtip_scope = G_K_SCOPE_SPTO
               THEN
                  --
                  pp_dev_imp_spto_s(g_cod_cia           ,
                                    g_cod_ramo          ,
                                    g_num_poliza        ,
                                    g_num_spto          ,
                                    g_num_apli          ,
                                    g_num_spto_apli     ,
                                    g_num_periodo       ,
                                    l_imp_prima_base    ,
                                    l_imp_descuentos    ,
                                    l_imp_recargos      ,
                                    l_imp_iva           ,
                                    l_imp_emision       ,
                                    l_imp_igsci         );                  
                  --
               END IF;
               --
            END IF;             
            -- 
            pp_write_clob(TRUE);
            pp_close_tag('datos_hogar'); 
            --
            pp_open_tag('prima');
            --
            IF g_num_riesgos > trn.uno
            THEN
               --
               pp_agrega_tbl('I', 'imp_prima',fp_format(l_imp_prima_base));
               --
               pp_agrega_tbl('I', 'imp_emision',fp_format(l_imp_emision));
               --
               pp_agrega_tbl('I', 'imp_descuentos',fp_format(l_imp_descuentos));
               --
               pp_agrega_tbl('I', 'imp_recargos',fp_format(l_imp_recargos));
               --
               pp_agrega_tbl('I', 'imp_prima_neta',fp_format((l_imp_prima_base+l_imp_descuentos+l_imp_recargos)));            
               --
               IF g_num_riesgos > trn.UNO 
                  AND l_imp_iva = TRN.CERO
               THEN
                  --
                  pp_agrega_tbl('I', 'imp_iva','N/A');
                  --
               ELSE
                  --
                  pp_agrega_tbl('I', 'imp_iva',fp_format(l_imp_iva));
                  --
               END IF;            
               --
               pp_agrega_tbl('I', 'imp_igsci', fp_format(l_imp_igsci));
               --
               pp_agrega_tbl('I', 'imp_prima_total ' , dc_k_a1000400.f_redondea_importe_fmt((l_imp_prima_base+                            
                                                                                             l_imp_descuentos+     
                                                                                             l_imp_recargos  +     
                                                                                             l_imp_iva       +     
                                                                                             l_imp_emision   +
                                                                                             l_imp_igsci     ),    
                                                                                             g_decimales,              
                                                                                             18));                         
               --
            ELSE 
               --
               pp_agrega_tbl('I', 'imp_prima',fp_format(l_imp_prima_base));--v 1.08
               --
               pp_agrega_tbl('I', 'imp_emision',fp_format(p_imp_emision));
               --
               pp_agrega_tbl('I', 'imp_descuentos',fp_format(p_imp_descuentos));
               --
               pp_agrega_tbl('I', 'imp_recargos',fp_format(p_imp_recargos));
               --
               pp_agrega_tbl('I', 'imp_prima_neta',fp_format((l_imp_prima_base+l_imp_descuentos+l_imp_recargos))); 
               --
               pp_agrega_tbl('I', 'imp_iva',fp_format(p_imp_iva));
               --
               pp_agrega_tbl('I', 'imp_igsci', fp_format(p_imp_igsci));
               --
               pp_agrega_tbl('I', 'imp_prima_total ' , dc_k_a1000400.f_redondea_importe_fmt((p_imp_prima_base+                            
                                                                                             p_imp_descuentos+     
                                                                                             p_imp_recargos  +     
                                                                                             p_imp_iva       +     
                                                                                             p_imp_emision   +
                                                                                             p_imp_igsci     ),    
                                                                                             g_decimales,
                                                                                             18));              
               --                                                                           
            END IF;
            --
            IF g_jbtip_scope = G_K_SCOPE_FOTO
            THEN
               --
               g_imp_prima_base := fp_prima_tarifa(G_K_SCOPE_FOTO);
               --
            ELSIF g_jbtip_scope = G_K_SCOPE_SPTO
            THEN
               --
               g_imp_prima_base := fp_prima_tarifa(G_K_SCOPE_SPTO);
               --
            END IF;             
            --
            pp_agrega_tbl('T', 'forma_pago', INITCAP(p_forma_pago));
            pp_agrega_tbl('T', 'medio_pago', INITCAP(p_medio_pago));
            pp_agrega_tbl('T', 'mon_pol   ', INITCAP(g_cod_mon   ));
            --
            pp_write_clob(TRUE  );
            pp_close_tag('prima');
            --
            IF g_num_riesgos > trn.uno
            THEN
               --
               g_tot_imp_descuentos  := g_tot_imp_descuentos +l_imp_descuentos;
               g_tot_imp_recargos    := g_tot_imp_recargos   +l_imp_recargos  ;
               g_tot_imp_prima_neta  := g_tot_imp_prima_neta +(l_imp_prima_base+l_imp_descuentos+l_imp_recargos);
               g_tot_imp_prima_pol   := g_tot_imp_prima_pol  +l_imp_prima_base;
               g_tot_imp_igsci       := g_tot_imp_igsci      +l_imp_igsci     ;
               g_tot_imp_emision     := g_tot_imp_emision    +l_imp_emision   ;
               g_tot_imp_iva         := p_imp_iva                             ;
               --
               g_tot_imp_total       := g_tot_imp_total+(l_imp_prima_base+                            
                                                         l_imp_descuentos+     
                                                         l_imp_recargos  +     
                                                         l_imp_iva       +     
                                                         l_imp_emision   +
                                                         l_imp_igsci     );               
               --
            ELSE
               --
               g_tot_imp_prima_pol := g_tot_imp_prima_pol+p_imp_prima_base;
               --
            END IF;
            --
            pp_open_tag('policyholder_details');
            --
            pp_agrega_tbl('T', 'ph_holder_name', p_ph_alt_holder_name  , TRUE                );
            pp_agrega_tbl('T', 'ph_holder_id'  , p_ph_alt_holder_id                          );
            pp_agrega_tbl('T', 'ph_birth'      , TO_CHAR(p_ph_alt_birth, g_k_formato_fec_xml));
            pp_agrega_tbl('T', 'ph_occupation' , p_ph_alt_occupation   , TRUE                );
            pp_agrega_tbl('T', 'ph_address'    , p_ph_alt_address      , TRUE                );
            --
            pp_write_clob(TRUE);
            pp_close_tag('policyholder_details');
            --
            -- Escribe en el clob la lista de suplementos
            pp_cal_sptos;
            --
            pp_close_tag('poliza');
            pp_write_clob(TRUE);
            --
            pp_open_tag('final_wording');
            --
            FOR k in g_l_list_cob.first ..g_l_list_cob.last
            LOOP
               --
               IF g_l_list_cob(k).cod_cob = g_k_2201
               THEN
                  --
                  pp_agrega_tbl('T', 'sum_aseg_const', fp_format(g_l_list_cob(k).suma_aseg));
                  --
                  l_suma_total_aseg := l_suma_total_aseg +g_l_list_cob(k).suma_aseg;
               ELSE
                  --
                  pp_agrega_tbl('T', 'sum_aseg_contenido', fp_format(g_l_list_cob(k).suma_aseg));
                  --
                  l_suma_total_aseg := l_suma_total_aseg +g_l_list_cob(k).suma_aseg;
                  --
               END IF;
               --
            END LOOP;       
            --
            g_l_list_cob.DELETE;
            --
            g_tot_sum_aseg_pol := g_tot_sum_aseg_pol+l_suma_total_aseg;
            --            
            pp_agrega_tbl('T', 'sum_aseg_total', fp_format(l_suma_total_aseg));
            pp_agrega_tbl('T', 'tasa_pol'      ,fp_format(p_importe => ((g_imp_prima_base/l_suma_total_aseg)*1000),
                                                          p_tasa    => FALSE));  
            --
            l_suma_total_aseg := trn.cero;            
            --
            l_fecha_imp := REPLACE(TO_CHAR(SYSDATE,'day','nls_date_language=spanish'),' ','') || ', ' || 
                           TO_CHAR(SYSDATE,'dd')|| ' de '||
                           REPLACE(TO_CHAR(SYSDATE,'month','nls_date_language=spanish'),' ','')|| ' de '||
                           TO_CHAR(SYSDATE,'yyyy');           
            --
            l_fecha_imp_2 := g_nom_ciudad||', '||TO_CHAR(SYSDATE,'dd')||' de '||
                             REPLACE(TO_CHAR(SYSDATE,'month','nls_date_language=spanish'),' ','')||' de '||
                             TO_CHAR(SYSDATE,'yyyy');            
            --
            l_fecha_imp_3 := TO_CHAR(SYSDATE,'dd')||' de '||
                             REPLACE(TO_CHAR(SYSDATE,'month','nls_date_language=spanish'),' ','')||' de '||
                             TO_CHAR(SYSDATE,'yyyy');                         
            --      
            pp_agrega_tbl('T', 'fw_date_txt'   , l_fecha_imp  );
            pp_agrega_tbl('T', 'fw_date_txt_2' , l_fecha_imp_2);
            pp_agrega_tbl('T', 'fw_date_txt_3' , l_fecha_imp_3);
            --
            pp_agrega_tbl('T', 'fw_date'       , TO_CHAR( l_fw_date, g_k_formato_fec_xml ));
            pp_agrega_tbl('T', 'fw_underwriter', l_fw_underwriter, TRUE);
            --
            pp_write_clob(TRUE);
            pp_close_tag('final_wording');
            --
            pp_dev_recibos;
            --
            IF g_cod_modalidad = g_k_cobertura_total
            THEN
               -- 
               pp_cob_pln_tr;
               --
            END IF;
            --
            pp_close_tag('data');
            --
            pp_close_tag('letter');
            --
            FETCH l_cv_riesgos INTO l_reg_riesgo;
            g_existe_riesgo := l_cv_riesgos%FOUND;
            --
         END LOOP;
         --
         pp_open_tag('totales');
         --
         pp_agrega_tbl('I', 'fecha_hora',TO_CHAR(sysdate,'dd/mm/yyyy HH:MM:SS','nls_date_language=spanish'));
         --
         pp_agrega_tbl('I', 'tot_imp_descuentos',fp_format(g_tot_imp_descuentos ));
         pp_agrega_tbl('I', 'tot_imp_recargos'  ,fp_format(g_tot_imp_recargos   ));
         pp_agrega_tbl('I', 'tot_imp_prima_neta',fp_format(g_tot_imp_prima_neta ));
         pp_agrega_tbl('I', 'tot_imp_emision'   ,fp_format(g_tot_imp_igsci      ));
         pp_agrega_tbl('I', 'tot_imp_igsci'     ,fp_format(g_tot_imp_emision    ));
         pp_agrega_tbl('I', 'tot_imp_iva '      ,fp_format(g_tot_imp_iva        ));
         pp_agrega_tbl('I', 'tot_prima_base'    ,fp_format(g_tot_imp_prima_pol  ));         
         --
         pp_agrega_tbl('I', 'tot_imp_total'     ,fp_format(g_tot_imp_total+g_tot_imp_iva));
         --
         IF g_num_riesgos > trn.uno
         THEN
            --
            pp_agrega_tbl('I', 'tarifa_total','P??a con mas de un riesgo');
            --
         ELSE
            --
            pp_agrega_tbl('I', 'tarifa_total',fp_format((g_imp_prima_base/g_tot_sum_aseg_pol)*1000)||' %o por Millar');
            --
         END IF;                        
         --       
         g_tot_imp_descuentos := trn.cero;
         g_tot_imp_recargos   := trn.cero;
         g_tot_imp_prima_neta := trn.cero;
         g_tot_imp_igsci      := trn.cero;
         g_tot_imp_emision    := trn.cero;
         g_tot_imp_iva        := trn.cero;
         g_tot_imp_total      := trn.cero;
         g_tot_imp_prima_pol  := trn.cero;
         g_tot_sum_aseg_pol   := trn.cero;
         --
         pp_write_clob(TRUE  );
         pp_close_tag('totales');           
         --
         IF l_cv_riesgos%ISOPEN
         THEN
            --
            CLOSE l_cv_riesgos;
            --
         END IF;
         --
      EXCEPTION
         --
         WHEN OTHERS
         THEN
            --
            g_aux_exc_trace := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
            --
            RAISE;
            --
      END pi_trata_datos_riesgos;
      --
      /* --------------------------------------------------------
      || pi_trata_datos_poliza:
      || Se iteran las polizas y para una de ellas se guardan los valores
      || que seran comunes a cada riesgo y que se agregaran al clob
      || dentro de pi_trata_datos_riesgos
      */ --------------------------------------------------------
      PROCEDURE pi_trata_datos_poliza
      IS
         --
         l_fec_emision       a2000030.fec_emision          %TYPE;
         l_pd_fec_inception  a2000030.fec_efec_poliza      %TYPE;
         l_pd_fec_exp        a2000030.fec_vcto_spto_publico%TYPE;
         l_pd_num_poliza     a2000030.num_poliza           %TYPE;
         l_pd_fec_issue      a2000030.fec_actu             %TYPE;
         l_pd_hor_issue      a2000030.hora_desde           %TYPE;
         l_nom_mon           a1000400.nom_mon              %TYPE;
         l_cab_report_type   a1009012_msv.contenido_objeto %TYPE;
         l_nom_agt           v1001390.nom_completo         %TYPE;
         l_nom_canal         a1000723.des_canal3           %TYPE;
         l_tel_agt           a1001332.tlf_numero           %TYPE;
         l_email_agt         a1001332.email                %TYPE;
         l_cab_fec_efec_spto a2000030.fec_efec_spto        %TYPE;
         l_cab_fec_vcto_spto a2000030.fec_vcto_spto        %TYPE;
         --
         l_concepto         VARCHAR2(500);
         l_cab_sched_pol    VARCHAR(1000);
         l_ph_holder_id     VARCHAR2(50) ;
         l_ph_address       VARCHAR2(500);
         l_ph_alt_holder_id VARCHAR2(50) ;
         l_ph_alt_address   VARCHAR2(500);
         --
         l_imp_prima_base            a2000161.imp_eco           %TYPE;
         l_imp_recargos              a2000161.imp_eco           %TYPE;
         l_imp_emision               a2000161.imp_eco           %TYPE;
         l_imp_iva                   a2000161.imp_eco           %TYPE;
         l_imp_descuentos            a2000161.imp_eco           %TYPE;
         l_imp_igsci                 a2000161.imp_eco           %TYPE;
         l_medio_pago                a5020200.nom_tip_gestor    %TYPE;
         l_forma_pago                a1001402.nom_fracc_pago    %TYPE;
         l_ph_holder_name            v1001390.nom_completo      %TYPE;
         l_ph_birth                  a1001331.fec_nacimiento    %TYPE;
         l_ph_occupation             g1000100.nom_profesion     %TYPE;
         l_ph_tip_prefijo_nombre     v1001390.tip_prefijo_nombre%TYPE;
         l_ph_ape1_tercero           v1001390.ape1_tercero      %TYPE;
         l_email_tomador             a1001331.email             %TYPE;
         l_dom1_tomador              a1001300.nom_domicilio1    %TYPE;
         l_dom2_tomador              a1001300.nom_domicilio2    %TYPE;
         l_dom3_tomador              a1001300.nom_domicilio3    %TYPE;
         l_pob_tomador               a1001300.nom_localidad     %TYPE;
         l_edo_tomador               a1000104.nom_estado        %TYPE;
         l_prov_tomador              a1000100.nom_prov          %TYPE;
         l_cp_tomador                a1001300.cod_postal        %TYPE;
         l_ph_alt_holder_name        v1001390.nom_completo      %TYPE;
         l_ph_alt_birth              a1001331.fec_nacimiento    %TYPE;
         l_ph_alt_occupation         g1000100.nom_profesion     %TYPE;
         l_ph_alt_tip_prefijo_nombre v1001390.tip_prefijo_nombre%TYPE;
         l_ph_alt_ape1_tercero       v1001390.ape1_tercero      %TYPE;
         l_dom1_alt_tomador          a1001300.nom_domicilio1    %TYPE;
         l_dom2_alt_tomador          a1001300.nom_domicilio2    %TYPE;
         l_dom3_alt_tomador          a1001300.nom_domicilio3    %TYPE;
         l_pob_alt_tomador           a1001300.nom_localidad     %TYPE;
         l_edo_alt_tomador           a1000104.nom_estado        %TYPE;
         l_prov_alt_tomador          a1000100.nom_prov          %TYPE;
         l_cp_alt_tomador            a1001300.cod_postal        %TYPE;
         l_nom_usr                   g1010120.nom_usr           %TYPE;
         l_cod_tercero               a1001300.cod_tercero       %TYPE;
         l_cod_tercero_alt           a1001300.cod_tercero       %TYPE;
         --
         reg_v1001390 v1001390%ROWTYPE;
         --
         l_es_presupuesto BOOLEAN;
         --
      BEGIN
         --
         BEGIN
            --
            IF g_jbtip_emision = g_k_rep_cotizacion
            THEN
               --
               l_es_presupuesto := TRUE;
               --
               l_cv_a2000030 := fp_abre_query(p_mca_tabla_p => trn.si);
               --
            ELSE
               --
               l_es_presupuesto := FALSE;
               --
               l_cv_a2000030 := fp_abre_query;
               --
            END IF;
            --
            g_cont_regs := trn.cero;
            --
            g_abre_reporte := TRUE;
            --
            FETCH l_cv_a2000030 INTO l_reg30;
            g_existe := l_cv_a2000030%FOUND;
            --
            WHILE g_existe
            LOOP
               --
               BEGIN
                  --
                  g_cod_ramo           := l_reg30.cod_ramo          ;
                  g_cod_sector         := l_reg30.cod_sector        ;
                  g_num_poliza         := l_reg30.num_poliza        ;
                  g_num_spto           := l_reg30.num_spto          ;
                  g_num_apli           := l_reg30.num_apli          ;
                  g_num_spto_apli      := l_reg30.num_spto_apli     ;
                  g_cod_spto           := l_reg30.cod_spto          ;
                  g_sub_cod_spto       := l_reg30.sub_cod_spto      ;
                  g_mca_impresion      := l_reg30.mca_impresion     ;
                  g_fec_efec_spto      := l_reg30.fec_efec_spto     ;
                  g_tip_docum_hdr      := l_reg30.tip_docum         ;
                  g_cod_docum_hdr      := l_reg30.cod_docum         ;
                  g_num_contrato       := l_reg30.num_contrato      ;
                  g_num_subcontrato    := l_reg30.num_subcontrato   ;
                  g_num_poliza_cliente := l_reg30.num_poliza_cliente;
                  g_cod_nivel1         := l_reg30.cod_nivel1        ;
                  g_cod_nivel2         := l_reg30.cod_nivel2        ;
                  g_cod_nivel3         := l_reg30.cod_nivel3        ;
                  g_cod_agt            := l_reg30.cod_agt           ;
                  g_num_poliza_grupo   := l_reg30.num_poliza_grupo  ;
                  g_num_spto_grp       := l_reg30.num_spto_grp      ;
                  g_cod_ejecutivo      := l_reg30.cod_ejecutivo     ;
                  g_num_riesgos        := fp_dev_riesgos(l_es_presupuesto);--l_reg30.num_riesgos       ;
                  --
                  --Variables necesarias para clausulas
                  g_fec_validez      := l_reg30.fec_validez    ;
                  g_fec_emision_spto := l_reg30.fec_emision    ;
                  g_fec_efec_poliza  := l_reg30.fec_efec_poliza;
                  g_tip_spto         := l_reg30.tip_spto       ;
                  --
                  g_fec_vcto_spto   := NVL( l_reg30.fec_vcto_spto_publico, l_reg30.fec_vcto_spto  );
                  g_fec_vcto_poliza := NVL( l_reg30.fec_vcto_spto_publico, l_reg30.fec_vcto_poliza);
                  --
                  g_cod_modalidad := fp_dev_modalidad;                  
                  --
                  pp_abre_reporte;
                  --
                  pp_write_clob_seg;
                  --
                  -- Nombre del reporte
                  l_cab_report_type := 'fp_txt_reporte(88)';
                  --
                  BEGIN
                     --
                     reg_v1001390 := dc_f_v1001390_1(g_cod_cia      ,
                                                     g_cod_ejecutivo,
                                                     g_k_11         );
                     --
                     g_nom_ejecutivo := reg_v1001390.nom_completo;
                     --
                  EXCEPTION
                     --
                     WHEN OTHERS
                     THEN
                        --
                        g_nom_ejecutivo := trn.nulo;
                        --
                  END;
                  --
                  l_fec_emision      := l_reg30.fec_emision;
                  l_pd_fec_inception := l_reg30.fec_efec_poliza;
                  l_pd_hor_issue     := l_reg30.hora_desde;
                  --
                  IF fp_val_renovacion
                  THEN
                     --
                     l_concepto := g_k_renovacion;
                     --
                  ELSE
                     --
                     l_concepto := g_k_nueva_produccion;
                     --
                  END IF;
                  --
                  dc_k_a5020200.p_lee(l_reg30.tip_gestor);
                  --
                  l_forma_pago := fp_forma_pago(l_reg30.cod_fracc_pago);
                  l_medio_pago := dc_k_a5020200.f_nom_tip_gestor       ;
                  --
                  IF g_usa_spto_temporal
                  THEN
                     --
                     l_pd_fec_exp := l_reg30.fec_vcto_spto;
                     --
                  ELSE
                     --
                     l_pd_fec_exp := fp_fec_vcto_poliza_publico(p_cod_cia               => g_cod_cia                    ,
                                                                p_num_poliza            => g_num_poliza                 ,
                                                                p_hora_desde            => l_reg30.hora_desde           ,
                                                                p_cod_spto              => g_cod_spto                   ,
                                                                p_sub_cod_spto          => g_sub_cod_spto               ,
                                                                p_fec_vcto_poliza       => l_reg30.fec_vcto_poliza      ,
                                                                p_fec_vcto_spto_publico => l_reg30.fec_vcto_spto_publico);
                  END IF;
                  --
                  l_pd_fec_issue  := l_reg30.fec_actu;
                  l_pd_num_poliza := g_num_poliza    ;
                  --
                  dc_k_a1000400.p_lee(p_cod_mon => l_reg30.cod_mon);
                  --
                  g_decimales := dc_k_a1000400.f_num_decimales;
                  --
                  IF l_reg30.cod_mon = trn.UNO
                  THEN
                     --
                     l_nom_mon := CONCAT(SUBSTR(dc_k_a1000400.f_nom_mon,0,7),g_k_s);
                     --
                     g_cod_mon := '$';
                     --
                  ELSE
                     --
                     l_nom_mon := dc_k_a1000400.f_nom_mon;
                     --
                     g_cod_mon := 'US$';
                     --
                  END IF;
                  --
                  -- Obtiene la informacion del agente
                  pp_dev_info_agente(p_cod_cia       => g_cod_cia      ,
                                     p_num_poliza    => g_num_poliza   ,
                                     p_num_spto      => g_num_spto     ,
                                     p_fec_efec_spto => g_fec_efec_spto,
                                     p_cod_agt       => l_reg30.cod_agt,
                                     p_nom_completo  => l_nom_agt      ,
                                     p_nom_canal     => l_nom_canal    ,
                                     p_tel_agt       => l_tel_agt      ,
                                     p_email_agt     => l_email_agt    );
                  --
                  l_cab_fec_efec_spto := l_reg30.fec_efec_spto;
                  l_cab_fec_vcto_spto := l_pd_fec_exp         ;
                  --
                  l_cab_sched_pol := 'fp_txt_reporte(89)';
                  --
                  l_cab_sched_pol := fp_txt_reporte_param(l_cab_sched_pol,
                                                          g_num_poliza   );
                  --
                  -- Obtiene los importes de la poliza o suplemento
                  --
                  IF g_jbtip_emision = g_k_rep_cotizacion
                  THEN
                     --
                     pp_dev_imp_spto_p(g_cod_cia           ,
                                       g_cod_ramo          ,
                                       g_num_poliza        ,
                                       g_num_spto          ,
                                       g_num_apli          ,
                                       g_num_spto_apli     ,
                                       l_imp_prima_base    ,
                                       l_imp_descuentos    ,
                                       l_imp_recargos      ,
                                       l_imp_iva           ,
                                       l_imp_emision       ,
                                       l_imp_igsci         );
                  ELSE                                          
                     --
                     IF g_jbtip_scope = G_K_SCOPE_FOTO
                     THEN
                        --
                        pp_dev_imp_spto_total(g_cod_cia       ,
                                              g_cod_ramo      ,
                                              g_num_poliza    ,
                                              g_num_spto      ,
                                              g_num_apli      ,
                                              g_num_spto_apli ,
                                              l_imp_prima_base,
                                              l_imp_descuentos,
                                              l_imp_recargos  ,
                                              l_imp_iva       ,
                                              l_imp_emision   ,
                                              l_imp_igsci     );                                                                                                    
                        --
                     ELSIF g_jbtip_scope = G_K_SCOPE_SPTO
                     THEN
                        --
                        pp_dev_imp_spto_s_total(g_cod_cia       ,
                                                g_cod_ramo      ,
                                                g_num_poliza    ,
                                                g_num_spto      ,
                                                g_num_apli      ,
                                                g_num_spto_apli ,
                                                g_num_periodo   ,
                                                l_imp_prima_base,
                                                l_imp_descuentos,
                                                l_imp_recargos  ,
                                                l_imp_iva       ,
                                                l_imp_emision   ,
                                                l_imp_igsci     );                       
                        --
                     END IF;
                     --
                  END IF;                  
                  --                                   
                  -- Comprobamos si este tomador es alterno.
                  g_tip_docum_alt_hdr := g_tip_docum_hdr;
                  g_cod_docum_alt_hdr := g_cod_docum_hdr;
                  --
                  IF g_jbtip_emision != g_k_rep_cotizacion
                  THEN
                     --
                     
                     ea_k_301_utils.p_devuelve_tomador(p_cod_cia        => g_cod_cia           ,
                                                       p_cod_ramo       => g_cod_ramo          ,
                                                       p_num_poliza     => g_num_poliza        ,
                                                       p_num_spto       => g_num_spto          ,
                                                       p_num_apli       => g_num_apli          ,
                                                       p_num_spto_apli  => g_num_spto_apli     ,
                                                       p_revisa_alterno => TRUE                ,
                                                       p_tip_docum      => g_tip_docum_alt_hdr ,
                                                       p_cod_docum      => g_cod_docum_alt_hdr ,
                                                       p_busca_en_a     => g_quotation = FALSE );
                     --
                  ELSE
                     --
                     ea_k_301_utils.p_devuelve_tomador(p_cod_cia        => g_cod_cia           ,
                                                       p_cod_ramo       => g_cod_ramo          ,
                                                       p_num_poliza     => g_num_poliza        ,
                                                       p_num_spto       => g_num_spto          ,
                                                       p_num_apli       => g_num_apli          ,
                                                       p_num_spto_apli  => g_num_spto_apli     ,
                                                       p_revisa_alterno => TRUE                ,
                                                       p_tip_docum      => g_tip_docum_alt_hdr ,
                                                       p_cod_docum      => g_cod_docum_alt_hdr ,
                                                       p_busca_en_a     => NULL                );                     
                     --
                  END IF;
                  --
                  -- Obtiene la informacion del tomador
                  pp_dev_info_holder(p_cod_cia            => g_cod_cia              ,
                                     p_tip_docum          => g_tip_docum_hdr        ,
                                     p_cod_docum          => g_cod_docum_hdr        ,
                                     p_num_poliza         => g_num_poliza           ,
                                     p_num_spto           => g_num_spto             ,
                                     p_fec_efec_spto      => g_fec_efec_spto        ,
                                     p_nom_completo       => l_ph_holder_name       ,
                                     p_fec_nacimiento     => l_ph_birth             ,
                                     p_dom1               => l_dom1_tomador         ,
                                     p_dom2               => l_dom2_tomador         ,
                                     p_dom3               => l_dom3_tomador         ,
                                     p_pob                => l_pob_tomador          ,
                                     p_edo                => l_edo_tomador          ,
                                     p_prov               => l_prov_tomador         ,
                                     p_cp                 => l_cp_tomador           ,
                                     p_nom_profesion      => l_ph_occupation        ,
                                     p_address            => l_ph_address           ,
                                     p_tip_prefijo_nombre => l_ph_tip_prefijo_nombre,
                                     p_ape1_tercero       => l_ph_ape1_tercero      ,
                                     p_cod_tercero        => l_cod_tercero          );
                  --
                  l_ph_holder_id  := UPPER(g_tip_docum_hdr)|| ' ' || g_cod_docum_hdr;
                  --
                  pp_dev_info_holder(p_cod_cia            => g_cod_cia                  ,
                                     p_tip_docum          => g_tip_docum_alt_hdr        ,
                                     p_cod_docum          => g_cod_docum_alt_hdr        ,
                                     p_num_poliza         => g_num_poliza               ,
                                     p_num_spto           => g_num_spto                 ,
                                     p_fec_efec_spto      => g_fec_efec_spto            ,
                                     p_nom_completo       => l_ph_alt_holder_name       ,
                                     p_fec_nacimiento     => l_ph_alt_birth             ,
                                     p_dom1               => l_dom1_alt_tomador         ,
                                     p_dom2               => l_dom2_alt_tomador         ,
                                     p_dom3               => l_dom3_alt_tomador         ,
                                     p_pob                => l_pob_alt_tomador          ,
                                     p_edo                => l_edo_alt_tomador          ,
                                     p_prov               => l_prov_alt_tomador         ,
                                     p_cp                 => l_cp_alt_tomador           ,
                                     p_nom_profesion      => l_ph_alt_occupation        ,
                                     p_address            => l_ph_alt_address           ,
                                     p_tip_prefijo_nombre => l_ph_alt_tip_prefijo_nombre,
                                     p_ape1_tercero       => l_ph_alt_ape1_tercero      ,   
                                     p_cod_tercero        => l_cod_tercero_alt          );
                  --
                  l_ph_alt_holder_id  := g_tip_docum_alt_hdr || ' ' || g_cod_docum_alt_hdr;
                  --
                  pp_dev_info_handler(l_reg30.cod_usr,
                                      l_nom_usr      );
                  --
                  -- Se procesan los datos de los riesgos de la poliza
                  --
                  pi_trata_datos_riesgos(p_cab_report_type    => l_cab_report_type    ,
                                         p_cab_nom_tomador    => l_ph_holder_name     ,
                                         p_cab_iden_tomador   => UPPER(l_ph_holder_id),
                                         p_cab_dom1_tomador   => l_dom1_tomador       ,
                                         p_cab_dom2_tomador   => l_dom2_tomador       ,
                                         p_cab_dom3_tomador   => l_dom3_tomador       ,
                                         p_cab_pob_tomador    => l_pob_tomador        ,
                                         p_cab_edo_tomador    => l_edo_tomador        ,
                                         p_cab_prov_tomador   => l_prov_tomador       ,
                                         p_cab_cp_tomador     => l_cp_tomador         ,
                                         p_cab_email_tomador  => l_email_tomador      ,
                                         p_cod_agt            => l_reg30.cod_agt      ,
                                         p_nom_agt            => l_nom_agt            ,
                                         p_canal_agt          => l_nom_canal          ,
                                         p_tel_agt            => l_tel_agt            ,
                                         p_email_agt          => l_email_agt          ,
                                         p_cab_fec_efec_spto  => l_cab_fec_efec_spto  ,
                                         p_cab_fec_vcto_spto  => l_cab_fec_vcto_spto  ,
                                         p_cab_sched_pol      => l_cab_sched_pol      ,
                                         p_nom_mon            => l_nom_mon            ,
                                         p_concepto           => l_concepto           ,
                                         p_fec_emision        => l_fec_emision        ,
                                         p_pd_fec_inception   => l_pd_fec_inception   ,
                                         p_pd_fec_exp         => l_pd_fec_exp         ,
                                         p_pd_num_poliza      => l_pd_num_poliza      ,
                                         p_pd_fec_issue       => l_pd_fec_issue       ,
                                         p_pd_hor_issue       => l_pd_hor_issue       ,
                                         p_medio_pago         => l_medio_pago         ,
                                         p_forma_pago         => l_forma_pago         ,                                         
                                         p_imp_prima_base     => l_imp_prima_base     ,
                                         p_imp_descuentos     => l_imp_descuentos     ,
                                         p_imp_recargos       => l_imp_recargos       ,
                                         p_imp_iva            => l_imp_iva            ,
                                         p_imp_emision        => l_imp_emision        ,
                                         p_imp_igsci          => l_imp_igsci          ,
                                         p_ph_alt_holder_name => l_ph_alt_holder_name ,
                                         p_ph_alt_holder_id   => l_ph_alt_holder_id   ,
                                         p_ph_alt_birth       => l_ph_alt_birth       ,
                                         p_ph_alt_occupation  => l_ph_alt_occupation  ,
                                         p_ph_alt_address     => l_ph_alt_address     ,
                                         p_pol_handler        => l_nom_usr            ,
                                         p_cod_tercero        => l_cod_tercero        );                                       
                  --
                  g_del_report := FALSE;
                  --
                  FETCH l_cv_a2000030 INTO l_reg30;
                  g_existe := l_cv_a2000030%FOUND;
                  --
                  g_cont_regs := g_cont_regs + 1;
                  --
                  --pp_actualiza_mca_impresion;
                  --
               EXCEPTION
                  --
                  WHEN OTHERS
                  THEN
                     --
                     pp_print_error_log ( p_report_name => g_cod_report,
                                          p_add_info    => g_num_poliza);
                     --
                     pp_restore_clob_seg;
                     --
                     FETCH l_cv_a2000030 INTO l_reg30;
                     g_existe := l_cv_a2000030%FOUND;
                     --
               END;
               --
            END LOOP;
            --
            IF l_cv_a2000030%ISOPEN
            THEN
               --
               CLOSE l_cv_a2000030;
               --
            END IF;
            --
         EXCEPTION
            --
            WHEN OTHERS
            THEN
               --
               pp_print_error_log(p_report_name => NVL(g_cod_report, 'N/A'),
                                  p_add_info    => g_num_poliza           );
            --
         END;
         --
      END pi_trata_datos_poliza;
      --
   BEGIN
      --
      --@mx('I','pp_gen_xml_ps');
      --
      pp_recupera_globales;
      --
      IF ea_k_301_utils.f_es_poliza_online
      THEN
         --
          g_jbtip_scope := g_k_scope_spto;
          --
          g_jbnum_spto  := trn_k_global.ref_f_global('num_spto');
          --
      END IF;
      --
      IF g_jbtip_emision = g_k_rep_cotizacion
      THEN
         --
         pp_inicia_variables ( p_quotation => TRUE );
         -- 
      ELSE         
         --
         pp_inicia_variables ( p_quotation => FALSE );
         --
      END IF;
      --
      pi_trata_datos_poliza;
      --
      IF g_cont_regs > trn.CERO
      THEN
         --
         pp_close_report(p_id_fichero => g_id_report    ,
                         p_clob_datos => g_xml_impresion);
         --
         g_cod_mensaje := trn.nulo;
         g_anx_mensaje := trn.nulo;
         --
      ELSE
         --
         g_cod_mensaje := 10100012; --NO SE ENCONTRARON DATOS
         --
         g_anx_mensaje := '. NO HAY INFORMACION CON LOS PARAMETROS SELECCIONADOS';
         --
         pp_devuelve_error;
         --
         pp_print_error_log(p_report_name => NVL(g_cod_report, 'N/A'),
                            p_add_info    => g_cod_mensaje || ' ' || g_anx_mensaje);
         --
      END IF;
      --
      trn_k_global.asigna('id_report',g_id_report);
      --
      pp_task_ending;
      --
      --@mx('F','pp_gen_xml_ps');
      --
   EXCEPTION
      --
      WHEN OTHERS
      THEN
         --
         pp_print_error_log ( p_report_name => 'N/A' );
         --
   END pp_gen_xml_ps;
   --
   /* --------------------------------------------------------
   || pp_gen_xml_sp:
   || Genera suplemento de poliza
   */ --------------------------------------------------------
   --   
   PROCEDURE pp_gen_xml_sp
   IS
      --
   BEGIN
      --
      em_k_jrp_228_spto.p_gen_xml_lanzador;
      --
   END pp_gen_xml_sp;
   --
   /* --------------------------------------------------------
   || pp_gen_xml_rb:
   || Genera recibos de poliza
   */ --------------------------------------------------------
   --
   PROCEDURE pp_gen_xml_rb
   IS
      --
   BEGIN
      --      
      pp_recupera_globales;
      --
      em_k_jrp_228_recibos.p_gen_xml_lanzador(g_jbcod_ramo      ,
                                              g_jbcod_nivel1    ,
                                              g_jbcod_nivel2    ,
                                              g_jbcod_nivel3    ,
                                              g_jbcod_agt       ,
                                              g_jbnum_poliza    ,
                                              g_jbnum_spto      ,
                                              g_num_apli        ,
                                              g_num_spto_apli   ,
                                              g_jbtip_docum_aseg,
                                              g_jbcod_docum_aseg,
                                              g_jbtip_docum_hdr ,
                                              g_jbcod_docum_hdr ,
                                              g_jbfec_desde     ,
                                              g_jbfec_hasta     ,
                                              g_jbtip_scope     ,
                                              g_jbchoose_report ,
                                              trn.NO            );
      --
   END pp_gen_xml_rb;   
   --
   ----------------------------------
   -- pp_gen_anex_fracc        
   ----------------------------------
   --
   PROCEDURE pp_gen_anex_fracc
   IS
      --
   BEGIN
      --
      null;
      --         
   END pp_gen_anex_fracc;  
   --
   ----------------------------------
   -- pp_gen_cond_part        
   ----------------------------------
   --
   PROCEDURE pp_gen_cond_part
   IS
   BEGIN
      --
      null;
      --
   END pp_gen_cond_part;
   --
   ----------------------------------
   -- pp_gen_anex_fracc        
   ----------------------------------
   --
   PROCEDURE pp_gen_cartas_228
   IS
      --
   BEGIN
      --
      null;
      --
   END pp_gen_cartas_228;
   --
   ----------------------------------
   -- p_devuelve_id_report
   ----------------------------------
   --
   PROCEDURE p_devuelve_id_report(p_id_report OUT tronweb_reports.id_report%TYPE)
   IS
   --
   BEGIN
      --
      --@mx('I','p_devuelve_id_report');
      --
      IF g_idx_id_report IS NULL
      THEN
         --
         g_idx_id_report := g_tbl_envio_email.FIRST;
         --
      ELSE
         --
         g_idx_id_report := g_tbl_envio_email.NEXT(g_idx_id_report);
         --
      END IF;
      --
      IF g_idx_id_report IS NOT NULL
      THEN
         --
         p_id_report := g_tbl_envio_email(g_idx_id_report).id_report;
         --
      ELSE
         --
         p_id_report := trn.nulo ;
         g_tbl_envio_email.DELETE;
         --
      END IF;
      --
      --@mx('F','p_devuelve_id_report');
      --
   EXCEPTION
      --
      WHEN OTHERS
      THEN
         --
         p_id_report := trn.nulo ;
         g_tbl_envio_email.DELETE;
         --
   END p_devuelve_id_report;
   --
   /* --------------------------------------------------------
   || p_gen_xml_lanzador
   */ --------------------------------------------------------
   --
   PROCEDURE p_gen_xml_lanzador
   IS
   --
   BEGIN
      --
      --@mx('I','p_gen_xml_lanzador');
      --
      g_n_error := trn.cero;
      --
      CASE trn_k_global.f_devuelve_n('jbchoose_report')
      --
      WHEN G_K_REP_PS               THEN pp_gen_xml_ps;     --CARATULA VIDA INDIVIDUAL
      --
      WHEN G_K_REP_CT               THEN pp_gen_xml_ps;     --OFERTA
      --
      WHEN G_K_REP_PC               THEN pp_gen_xml_ps;     --CARATULA DE POLIZA COMPLETA
      --
      WHEN G_K_REP_RB               THEN pp_gen_xml_rb;     --RECIBO
      --
      WHEN G_K_REP_SPTO             THEN pp_gen_xml_sp;     --SUPLEMENTOS
      --
      WHEN G_K_REP_PF               THEN pp_gen_anex_fracc; --ANEXO DE PAGOS FRACCIONADOS
      --
      WHEN G_K_REP_CP               THEN pp_gen_cond_part;  --CONDICIONES PARTICULARES
      --
      WHEN G_K_REP_CARAT            THEN pp_gen_cartas_228; --CARATULA DE POLIZA
      --
      WHEN G_K_REP_COND_TODO_RIES   THEN pp_gen_cartas_228; --CONDICIONES TODO RIESGO
      --
      WHEN G_K_REP_END_ACLA_ESP     THEN pp_gen_cartas_228; --ENDOSO DE ACLARACIONES ESPECIALES
      --
      WHEN G_K_REP_COND_GRALES      THEN pp_gen_cartas_228; --CONDICIONES GENERALES
      --
      WHEN G_K_REP_ACLA_RIES_NAT    THEN pp_gen_cartas_228; --ACLARACION DE RIESGOS DE LA NATURALEZA
      --
      WHEN G_K_REP_EXC_TERR_SAB     THEN pp_gen_cartas_228; --EXCLUSION DE TERREMOTO Y SABOTAJE
      --
      WHEN G_K_REP_ANX_ATRACO       THEN pp_gen_cartas_228; --ANEXO DE ATRACO
      --
      WHEN G_K_REP_ANX_ROBO         THEN pp_gen_cartas_228; --ANEXO DE ROBO
      --
      WHEN G_K_END_TERREMOTO        THEN pp_gen_cartas_228; --ENDOSO DE TERREMOTO      
      --
      WHEN G_K_END_DANOS_AGUA       THEN pp_gen_cartas_228; --ENDOSO DE DANOS POR AGUA   
      --
      WHEN G_K_ANX_ROTAVE_CRIS      THEN pp_gen_cartas_228; --ANEXO DE ROTURA Y AVERIA DE CRISTALES
      --
      WHEN G_K_REP_CS               THEN  pp_gen_xml_sp;     --SUPLEMENTOS
      -- 
      WHEN G_K_REP_CA               THEN  pp_gen_xml_sp;     --SUPLEMENTOS
      --
      WHEN G_K_REP_CE               THEN  pp_gen_xml_sp;     --SUPLEMENTOS
      --
      WHEN G_K_REP_AN               THEN  pp_gen_xml_sp;     --SUPLEMENTOS
      --
      WHEN G_K_REP_CD               THEN  pp_gen_xml_sp;     --SUPLEMENTOS
      --
      WHEN G_K_REP_CSD              THEN  pp_gen_xml_sp;     --SUPLEMENTOS
      --
      ELSE
         --
         g_cod_mensaje := -20001;
         g_anx_mensaje := 'OPCION INVALIDA';
         --
         pp_devuelve_error;
         --
      END CASE;
      --
      pp_close_error_log;
      --
      trn_k_global.borra_variable('jbcod_ramo'        );
      trn_k_global.borra_variable('jbcod_nivel1'      );
      trn_k_global.borra_variable('jbcod_nivel2'      );
      trn_k_global.borra_variable('jbcod_nivel3'      );
      trn_k_global.borra_variable('jbcod_agt'         );
      trn_k_global.borra_variable('jbcod_agt'         );
      trn_k_global.borra_variable('JBNUM_POLIZA_GRUPO');
      trn_k_global.borra_variable('JBNUM_CONTRATO'    );
      trn_k_global.borra_variable('JBNUM_SPTO_GRUPO'  );
      trn_k_global.borra_variable('jbtip_emision'     );
      trn_k_global.borra_variable('jbtip_docum_i'     );
      trn_k_global.borra_variable('jbcod_docum_i'     );
      trn_k_global.borra_variable('jbnum_poliza'      );
      trn_k_global.borra_variable('jbnum_spto'        );
      trn_k_global.borra_variable('jbtip_soa'         );
      trn_k_global.borra_variable('jbcod_agt_advisor' );
      trn_k_global.borra_variable('jbtip_docum_hdr'   );
      trn_k_global.borra_variable('jbcod_docum_hdr'   );
      trn_k_global.borra_variable('jbchoose_report'   );
      trn_k_global.borra_variable('jbprint_copies'    );
      trn_k_global.borra_variable('jbinvoice_number'  );
      trn_k_global.borra_variable('mca_brokerage_mod' );
      trn_k_global.borra_variable('tip_scope'         );
      trn_k_global.borra_variable('jbfec_desde'       );
      trn_k_global.borra_variable('jbfec_hasta'       );
      trn_k_global.borra_variable('mca_envio_email'   );
      trn_k_global.borra_variable('mca_migracion'     );
      trn_k_global.borra_variable('mca_gen_individual');
      trn_k_global.borra_variable('cod_proceso'       );
      trn_k_global.borra_variable('num_proceso'       );
      trn_k_global.borra_variable('fec_tratamiento'   );
      trn_k_global.borra_variable('num_orden'         );
      trn_k_global.borra_variable('tip_mvto_batch'    );
      trn_k_global.borra_variable('jbmca_con_gen'     );
      trn_k_global.borra_variable('jbnum_apli'        );
      trn_k_global.borra_variable('jbnum_spto_apli'   );      
      --
      g_jbcod_ramo       := trn.nulo;
      g_jbcod_nivel1     := trn.nulo;
      g_jbcod_nivel2     := trn.nulo;
      g_jbcod_nivel3     := trn.nulo;
      g_jbcod_agt        := trn.nulo;
      g_jbnum_poliza     := trn.nulo;
      g_jbnum_spto       := trn.nulo;
      g_num_apli         := trn.nulo;
      g_num_spto_apli    := trn.nulo;
      g_jbtip_docum_aseg := trn.nulo;
      g_jbcod_docum_aseg := trn.nulo;
      g_jbtip_docum_hdr  := trn.nulo;
      g_jbcod_docum_hdr  := trn.nulo;
      g_jbfec_desde      := trn.nulo;
      g_jbfec_hasta      := trn.nulo;
      g_jbtip_scope      := trn.nulo;
      g_jbchoose_report  := trn.nulo;
      g_tip_scope        := trn.nulo;
      --
      trn_k_global.asigna('id_report',g_id_report);
      --
      --@mx('F','p_gen_xml_lanzador');
      --
   END p_gen_xml_lanzador;
   --
END em_k_jrp_228_emi_msv;
