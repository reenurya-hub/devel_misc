DECLARE
   --
BEGIN
   --
   BEGIN
      --
      INSERT INTO a1009012_msv (cod_report      ,
                                num_secu        ,
                                cod_ramo        ,
                                tip_objeto      ,
                                contenido_objeto,
                                fec_validez     ,
                                mca_inh         ,
                                cod_usr         ,
                                fec_actu        )
                        VALUES ('EM_K_JRP_POLIZA_228_PS_MSV'   ,
                                20                             ,
                                228                            ,
                                'T'                            ,
                                'Se establece una prima m�nima por cuota de US $ PRIMA_MINIMA (enti�ndase coma prima m�nima, la Prima Neta, que no incluye gastos ni impuestos).',
                                TO_DATE('11062020', 'DDMMYYYY'),
                                'N'                            ,
                                'TRON2000'                     ,
                                TRUNC(SYSDATE)                 );
      --
      COMMIT;
      --
   EXCEPTION
      --
      WHEN DUP_VAL_ON_INDEX
      THEN
         --
         UPDATE a1009012_msv a1
            SET a1.tip_objeto       = 'T'                            ,
                a1.contenido_objeto = 'Se establece una prima m�nima por cuota de US $ PRIMA_MINIMA (enti�ndase coma prima m�nima, la Prima Neta, que no incluye gastos ni impuestos).',
                a1.mca_inh          = 'N'                            ,
                a1.cod_usr          = 'TRON2000'                     ,
                a1.fec_actu         = TRUNC(SYSDATE)                
          WHERE a1.cod_report  = 'EM_K_JRP_POLIZA_228_PS_MSV'
            AND a1.num_secu    = 20
            AND a1.cod_ramo    = 228
            AND a1.fec_validez = TO_DATE('11062020', 'DDMMYYYY');
         --
         IF SQL%ROWCOUNT = 1
         THEN
            --
            COMMIT;
            --
         ELSE
            --
            dbms_output.put_line('A1009012_MSV'||SQLCODE||' -ERROR- '||SQLERRM);
            --
            ROLLBACK;
            --
         END IF;
         --
   END;
   --
   BEGIN
      --
      INSERT INTO a1009012_msv (cod_report      ,
                                num_secu        ,
                                cod_ramo        ,
                                tip_objeto      ,
                                contenido_objeto,
                                fec_validez     ,
                                mca_inh         ,
                                cod_usr         ,
                                fec_actu        )
                        VALUES ('EM_K_JRP_POLIZA_228_PS_TR_MSV',
                                20                             ,
                                228                            ,
                                'T'                            ,
                                'Se establece una prima m�nima por cuota de US $ PRIMA_MINIMA (enti�ndase coma prima m�nima, la Prima Neta, que no incluye gastos ni impuestos).',
                                TO_DATE('11062020', 'DDMMYYYY'),
                                'N'                            ,
                                'TRON2000'                     ,
                                TRUNC(SYSDATE)                 );
      --
      COMMIT;
      --
   EXCEPTION
      --
      WHEN DUP_VAL_ON_INDEX
      THEN
         --
         UPDATE a1009012_msv a1
            SET a1.tip_objeto       = 'T'                            ,
                a1.contenido_objeto = 'Se establece una prima m�nima por cuota de US $ PRIMA_MINIMA (enti�ndase coma prima m�nima, la Prima Neta, que no incluye gastos ni impuestos).',
                a1.mca_inh          = 'N'                            ,
                a1.cod_usr          = 'TRON2000'                     ,
                a1.fec_actu         = TRUNC(SYSDATE)                
          WHERE a1.cod_report  = 'EM_K_JRP_POLIZA_228_PS_TR_MSV'
            AND a1.num_secu    = 20
            AND a1.cod_ramo    = 228
            AND a1.fec_validez = TO_DATE('11062020', 'DDMMYYYY');
         --
         IF SQL%ROWCOUNT = 1
         THEN
            --
            COMMIT;
            --
         ELSE
            --
            dbms_output.put_line('A1009012_MSV'||SQLCODE||' -ERROR- '||SQLERRM);
            --
            ROLLBACK;
            --
         END IF;
         --
   END;
   --
   COMMIT;
   --
EXCEPTION
   --
   WHEN OTHERS
   THEN
      --
      dbms_output.put_line('A1009012_MSV'||SQLCODE||' -ERROR- '||SQLERRM);
      --
      ROLLBACK;
      --
   --
END;
/
