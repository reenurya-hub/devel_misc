cotizaci�n emitida el 13/01/2023         = 2222800000991

SELECT * FROM a1009012_msv WHERE CONTENIDO_OBJETO LIKE UPPER('%VALIDEZ%') 

em_k_jrp_228_emi_msv


SELECT * FROM tronweb_reports
ORDER BY fec_created DESC;

msv,em_k_jrp_oferta_228_tr_PS_msv


SELECT * FROM  g2990300 WHERE cod_ramo = 228;

SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_OFERTA_228_CT_MSV';
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_OFERTA_228_TR_CT_MSV';
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_MSV';
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228 AND cod_report = 'EM_K_JRP_POLIZA_228_PS_TR_MSV';
SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND UPPER(contenido_objeto) LIKE UPPER('%VALIDEZ%');

SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND NUM_SECU = 15 AND 
COD_REPORT IN ('EM_K_JRP_OFERTA_228_CT_MSV', 'EM_K_JRP_OFERTA_228_TR_CT_MSV')
FOR UPDATE;

Esperamos que la presente oferta de seguros merezca su aceptaci�n y para cualquier aclaraci�n o duda sobre la misma, estamos a sus apreciables ordenes. <br><br> Validez de la presente oferta: 30 d�as, a partir de la fecha de emisi�n. <br><br>  
La presente oferta de seguro se emite en [ciudad] el dia [fecha].

insert into a1009012_msv (COD_REPORT, NUM_SECU, COD_RAMO, TIP_OBJETO, CONTENIDO_OBJETO, FEC_VALIDEZ, MCA_INH, COD_USR, FEC_ACTU)
values ('EM_K_JRP_OFERTA_228_CT_MSV', 15, 228, 'T', '<CLOB>', to_date('11-06-2020', 'dd-mm-yyyy'), 'N', 'TRON2000', to_date('11-09-2020', 'dd-mm-yyyy'));

insert into a1009012_msv (COD_REPORT, NUM_SECU, COD_RAMO, TIP_OBJETO, CONTENIDO_OBJETO, FEC_VALIDEZ, MCA_INH, COD_USR, FEC_ACTU)
values ('EM_K_JRP_OFERTA_228_TR_CT_MSV', 15, 228, 'T', '<CLOB>', to_date('11-06-2020', 'dd-mm-yyyy'), 'N', 'TRON2000', to_date('11-09-2020', 'dd-mm-yyyy'));

prompt Done.


em_k_jrp_228_emi_msv

SELECT * FROM tronweb_reports
ORDER BY fec_created DESC;

SELECT * FROM tronweb_reports_datamodel


SELECT * FROM a1009012_msv WHERE cod_ramo = 228 AND NUM_SECU IN(70,71) 
AND COD_REPORT IN ('EM_K_JRP_OFERTA_228_CT_MSV', 'EM_K_JRP_OFERTA_228_TR_CT_MSV')


-- cotizacion todo riesgo = 2222800000991
-- cotizacion tradicional = 2222800000992

