DECLARE
   --
BEGIN
   --
   BEGIN
      --
      INSERT INTO a1009012_msv (cod_report      ,
                                num_secu        ,
                                cod_ramo        ,
                                tip_objeto      ,
                                contenido_objeto,
                                fec_validez     ,
                                mca_inh         ,
                                cod_usr         ,
                                fec_actu        )
                        VALUES ('EM_K_JRP_OFERTA_228_CT_MSV'   ,
                                15                             ,
                                228                            ,
                                'T'                            ,
                                'Esperamos que la presente oferta de seguros merezca su aceptaci�n y para cualquier aclaraci�n o duda sobre la misma, estamos a sus apreciables ordenes. <br><br> Validez de la presente oferta: 15 d�as, a partir de la fecha de emisi�n. <br><br>  
La presente oferta de seguro se emite en [ciudad] el dia [fecha].',
                                TO_DATE('11062020', 'DDMMYYYY'),
                                'N'                            ,
                                'TRON2000'                     ,
                                TRUNC(SYSDATE)                 );
      --
      COMMIT;
      --
   EXCEPTION
      --
      WHEN DUP_VAL_ON_INDEX
      THEN
         --
         UPDATE a1009012_msv a1
            SET a1.tip_objeto       = 'T'                            ,
                a1.contenido_objeto = 'Esperamos que la presente oferta de seguros merezca su aceptaci�n y para cualquier aclaraci�n o duda sobre la misma, estamos a sus apreciables ordenes. <br><br> Validez de la presente oferta: 15 d�as, a partir de la fecha de emisi�n. <br><br>  
La presente oferta de seguro se emite en [ciudad] el dia [fecha].',
                a1.mca_inh          = 'N'                            ,
                a1.cod_usr          = 'TRON2000'                     ,
                a1.fec_actu         = TRUNC(SYSDATE)                
          WHERE a1.cod_report  = 'EM_K_JRP_OFERTA_228_CT_MSV'
            AND a1.num_secu    = 15
            AND a1.cod_ramo    = 228
            AND a1.fec_validez = TO_DATE('11062020', 'DDMMYYYY');
         --
         IF SQL%ROWCOUNT = 1
         THEN
            --
            COMMIT;
            --
         ELSE
            --
            dbms_output.put_line('A1009012_MSV'||SQLCODE||' -ERROR- '||SQLERRM);
            --
            ROLLBACK;
            --
         END IF;
         --
   END;
   --
   BEGIN
      --
      INSERT INTO a1009012_msv (cod_report      ,
                                num_secu        ,
                                cod_ramo        ,
                                tip_objeto      ,
                                contenido_objeto,
                                fec_validez     ,
                                mca_inh         ,
                                cod_usr         ,
                                fec_actu        )
                        VALUES ('EM_K_JRP_OFERTA_228_TR_CT_MSV',
                                15                             ,
                                228                            ,
                                'T'                            ,
                                'Esperamos que la presente oferta de seguros merezca su aceptaci�n y para cualquier aclaraci�n o duda sobre la misma, estamos a sus apreciables ordenes. <br><br> Validez de la presente oferta: 15 d�as, a partir de la fecha de emisi�n. <br><br>  
La presente oferta de seguro se emite en [ciudad] el dia [fecha].',
                                TO_DATE('11062020', 'DDMMYYYY'),
                                'N'                            ,
                                'TRON2000'                     ,
                                TRUNC(SYSDATE)                 );
      --
      COMMIT;
      --
   EXCEPTION
      --
      WHEN DUP_VAL_ON_INDEX
      THEN
         --
         UPDATE a1009012_msv a1
            SET a1.tip_objeto       = 'T'                            ,
                a1.contenido_objeto = 'Esperamos que la presente oferta de seguros merezca su aceptaci�n y para cualquier aclaraci�n o duda sobre la misma, estamos a sus apreciables ordenes. <br><br> Validez de la presente oferta: 15 d�as, a partir de la fecha de emisi�n. <br><br>  
La presente oferta de seguro se emite en [ciudad] el dia [fecha].',
                a1.mca_inh          = 'N'                            ,
                a1.cod_usr          = 'TRON2000'                     ,
                a1.fec_actu         = TRUNC(SYSDATE)                
          WHERE a1.cod_report  = 'EM_K_JRP_OFERTA_228_TR_CT_MSV'
            AND a1.num_secu    = 15
            AND a1.cod_ramo    = 228
            AND a1.fec_validez = TO_DATE('11062020', 'DDMMYYYY');
         --
         IF SQL%ROWCOUNT = 1
         THEN
            --
            COMMIT;
            --
         ELSE
            --
            dbms_output.put_line('A1009012_MSV'||SQLCODE||' -ERROR- '||SQLERRM);
            --
            ROLLBACK;
            --
         END IF;
         --
   END;
   --
   COMMIT;
   --
EXCEPTION
   --
   WHEN OTHERS
   THEN
      --
      dbms_output.put_line('A1009012_MSV'||SQLCODE||' -ERROR- '||SQLERRM);
      --
      ROLLBACK;
      --
   --
END;
/
