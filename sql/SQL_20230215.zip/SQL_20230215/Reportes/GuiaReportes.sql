
--1. Para ubicar el paquete PL/SQL del que se sacan los reportes se ubica el c�digo que se est� ejecutando:
EM_K_JRP_PRINT.P_GEN_XML_LANZADOR
--Ejemplo: 
--Ramo 301 (autos) = 
em_k_jrp_301_emi;
--Ramo 228 (hogar) = 
em_k_jrp_228_emi

--2. Cuando se imprime un documento en tronweb se puede recuperar el jasper que se ejecut� 
SELECT * FROM tronweb_reports ORDER BY fec_created DESC;

-- 3. En los jasper se tienen objetos de reporte tipo byte o tipo texto (XML):
SELECT * FROM a1009012_msv WHERE cod_ramo = 228;
-- Estos se les puede cambiar el valor de acuerdo al c�digo del objeto PL/SQL que lo controla (titulo_16)
--pp_agrega_tbl('T', 'titulo_16'  , fp_txt_reporte(18));

