-- COD_REPORT, NUM_SECU, COD_RAMO, FEC_VALIDEZ  -- PK
--OBJETOS DE REPORTE
SELECT a.*
  FROM a1009012_msv a
 WHERE a.cod_ramo           = 228
   AND a.cod_report         = 'EM_K_JRP_OFERTA_228_CT_MSV'
   AND a.num_secu           = 21
   AND TRUNC(a.fec_validez) = TO_DATE ('11062020' , 'DDMMYYYY')
   -- AND a.tip_objeto = a.tip_objeto
   -- AND a.contenido_objeto = a.contenido_objeto
   -- AND a.mca_inh = a.mca_inh
   -- AND a.cod_usr = a.cod_usr
   -- AND a.fec_actu = a.fec_actu
;
