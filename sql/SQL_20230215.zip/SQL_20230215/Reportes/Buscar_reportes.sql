
--OBJETOS DE REPORTE
SELECT * FROM a1009012_msv WHERE num_secu = 21 AND cod_ramo = 228;

em_k_jrp_228_emi_msv

SELECT * FROM tronweb_reports
ORDER BY fec_created DESC;.

