select * from g2000020 where cod_cia = 1 and cod_ramo = 985 order by tip_nivel, num_secu;

select * from g2000010 where cod_campo = 'FEC_VCTO_POLIZA_TOTAL';
