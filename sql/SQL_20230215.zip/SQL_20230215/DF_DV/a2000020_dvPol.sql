-- DATOS VARIABLES DE LA POLIZA
-- NUM_POLIZA, COD_CIA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, COD_CAMPO, NUM_PERIODO, COD_RAMO  -- PK
SELECT a.*
  FROM a2000020 a
 WHERE 1=1
   AND a.cod_cia             = 1
   AND a.num_poliza          = '4135000092077'
   AND a.num_spto            = 0
   AND a.num_apli            = 0
   AND a.num_spto_apli       = 0
   AND a.num_riesgo          = 0
   AND a.cod_campo           = a.cod_campo
   AND a.num_periodo         = 1
   AND a.cod_ramo            = 985
   -- AND a.tip_nivel        = a.tip_nivel
   -- AND a.val_campo        = a.val_campo
   -- AND a.val_cor_campo    = a.val_cor_campo
   -- AND a.num_secu         = a.num_secu
   -- AND a.txt_campo        = a.txt_campo
   -- AND a.mca_baja_riesgo  = a.mca_baja_riesgo
   -- AND a.mca_vigente      = a.mca_vigente
   -- AND a.mca_vigente_apli = a.mca_vigente_apli
   -- AND a.tip_subnivel     = a.tip_subnivel
ORDER BY TIP_NIVEL, NUM_SECU;
