-- Definicion general de Datos Variables
select * from g2000010 where cod_cia = 1;

-- Definicion de Datos Variables por ramo
-- TIP_NIVEL 1= POLIZA 2= RIESGO 3= COBERTURA
-- MCA_VISIBLE = SI SE MUESTRA O NO DEBE ESTAR EN S
select * from g2000020 where cod_cia = 1 and cod_ramo = 736;
select * from g2000020 where cod_cia = 1 and cod_ramo = 736 for update;

-- Ayudas para llenar datos variables
select * from g2990006 where cod_cia = 1 and cod_ramo = 736 and cod_campo = 'MCA_AUTORIZA_EMAIL';

-- mensajes desde pantalla
select * from G1010020;
