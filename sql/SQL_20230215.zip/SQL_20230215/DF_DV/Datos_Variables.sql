-- P_PRE: 
em_k_ptd_atr.p_asg_val_campo(g_cod_postal.Cod_prov);
em_k_ptd_atr.p_asg_txt_campo(l_nom_prov);

-- MARCA SALTO
em_k_ptd_atr.p_asg_mca_salto( p_mca_salto => 'S');


-- P_V (VALIDACION)
g_reg_informacion_tercero := dc_k_ptd_thp.f_con_datos_asegurado

l_cod_prov := g_reg_informacion_tercero.cod_prov;

l_nom_prov := dc_k_ptd_thp.f_val_cod_prov( l_cod_cia, 'BRA', 1,l_cod_prov );
