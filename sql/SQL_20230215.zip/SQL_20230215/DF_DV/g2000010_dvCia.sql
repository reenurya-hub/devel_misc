-- Datos variables a nivel de compania
SELECT a.*
  FROM g2000010 a
 WHERE a.cod_cia  = 2
   AND a.cod_ramo = 228;
  
