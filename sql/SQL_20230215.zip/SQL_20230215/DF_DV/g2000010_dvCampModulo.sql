SELECT * FROM G2000010 a 
WHERE a.cod_cia  = 7 
AND a.cod_campo  = 'TIP_REPORTE' 
AND a.cod_modulo = 'GC' 
AND a.nom_campo  = 'TIPO DE REPORTE'
AND a.tip_campo  = 'C';
