   /* --------------------------------------------------------
   || pp_asigna :
   ||
   || Llama a trn_k_global.asigna
   */ --------------------------------------------------------
   --
   PROCEDURE pp_asigna (p_nom_global VARCHAR2,
                        p_val_global DATE    )
   IS
   --
   BEGIN
      --
      trn_k_global.asigna(p_variable => p_nom_global                    ,
                          p_valor    => TO_CHAR(p_val_global,'ddmmyyyy'));
      --
   END pp_asigna;
  --