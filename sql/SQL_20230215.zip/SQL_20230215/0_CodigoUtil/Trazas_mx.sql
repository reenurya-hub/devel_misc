   /* --------------------------------------------------------
   || mx :
   || Generacion de traza con VARCHAR2
   */ --------------------------------------------------------
   --
   PROCEDURE mx (p_tit VARCHAR2,
                 p_val VARCHAR2)
   IS
   BEGIN
      --
      trn_k_global.asigna (p_variable => 'fic_traza', p_valor => 'Liquid' );
      trn_k_global.asigna (p_variable => 'cab_traza', p_valor => 'imp_liq');
      --
      em_k_traza.p_escribe (p_titulo => p_tit,
                            p_valor  => p_val);
      --
   END mx;
   --
   /* --------------------------------------------------------
   || mx :
   || Generacion de traza con BOOLEAN
   */ --------------------------------------------------------
   --
   PROCEDURE mx (p_tit VARCHAR2,
                 p_val BOOLEAN )
   IS
   BEGIN
      --
      trn_k_global.asigna (p_variable => 'fic_traza', p_valor => 'Liquid' );
      trn_k_global.asigna (p_variable => 'cab_traza', p_valor => 'imp_liq');
      --
      em_k_traza.p_escribe (p_titulo => p_tit,
                            p_valor  => p_val);
      --
   END mx;
   --