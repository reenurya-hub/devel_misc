    /* ----------------------------------
    ||  pp_recupera_globales      :
    */ ----------------------------------
    --
    PROCEDURE pp_recupera_globales
    IS
    BEGIN
       --
       --@mx('I', 'pp_recupera_globales');
       --
       g_cod_cia              := trn_k_global.devuelve('cod_cia'                                         );
       g_cod_ramo             := trn_k_global.devuelve('cod_ramo'                                        );
       g_cod_tarifa           := TO_NUMBER(NVL(ea_k_231_utils.f_valor_dv('cod_tarifa'),EM.COD_TARIFA_GEN));
       g_fec_validez          := TO_DATE(trn_k_global.devuelve('fec_validez'),'ddmmyyyy'                 );
       g_num_poliza_grupo     := trn_k_global.ref_f_global('num_poliza_grupo'                            ); 
       g_num_contrato         := trn_k_global.ref_f_global('num_contrato'                                );
       g_num_poliza_cliente   := trn_k_global.ref_f_global('num_poliza_cliente'                          );
       g_num_poliza           := trn_k_global.ref_f_global('num_poliza'                                  );
       g_num_presupuesto      := trn_k_global.ref_f_global('num_presupuesto'                             );
       g_num_cotizacion       := trn_k_global.ref_f_global('num_cotizacion'                              );
       g_cod_agt              := trn_k_global.ref_f_global('cod_agt'                                     );
       g_cod_modalidad        := trn_k_global.ref_f_global(em_k_g2990015.f_dvcod_modalidad               );
       g_num_subcontrato      := trn_k_global.ref_f_global('num_subcontrato'                             );
       g_cod_mon              := trn_k_global.ref_f_global('cod_mon'                                     );
       g_fec_efec_spto        := TO_DATE(trn_k_global.ref_f_global('fec_efec_spto'), trn.FORMATO_FECHA   ); 
       g_fec_vcto_spto        := TO_DATE(trn_k_global.ref_f_global('fec_vcto_spto'), trn.FORMATO_FECHA   );
       g_fec_emision_spto     := TO_DATE(trn_k_global.ref_f_global('fec_emision_spto'),'ddmmyyyy'        );
       g_cod_cob              := trn_k_global.ref_f_global('cod_cob'                                     );
       g_cod_desglose         := trn_k_global.ref_f_global('cod_desglose'                                );
       g_num_cotacao          := trn_k_global.ref_f_global('num_cotizacion'                              );
       g_tip_emision          := trn_k_global.ref_f_global('tip_emision'                                 );
       g_num_spto             := trn_k_global.ref_f_global('num_spto'                                    );
       g_num_apli             := NVL(trn_k_global.ref_f_global('num_apli'),trn.CERO                      );
       g_num_riesgo           := trn_k_global.ref_f_global('num_riesgo'                                  );
       g_num_spto_apli        := NVL(trn_k_global.ref_f_global('num_spto_apli'),trn.CERO                 );
       g_cod_spto             := NVL(trn_k_global.ref_f_global('cod_spto'          ),trn.CERO            );
       g_tip_benef            := NVL(trn_k_global.ref_f_global('tip_benef'         ),trn.CERO            );
       g_tip_mvto_batch       := trn_k_global.ref_f_global('tip_mvto_batch'                              );
       g_cod_usr_recusa       := trn_k_global.ref_f_global('cod_usr'                                     );
       g_mca_poliza_grupo     := trn_k_global.ref_f_global('mca_poliza_grupo'                            );  
       g_cod_nivel1           := trn_k_global.ref_f_global('COD_NIVEL1'                                  );
       g_cod_nivel2           := trn_k_global.ref_f_global('COD_NIVEL2'                                  );
       g_cod_nivel3           := trn_k_global.ref_f_global('COD_NIVEL3'                                  );
       g_cod_canal1           := trn_k_global.ref_f_global('COD_CANAL1'                                  );
       g_cod_canal2           := trn_k_global.ref_f_global('COD_CANAL2'                                  );
       g_cod_canal3           := trn_k_global.ref_f_global('COD_CANAL3'                                  );
       --
       --@mx('F', 'pp_recupera_globales');
       --
     END pp_recupera_globales;
     --