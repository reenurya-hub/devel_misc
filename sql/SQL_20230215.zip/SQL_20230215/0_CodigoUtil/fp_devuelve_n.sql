   /* --------------------------------------------------------
   || fp_devuelve_n:
   ||
   || Llama a trn_k_global.devuelve y retorna como NUMBER
   */ --------------------------------------------------------
   --
   FUNCTION fp_devuelve_n(p_nom_global VARCHAR2)
      --
      RETURN NUMBER IS
      --
   BEGIN
      --
      RETURN TO_NUMBER(trn_k_global.devuelve(p_nom_global));
      --
   END fp_devuelve_n;
   --