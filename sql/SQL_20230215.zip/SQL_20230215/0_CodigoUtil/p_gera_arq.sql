  /* -----------------------------------------------------------
  || p_gera_arq: Gera o arquivo para impressao
  */ -----------------------------------------------------------
  --
  PROCEDURE p_gera_arq IS
  --
  l_rc BOOLEAN;
  l_reg_30 c_a2000030%ROWTYPE;
  l_num_mvto_bo    a2992131_vcr.num_mvto_bo%TYPE;
  l_tip_situ_bo    a2992131_vcr.tip_situ_bo%TYPE;
  --
  BEGIN
    --
    trn_k_ptd.p_gen_comienzo_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr',
                                   p_nom_metodo => 'p_gera_arq'              );
    --
    g_seq_remessa := seq_985_ccm.NEXTVAL;
    --
    g_nom_origem_arq1_vcr := 'VDPRE'||'_'||LPAD(g_seq_remessa,6,trn.CERO)||'_'||'02'||'.txt';
    --
    dc_k_format_output.p_set_default_environment;
    l_rc:= dc_k_format_output.f_initialize(1999);
    --
    OPEN  c_a2000030;
    FETCH c_a2000030 INTO l_reg_30;
    --
    g_existe := c_a2000030%FOUND;
    --
    pp_header;
    --
    WHILE c_a2000030%FOUND
    LOOP
       --
       dc_k_ptd_vcr.p_devuelve_tip_situ_fech (
          p_cod_cia           => l_reg_30.cod_cia       ,
          p_cod_ramo          => l_reg_30.cod_ramo      ,
          p_num_cotacao       => em.NUM_POLIZA_GEN      ,
          p_num_poliza        => l_reg_30.num_poliza    ,
          p_num_spto          => l_reg_30.num_spto      ,
          p_num_apli          => l_reg_30.num_apli      ,
          p_num_spto_apli     => l_reg_30.num_spto_apli ,
          p_tip_emision       => em.CARGA_BATCH         ,
          p_num_mvto_bo       => l_num_mvto_bo          ,
          p_tip_situ_bo       => l_tip_situ_bo );
       --
       --IF NVL( l_tip_situ_bo, -1) = 3 THEN
       IF NVL( l_tip_situ_bo, 3) = 3 THEN
         --
         pp_d2_apolice(l_reg_30);
         --
         pp_d3_contato_apolice(l_reg_30);
         --
         pp_d4_pessoa_segurado(l_reg_30);
         --
         pp_d4_pessoa_tomador(l_reg_30);
         --
         pp_d5_coberturas(l_reg_30);
         --
         pp_d6_seguradora(l_reg_30);
         --
         --pp_d8_sucursal(l_reg_30); ABSP-629
         --
         pp_d9_corredor(l_reg_30);
         --
         pp_d10_estipulante(l_reg_30);
         --
         pp_d11_dps(l_reg_30);
         --
         g_qtd_reg := g_qtd_reg+1;
         --
       END IF;
       --
       UPDATE a2000030 a
          SET a.mca_impresion = trn.SI
        WHERE a.cod_cia       = l_reg_30.cod_cia
          AND a.num_poliza    = l_reg_30.num_poliza
          AND a.num_spto      = l_reg_30.num_spto
          AND a.num_apli      = l_reg_30.num_apli
          AND a.num_spto_apli = l_reg_30.num_spto_apli;
       --
       COMMIT;
       --
       FETCH c_a2000030 INTO l_reg_30;
       --
    END LOOP;
    --
    CLOSE c_a2000030;
    --
    pp_trailler;
    --
    pp_finaliza;
    --
    trn_k_global.asigna('JBNOM_LISTADO',g_nom_origem_arq1_vcr);
    trn_k_global.asigna('TXT_TAREA', g_k_mensaje_1 || g_nom_origem_arq1_vcr);
    --
    trn_k_global.asigna('mca_ter_tar',trn.SI);
    --
    jb_p_termino_tarea ('S',0,trn.blanco);
    --
    trn_k_ptd.p_gen_final_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr',
                                p_nom_metodo => 'p_gera_arq'              );
   --
  END p_gera_arq;
  --