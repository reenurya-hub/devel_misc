   /* --------------------------------------------------------
   || pp_asigna :
   ||
   || Llama a trn_k_global.asigna
   */ --------------------------------------------------------
   --
   PROCEDURE pp_asigna(p_nom_global VARCHAR2,
                       p_val_global VARCHAR2)
   IS
   --
   BEGIN
      --
      trn_k_global.asigna(p_variable => p_nom_global,
                          p_valor    => p_val_global);
      --
   END pp_asigna;
   --