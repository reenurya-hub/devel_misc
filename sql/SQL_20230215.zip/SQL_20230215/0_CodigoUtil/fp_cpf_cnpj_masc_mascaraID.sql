  /* --------------------------------------------------------
  || fp_cpf_cnpj_masc - funcao para retornar CPF/CNPJ
  */ --------------------------------------------------------
  --
  FUNCTION fp_cpf_cnpj_masc(p_cod_docum  a2000030.cod_docum%TYPE)
  RETURN VARCHAR2 IS
  --
  l_cod_docum a2000030.cod_docum%TYPE;
  --
  BEGIN
     --
     trn_k_ptd.p_gen_comienzo_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr',
                                    p_nom_metodo => 'fp_cpf_cnpj_masc'        );
     --
     IF LENGTH(p_cod_docum) <= g_k_tamanho_cpf THEN
       l_cod_docum := regexp_replace(LPAD(p_cod_docum,g_k_tamanho_cpf,'0'),'([0-9]{3})([0-9]{3})([0-9]{3})([0-9]{2})','\1.\2.\3-\4');
     ELSIF LENGTH(p_cod_docum) <= g_k_tamanho_cnpj THEN  -- 1.2
       l_cod_docum := regexp_replace(LPAD(p_cod_docum, g_k_tamanho_cnpj),'([0-9]{2})([0-9]{3})([0-9]{3})([0-9]{4})','\1.\2.\3/\4-'); -- 1.2
     ELSE
       l_cod_docum := p_cod_docum;
     END IF;
     --
     RETURN l_cod_docum;
     --
     trn_k_ptd.p_gen_final_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr' ,
                                 p_nom_metodo => 'fp_cpf_cnpj_masc'         );
  --
  END fp_cpf_cnpj_masc;
  --