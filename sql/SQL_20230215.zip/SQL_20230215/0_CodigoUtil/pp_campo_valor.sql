  /* --------------------------------------------------------
  || pp_campo_valor
  */ --------------------------------------------------------
  --
  PROCEDURE pp_campo_valor(
    p_valor           IN NUMERIC,
    p_tamanho         IN NUMERIC DEFAULT 10
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_set_character_alinement(TRUE);
    dc_k_format_output.p_add_fld(p_valor, p_tamanho, 2, '0' );
    --
  END pp_campo_valor;
  --