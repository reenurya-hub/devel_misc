  /* -----------------------------------------------------------
  || Aqui comienza la declaracion de cursores GLOBALES
  */ -----------------------------------------------------------
  --
  CURSOR c_a2000030 IS
  SELECT a.*
    FROM a2000030 a
   WHERE a.cod_cia          = g_cod_cia
     AND a.cod_sector       = g_cod_sector
     AND a.cod_ramo         = g_cod_ramo
     AND a.mca_provisional  = g_mca_provisional
     AND a.num_spto         = trn.CERO
     AND a.cod_canal3       = g_k_cuatro
     AND a.mca_impresion    = trn.NO
     AND a.fec_emision_spto BETWEEN g_fec_emision_spto - g_k_cant_dias AND g_fec_emision_spto;