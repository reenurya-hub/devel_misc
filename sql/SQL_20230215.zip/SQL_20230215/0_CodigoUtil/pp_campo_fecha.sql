  /* --------------------------------------------------------
  || pp_campo_fecha
  */ --------------------------------------------------------
  --
  PROCEDURE pp_campo_fecha(
    p_valor         IN DATE
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_add_fld(p_valor, 8, 'YYYYMMDD', NULL );
    --
  END pp_campo_fecha;
  --