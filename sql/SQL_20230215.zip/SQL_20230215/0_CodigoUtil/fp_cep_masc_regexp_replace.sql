  /* --------------------------------------------------------
  || fp_cep_masc - funcao para retornar CEP
  */ --------------------------------------------------------
  --
  FUNCTION fp_cep_masc(p_cod_postal  a1001331.cod_postal%TYPE)
  RETURN VARCHAR2 IS
  --
  l_cod_postal a1001331.cod_postal%TYPE;
  --
  BEGIN
  --
  trn_k_ptd.p_gen_comienzo_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr',
                                 p_nom_metodo => 'fp_cep_masc'             );
  --
  IF LENGTH(p_cod_postal) = g_k_tamanho_cep THEN
    l_cod_postal := regexp_replace(p_cod_postal, '([[:digit:]]{5})([[:digit:]]{3})', '\1-\2');
  ELSE
    l_cod_postal := p_cod_postal;
  END IF;
  --
  RETURN l_cod_postal;
  --
  trn_k_ptd.p_gen_final_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr' ,
                              p_nom_metodo => 'fp_cep_masc'              );
  --
  END fp_cep_masc;
  --