   /* --------------------------------------------------------
   || fp_devuelve_f:
   ||
   || Llama a trn_k_global.devuelve y retorna como DATE
   */ --------------------------------------------------------
   --
   FUNCTION fp_devuelve_f(p_nom_global VARCHAR2)
      --
      RETURN DATE IS
      --
   BEGIN
      --
      RETURN TO_DATE(trn_k_global.devuelve(p_nom_global),trn_k_g0000000.f_formato_fecha_sin_separador);
      --
   END fp_devuelve_f;
   --