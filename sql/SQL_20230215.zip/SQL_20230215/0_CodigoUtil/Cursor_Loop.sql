DECLARE
   /* -----------------------------------------------------------
   || Aqui comienza la declaracion de cursores GLOBALES
   */ -----------------------------------------------------------
   --
   CURSOR c_060_031(pc_cod_cia       a2000060.cod_cia%TYPE      ,
                    pc_cod_ramo      a2000030.cod_ramo%TYPE     ,
                    pc_tip_docum     a2000060.tip_docum%TYPE    ,
                    pc_cod_docum     a2000060.cod_docum%TYPE    ,
                    pc_num_apli      a2000060.num_apli%TYPE     ,
                    pc_num_spto_apli a2000060.num_spto_apli%TYPE) IS
   SELECT a.*
     FROM a2000060 a , a2000031 b, a2000030 c
    WHERE a.cod_cia         = pc_cod_cia
      AND a.tip_docum       = pc_tip_docum
      AND a.cod_docum       = pc_cod_docum
      AND a.num_apli        = pc_num_apli
      AND a.num_spto_apli   = pc_num_spto_apli
      AND a.tip_benef       = em.TIP_BENEF_ASEGURADO
      AND a.mca_principal   = trn.no
      AND a.MCA_CALCULO     = trn.no
      AND a.MCA_BAJA        = trn.no
      AND a.MCA_VIGENTE     = trn.si
      AND a.cod_cia         = b.cod_cia
      AND a.num_poliza      = b.num_poliza
      AND a.num_spto        = b.num_spto
      AND a.num_apli        = b.num_apli
      AND a.num_spto_apli   = b.num_spto_apli
      AND a.num_riesgo      = b.num_riesgo
      AND b.mca_baja_riesgo = trn.no
      AND b.mca_vigente     = trn.si
      AND a.cod_cia         = c.cod_cia
      AND a.num_poliza      = c.num_poliza
      AND a.num_apli        = c.num_apli
      AND a.num_spto_apli   = c.num_spto_apli
      AND c.cod_ramo        = pc_cod_ramo;
   --
BEGIN
   FOR reg_60 IN  c_060_031(pc_cod_cia       => l_cod_cia,
                            pc_cod_ramo      => l_cod_ramo,
                            pc_tip_docum     => l_tb_docum_benef(l_ind_carga).tip_docum,
                            pc_cod_docum     => l_tb_docum_benef(l_ind_carga).cod_docum,
                            pc_num_apli      => l_num_apli,
                            pc_num_spto_apli => l_num_spto_apli)
   LOOP
      --
      BEGIN
         --
         OPEN ev_k_901_utils.gc_a2000031(l_cod_cia            ,
                                         reg_60.num_poliza    ,
                                         reg_60.num_spto      ,
                                         reg_60.num_apli      ,
                                         reg_60.num_spto_apli ,
                                         reg_60.num_riesgo    );
         --
         FETCH ev_k_901_utils.gc_a2000031 INTO l_cod_modalidad;
         --
         CLOSE ev_k_901_utils.gc_a2000031;
         --
         BEGIN
            --
            l_reg_cobertura := em_k_ptd_cvr.f_con_vigente(l_cod_cia                      ,
                                                          l_cod_ramo,--reg_60.cod_ramo                ,
                                                          reg_60.num_poliza              ,
                                                          reg_60.num_apli                ,
                                                          reg_60.num_riesgo              ,
                                                          l_cod_modalidad                ,
                                                          trn.UNO                        ,
                                                          l_tb_record_cob(l_fila).cod_cob);
            --
            l_suma_aseg := l_reg_cobertura.suma_aseg;
            --
         EXCEPTION
            WHEN OTHERS
            THEN
               --
               l_suma_aseg := g_k_cero;
               --
         END;
         --
         total := total + l_suma_aseg;
         --
      EXCEPTION
         WHEN no_data_found 
		 THEN
            --
            total := trn.CERO;
            --
         WHEN OTHERS THEN
            --
            total := trn.CERO;
            --
      END;
   --
   END LOOP;
   --
END;