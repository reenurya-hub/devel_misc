     /* -----------------------------------------------------
     || fp_ref_global_n :
     ||
     || Llama al procedimiento trn_k_global.ref_f_global,
     || convirtiendo el valor a numerico y retorna el valor,
     || si no existe el dato, retorna nulo
     */ -----------------------------------------------------
     --
     FUNCTION fp_ref_global_n (p_nom_global IN            VARCHAR2)
        RETURN NUMBER
     IS
        --
        l_val_global NUMBER;
        --
     BEGIN
        --
        l_val_global := TO_NUMBER(trn_k_global.ref_f_global (p_variable => p_nom_global));
        --
        --@mx('----','l_val_global = ' || l_val_global);
        --
        RETURN l_val_global;
        --
     END fp_ref_global_n;
    --