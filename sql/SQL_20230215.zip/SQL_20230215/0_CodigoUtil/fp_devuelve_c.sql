   /* --------------------------------------------------------
   || fp_devuelve_c:
   ||
   || Llama a trn_k_global.devuelve y retorna como VARCHAR2
   */ --------------------------------------------------------
   --
   FUNCTION fp_devuelve_c(p_nom_global VARCHAR2)
      --
      RETURN VARCHAR2 IS
      --
   BEGIN
      --
      RETURN trn_k_global.devuelve(p_nom_global);
      --
   END fp_devuelve_c;
   --