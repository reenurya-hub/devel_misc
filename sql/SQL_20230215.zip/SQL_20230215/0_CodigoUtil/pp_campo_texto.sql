  /* --------------------------------------------------------
  || pp_campo_texto
  */ --------------------------------------------------------
  --
  PROCEDURE pp_campo_texto(
    p_valor         IN CHARACTER,
    p_tamanho       IN NUMERIC
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_set_character_alinement(FALSE);
    dc_k_format_output.p_add_fld(p_valor, p_tamanho, trn.blanco);
    --
  END pp_campo_texto;
  --