   --
   /* --------------------------------------------------------
   || pp_devuelve_error :
   || Devuelve un error al llamador
   */ --------------------------------------------------------
   --
   PROCEDURE pp_devuelve_error
   IS
      --
   BEGIN
      --
      --@mx('I','pp_devuelve_error');
      --
      IF g_cod_mensaje BETWEEN g_k_20000
                           AND g_k_20999
      THEN
         --
         RAISE_APPLICATION_ERROR (-g_cod_mensaje                                                 ,
                                  ss_k_mensaje.f_texto_idioma (p_cod_mensaje => g_cod_mensaje    ,
                                                               p_cod_idioma  => g_cod_idioma )  ||
                                  g_anx_mensaje                                                  );
         --
      ELSE
         --
         RAISE_APPLICATION_ERROR (-g_k_20000                                                     ,
                                  ss_k_mensaje.f_texto_idioma (p_cod_mensaje => g_cod_mensaje    ,
                                                               p_cod_idioma  => g_cod_idioma )  ||
                                  g_anx_mensaje                                                  );
         --
      END IF;
      --
      --@mx('F','pp_devuelve_error');
      --
   END pp_devuelve_error;
   --