     /* ----------------------------------
     ||  pp_cargar_globales      :
     */ ----------------------------------
     --
     PROCEDURE pp_cargar_globales(p_cod_cia               IN a2000030.cod_cia                  %TYPE,
                                  p_cod_ramo              IN a2000030.cod_ramo                 %TYPE,
                                  p_num_cotizacion        IN a2000030.num_poliza               %TYPE,
                                  p_num_poliza            IN a2000030.num_poliza               %TYPE,
                                  p_tip_mvto_batch        IN a2992130_vcr.tip_mvto_batch       %TYPE,
                                  p_num_spto              IN a2992130_vcr.num_spto             %TYPE,
                                  p_num_apli              IN a2992130_vcr.num_apli             %TYPE,
                                  p_num_spto_apli         IN a2992130_vcr.num_spto_apli        %TYPE)
     IS
     BEGIN
        --
        --@mx('I', 'pp_cargar_globales');
        --
        trn_k_global.asigna('COD_CIA'       ,p_cod_cia       );
        trn_k_global.asigna('COD_RAMO'      ,p_cod_ramo      );
        trn_k_global.asigna('NUM_COTIZACION',p_num_cotizacion);
        trn_k_global.asigna('num_propuesta' ,p_num_poliza    );
        trn_k_global.asigna('NUM_POLIZA'    ,p_num_poliza    );
        trn_k_global.asigna('TIP_MVTO_BATCH',p_tip_mvto_batch);
        trn_k_global.asigna('NUM_SPTO'      ,p_num_spto      );
        trn_k_global.asigna('NUM_APLI'      ,p_num_apli      );
        trn_k_global.asigna('NUM_SPTO_APLI' ,p_num_spto_apli );
        trn_k_global.asigna('COD_IDIOMA'    ,g_cod_idioma    );
        --
        --@mx('F', 'pp_cargar_globales');
        --
     END pp_cargar_globales;
     --