  /* --------------------------------------------------------
  || fp_num_masc : formata el numero
  */ --------------------------------------------------------
  --
  FUNCTION fp_num_masc (p_val_num  NUMBER)
  RETURN VARCHAR2 IS
  --
  l_retorno VARCHAR2(255);
  --
  BEGIN
     --
     trn_k_ptd.p_gen_comienzo_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr',
                                    p_nom_metodo => 'fp_num_masc'             );
     --
      l_retorno := REGEXP_REPLACE(TO_CHAR(p_val_num,'09999990D99','NLS_NUMERIC_CHARACTERS = '',.'''),'\D','');
     --
     RETURN l_retorno;
     --
     trn_k_ptd.p_gen_final_traza(p_nom_prg    => 'ev_k_985_welcome_kit_vcr' ,
                                 p_nom_metodo => 'fp_num_masc'              );
     --
  END fp_num_masc;
  --