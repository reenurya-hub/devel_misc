CREATE OR REPLACE PACKAGE BODY TRON2000.dc_k_format_output_vcr IS
  --
  /* -------------------- VERSION = 3.52 -------------------- */
  --
  -- Author  : MARCIO OLIVEIRA
  -- Created : 21/03/2002 13:41:29
  -- Purpose : Formatacao de Dados p/ Output em PL
  --
  -- ========================================================
  -- TODAS AS PROPRIEDADES SAO ***PRIVATE***
  -- TODAS SAO MANIPULADAS ATRAVES DOS METODOS PUBLIC
  -- ***PRIVATE***
  TYPE rtable_of_values IS RECORD(
    variable_name  VARCHAR2(035),
    variable_value VARCHAR2(150));
  TYPE tr_table_of_values IS TABLE OF rtable_of_values INDEX BY BINARY_INTEGER;
  --
  g_table_of_values tr_table_of_values;
  -------------------------------------------------------------------------------------------------
  g_comando VARCHAR2(200);
  --
  g_k_message_type constant VARCHAR2(20) := 'FILE';
  g_pathfile        VARCHAR2(200) := null;
  g_filename        VARCHAR2(200) := 'tron2000_gp.log';
  g_oraversion      VARCHAR2(02);
  l_record_size_now NUMERIC(04) := 0; -- Guarda tamanho atual do registro (somat)
  l_record          VARCHAR2(4097) := NULL; --
  l_record_size     NUMERIC(04) := NULL; -- Tamanho total informado do registro
  l_record_fields   NUMERIC(04) := 0; -- Qtd atual de cpos do registro (somat)
  --
  l_field_separator CHARACTER := NULL;
  --
  l_default_date_mask            VARCHAR2(08) := 'DDMMYYYY'; -- Formato de mascara p/ data se nenhuma outra for especificada
  l_default_decimal_point        BOOLEAN := FALSE; -- Nao gera (FALSE) "virgula" qdo numerico decimal (default)
  l_default_decimal_simbol       CHARACTER(01) := '.'; -- Define simbolo decimal default;
  l_decimal_size                 NUMERIC := 0; -- Cpo decimal nao mostra parte fracionaria (default)
  l_default_record_filling       CHARACTER := ' '; -- Preenchimento default de registro
  l_default_field_char_filling   CHARACTER := ' '; -- Preenchimento default de campo 'tipo' character
  l_default_field_date_filling   CHARACTER := ' '; -- Preenchimento default de campo 'tipo' date
  l_default_field_numer_filling  CHARACTER := '0'; -- Preenchimento default de campo 'tipo' numeric
  l_default_numeric_negative_use BOOLEAN := TRUE; -- Cpos numerico qdo negativo tera sinal (TRUE/FALSE)
  l_default_numeric_positive_use BOOLEAN := FALSE; -- Cpos numerico qdo positivo tera sinal (TRUE/FALSE)
  l_ebcdic_format                BOOLEAN := FALSE; -- Utiliza formato EBCDIC p/ numerico negativo (TRUE/FALSE)
  --
  l_default_character_alinement BOOLEAN := FALSE; -- Alinhamento default para caracter (Left)
  l_default_numeric_alinement   BOOLEAN := TRUE; -- Alinhamento default para numerico (Rigth)
  l_default_date_alinement      BOOLEAN := FALSE; -- Alinhamento default para data     (Left)
  k_record_size constant NUMERIC(04) := 4096; -- Tamanho maximo permitido p/ registro
  -- (So altere o valor/tamanho de "k_record_size" e "l_record" se vce souber muito bem o q esta fazendo !!!!)
  -- ***PRIVATE***
  --
  -- ========================================================
  -- Recoloca todas as variaveis na situacao inicial (default)
  -- PUBLIC
  -- ========================================================
  PROCEDURE p_set_default_environment is
  BEGIN
    --
    g_pathfile                     := null;
    g_filename                     := 'tron2000_gp.log';
    l_record_size_now              := 0;
    l_record                       := NULL;
    l_record_size                  := NULL;
    l_record_fields                := 0;
    l_field_separator              := NULL;
    l_default_date_mask            := 'DDMMYYYY';
    l_default_decimal_point        := FALSE;
    l_default_decimal_simbol       := '.';
    l_decimal_size                 := 0;
    l_default_record_filling       := ' ';
    l_default_field_char_filling   := ' ';
    l_default_field_date_filling   := ' ';
    l_default_field_numer_filling  := '0';
    l_default_numeric_negative_use := TRUE;
    l_default_numeric_positive_use := FALSE;
    l_ebcdic_format                := FALSE;
    l_default_character_alinement  := FALSE;
    l_default_numeric_alinement    := TRUE;
    l_default_date_alinement       := FALSE;
    --
  END p_set_default_environment;
  -- ========================================================
  -- Retorna Qtd de Campos que ja foram empilhados (PUBLIC)
  -- ========================================================
  FUNCTION f_get_fields RETURN NUMERIC IS
  BEGIN
    RETURN l_record_fields;
  END f_get_fields;
  -- ========================================================
  -- Retorna o Tamanho do Registro (PUBLIC)
  -- ========================================================
  FUNCTION f_get_record_length_now RETURN NUMERIC IS
  BEGIN
    RETURN l_record_size_now;
  END f_get_record_length_now;
  -- ========================================================
  -- Retorna o registro (o que foi adicionado desde o ultimo start) (PUBLIC)
  -- ========================================================
  FUNCTION f_get_record RETURN CHARACTER IS
  BEGIN
    -- trn_p_traza(p_file => 'p_add.log',p_modo => 'a' ,p_buffer =>  l_record_size_now || ' ==> ' || l_record);
    -- trn_p_traza(p_file => 'p_add.log',p_modo => 'a' ,p_buffer =>  RPAD(SUBSTR(l_record, 2, k_record_size), l_record_size, l_default_record_filling));
    RETURN RPAD(SUBSTR(l_record, 2, k_record_size), l_record_size, l_default_record_filling);
  END f_get_record;
  -- ========================================================
  -- Inicializa o registro (limpa) (PUBLIC)
  -- ========================================================
  PROCEDURE p_start IS
  BEGIN
    l_record          := '@';
    l_record_fields   := 0;
    l_record_size_now := 0;
  END p_start;
  -- ========================================================
  -- Inicializa registro (define tamanho do reg e limpa)
  -- Nao e possivel dar *ADD* ou *START* enquanto nao houver
  -- *INITIALIZE* (PUBLIC)
  -- ========================================================
  FUNCTION f_initialize(p_total_length IN NUMERIC) RETURN BOOLEAN IS
  BEGIN
    IF l_record_size IS NOT NULL THEN
      raise_application_error(-20001, 'Registro ja inicializado');
    END IF;
    --
    IF p_total_length > k_record_size THEN
      raise_application_error(-20001, 'Tamanho Excede maximo permitido');
    END IF;
    l_record_size := p_total_length;
    p_start;
    p_set_field_separator(NULL);
    RETURN TRUE;
  END f_initialize;
  -- ========================================================
  -- Coloca registro em estado de nao inicializado.
  -- Apos *FINALIZE* nao e possivel fazer *START* ou *ADD*
  -- apenas *INITIALIZE* (PUBLIC)
  -- ========================================================
  PROCEDURE p_finalize IS
  BEGIN
    l_record          := NULL;
    l_record_fields   := 0;
    l_record_size_now := 0;
    l_record_size     := NULL;
  END p_finalize;
  -- ========================================================
  -- Utiliza formato EBCDIC p/ numerico negativo (TRUE/FALSE)
  -- ========================================================
  PROCEDURE p_set_ebcdic_format(p_ebcdic_format BOOLEAN) IS
  BEGIN
    l_ebcdic_format := p_ebcdic_format;
    --
    if p_ebcdic_format = TRUE then
      if l_default_decimal_point = TRUE then
        raise_application_error(-20001, 'Nao pode haver EBCDIC com ponto decimal');
      end if;
    end if;
  END p_set_ebcdic_format;
  -- ========================================================
  PROCEDURE p_add_fld_generic(p_valor   IN CHARACTER,
                              p_tamanho IN NUMERIC) IS
  BEGIN
    IF l_record_size IS NULL THEN
      raise_application_error(-20001, 'Registro ainda nao inicializado');
    END IF;
    --
    l_record_size_now := l_record_size_now + p_tamanho;
    l_record_fields   := l_record_fields + 1;
    IF l_record_size_now > l_record_size THEN
      raise_application_error(-20001, 'Tamanho maximo definido do registro excedido.');
    END IF;
    --
    l_record := l_record || LPAD(p_valor, p_tamanho);
    --
    IF l_field_separator IS NOT NULL THEN
      -- Se inicializado coloca caracter de separacao no registro....
      l_record_size_now := l_record_size_now + 1; -- Tamanho deve ser previsto
      IF l_record_size_now > l_record_size THEN
        raise_application_error(-20001, 'Tamanho maximo definido do registro excedido.');
      END IF;
      l_record := l_record || l_field_separator;
    END IF;
    -- trn_p_traza(p_file => 'p_add.log',p_modo => 'a' ,p_buffer =>  l_record_size_now || ' ==> ' || l_record);
    --
  END p_add_fld_generic;
  -- ========================================================
  -- Adiciona campo ao registro ja inicializado (CHARACTER) (PUBLIC)
  -- ========================================================
  --
  PROCEDURE p_add_fld(p_valor         IN CHARACTER,
                      p_tamanho       IN NUMERIC,
                      p_preenchimento IN CHARACTER DEFAULT NULL) IS
    l_valor         VARCHAR2(4096);
    l_preenchimento CHARACTER(01);
  BEGIN
    IF p_tamanho > k_record_size THEN
      raise_application_error(-20001, 'Campo muito grande');
    END IF;
    --
    IF p_tamanho IS NULL THEN
      raise_application_error(-20001, 'Tamanho deve ser informado');
    END IF;
    --
    l_preenchimento := LPAD(NVL(p_preenchimento, l_default_field_char_filling), 1);
    --
    IF l_default_character_alinement = FALSE THEN
      l_valor := RPAD(NVL(p_valor, l_preenchimento), p_tamanho, l_preenchimento);
    END IF;
    IF l_default_character_alinement = TRUE THEN
      l_valor := LPAD(NVL(p_valor, l_preenchimento), p_tamanho, l_preenchimento);
    END IF;
    --
    p_add_fld_generic(l_valor, p_tamanho);
  END p_add_fld;
  -- ========================================================
  -- PRIVATE FUNCTION
  -- traduz caracteres segundo tabela abaixo
  -- Originalmente criada para dar suporte a "SET_EBCDIC_FORMAT"
  -- p_sign (TRUE p/ POSITIVOS e FALSE p/ NEGATIVOS)
  -- ========================================================
  FUNCTION f_char_translate(p_character IN CHARACTER,
                            p_sign      IN BOOLEAN) RETURN CHARACTER IS
    l_character CHARACTER(01);
  BEGIN
    l_character := p_character;
    IF l_character NOT BETWEEN 0 AND 9 THEN
      raise_application_error(-20001, 'valor fora do dominio');
    END IF;
    --
    IF p_sign THEN
      RETURN TRANSLATE(l_character, '0123456789', '{ABCDEFGHI'); -- POSITIVO
    ELSE
      RETURN TRANSLATE(l_character, '0123456789', '}JKLMNOPQR'); -- NEGATIVO
    END IF;
  END f_char_translate;
  -- ========================================================
  -- Adiciona campo ao registro ja inicializado (NUMERIC) (PUBLIC)
  -- ========================================================
  PROCEDURE p_add_fld(p_valor           IN NUMERIC,
                      p_tamanho         IN NUMERIC,
                      p_tamanho_decimal IN NUMERIC DEFAULT NULL,
                      p_preenchimento   IN CHARACTER DEFAULT NULL) IS
    l_decimal_point     BOOLEAN;
    l_tamanho_decimal   NUMERIC(04);
    l_tamanho           NUMERIC(04);
    l_tamanho_inteiro   NUMERIC(04);
    l_valor             VARCHAR2(4096);
    l_valor_inteiro     VARCHAR2(4096);
    l_valor_decimal     VARCHAR2(4096);
    l_valor_work        VARCHAR2(4096);
    l_ultimo_caractere  CHARACTER(01);
    l_preenchimento     CHARACTER(01);
    l_is_valor_negativo BOOLEAN;
    l_is_valor_positivo BOOLEAN;
    l_sinal_decimal     VARCHAR2(01);
    l_is_sinal_decimal  BOOLEAN;
    l_posicao           NUMERIC(04);
  BEGIN
    -- Tamanho nao pode ser maior que o registro
    IF p_tamanho > k_record_size THEN
      raise_application_error(-20001, 'Campo muito grande');
    END IF;
    -- Tamanho decimal deve fazer parte do tamanho total ..... Como no oracle
    IF p_tamanho_decimal >= NVL(p_tamanho, 0) THEN
      raise_application_error(-20001, 'Campo decimal muito grande');
    END IF;
    -- Tamanho nao pode ser NULL
    IF p_tamanho IS NULL THEN
      raise_application_error(-20001, 'Tamanho deve ser informado');
    END IF;
    -- Se valor de entrada tiver virgulas ',' substitui por ponto '.' (ou default definido ....)
    l_sinal_decimal := l_default_decimal_simbol;
    l_valor         := REPLACE(p_valor, ',', l_sinal_decimal);
    --
    l_decimal_point   := l_default_decimal_point;
    l_tamanho_decimal := NVL(p_tamanho_decimal, 0);
    l_tamanho         := p_tamanho;
    l_tamanho_inteiro := l_tamanho - l_tamanho_decimal; -- Calcula tamanho da parte inteira
    l_preenchimento   := LPAD(NVL(p_preenchimento, l_default_field_numer_filling), 1);
    --    Marca se ha parte decimal no valor recebido
    IF INSTR(l_valor, '.') > 0 THEN
      l_is_sinal_decimal := TRUE;
    ELSE
      l_is_sinal_decimal := FALSE;
    END IF;
    --    tira o sinal se valor negativo e seta flags
    IF TO_NUMBER(l_valor) < 0 THEN
      l_valor             := l_valor * -1;
      l_is_valor_negativo := TRUE;
      l_is_valor_positivo := FALSE;
    ELSE
      l_is_valor_negativo := FALSE;
      l_is_valor_positivo := TRUE;
    END IF;
    --
    --
    IF NOT l_default_numeric_negative_use AND NOT l_ebcdic_format THEN
      l_is_valor_negativo := FALSE; -- tirou sinal do numero mas age como se fosse positivo
    END IF;
    --    Separa valor em parte inteira e parte fracionaria
    l_valor_inteiro := TRUNC(l_valor, 0);
    --
    IF l_is_sinal_decimal THEN
      l_valor_decimal := SUBSTR(l_valor, INSTR(l_valor, l_sinal_decimal) + 1);
      l_valor_decimal := RPAD(l_valor_decimal, l_tamanho_decimal, 0); -- Formata de acordo com tamanho
    ELSE
      l_valor_decimal := 0;
      l_valor_decimal := RPAD(l_valor_decimal, l_tamanho_decimal, 0);
    END IF;
    --
    --    Define posicao do corte a esquerda se colocando um cpo em um menor
    l_posicao := (LENGTH(l_valor_inteiro) - l_tamanho_inteiro) + 1;
    --    Posicao de corte nao pode ser zero(0) nem menor que zero
    IF l_posicao < 1 THEN
      l_posicao := 1;
    END IF;
    --    junta parte inteira com parte decimal
    l_valor := SUBSTR(l_valor_inteiro, l_posicao, l_tamanho_inteiro) || l_sinal_decimal || l_valor_decimal;
    --
    --    Tira a virgula/ponto se necessario (depende do l_default_decimal_point)
    --
    IF l_tamanho_decimal <= 0 THEN
      -- Nao ha pto decimal se casas decimais for zero
      l_decimal_point := FALSE;
    END IF;
    --
    IF NOT l_decimal_point THEN
      l_valor := REPLACE(l_valor, l_sinal_decimal, '');
    END IF;
    --
    --    Se valor numerico negativo e nao EBCDIC, entao diminui o tamanho p/ acomodar o sinal
    --    na primeira posicao ... Usuario deve se preocupar com tamanho necessario
    --    No caso de valores positivos com sinal, so havera sinal se l_default_numeric_positive_use = TRUE
    IF (l_is_valor_negativo OR (l_is_valor_positivo AND l_default_numeric_positive_use)) AND NOT l_ebcdic_format THEN
      l_tamanho := l_tamanho - 1;
    END IF;
    --
    --    Acerta alinhamento do valor em funcao do alinhamento solicitado/default.
    IF l_default_numeric_alinement = FALSE THEN
      l_valor := RPAD(NVL(l_valor, l_preenchimento), l_tamanho, l_preenchimento);
    END IF;
    IF l_default_numeric_alinement = TRUE THEN
      l_valor := LPAD(NVL(l_valor, l_preenchimento), l_tamanho, l_preenchimento);
    END IF;
    --
    IF l_is_valor_negativo AND NOT l_ebcdic_format THEN
      l_valor   := '-' || l_valor;
      l_tamanho := l_tamanho + 1;
    END IF;
    --
    IF l_is_valor_positivo AND l_default_numeric_positive_use AND  NOT l_ebcdic_format THEN
      l_valor   := '+' || l_valor;
      l_tamanho := l_tamanho + 1;
    END IF;
    --
    IF l_ebcdic_format THEN
      l_ultimo_caractere := SUBSTR(l_valor, LENGTH(l_valor), 1);
      l_valor_work       := SUBSTR(l_valor, 1, LENGTH(l_valor) - 1);
      IF l_is_valor_negativo THEN
        l_valor := l_valor_work || f_char_translate(l_ultimo_caractere, FALSE);
      ELSE
        l_valor := l_valor_work || f_char_translate(l_ultimo_caractere, TRUE);
      END IF;
    END IF;
    --
    p_add_fld_generic(l_valor, l_tamanho);
  END p_add_fld;
  -- ========================================================
  -- Adiciona campo ao registro ja inicializado (DATE) (PUBLIC)
  -- ========================================================
  PROCEDURE p_add_fld(p_valor         IN DATE,
                      p_tamanho       IN NUMERIC,
                      p_mascara       IN VARCHAR2 DEFAULT NULL,
                      p_preenchimento IN CHARACTER DEFAULT NULL) IS
    l_valor         VARCHAR2(4096);
    l_preenchimento CHARACTER(01);
    l_mask          VARCHAR2(30);
  BEGIN
    IF p_tamanho > k_record_size THEN
      raise_application_error(-20001, 'Campo muito grande');
    END IF;
    --
    IF p_tamanho IS NULL THEN
      raise_application_error(-20001, 'Tamanho deve ser informado');
    END IF;
    --
    IF p_mascara IS NOT NULL THEN
      l_mask := p_mascara;
    ELSE
      l_mask := l_default_date_mask;
    END IF;
    --
    l_preenchimento := LPAD(NVL(p_preenchimento, l_default_field_date_filling), 1);
    --
    IF l_default_date_alinement = FALSE THEN
      l_valor := RPAD(TO_CHAR(p_valor, l_mask), p_tamanho, l_preenchimento);
    END IF;
    IF l_default_date_alinement = TRUE THEN
      l_valor := LPAD(TO_CHAR(p_valor, l_mask), p_tamanho, l_preenchimento);
    END IF;
    IF l_valor IS NULL THEN
      l_valor := LPAD(NVL(l_valor, l_preenchimento), p_tamanho, l_preenchimento);
    END IF;
    --
    p_add_fld_generic(l_valor, p_tamanho);
  END p_add_fld;
  -- ========================================================
  -- Altera alinhamento de campo tipo CHAR (PUBLIC)
  -- ========================================================
  PROCEDURE p_set_character_alinement(p_alinement IN BOOLEAN) IS
  BEGIN
    l_default_character_alinement := p_alinement;
  END p_set_character_alinement;
  -- ========================================================
  -- Altera alinhamento de campo tipo NUMERIC (PUBLIC)
  -- ========================================================
  PROCEDURE p_set_numeric_alinement(p_alinement IN BOOLEAN) IS
  BEGIN
    l_default_numeric_alinement := p_alinement;
  END p_set_numeric_alinement;
  -- ========================================================
  -- Altera alinhamento de campo tipo DATE (PUBLIC)
  -- ========================================================
  PROCEDURE p_set_date_alinement(p_alinement IN BOOLEAN) IS
  BEGIN
    l_default_date_alinement := p_alinement;
  END p_set_date_alinement;
  -- ========================================================
  -- Define se campo na saida tera ou nao ponto decimal (por default nao tem) (PUBLIC)
  -- ========================================================
  PROCEDURE p_set_decimalpoint_output(p_falsetrue IN BOOLEAN) IS
  BEGIN
    l_default_decimal_point := p_falsetrue;
    --
    if p_falsetrue = TRUE then
      if l_ebcdic_format = TRUE then
        raise_application_error(-20001, 'Nao pode haver ponto decimal com EBCDIC ');
      end if;
    end if;
  END p_set_decimalpoint_output;
  -- ========================================================
  -- Seta Caractere de separacao entre os cpos do registro.
  -- por default e null (e nao coloca nada)
  -- ========================================================
  PROCEDURE p_set_field_separator(p_field_separator IN CHARACTER) IS
  BEGIN
    l_field_separator := p_field_separator;
  END p_set_field_separator;
  -- ========================================================
  -- Seta se havera sinal negativo ou nao nos numericos
  -- (APENAS NEGATIVOS)
  -- ========================================================
  PROCEDURE p_set_numeric_sign(p_use_sign IN BOOLEAN) IS
  BEGIN
    l_default_numeric_negative_use := p_use_sign;
  END p_set_numeric_sign;
  -- ========================================================
  -- Seta se havera sinal positivo ou nao nos numericos
  -- so funcionara se houver (l_default_numeric_negative_use=TRUE)
  -- ou seja se os numericos aceitarem sinal
  -- ========================================================
  PROCEDURE p_set_positive_sign_use(p_use_positive_sign IN BOOLEAN) IS
  BEGIN
    if l_default_numeric_negative_use = false AND  p_use_positive_sign = TRUE then
      raise_application_error(-20001, 'Numericos com sinal positivo DEVEM ter #p_set_numeric_sign(TRUE)#');
    end if;
    l_default_numeric_positive_use := p_use_positive_sign;
  END p_set_positive_sign_use;
  -- ========================================================
  -- ========================================================
  -- ========================================================
  -- ========================================================
  --------------------------------------------------------------------------------------------------
  -- ========================================================
  -- F_GET_ORACLE_VERSION - Pega a versao do oracle
  -- REtorna um VARCHAR.
  -- ========================================================
  FUNCTION F_GET_ORACLE_VERSION RETURN VARCHAR2 is
    l_r_version        v$version%ROWTYPE;
    l_initial_position number(02) := 0;
    l_version          varchar2(5);
    l_k_string      constant varchar2(6) := 'ORACLE';
    l_k_string_size constant number(02) := 6;
    --
    cursor c_version is
      select * from v$version;
    --
  BEGIN
    --
    open c_version;
    fetch c_version
      into l_r_version;
    close c_version;
    --
    l_initial_position := instr(upper(l_r_version.banner), l_k_string, 1, 1);
    --
    if l_initial_position > 0 then
      -- VErsao pode ser algo como '7', '9' , '9i' etc
      l_version := substr(upper(l_r_version.banner), l_initial_position + l_k_string_size, 2);
    else
      -- NAO ACHOU ORACLE NA STRING (l_r_version.banner)
      l_version := 0;
    end if;
    --
    return rtrim(ltrim(upper(l_version)));
  EXCEPTION
    WHEN OTHERS THEN
      return 0;
  END F_GET_ORACLE_VERSION;
  --------------------------------------------------------------------------------------------------
  PROCEDURE P_OPEN_FILE_DINAMIC(p_pathfile  in VARCHAR2,
                                p_filename  in VARCHAR2,
                                p_open_mode in char,
                                p_size      in binary_integer) is
    l_cursor   INTEGER;
    l_comando1 VARCHAR2(700); -- VErsao 7
    l_comando2 VARCHAR2(700); -- VErsao 8 ou maior
    l_comando  VARCHAR2(700); -- O QUE VAI SER EXECUTADO INDEPENDENTE DA VERSAO;
    l_filas    INTEGER;
    --
    l_k_inicio CONSTANT VARCHAR2(06) := 'BEGIN ';
    l_k_fin    CONSTANT VARCHAR2(06) := ' END; ';
    --
    -- ===================================================================
    -- PROCEDIMENTO INTERNO
    PROCEDURE popen is
    BEGIN
      if g_oraversion = '7' then
        -- Monta comando SEM o tamanho maximo.
        l_comando1 := 'dc_k_format_output.G_FILE_TYPE := utl_file.fopen(' || chr(39) || p_pathfile || chr(39) || ',' ||
                      chr(39) || p_filename || chr(39) || ',' || chr(39) || p_open_mode || chr(39) || ')' || ';';
      else
        -- Monta comando COM o tamanho maximo.
        l_comando2 := 'dc_k_format_output.G_FILE_TYPE := utl_file.fopen(' || chr(39) || p_pathfile || chr(39) || ',' ||
                      chr(39) || p_filename || chr(39) || ',' || chr(39) || p_open_mode || chr(39) || ',' || p_size || ')' || ';';
      end if;
      --
      if g_ORAVERSION = '7' THEN
        l_comando := l_comando1;
      ELSE
        l_comando := l_comando2;
      end if;
      --
      l_comando := l_k_inicio || l_comando || l_k_fin;
      -- Faz o parse apenas se o comando for diferente.
      l_cursor := DBMS_SQL.open_cursor;
      DBMS_SQL.parse(l_cursor, l_comando, DBMS_SQL.v7);
      g_comando := l_comando;
      --
      l_filas := DBMS_SQL.EXECUTE(l_cursor);
      DBMS_SQL.close_cursor(l_cursor);
    END popen;
    -- fim do procedimento interno
    -- ===================================================================
  BEGIN
    -- ===================================================================
    -- Inicio do procedimento
    --
    popen;
  END P_OPEN_FILE_DINAMIC;
  --------------------------------------------------------------------------------------------------
  FUNCTION get_utl_file_path RETURN VARCHAR2 IS
  BEGIN
    return trn_k_global.sql_dir;
  END get_utl_file_path;
  --------------------------------------------------------------------------------------------------
  PROCEDURE set_filename(p_file_name IN VARCHAR2) is
  BEGIN
    g_filename := p_file_name;
  END set_filename;
  --------------------------------------------------------------------------------------------------
  PROCEDURE set_pathfile(p_pathfile IN VARCHAR2) is
  BEGIN
    g_pathfile := p_pathfile;
  END set_pathfile;
  --------------------------------------------------------------------------------------------------
  PROCEDURE pfile(p_linha IN VARCHAR2) AS
  BEGIN
    IF NOT UTL_FILE.is_open(G_FILE_TYPE) THEN
      BEGIN
        --g_fileout := UTL_FILE.fopen(g_pathfile, g_filename, 'A');
        --===============================================================
        -- Alterada p/ suportar diferencas entre versao do Oracle (7 e 9)
        P_OPEN_FILE_DINAMIC(g_pathfile, g_filename, 'A', k_record_size);
        --===============================================================
      EXCEPTION
        WHEN UTL_FILE.invalid_path THEN
          DBMS_OUTPUT.put_line(' UTL_FILE.fopen INVALID_PATH ');
        WHEN UTL_FILE.invalid_mode THEN
          DBMS_OUTPUT.put_line(' UTL_FILE.fopen INVALID_MODE ');
        WHEN UTL_FILE.invalid_filehandle THEN
          DBMS_OUTPUT.put_line(' UTL_FILE.fopen INVALID_FILEHANDLE ');
        WHEN UTL_FILE.invalid_operation THEN
          DBMS_OUTPUT.put_line(' UTL_FILE.fopen CRIANDO ARQUIVO - ' || g_filename);
          P_OPEN_FILE_DINAMIC(g_pathfile, g_filename, 'W', k_record_size);
        WHEN UTL_FILE.internal_error THEN
          DBMS_OUTPUT.put_line(' UTL_FILE.fopen INTERNAL_ERROR ');
      END;
    END IF;
    BEGIN
      UTL_FILE.put_line(G_FILE_TYPE, p_linha);
    EXCEPTION
      WHEN UTL_FILE.invalid_path THEN
        DBMS_OUTPUT.put_line(' UTL_FILE.put_line INVALID_PATH ');
      WHEN UTL_FILE.invalid_mode THEN
        DBMS_OUTPUT.put_line(' UTL_FILE.put_line INVALID_MODE ');
      WHEN UTL_FILE.invalid_filehandle THEN
        DBMS_OUTPUT.put_line(' UTL_FILE.put_line INVALID_FILEHANDLE ');
      WHEN UTL_FILE.invalid_operation THEN
        DBMS_OUTPUT.put_line(' UTL_FILE.put_line INVALID_OPERATION ');
      WHEN UTL_FILE.internal_error THEN
        DBMS_OUTPUT.put_line(' UTL_FILE.put_line INTERNAL_ERROR ');
    END;
    UTL_FILE.fclose(G_FILE_TYPE);
    RETURN;
  END pfile;
  --------------------------------------------------------------------------------------------------
  PROCEDURE message(p_linha IN VARCHAR2) AS
  BEGIN
    --
    IF g_filename IS NULL THEN
      DBMS_OUTPUT.put_line(' NAO HA ARQUIVO DE SAIDA DEFINIDO ');
      DBMS_OUTPUT.put_line(' Erro chamando procedure **global_procs.message** ');
      RETURN;
    END IF;
    --
    IF g_pathfile IS NULL THEN
      DBMS_OUTPUT.put_line(' NAO HA PATH DE SAIDA DEFINIDO ');
      DBMS_OUTPUT.put_line(' Erro chamando procedure **global_procs.message** ');
      RETURN;
    END IF;
    --
    IF g_k_message_type = 'FILE' THEN
      pfile(p_linha);
      RETURN;
    END IF;
    --
  END message;
  -- ==================================================
  FUNCTION get_hash(p_variable_name VARCHAR2) RETURN BINARY_INTEGER IS
    g_k_min_valor_hash CONSTANT BINARY_INTEGER := 1;
    g_k_max_valor_hash CONSTANT BINARY_INTEGER := POWER(2, 31) - 2;
  BEGIN
    --
    RETURN DBMS_UTILITY.get_hash_value(UPPER(p_variable_name), g_k_min_valor_hash, g_k_max_valor_hash);
    --
  END get_hash;
  -- ==================================================
  FUNCTION get_value(p_variable_name IN VARCHAR2) RETURN VARCHAR2 IS
    l_fila BINARY_INTEGER := 0;
  BEGIN
    l_fila := get_hash(p_variable_name);
    RETURN g_table_of_values(l_fila) .variable_value;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;
  -- ==================================================
  PROCEDURE set_value(p_variable_name  IN VARCHAR2,
                      p_variable_value IN VARCHAR2) IS
    --
    l_fila BINARY_INTEGER := 0;
  BEGIN
    l_fila := get_hash(p_variable_name);
    g_table_of_values(l_fila).variable_name := UPPER(p_variable_name);
    g_table_of_values(l_fila).variable_value := p_variable_value;
  END;
  -- ==================================================
  PROCEDURE p_campo_texto(
    p_valor         IN CHARACTER,
    p_tamanho       IN NUMERIC
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_set_character_alinement(FALSE);
    dc_k_format_output.p_add_fld(p_valor, p_tamanho, trn.blanco);      
    --
  END p_campo_texto;
  --
  -- ==================================================
  --
  PROCEDURE p_campo_numerico(
    p_valor           IN NUMERIC,
    p_tamanho         IN NUMERIC
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_set_character_alinement(TRUE);
    dc_k_format_output.p_add_fld(p_valor, p_tamanho, NULL, '0' );      
    --
  END p_campo_numerico;
  --
  -- ==================================================
  --
  PROCEDURE p_campo_valor(
    p_valor           IN NUMERIC,
    p_tamanho         IN NUMERIC DEFAULT 10
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_set_character_alinement(TRUE);
    dc_k_format_output.p_add_fld(p_valor, p_tamanho, 2, '0' );      
    --
  END p_campo_valor;
  --
  -- ==================================================
  --
  PROCEDURE p_campo_fecha(
    p_valor         IN DATE
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_add_fld(p_valor, 8, 'YYYYMMDD', NULL );      
    --
  END p_campo_fecha;
  --
BEGIN
  g_oraversion := F_GET_ORACLE_VERSION;
END dc_k_format_output_vcr;
/
