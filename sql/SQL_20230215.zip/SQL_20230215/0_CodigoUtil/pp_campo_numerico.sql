  /* --------------------------------------------------------
  || pp_campo_numerico
  */ --------------------------------------------------------
  --
  PROCEDURE pp_campo_numerico(
    p_valor           IN NUMERIC,
    p_tamanho         IN NUMERIC
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_set_character_alinement(TRUE);
    dc_k_format_output.p_add_fld(p_valor, p_tamanho, NULL, '0' );
    --
  END pp_campo_numerico;
  --