  /* --------------------------------------------------------
  || pp_campo_fecha2
  */ --------------------------------------------------------
  --
  PROCEDURE pp_campo_fecha2(
    p_valor         IN DATE
  ) IS
    --
  BEGIN
    --
    dc_k_format_output.p_add_fld(p_valor, 8, 'DDMMYYYY', NULL );
    --
  END pp_campo_fecha2;
  --