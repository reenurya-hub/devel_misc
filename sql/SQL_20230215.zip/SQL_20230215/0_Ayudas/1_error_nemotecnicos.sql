select * from g2999003_mgt where cod_cia = 2 and cod_ramo = 228 and nom_nemotecnico = 'VAL_MAXIMO_EDIF_CONT';
