-- cx bds brasil
dev= rurquijo Septiembre2021
homologacion= rurquijo Septiembre2021
corphme= tron2000 Tron##mE2020

-- PARA CONSULTAR LA POLIZA GENERADA POR LA API
select num_poliza from corpp0.a2000030 where num_presupuesto = '9851987781075';

--despues de grabar la poliza posgrabar
select * from g2990016;-- postgrabar (emitir-abandonar)

-- tablas newtron
select * from all_tables;
select * from all_tables where table_name LIKE UPPER('%DF_TRN_NWT_XX_EVN_DEF%');
select * from all_tables where table_name LIKE UPPER('%NWT%') ;

select * from all_tab_comments WHERE TABLE_NAME iN (select TABLE_NAME from all_tables where table_name LIKE UPPER('%NWT%') )

-- solo serasa en homologacion (corpp0)
select b.COD_DOCUM
from corpp0.a2009016_vcr b
where b.cod_cia = 1
and b.cod_situacao = 2
and b.desc_servico = 'SERASA_PF'
and tip_docum = 'CPF'
and fec_validez >=(SYSDATE + 15);
SELECT * FROM CORPP0.a2009016_vcr
-- TERCEROS EN SERASA en blacklist
SELECT * FROM a1009031_VCR where cod_cia =1 and COD_DOCUM IN (select COD_DOCUM from a1001331_vcr WHERE TIP_DOCUM = 'CPF')
and cod_docum in (select b.COD_DOCUM
from a2009016_vcr b
where b.cod_cia = 1
and b.cod_situacao = 2
and b.desc_servico = 'SERASA_PF'
and tip_docum = 'CPF'
and fec_validez >=(SYSDATE + 15));

SELECT * FROM corpp0.a1009031_VCR where cod_cia =1 and COD_DOCUM IN (select COD_DOCUM from corpp0.a1001331_vcr WHERE TIP_DOCUM = 'CPF')
and cod_docum in (select b.COD_DOCUM
from corpp0.a2009016_vcr b
where b.cod_cia = 1
and b.cod_situacao = 2
and b.desc_servico = 'SERASA_PF'
and tip_docum = 'CPF'
and fec_validez >=(SYSDATE + 15));

69720010568


select b.*
from a2009016_vcr b
where b.cod_cia = 1
and b.cod_situacao = 2
and b.desc_servico = 'SERASA_PF'
and tip_docum = 'CPF'
and fec_validez >=(SYSDATE + 15) order by fec_validez desc;


-- serasa
select b.*
from a2009016_vcr b
where b.cod_cia = 1
and b.cod_situacao = 2
and b.desc_servico = 'SERASA_PF'
--and cod_docum = '36066586807'
and fec_validez >=(SYSDATE + 15) order by fec_validez desc;


poliza grupo contrato 23200

-- datos varios
SERVIDOR: ubr001001-137  USUARIO: tron2000 CONTRASENA: tron2000 PUERTO: 22
poliza grupo dev: 7304020000001 tercero 10432227660;
REMOTO BRASIL    RURQUIJO  Noviembre2021*    
BD RURQUIJO IDE PL DEV    RURQUIJO  Septiembre2021  CORPD0  
APP RURQUIJO APP TW DEV    RURQUIJO  Diciembre2021*  JOSPINA  Junio2020
BD RURQUIJO IDE PL HOM    RURQUIJO  Septiembre2021  HMAPFRE  
APP RURQUIJO APP TW HOM    RURQUIJO  Septiembre2021*		
BD PARA PRUEBAS HOMOLOGACION (COPIA)		tron2000	Tron##mE2020	CORPHME	
BD PARA PRUEBAS HOMOLOGACION (USUARIO TRP)		TRP_XX_DL	TrP##MapFrE2021		

select * from g2000010 where cod_cia = 1 and cod_campo in (select cod_campo from g2000020 where cod_cia = 1 and cod_ramo = 734)
and cod_campo NOT in (select cod_campo from g2000020 where cod_cia = 1 and cod_ramo != 734);


trp_xx_dl.dc_k_ptd_thp_vcr

select * from tron2000.a1009031_vcr where cod_cia = 1 and cod_act_benef = 1 and mca_inh ='S';
/* CREAR TRAZAS 
drop table TRON2000.tmp_traz;

create table TRON2000.tmp_traz
(
  cod_traza   VARCHAR2(100),
  descripcion VARCHAR2(2000)
);

grant select, insert, update, delete on TRON2000.tmp_traz to ROL_TRON2000_APP, NWT_IL, ANALISTAS,USUARIOS,TRP_XX_DL, LMURCIA, JOSPINA;

select * from TRON2000.tmp_traz;

delete from TRON2000.tmp_traz;
commit;

BEGIN
  INSERT INTO TRON2000.tmp_traz VALUES
  ('l_reg_a1009031_vcr.mca_inh: ' || l_reg_a1009031_vcr.mca_inh);
  COMMIT;
END;
*/
ed_k_734_df
ed_k_734_dv
ed_k_734_utils
trp_xx_dl.dc_k_ptd_thp_vcr

select * from TRON2000.tmp_traz;
select * from g2000030 where cod_cia = 1 and cod_ramo = 734;
-- Terceros para p�lizas
select * from a1001399 where cod_docum = '10228777000161' and cod_cia = 1
select * from A1001331 where cod_docum = '10228777000161' and cod_cia = 1 for update;
select * from a1000802 where cod_docum = '10228777000161'
select * from a1000102
10228777000161
select cod_prov,cod_localidad from A1001331 where cod_docum = '10228777000161' and cod_cia = 1 ;

select * from A1001331 where nom_domicilio2 is not null;



select * from x2000030  where num_poliza='';
select * from x2000020  where num_poliza='';
select * from x2000060  where num_poliza='';

-- blacklist
SELECT * FROM a1009031_VCR where cod_cia =1 and COD_DOCUM IN (select COD_DOCUM from a1001331_vcr WHERE TIP_DOCUM = 'CPF');

SELECT * FROM corpp0.a1009031_VCR where cod_cia =1 and COD_DOCUM ='35912902000189';

select * from a1001331_vcr WHERE COD_DOCUM ='100901000155';
10228777000161
SELECT * FROM df_cmn_nwt_xx_cnn WHERE vrb_nam = 'COD_RAMO_734' and vrb_nam_val = 734;

-- background
SELECT * FROM xbackground;
delete from xbackground where cod_marco = '985'; -- x2000040 cod_marco del producto
COMMIT;


SELECT * FROM G2000020 WHERE COD_CIA=1 AND COD_RAMO = 734 AND COD_CAMPO NOT IN (SELECT COD_CAMPO FROM G2000010);

-- trazas
poner traza 
SELECT * FROM TRAZAS_MPR WHERE COD_TRAZA = 'REUY' ORDER BY ID_TRAZA DESC;
TRON2000.dc_k_ptd
tron2000.dc_k_g2990006_vcr_vcr;
SELECT * FROM g2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734;
SELECT * FROM tron2000.TRAZAS_MPR WHERE COD_TRAZA = 'reuy' ORDER BY ID_TRAZA DESC;
DELETE FROM TRON2000.TRAZAS_MPR WHERE COD_TRAZA = 'reuy' ;
COMMIT;
dc_p_trazas_mpr ('JGG', 'XXXXXX => ' || NULL);

-- recusas
TRP_XX_DL.ev_k_901_ct_vcr
SELECT * FROM tron2000.G2992051_VCR where lower(nom_recusa) like '%risco%';
SELECT * FROM tron2000.G2992051_VCR where cod_cia = 1 and cod_recusa = 21078--Creacion de cod_recusa ( mas adelante se usa como cod_recusa_flex)
SELECT * FROM tron2000.G2992152_VCR where cod_cia = 1 and cod_ramo = 734 and cod_modalidad = 3013 and cod_recusa_flex = 21077;-- Cod_recusa flex = cod_recusa ( Tabla G2992051_VCR)
SELECT * FROM tron2000.G2992153_VCR where cod_cia = 1 and cod_ramo = 734 and cod_recusa_flex = 21077;-- Asociación de cod_recusa_flex y cod_recusa
SELECT * FROM tron2000.G2992154_VCR where cod_cia = 1 and cod_ramo = 734 and cod_recusa IN (21075,21076);--Limites y pesos de las recusas
SELECT * FROM tron2000.G2992151_VCR where cod_cia = 1 and cod_ramo = 734 and cod_recusa IN (21075,21076);-- Cod_recusas generales y caracteristicas de los mismo ( COD_CAMPO/TIP_RECUSA/TIP_DEF_RECUSA)
SELECT * FROM tron2000.G2992152_VCR where cod_cia = 1 and cod_ramo = 734 and cod_recusa_flex = 21078 order by cod_recusa_flex desc;

-- ejemplo producto 231
cod_recusa_flex = 21074 agrupa a cod_recusa = 27

SELECT * FROM tron2000.G2992051_VCR where cod_cia = 1 and cod_recusa = 27;
SELECT * FROM tron2000.G2992051_VCR where cod_cia = 1 and cod_recusa = 21074;
SELECT * FROM tron2000.G2992152_VCR where cod_cia = 1 and cod_ramo = 231 and cod_tarifa = 21701 and cod_recusa_flex = 21074;
SELECT * FROM tron2000.G2992153_VCR where cod_cia = 1 and cod_ramo = 231 and cod_tarifa = 21701 and cod_recusa_flex = 21074;
SELECT * FROM tron2000.G2992154_VCR where cod_cia = 1  and cod_ramo = 231 and cod_tarifa = 21701 and cod_recusa_flex = 21074;
select * from a2992131_vcr where cod_ramo= 734;
--
em_k_recusa_flexivel_gen;
--
-- Tablas para el backoffice
SELECT * FROM tron2000.a2992131_vcr where cod_cia = 1 and cod_ramo = 901 and num_poliza = '1630513725712';
SELECT * FROM tron2000.a2992130_vcr where cod_cia = 1 and cod_ramo = 901 and num_poliza = '1630513725712';

21078
SELECT * FROM tron2000.G2992051_VCR where cod_cia = 1 and lower(nom_recusa) like '%equipamento%';
select * from tron2000.G2992051_VCR where cod_cia = 1 and cod_recusa = 21077;
select * from tron2000.G2992051_VCR where cod_cia = 1 order by cod_recusa desc;
select * from tron2000.G2992051_VCR where cod_cia = 1 and lower(nom_recusa) like '%mca%';
select * from tron2000.G2992051_VCR where cod_cia = 1 and cod_recusa in (21075,21076, 21078);

insert into tron2000.G2992051_VCR (COD_CIA, COD_RECUSA, COD_IDIOMA, NOM_RECUSA, NOM_COR_RECUSA, FEC_VALIDEZ, COD_USR, FEC_ACTU, MCA_INH, FRONTEND)
values (1, 21078, 'PT', 'COMPROVA AQUISICAO EQUIPAMENTO', 'COMPROVA AQUISICAO EQUIPAMENTO', to_date('21-05-2019', 'dd-mm-yyyy'), 'SVIDAL', to_date('20-12-2021', 'dd-mm-yyyy'), 'N', 'Risco sem aceita��o.');

select * from g2000020 where cod_cia = 1 and cod_ramo = ;
MCA_COMP_AQUISICAO
21077 AGRUPA A 21075 Y  21076 
21079 AGRUPA A 21078
select * from tron2000.G2992151_VCR where cod_cia = 1 and cod_recusa IN(21075,21076, 21077, 21078) for update;
select * from tron2000.G2992151_VCR where cod_cia = 1 and cod_ramo = 231;
select * from tron2000.G2992151_VCR where cod_cia = 1 and cod_recusa = 21074;
21074
insert into tron2000.G2992151_VCR (COD_CIA, COD_RAMO, COD_RECUSA, FEC_VALIDEZ, TIP_RECUSA, COD_CAMPO, NOM_PRG, TIP_DEF_RECUSA, COD_USR, FEC_ACTU, MCA_INH)
values (1, 734, 21078, to_date('21-05-2021', 'dd-mm-yyyy'), 1, 'COMPROVA AQUISICAO EQUIPAMENTO', null, 'N', 'SVIDAL', to_date('21-12-2021', 'dd-mm-yyyy'), 'N');

select * from tron2000.G2992152_VCR where cod_cia = 1 and cod_RAMO = 734 for update;
select * from tron2000.G2992152_VCR where cod_cia = 1
insert into tron2000.G2992152_VCR (COD_CIA, COD_RAMO, COD_TARIFA, COD_RECUSA_FLEX, FEC_VALIDEZ, COD_MODALIDAD, COD_NIVEL1, COD_NIVEL2, COD_NIVEL3, COD_CANAL1, COD_CANAL2, COD_CANAL3, COD_AGT, NUM_POLIZA_GRUPO, NUM_CONTRATO, NUM_SUBCONTRATO, NUM_POLIZA_CLIENTE, NUM_POLIZA, NUM_ORDEN, COD_USR, FEC_ACTU, MCA_INH, COD_ENDOSSO, TIP_AGRUP_RECUSA, COD_NIVEL_AUTORIZACION, MCA_AUTORIZA_AUTOMATICA, NOM_PRG_AUTORIZA, NOM_PRG_RECHAZA, TIP_RECUSA)
values (1, 734, 734, 21078, to_date('21-05-2019', 'dd-mm-yyyy'), 3013, 99, 999, 9999, 'ZZZZ', 'ZZZZ', 'ZZZZ', 99999, '9999999999999', 99999, 99999, '9999999999999', '9999999999999', 1, 'SVIDAL', to_date('21-12-2021', 'dd-mm-yyyy'), 'N', 0, 'DIR', 1, 'N', null, null, 'BO');


select * from tron2000.G2992153_VCR where cod_cia = 1 and cod_RAMO = 734 for update;
select * from tron2000.G2992152_VCR where cod_cia = 1 and cod_recusa = 21074;
select * from G2002050 where cod_cia = 1 and lower(nom_tarifa) like '%rural%';

select * from G2002050 where cod_cia = 1 and cod_tarifa = 734;


select * from tron2000.G2992154_VCR where cod_cia = 1 and cod_RAMO = 734 for update;
select * from tron2000.G2992154_VCR where cod_cia = 1 and cod_recusa = 21074;

-- ct
dc_p_trazas_mpr ('REUY', 'TRAZA EJEC => ' || dbms_utility.format_call_stack);
-- configuracion ct por pasos a nivel de cod_ramo
SELECT * FROM G2000200 WHERE cod_cia = 1 and cod_ramo = 734;
-- codigos de sistema
select * from a1002700 where cod_cia = 1 and cod_sistema = '2'; --cod_sistema ='2' emissao, '7'  sinistros
-- cod_error por ct
select * from g2000210 where cod_cia = 1 and cod_error = 9018;
SELECT * FROM G2000200 WHERE cod_cia = 1 AND cod_ramo = 734;
SELECT * FROM G2009015_VCR
dc

SELECT * FROM a2009048_vcr WHERE COD_CIA = 1 AND COD_RAMO IN (417, 734);
select * from g2000211;
DC_P_CT_540
DC_P_CT_190
EV_K_901_CT
DC_P_CT_735
ED_K_734_dv
ed_p_
DC_P_CT_LIQUIDACAO
select * from g2000211 where cod_cia = 1 and lower(nom_error) like '%20098400%';
select * from g2000211 where cod_cia = 1 
select * from g2000211 where cod_error = 20098400; -- mensajes de control tecnico
select * from g2000211 where cod_cia = 1  and lower(nom_error) like '%existe%';--cod_error 39
select max(cod_error) from g2000211
select * from g2000211 where cod_error = 9852;
insert into g2000211 (COD_CIA, COD_ERROR, NOM_ERROR, COD_IDIOMA, COD_USR, FEC_ACTU)
values (1, 9855, 'Quantidade de Riscos diferente da declarada', 'PT', 'TRON2000', to_date('11-04-2021', 'dd-mm-yyyy'));
SELECT * FROM G2990021
SELECT * FROM P2000290
TRON2000.EM_K_GEN_EMI_SPTO_VCR
SELECT * FROM G1010031 WHERE COD_RAMO = 417;
TRP_XX_DL.ED_K_734_COTI_VCR
SELECT * FROM g0200002 WHERE NOM_PRG IS NULL;
select * from g2000210 where cod_cia = 1 and cod_nivel_autorizacion= '8'
select * from g2000210 where cod_cia = 1 and cod_error = 20098400;-- ct a nivel compania
select * from g2000210 where cod_cia = 1;
select * from g2000220 where cod_cia = 1;
select * from g2000220 where cod_cia = 54 and cod_sistema = 7 and cod_nivel_salto = 8;

select * from x2000221;

SELECT *
          FROM g2000210
         WHERE cod_cia   = 1
           AND cod_error = 20098400;

dc_p_ct_540
trp_xx_dl.ED_K_734_CT_vcr;
select * from tron2000.g2999017; -- ct a nivel de ramo y cobertura
select * from g2000220 where cod_cia = 1 ; -- definicion de niveles de salto de control tecnico
select * from g2000230 where; -- definicion de niveles de autorizacion de control tecnico
SELECT * FROM A2999018_VCR WHERE COD_CIA = 1 AND COD_RAMO = 734 and cod_error = '-82'; -- CT�s por Producto
SELECT * FROM a1009039_vcr WHERE cod_cia = 1 AND cod_ramo = 734; --Control de Producto SUSEP
 
SELECT * FROM DF_CMN_NWT_XX_CNN WHERE LOB_VAL = 417 AND VRB_NAM IN( 'MES_MAX', 'MES_MIN') FOR UPDATE;

'MES_MAX'

SELECT * FROM A1002700 WHERE COD_CIA = 1 AND COD_SISTEMA = '2';
SELECT * FROM G2000200 where cod_cia=1 and cod_ramo IN( 734,901); -- SE CONFIGURAN LOS SALTOS Y LOS PROCEDIMIENTOS QUE SE VAN A LLAMAR
SELECT * FROM G2000200 where cod_cia=1 and cod_ramo IN( 734); 
ed_k_734_ct;
SELECT * FROM G2000210; -- SE CONFIGURAN LOS CODIGOS DE ERROR
SELECT * FROM G2000211; -- SE CONFIGURAN LOS CODIGOS DE ERROR
SELECT * FROM G2000230; -- SE CONFIGURAN LOS ROLES POR SECTOR
SELECT * FROM A2000221; -- QUEDAN LOS CONTROLES TECNICOS SI ESTAN O NO AUTORIZADOS
SELECT * FROM a2000030; -- MCA_PROVISIONAL ESTA EN 'S' ES CONTROL TECNICO
SELECT * FROM tron2000.G2009015_vcr; -- SE CONFIGURA POR CODIGO DE ERROR YEL TIPO DE EMISION


A2000030

SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 order by tip_nivel, num_secu FOR UPDATE;
SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734  AND COD_CAMPO LIKE '%INSPEC%';

-- tip_classificacao_corretor
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734;--4147
select COD_AGT, TIP_CLASSIFICACAO_CORRETOR  from g1001332_vcr where cod_cia = 1 and cod_ramo = 734 FOR UPDATE; 

-- dv 
-- dv nivel compania
NUM_CARENCIA_DIAS
select * from g2000010 where cod_cia = 1 and cod_campo like '%CAREN%' FOR UPDATE;
select * from g2000010 where cod_cia = 1 and cod_campo in (select cod_campo from g2000020 where cod_cia = 1 and cod_ramo =734);
select * from g2000010 where cod_cia = 1 AND NOM_CAMPO LIKE 'CPF%'

select * from g2000010 where cod_cia = 1 and cod_campo like '%NUM_CARENCIA_DIAS%';

SELECT * FROM  g2000010 where cod_cia = 1 and cod_campo ='NUM_QUANTIDADE_EQUIPAMENTOS';

DELETE FROM  g2000010 where cod_cia = 1 and cod_campo ='NUM_CARENCIA_HORAS';

insert into g2000010 (COD_CIA, COD_CAMPO, COD_MODULO, COD_TEXTO, NOM_CAMPO, TIP_CAMPO, LNG_CAMPO, COD_SISTEMA, MCA_INH, MCA_SINI, MCA_OBLIGATORIO, MCA_VALIDACION, NOM_PRG_PRE_CAMPO, NOM_PRG_CAMPO, VAL_DEFECTO, NOM_PGM_HELP, COD_VERSION, NOM_GLOBAL_PGM_HELP, NOM_TABLA_VALIDA, COD_USR, FEC_ACTU)
values (1, 'NUM_CARENCIA_HORAS', 'EM', null, 'CARENCIA (HORAS)', 'N', 2, '2', 'N', 'N', 'S', 'N', null, null, null, null, null, null, null, 'VERA48', to_date('06-10-2006', 'dd-mm-yyyy'));

  INSERT INTO g2000020 (cod_cia,cod_ramo,cod_modalidad,cod_cob,cod_agr,fec_validez,tip_nivel,num_secu,cod_campo,mca_inh,mca_visible,mca_obligatorio,mca_valida_si_null,mca_modalidad,mca_calculo,mca_presupuesto,mca_sini,mca_unico,mca_inspec,mca_busca_insp,mca_busca_por_igual_insp,mca_solicita_en_copia,mca_graba_rechazo,mca_suma_aseg,mca_validacion,mca_validacion_cia,cod_usr,fec_actu,tip_regulariza,tip_regulariza_esp,pct_regulariza_esp,cod_indice,nom_prg_regulariza_esp,nom_prg_pre_campo,val_defecto,nom_tabla_val_defecto,nom_campo_tabla_val_defecto,nom_pgm_help,nom_tabla_valida,cod_version,nom_global_pgm_help,nom_prg_campo,cod_lista,cod_transportes,num_secu_insp,mca_case_sensitive,cod_panel,tip_subnivel,tip_dato_fondo,mca_vld_online,mca_exportar_rea_ext)
VALUES (1,734,99999,9999,999,TO_DATE('21052019', 'DDMMYYYY'),1,24,'NUM_DIA_VENCIMENTO','N','S','S','N','N','N','S','N','N','N','N','N','N','S','N','N','S','JOSPINA',TRUNC(SYSDATE),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ED_K_734_DV.P_V_NUM_DIA_VENCIMENTO',NULL,NULL,99,'N',NULL,NULL,NULL,'N',NULL);

-- dv nivel ramo
SELECT a.*,ROWID FROM g2000020 a WHERE COD_CIA = 1 AND cod_ramo = 734 order by tip_nivel, num_secu;
select * from g2000020 where cod_cia = 1 and cod_ramo =734 order by tip_nivel, num_secu FOR UPDATE;--p_pre_num_pac
select COD_CAMPO from g2000020 where cod_cia = 1 and cod_ramo =734 order by tip_nivel, num_secu 
update 

MCA_COMP_AQUISICAO
update g2000020 set NOM_PRG_CAMPO = 'ED_K_734_DV.P_V_MCA_COMP_AQUISICAO' WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO = 'MCA_COMP_AQUISICAO'
p_pre_num_carencia_horas
select * from g2000020 where cod_cia = 1 and cod_ramo =734 and cod_campo = 'COD_MODALIDAD' order by tip_nivel, num_secu FOR UPDATE;
UPDATE G2000020 SET NOM_PRG_PRE_CAMPO ='ED_K_734_DV.P_PRE_NUM_CARENCIA_HORAS' WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO = 'NUM_CARENCIA_HORAS';
select * from g2000020 where cod_cia = 1 and cod_ramo in (417,734) and cod_campo LIKE 'NOM_MARCA_EQUIP%' order by tip_nivel, num_secu
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 3 order by num_secu;
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 3 AND COD_COB = 869 AND NUM_SECU = 4 order by num_secu;
insert into g2000020 (COD_CIA, COD_RAMO, COD_MODALIDAD, COD_COB, COD_AGR, FEC_VALIDEZ, TIP_NIVEL, NUM_SECU, COD_CAMPO, MCA_INH, MCA_VISIBLE, MCA_OBLIGATORIO, MCA_VALIDA_SI_NULL, MCA_MODALIDAD, MCA_CALCULO, MCA_PRESUPUESTO, MCA_SINI, MCA_UNICO, MCA_INSPEC, MCA_BUSCA_INSP, MCA_BUSCA_POR_IGUAL_INSP, MCA_SOLICITA_EN_COPIA, MCA_GRABA_RECHAZO, MCA_SUMA_ASEG, MCA_VALIDACION, MCA_VALIDACION_CIA, COD_USR, FEC_ACTU, TIP_REGULARIZA, TIP_REGULARIZA_ESP, PCT_REGULARIZA_ESP, COD_INDICE, NOM_PRG_REGULARIZA_ESP, NOM_PRG_PRE_CAMPO, VAL_DEFECTO, NOM_TABLA_VAL_DEFECTO, NOM_CAMPO_TABLA_VAL_DEFECTO, NOM_PGM_HELP, NOM_TABLA_VALIDA, COD_VERSION, NOM_GLOBAL_PGM_HELP, NOM_PRG_CAMPO, COD_LISTA, COD_TRANSPORTES, NUM_SECU_INSP, MCA_CASE_SENSITIVE, COD_PANEL, TIP_SUBNIVEL, TIP_DATO_FONDO, MCA_VLD_ONLINE, MCA_EXPORTAR_REA_EXT)
values (1, 734, 99999, 869, 999, to_date('21-05-2019', 'dd-mm-yyyy'), 3, 4, 'NUM_CARENCIA_HORAS', 'N', 'S', 'S', 'N', 'N', 'N', 'S', 'N', 'N', 'N', 'N', 'S', 'N', 'S', 'N', 'N', 'N', 'JOSPINA', to_date('26-10-2021', 'dd-mm-yyyy'), null, null, null, null, null, null, NULL, null, null, 'AL299999', null, null, null, null, null, null, null, 'N', null, null, null, 'N', null);
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 3 AND COD_COB = 869 order by num_secu;
select cod_campo, nom_prg_pre_campo, nom_prg_campo  from g2000020 where cod_cia = 1 and cod_ramo =734 order by tip_nivel, num_secu;
select cod_campo, nom_prg_pre_campo, nom_prg_campo  from g2000020 where cod_cia = 1 and cod_ramo =734 order by tip_nivel, num_secu for update;
select cod_campo, nom_prg_pre_campo, nom_prg_campo  from g2000020 where cod_cia = 1 and cod_ramo =734 and tip_nivel = 3 order by tip_nivel, num_secu;
select cod_campo, nom_prg_pre_campo, nom_prg_campo  from g2000020 where cod_cia = 1 and cod_ramo =417 order by tip_nivel, num_secu;
SELECT TIP_NIVEL, NUM_SECU, COD_CAMPO, NOM_PRG_PRE_CAMPO, NOM_PRG_CAMPO FROM g2000020 where cod_cia = 1 and cod_ramo =734 order by tip_nivel, num_secu;
update g2000020 set mca_visible = 'S' WHERE COD_CIA = 1 AND COD_RAMO = 734  AND COD_CAMPO = 'MCA_COMP_AQUISICAO';

SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO IN (
'TIP_GESTOR_PARCELA1_VCR',
'COD_BNC_FCA',
'NUM_BLOQUETE_FCA',
'IMP_BLOQUETE_FCA',
'NUM_DIA_VENCIMIENTO',
'TID_CARTAO'
);

select * from g2000020 where cod_cia = 1 and cod_ramo = 231 order by tip_nivel, num_secu;

select * from g2000020 where cod_cia = 1 and cod_ramo = 231 order by tip_nivel, num_secu;

SELECT a.*,ROWID FROM G2000020 a WHERE COD_CIA = 1 AND COD_RAMO in (231,734) AND COD_CAMPO IN (
'TIP_GESTOR_PARCELA1_VCR',
'COD_BNC_FCA',
'NUM_BLOQUETE_FCA',
'IMP_BLOQUETE_FCA',
'NUM_DIA_VENCIMENTO',
'COD_TID_CARTAO'
);

select * from a1001800 where cod_cia = 1 and upper(nom_ramo) like '%AUTO%';

231

EA_K_231_CT

SELECT * FROM G2000020 a WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO IN (
'TIP_GESTOR_PARCELA1_VCR',
'COD_BNC_FCA',
'NUM_BLOQUETE_FCA',
'IMP_BLOQUETE_FCA',
'NUM_DIA_VENCIMENTO',
'COD_TID_CARTAO'
);

EA_K_231_DV.P_PRE_COD_TID_CARTAO
EA_K_231_DV.P_PRE_NUM_BLOQUETE_FCA
EA_K_231_DV.P_PRE_NUM_DIA_VENCIMENTO
EA_K_231_DV.P_PRE_TIP_GESTOR_PARCELA1
DC_K_DV_GEN.P_VAL_MAYOR_IGUAL_CERO
EA_K_231_DV.P_V_COD_TID_CARTAO
DC_K_DV_GEN.P_VAL_MAYOR_IGUAL_CERO
EA_K_231_DV.P_V_NUM_BLOQUETE_FCA
EA_K_231_DV.P_V_NUM_DIA_VENCIMENTO
EA_K_231_DV.P_V_TIP_GESTOR_PARCELA1

select * from G1010031 where cod_campo= 'NUM_DIA_VENCIMENTO';



select * from g2000010 where cod_cia = 1 and lower(cod_campo) like '%num_dia_%';

select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'TIP_DURACION' FOR UPDATE;
AYUDA G2000020 cuandot el tipo de ayuda NOM_TABLA AL299999 = SE ENVIA EL COD_CAMPO
cuando el tipo de ayuda es al000010 tabla x2009701_vcr cod_vesion = 1
AL000010 BUISCA EN LAS TABLAS G1010300 Y G1010310
TIPO AYUDAS
---AL299999() := MCA_IOF_194-- Cod_ramo = 734, cod_Cia =1  ;
---AL000010(PCT_POS_194) := TABLA ='X2009701_VCR' cod_version = 1 COD_CIA = 1   
--AL000010
select * from g1010300 where nom_tabla ='X2009701_VCR' and cod_version = 1;
select * from g1010310 where nom_tabla ='X2009701_VCR' and cod_version = 1;
---AL299999() 
select * from g2990006 where cod_cia = 1 and  cod_campo = 'MCA_AUTORIZA_EMAIL' AND  cod_Ramo = 734 ;

SELECT * FROM G2000180 WHERE COD_CIA = 1 AND COD_RAMO = 734;
SELECT * FROM G2000190 WHERE COD_CIA = 1 AND COD_RAMO = 734;
TRP_XX_DL.ED_K_734_DES_VCR

-- ayudas (relacionado con la g200020)
SELECT a.*,ROWID FROM G2990006 a WHERE COD_CIA = 1 AND cod_ramo = 734 AND cod_campo = 'NUM_CARENCIA_HORAS' ;
select * from g2990006;
tron2000.dc_k_g2990006_vcr_vcr;

select * from G2990006 where cod_cia = 1 and cod_ramo = 734 order by cod_campo;
select * from G2990006 where  cod_cia = 1 and cod_ramo = 734 AND cod_campo = 'NUM_CARENCIA_HORAS' for update;
select * from G2990006 where  cod_cia = 1 and cod_ramo = 734 AND cod_campo = 'NUM_PERC_ISVR' AND COD_VALOR = 100;
select * from G2990006 where cod_campo = 'TIP_FINANC' AND COD_CIA = 1  for update;

insert into G2990006 (COD_CIA, COD_RAMO, COD_MODALIDAD, FEC_VALIDEZ, COD_CAMPO, COD_VALOR, NOM_VALOR, NUM_PTO, FEC_ACTU, COD_USR)
values (1, 734, 99999, to_date('21-05-2019', 'dd-mm-yyyy'), 'NUM_CARENCIA_HORAS', '15', '15', NULL, to_date('20-10-2021', 'dd-mm-yyyy'), 'MRAMIREZ');

insert into G2990006 (COD_CIA, COD_RAMO, COD_MODALIDAD, FEC_VALIDEZ, COD_CAMPO, COD_VALOR, NOM_VALOR, NUM_PTO, FEC_ACTU, COD_USR)
values (1, 734, 99999, to_date('21-05-2019', 'dd-mm-yyyy'), 'NUM_CARENCIA_HORAS', '25', '25', NULL, to_date('20-10-2021', 'dd-mm-yyyy'), 'MRAMIREZ');

insert into G2990006 (COD_CIA, COD_RAMO, COD_MODALIDAD, FEC_VALIDEZ, COD_CAMPO, COD_VALOR, NOM_VALOR, NUM_PTO, FEC_ACTU, COD_USR)
values (1, 734, 99999, to_date('21-05-2019', 'dd-mm-yyyy'), 'NUM_CARENCIA_HORAS', '48', '48', NULL, to_date('20-10-2021', 'dd-mm-yyyy'), 'MRAMIREZ');

-- datos personales tercero
select * from a1009031_vcr; 
select * from x2000030
select * from x2000020;
select * from g1001330

-- tip_classificacao_corretor 29671 SICREDI - 85865 CA
SELECT * FROM g1001332_vcr where cod_CIA = 1 AND COD_RAMO = 734; 

-- datos asegurado
select * from a1001331  where cod_cia = 1 and cod_docum = '10228777000161';
select nom_complemento from a1001331  where cod_cia = 1 and cod_docum = '10228777000161';

SELECT * FROM A1002050 WHERE COD_CIA= 1;--  Definicion de Coberturas a Nivel Compa��a
SELECT COD_COB, NOM_COB FROM A1002150 WHERE COD_CIA = 1 AND COD_RAMO = 734;--  Definicion de Coberturas a Nivel de Ramo
SELECT COD_COB, NOM_COB,NOM_PRG_CALCULO,NOM_PRG_VALIDACION,NOM_PRG_PRE_FRANQUICIA FROM A1002150 WHERE COD_CIA = 1 AND COD_RAMO = 734;
select distinct(cod_cob) from a1002150 where cod_cia = 1 and cod_ramo = 734;
SELECT COD_COB, NOM_COB,NOM_PRG_CALCULO FROM A1002150 WHERE COD_CIA = 1 AND COD_RAMO = 734;

-- Equipamentos
SELECT * FROM G2009070_VCR; -- SEGUN TIP_CLASSIFICACAO_CORRETOR
SELECT * FROM G2009071_VCR; -- SEGUN cod_CLASE
SELECT * fROM G2009072_VCR; -- segun cod_equipamento

-- Comisiones
SELECT * FROM A1001750 WHERE COD_CIA = 1 AND COD_RAMO = 734;
SELECT * FROM A1001342 WHERE COD_AGT = 2301 AND COD_TRATAMIENTO = 'D';
select * from df_cmn_nwt_xx_cnn where vrb_nam = 'VAL_PTC_AGRAVO_734';--constantes
select * from corpp0.df_cmn_nwt_xx_cnn where vrb_nam in('VAL_PTC_AGRAVO_734','TIP_FINANC_DOS_734','COD_VAL_TIP_FIN_DOS_734',
'DV_TIP_FINANC','TIP_FINANC_TRES_734','COD_VAL_TIP_FIN_TRES_734','TIP_DOC_PESSOA_JURIDICA');
p_pre_tip_produto
p_pre_nom_agencia

ed_k_734_coti
-- mensajes de error
select * from g1010020 where UPPER(txt_mensaje) like '%VALOR DEL EQUIPAMENTO MAYOR AL DE LA TABLA%';
select * from g1010020
SELECT * FROM G1010020 WHERE COD_MENSAJE = 20098400 for update;
SELECT * FROM G1010020 WHERE COD_MENSAJE IN(99990815, 99990816 );
SELECT * FROM G1010020 WHERE COD_MENSAJE = 20098161 FOR UPDATE;
select max(cod_mensaje) from g1010020;
insert into g1010020 (COD_MENSAJE, COD_IDIOMA, TXT_MENSAJE, COD_INSTALACION, MCA_MENSAJE) values (99990829, 'PT', 'NECESSARIO CADASTRAMENTO DE ESTADO', 'VCR', null);
trp_xx_dl.trn_k_ptd
dc_k_dv_gen

-- packages
ptd_atr_vcr;
TRON2000.EM_K_PTD_ATR
tron2000.dc_k_g2009070_vcr
select * from g2009070_vcr;
trp_xx_dl.ed_k_734_utils_vcr;--Constantes y otras funciones
em_k_g2990006
select * from g2990006 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'TIP_FINANC' for update;
trp_xx_dl.ed_k_734_dv_vcr; -- datos variables
tron2000.em_k
tron2000.em_k_ptd_atr
trp_xx_dl.ed_k_734_coti_vcr;

SELECT * FROM A2000020 WHERE COD_CIA = 1 AND NUM_POLIZA LIKE '734%' AND COD_CAMPO LIKE '%AGT%' ORDER BY NUM_POLIZA DESC;
--TRON2000.ed_k_734_coti
trp_xx_dl.ed_k_734_coti_vcr;
trp_xx_dl.ed_k_734_ct_vcr;
trp_xx_dl.ed_k_417_coti_vcr;
trp_xx_dl.ed_k_417_dv_vcr;
trp_xx_dl.ed_k_734_dv_vcr;
trp_xx_dl.ed_k_417_utils_vcr;
trp_xx_dl.ed_k_734_utils_vcr;
trp_xx_dl.ed_k_417_df_vcr;
trp_xx_dl.ed_k_734_df_vcr; -- datos fijos
trp_xx_dl.ed_k_734_cob_vcr; -- coberturas
trp_xx_dl.ed_k_734_int_vcr; 
tron2000.dc_k_ptd_int_vcr;-- PTD de corretor, cobertura etc
tron2000.dc_k_ptd_thp_vcr;-- PTD de cod_postaL
dc_k_ptd_thp_vcr
select * from a1009031_vcr;


tron2000.em_k_ptd_ine; -- PTD para obtener algunos datos.
tron2000.dc_k_ptd;
tron2000.em_k_ptd_atr;  -- atributos de datos variables y otros
TRON2000.DC_K_DV_VCR;
tron2000.ev_k_901_dv_vcr;
tron2000.ev_k_901_dv
em_k_g2990006;
em_k_ptd_atr
select * from a1002150 where cod_cia = 1 and cod_ramo = 734;
em_k_a1002150;
SELECT DISTINCT(FEC_VALIDEZ) FROM g2990006 WHERE cod_ramo = 734 AND cod_campo LIKE '%TIP_PROD%' ;
tron2000.em_k_g2990006_trn



-- sinonimos
CREATE OR REPLACE SYNONYM dc_k_ptd_int_vcr
FOR TRON2000.dc_k_ptd_int_vcr;
GRANT EXECUTE ON  tron2000.dc_k_ptd_int_vcr TO TRP_XX_DL;

SELECT * FROM A1002050;--  Definicion de Coberturas a Nivel Compa��a
SELECT * FROM A1002150 where cod_cia = 1 and cod_ramo = 734;--  Definicion de Coberturas a Nivel de Ramo
SELECT * FROM A1002150 where nom_prg_pre_cob is not null;
trp_xx_dl.ED_K_417_COB;
ED_K_417_COB.P_PRE_SUMA_ASEG_139
/* ********************************************************** */
     SELECT *
        FROM a1000102 where cod_localidad = 1399;
dc_k_a1000104
tron2000.dc_k_a1000104
select max(cod_mensaje) from g1010020;--99990851
select max(cod_mensaje) from corpp0.g1010020;--99990851 --99990850
select * from  g1010020 where cod_mensaje = 70096004;
select * from  g1010020 where lower(txt_mensaje) like '%valor%';--20003050,70096004------50016
insert into g1010020 (COD_MENSAJE, COD_IDIOMA, TXT_MENSAJE, COD_INSTALACION, MCA_MENSAJE)
values (99990829, 'PT', 'NECESSARIO CADASTRAMENTO DE ESTADO', 'VCR', null);

select * from g1010020 where upper(txt_mensaje) like '%cadastramento de cidade%';
select * from g1010020 where upper(txt_mensaje) like '%DE BAIRRO%';

SERVIDOR: ubr001001-137  USUARIO: tron2000 CONTRASENA: tron2000 PUERTO: 22
poliza grupo dev: 7304020000001 tercero 10432227660;
SELECT SYSDATE FROM DUAL;
SELECT * FROM TRON2000.t_trn_trn_r_dbg
WHERE 
PGM_NAM = 'ed_k_734_dv'
AND TIM_INV BETWEEN TO_TIMESTAMP('22-OCT-21 00:55:00,000000000', 'DD-MON-RR HH24:MI:SS,FF9') 
  AND                TO_TIMESTAMP('22-OCT-21 17:20:00,999999999', 'DD-MON-RR HH24:MI:SS,FF9')
ORDER BY TIM_INV DESC;

DELETE FROM TRON2000.t_trn_trn_r_dbg
WHERE TIM_INV BETWEEN TO_TIMESTAMP('22-OCT-21 16:45:00,000000000', 'DD-MON-RR HH24:MI:SS,FF9') 
  AND                TO_TIMESTAMP('22-OCT-21 17:10:00,999999999', 'DD-MON-RR HH24:MI:SS,FF9')


TRON2000.trn_k_ptd
select cod_prov, cod_localidad, cod_estado from a1001331  where cod_cia = 1 and cod_docum = '10228777000161';
select * from a1000102 where cod_prov = 791 and cod_localidad = 1399;
select COD_PROV from a1001331  where cod_cia = 1 and cod_docum = '10228777000161';
SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO in ( 'COD_ESTADO','COD_BAIRRO') for update ;
SELECT * FROM G2000010 WHERE COD_CIA = 1 AND COD_CAMPO = 'COD_BAIRRO';
COD_POSTAL  ED_K_734_DV.P_PRE_COD_POSTAL
COD_PROV_734 ED_K_734_DV.P_PRE_COD_PROV     CODIGO DA CIDADE
COD_BAIRRO  ED_K_734_DV.P_PRE_COD_BAIRRO    CODIGO DO BAIRRO

select * from a1000102;

trp_xx_dl.ed_k_734_utils_vcr;
.record_codigo_postal;
tron2000.dc_k_ptd

SELECT DISTINCT 'SELECT * FROM ' || 'G2000020' || ' WHERE COD_CIA = 1 AND COD_RAMO = 734' FROM DUAL;
select * from g1010020 where lower(txt_mensaje) like '%idenitario%';
select max(cod_mensaje) from g1010020
select * from g1010020 where cod_mensaje = '99990823';
SELECT * FROM TRAZAS_MPR WHERE COD_TRAZA = 'MY' ORDER BY ID_TRAZA DESC;
DELETE FROM TRAZAS_MPR WHERE COD_TRAZA = 'MY' ;
|dc_p_trazas_mpr ('JGG', 'XXXXXX => ' || NULL);
select * from a1001331 where cod_docum = '10228777000161';
cod_campo = 'MCA_IOF' and
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 for update;
194 / 869 / 972
select * from x2000020;
delete from x2000020 where cod_cia = 1 and cod_ramo = 734;
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 order by tip_nivel, num_secu for update;
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 and cod_campo LIKE 'MCA_IOF%' FOR UPDATE;
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 and TIP_NIVEL = 3 FOR UPDATE;
select * from g2000020 where  cod_cia = 1 and cod_campo like '%IOF%'  AND VAL_DEFECTO IS NOT NULL order by cod_ramo;
select * from g2000010 where  cod_cia = 1  and cod_campo = 'MCA_IOF' FOR UPDATE;
MCA_IOF_194
MCA_IOF_869
MCA_IOF_972
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 AND COD_COB = 194 FOR UPDATE;
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 AND COD_COB = 869 FOR UPDATE;
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 AND COD_COB = 972 FOR UPDATE;
194	30	051	30051734R	RESP.CIVIL - MAQ.AGRICOLA
869	30	041	30041734R	PERDA DE LUCRO LIQUIDO
972	30	051	30051734R	RESP. CIVIL EMPREGADOR
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 and cod_campo in ('MCA_IOF','MCA_AUTORIZA_DADOS');
ED_K_734_DV.P_PRE_MCA_IOF
p_pre_mca_iof
select * from g2000020 where cod_cia = 1 and cod_ramo = 417 order by tip_nivel, num_secu;
trp_xx_dl.ed_k_417_dv_vcr;
trp_xx_dl.ed_k_417_dv_vcr
tron2000.dc_k_ptd_thp_vcr;
trp_xx_dl.dv_k_ptd_int_vcr
trp_xx_dl.dv_k_ptd_int_vcr
dc_k_ptd_thp.record_tercero;
trp_xx_dl.ed_k_734_dv_vcr;
dc_k_a1000102
select * from a1000102;
tron2000.dc_k_ptd_thp
tron2000.dc_k_ptd_int_vcr
dc_k_ptd_thp_vcr
a1001331
tron2000.dc_k_ptd_thp_vcr;
tron2000.dc_k_ptd

      trn_k_ptd.p_gen_traza_parametro (p_nom_prg       => 'dc_k_ptd_int',
                                       p_nom_parametro => 'p_cod_cia'   ,
                                       p_val_parametro => p_cod_cia     );


select * from a2009051_vcr where cod_cia = 1 and cod_ramo = 417;

select * from a2009051_vcr where cod_ramo = 998;

select * from tron2000.G2009070_VCR;
trp_xx_dl.ed_k_734_dv_vcr;
trp_xx_dl.em_
trp_xx_dl.ed_k_734_df_vcr;
trp_xx_dl.
tron2000.dc_k_ptd_int_vcr;
TRON2000.EM_K_PTD
em_f_tip_classifi_corretor
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734 FOR UPDATE;
tip_classificacao_corretor
mca_corretor_mais
     SELECT * FROM x2000040;
tron2000.em_k_ptd_cvr
TRON2000.dc_k_ptd_int_vcr;
delete from xbackground where cod_marco = 734;
g1001332_vcr
select * from A1001430;
select * from x2000020;

para las ayudas nuevas de tablas nuevas se usan las tablas
G1010300
G1010310
SELECT * FROM G1010300 WHERE NOM_TABLA = 'g2009072_VCR';
SELECT * FROM G1010310 WHERE NOM_TABLA = 'g2009071_VCR';
select * from G2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'COD_ESTADO' FOR UPDATE;
select * from G2990006 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'COD_ESTADO' FOR UPDATE;
MCA_IOF_194
MCA_IOF_869
MCA_IOF_972



select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734;


SELECT * FROM g2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734;
select * from g2000020 where cod_campo = 'TIP_CLASSIFICACAO_CORRECTOR';
EA_K_231_DV.P_PRE_TIP_CLASSIFI_CORRETOR
EA_K_231_DV.P_PRE_TIP_CLASSIFI_CORRETOR

TRP_XX_DL.ED_K_734_UTILS_VCR;
select * from G2990006 where cod_cia = 1 and cod_ramo = 734 and cod_campo IN( 'NUM_PER_IDENITARIO', 'MCA_RENOV_OUTRAS') for update ;
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo IN( 'NUM_PER_IDENITARIO', 'MCA_RENOV_OUTRAS') for update ;
select * from G2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo IN( 'NUM_PER_IDENITARIO', 'MCA_RENOV_OUTRAS') ;

update G2000020 set nom_pgm_help = 'AL299999' WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO = 'NUM_PER_IDENITARIO';

select * from g2990006 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'NUM_PER_IDENITARIO';
select * from g2990006 where cod_cia = 1 AND NOM_VALOR LIKE '%MES%' AND COD_RAMO= 637 and cod_campo = 'NUM_PER_IDENITARIO' AND COD_VALOR IN (1,2,3);

insert into g2990006 (COD_CIA, COD_RAMO, COD_MODALIDAD, FEC_VALIDEZ, COD_CAMPO, COD_VALOR, NOM_VALOR, NUM_PTO, FEC_ACTU, COD_USR)
values (1, 734, 99999, to_date('01-01-2012', 'dd-mm-yyyy'), 'NUM_PER_IDENITARIO', '1', '1 MES', null, to_date('14-01-2004', 'dd-mm-yyyy'), 'T_JANTON');

insert into g2990006 (COD_CIA, COD_RAMO, COD_MODALIDAD, FEC_VALIDEZ, COD_CAMPO, COD_VALOR, NOM_VALOR, NUM_PTO, FEC_ACTU, COD_USR)
values (1, 734, 99999, to_date('01-01-2012', 'dd-mm-yyyy'), 'NUM_PER_IDENITARIO', '2', '2 MESES', null, to_date('14-01-2004', 'dd-mm-yyyy'), 'T_JANTON');

insert into g2990006 (COD_CIA, COD_RAMO, COD_MODALIDAD, FEC_VALIDEZ, COD_CAMPO, COD_VALOR, NOM_VALOR, NUM_PTO, FEC_ACTU, COD_USR)
values (1, 734, 99999, to_date('01-01-2012', 'dd-mm-yyyy'), 'NUM_PER_IDENITARIO', '3', '3 MESES', null, to_date('14-01-2004', 'dd-mm-yyyy'), 'T_JANTON');


g_k_tip_produto_gen := 99;
g_k_cod_susep_gen   := 99999;
g_k_tip_segmento_gen := 9999999999;


TRON2000.dc_k_g1001332_vcr

TRP_XX_DL.EV_K_901_DV_VCR;


select * from a1001342 where cod_agt = 2301 and cod_tratamiento = 'D';
SELECT * FROM A1001750 where cod_cia = 1 and cod_ramo = 734;


select * from g2000010 where cod_cia = 1 and cod_campo = 'VAL_VOUCHER_CLUBE_AGRO'
select * from g2000020 where cod_cia = 1 and cod_campo = 'VAL_VOUCHER_CLUBE_AGRO';
update g2000010 set mca

select * from g2000020 where cod_cia = 1  and cod_ramo = 734 and cod_campo = 'PCT_AGRAVO' for update;
ED_K_734_DV.P_V_PCT_AGRAVO
p_v_pct_agravo
select max(cod_mensaje) from g1010020;

  INSERT INTO g1010020 (cod_mensaje,cod_idioma,txt_mensaje,cod_instalacion,mca_mensaje)
VALUES (99990817,'PT','O valor da porcentagem n�o deve ser maior que 60','VCR','S');



tron2000.dc_k_ptd_int_vcr;
dc_k_ptd_int_vcr

CREATE OR REPLACE SYNONYM dc_k_ptd_int_vcr
FOR TRON2000.dc_k_ptd_int_vcr;
GRANT EXECUTE ON  tron2000.dc_k_ptd_int_vcr TO TRP_XX_DL;

PCSGR-200	FATOR DE AGRAVO - TRONWEB Descripci�n
Eu como corretor, quero incluir um fator que agrave minha cota�ao
Acceptance criteria
Campo livre. Pode agravar at� 60 porcentoele pode passar em branco



GRANT EXECUTE ON  tron2000.em_f_tip_classifi_corretor_vcr TO TRP_XX_DL;

tron2000.em_f_tip_classifi_corretor_vcr
select * from a2000030 where cod_cia = 1 and cod_ramo = 734;
select * from G1001332_vcr where cod_cia = 1 and cod_ramo = 734;-- validar con autos si permite crear codigos para produtos rural
delete from g1001332_vcr where cod_cia = 1 and cod_ramo = 734 and cod_agt = 2103;
trn_k_global
SELECT * FROM a2000030 WHERE COD_CIA = 1 AND COD_RAMO = 734;
SELECT to_date('01012019','DDMMYYYY') FROM DUAL;
          SELECT *   FROM g1001332_vcr WHERE COD_RAMO = 734;
SELECT * FROM TRAZAS_MPR WHERE COD_TRAZA = 'rei' ORDER BY ID_TRAZA deSC;
DELETE FROM TRAZAS_MPR WHERE COD_TRAZA = 'rei';


SELECT *   FROM g1001332_vcr
           WHERE cod_cia                    = 1
             AND cod_agt                    IN (29671,'999999')
             AND cod_sector                 IN (30,99)
             AND cod_ramo                   IN (734,999)
             AND tip_produto                IN (99)
             AND cod_nivel1                 IN (99)
             AND cod_nivel2                 IN (999)
             AND cod_nivel3                 IN (9999)
             AND cod_canal1                 IN ('ZZZZ')
             AND cod_canal2                 IN ('ZZZZ')
             AND cod_canal3                 IN ('ZZZZ')
             AND cod_susep                  IN (99999)
             AND num_poliza_grupo           IN (9999999999999)
             AND num_contrato               IN (99999)
             AND num_subcontrato            IN (99999)
             AND num_poliza_cliente         IN (9999999999999)
             AND num_poliza                 IN (9999999999999)
             AND cod_modalidad              IN (99999)
             AND tip_segmento               IN (9999999999)
             AND mca_baja                   =  'N'
             AND fec_validez                <= TO_DATE('01012019','MMDDYYYY')--TO_DATE(NULL,'MMDDYYYY')
        ORDER BY cod_cia           ,
                 cod_sector        ,
                 cod_ramo          ,
                 tip_produto       ,
                 cod_nivel1        ,
                 cod_nivel2        ,
                 cod_nivel3        ,
                 cod_canal1        ,
                 cod_canal2        ,
                 cod_canal3        ,
                 cod_agt           ,
                 cod_susep         ,
                 num_poliza_grupo  ,
                 num_contrato      ,
                 num_subcontrato   ,
                 num_poliza_cliente,
                 num_poliza        ,
                 cod_modalidad     ,
                 tip_segmento      ,
                 fec_validez DESC  ;



 SELECT *   FROM g1001332_vcr
           WHERE cod_cia                    = 1
             AND cod_agt                    IN (29671,'999999')
             AND cod_sector                 IN (30,99)
             AND cod_ramo                   IN (734,999)
             AND tip_produto                IN (99,99)
             AND cod_nivel1                 IN (11,99)
             AND cod_nivel2                 IN (506,999)
             AND cod_nivel3                 IN (3354,9999)
             AND cod_canal1                 IN (1,'ZZZZ')
             AND cod_canal2                 IN (1,'ZZZZ')
             AND cod_canal3                 IN (4,'ZZZZ')
             AND cod_susep                  IN (99999,99999)
             AND num_poliza_grupo           IN (9999999999999,9999999999999)
             AND num_contrato               IN (99999,99999)
             AND num_subcontrato            IN (99999,99999)
             AND num_poliza_cliente         IN (9999999999999,9999999999999)
             AND num_poliza                 IN (7342100002118,9999999999999)
             AND cod_modalidad              IN (99999,99999)
             AND tip_segmento               IN (9999999999,9999999999)
             AND mca_baja                   =  'N'
             AND fec_validez                <= TO_DATE('10272021','MMDDYYYY')--TO_DATE(NULL,'MMDDYYYY')
        ORDER BY cod_cia           ,
                 cod_sector        ,
                 cod_ramo          ,
                 tip_produto       ,
                 cod_nivel1        ,
                 ,
        ev_k_901_dv           cod_nivel2        ,
                 cod_nivel3        ,
                 cod_canal1        ,
                 cod_canal2        ,
                 cod_canal3        ,
                 cod_agt           ,
                 cod_susep         ,
                 num_poliza_grupo  ,
                 num_contrato      ,
                 num_subcontrato   ,
                 num_poliza_cliente,
                 num_poliza        ,
                 cod_modalidad     ,
                 tip_segmento      ,
                 fec_validez DESC  ;


select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734
select * from xbackground;
DELETE FROM XBACKGROUND WHERE COD_MARCO = 734;

delete from a2009048_vcr where cod_cia = 1 and cod_sector = 30 and cod_ramo = 734;

SELECT * FROM G1010107 WHERE COD_USR IN ('JOSPINA') AND TXT_NOMBRE_VARIABLE IN ('GENERA.TRAZAS');
SELECT * FROM G1010107 WHERE COD_USR IN ('JOSPINA') FOR UPDATE;
SELECT * FROM G1010107 WHERE COD_USR IN ('RURQUIJO')
insert into G1010107 (COD_USR, COD_GRUPO, TXT_NOMBRE_VARIABLE, TXT_VALOR_VARIABLE)
values ('RURQUIJO', 'AUTOMATICA', 'GENERA.TRAZAS', 'S');

insert into G1010107 (COD_USR, COD_GRUPO, TXT_NOMBRE_VARIABLE, TXT_VALOR_VARIABLE)
values ('RURQUIJO', 'DEFECTO', 'GENERA.TRAZAS', 'S');
dc_k_g1001332_vcr;
EA_K_231_DV
EA_K_231_DV.P_PRE_TIP_CLASSIFI_CORRETOR;
tron2000.em_f_tip_classifi_corretor_vcr;
TRON2000.ED_K_734_DV;
  INSERT INTO a2009048_vcr (cod_cia,cod_sector,cod_ramo,cod_nivel3,cod_agt,num_contrato,mca_vigente,fec_vig_ini_vcr,fec_fin_vig_vcr,cod_usr,fec_actu,mca_vigente_tw_vcr,mca_completo,mca_sub_risco_vcr,mca_tw_total,mca_circular_326,mca_carta_sinistro)
VALUES (1,30,734,9998,99998,99998,'S',TO_DATE('01012018', 'DDMMYYYY'),TO_DATE('31122000', 'DDMMYYYY'),'T_ROSANA',TRUNC(SYSDATE),'S','S','N','S',NULL,'S');
select * from g2000010 where cod_campo = 'TIP_CLASSIFICACAO_CORRECTOR';
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734 for update;
SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO = 'TIP_CLASSIFICACAO_CORRECTOR' FOR UPDATE;
SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 231 AND COD_CAMPO = 'TIP_CLASSIFICACAO_CORRECTOR'
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 231
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734 for update;
select * from g1001332_vcr where cod_cia = 1 and cod_ramo in (231, 734) and cod_agt = 2103;
select * from a2009048_vcr where cod_cia = 1 and cod_ramo = 734;
trp_xx_dl.ed_k_734_dv_vcr
;
  INSERT INTO a2009048_vcr (cod_cia,cod_sector,cod_ramo,cod_nivel3,cod_agt,num_contrato,mca_vigente,fec_vig_ini_vcr,fec_fin_vig_vcr,cod_usr,fec_actu,mca_vigente_tw_vcr,mca_completo,mca_sub_risco_vcr,mca_tw_total,mca_circular_326,mca_carta_sinistro)
VALUES (1,30,734,9998,99998,99998,'S',TO_DATE('01012018', 'DDMMYYYY'),TO_DATE('31122000', 'DDMMYYYY'),'T_ROSANA',TRUNC(SYSDATE),'S','S','N','S',NULL,'S');

tron2000.dc_k_
tron2000.dc_k_15_ct_vcr;
tron2000.dc_p_ct_015_vcr
trp_xx_dl.ed_k_734_ct_vcr;
trp_xx_dl.ed_k_734_dv_vcr
select * from g2000200 where cod_cia = 1 ;
em_f_tip_classifi_corretor
em_k_ptd_gni.f_dev_cod_agt
SELECT * FROM TRAZAS_MPR WHERE COD_TRAZA = 'rei' ORDER BY ID_TRAZA DESC;
DELETE FROM TRAZAS_MPR WHERE COD_TRAZA = 'rei';
dc_p_trazas_mpr ('rei', 'antes del p_lee_vigente ');
  dc_k_g1001332_vcr           
tip_produto = 99
cod_canal1 = 1 
cod_canal2 = 2
cod_canal3 = 25
cod_sector = 30
cod_ramo = 734
cod_agt= 2103
cod_nivel1 = 1
cod_nivel2 = 501
cod_nivel3 = 2103
cod_susep_gen = 99999

ea_k_231_utils
         SELECT *
            FROM g1001332_vcr
           WHERE cod_cia                    = 1
             AND cod_agt                    IN (2103
                                               ,'999999')
             AND cod_sector                 IN (30
                                               ,99)
             AND cod_ramo                   IN (734
                                               ,999)
             AND tip_produto                IN (null
                                               ,99)
             AND cod_nivel1                 IN (1
                                               ,99)
             AND cod_nivel2                 IN (501
                                               ,999)
             AND cod_nivel3                 IN (2103
                                               ,9999)
             AND cod_canal1                 IN (1
                                               ,'ZZZZ')
             AND cod_canal2                 IN (2
                                               ,'ZZZZ')
             AND cod_canal3                 IN (25
                                               ,'ZZZZ')
             AND cod_susep                  IN (NULL                 
                                               ,99999) 
             AND num_poliza_grupo           IN (  7304020000001        
                                               ,9999999999999)
             AND num_contrato               IN (73402              
                                               ,99999)
             AND num_subcontrato            IN (NULL           
                                               ,99999)
             AND num_poliza_cliente         IN (NULL        
                                               ,9999999999999)
             AND num_poliza                 IN (NULL                
                                               ,9999999999999)
             AND cod_modalidad              IN (NULL            
                                               ,99999)
             AND tip_segmento               IN (NULL             
                                               ,9999999999)
             AND mca_baja                   =  'N'
             AND fec_validez                <= TO_DATE('05212019','MMDDYYYY')
        ORDER BY cod_cia           ,
                 cod_sector        ,
                 cod_ramo          ,
                 tip_produto       ,
                 cod_nivel1        ,
                 cod_nivel2        ,
                 cod_nivel3        ,
                 cod_canal1        ,
                 cod_canal2        ,
                 cod_canal3        ,
                 cod_agt           ,
                 cod_susep         ,
                 num_poliza_grupo  ,
                 num_contrato      ,
                 num_subcontrato   ,
                 num_poliza_cliente,
                 num_poliza        ,
                 cod_modalidad     ,
                 tip_segmento      ,
                 fec_validez DESC  ;
 


-- Cuando no se usa pp_recupera_vlobales
g_cod_agt       := :=           trn_k_global.ref_f_global('g_cod_agt      '   );

alt + clic selecciona todo en notepad
select * from a2009048_vcr where cod_cia = 1 and cod_ramo = 734;
SELECT * FROM G2000010 WHERE COD_CAMPO = 'TXT_DESC_RISCO';
SELECT * FROM G2000020 WHERE COD_CAMPO = 'TXT_DESC_RISCO' and cod_cia = 1 and cod_ramo = 734;

liza grupo 7304020000001
tercero 10432227660

select * from g2990000 where cod_cia = 1 and cod_ramo = 734;


[8:28 a. m.] Prieto Vega, Freddy Eliecer
SELECT *
FROM G2002050 a
WHERE a.cod_cia = &cod_cia
AND a.cod_tarifa = NVL('&cod_tarifa' , a.cod_tarifa)
ORDER BY cod_tarifa
;
SELECT *
FROM G2002051 A
WHERE a.cod_cia = &cod_cia
AND a.cod_factor = nvl('&cod_factor' , a.cod_factor)
ORDER BY cod_factor
;
SELECT *
FROM G2002150 a
WHERE a.cod_cia = &cod_cia
AND a.cod_ramo = &cod_ramo
AND a.cod_desglose = NVL('&cod_desglose' , a.cod_desglose)
AND a.cod_factor = NVL('&cod_factor' , a.cod_factor)
ORDER BY cod_factor, cod_desglose
;
SELECT *
FROM G2002151 a
WHERE a.cod_cia = &cod_cia
AND a.cod_ramo = &cod_ramo
AND a.cod_desglose = NVL('&cod_desglose' , a.cod_desglose)
AND a.cod_factor = NVL('&cod_factor' , a.cod_factor)
ORDER BY cod_ramo, cod_factor, cod_desglose
;
SELECT *
FROM G2002152 a
WHERE a.cod_cia = &cod_cia
AND a.cod_ramo = &cod_ramo
AND a.cod_cob = NVL('&cod_cob' , a.cod_cob)
AND a.cod_tarifa = NVL('&cod_tarifa' , a.cod_tarifa)
AND a.cod_factor = NVL('&cod_factor' , a.cod_factor)
AND a.cod_modalidad = NVL('&cod_modalidad', a.cod_modalidad)
ORDER BY cod_ramo, cod_tarifa, cod_modalidad, cod_cob, num_orden;
SELECT * FROM G2002159 WHERE cod_cia = 1 ORDER BY cod_ramo, cod_cob, cod_tarifa;/*************************************************************************/
SELECT *
FROM G2002153 a
WHERE a.cod_cia = &cod_cia
AND a.cod_ramo = &cod_ramo
AND a.cod_cob = NVL('&cod_cob' , a.cod_cob)
AND a.cod_tarifa = NVL('&cod_tarifa' , a.cod_tarifa)
AND a.cod_modalidad = NVL('&cod_modalidad', a.cod_modalidad)
AND a.fec_validez >= NVL(TO_DATE('&fec_tarifa', 'DDMMYYYY'), TO_DATE('01012014', 'DDMMYYYY'))
ORDER BY cod_ramo, cod_tarifa, cod_modalidad, cod_cob ;
SELECT a.*
FROM g2002154 a
WHERE a.cod_cia = &cod_cia
AND a.cod_ramo = &cod_ramo
AND a.cod_cob = NVL('&cod_cob' , a.cod_cob)
AND a.cod_desglose = NVL('&cod_desglose' , a.cod_desglose)
AND a.cod_tarifa = NVL('&cod_tarifa' , a.cod_tarifa)
AND a.cod_factor = NVL('&cod_factor' , a.cod_factor)
AND a.cod_modalidad = NVL('&cod_modalidad', a.cod_modalidad)
AND NVL(a.val_factor_nom, 'X') = NVL('&valor_factor_nominal', NVL(a.val_factor_nom, 'X'))
AND NVL('&valor_factor_intervalor', NVL(a.val_factor_min, '0')) BETWEEN NVL(a.val_factor_min, '0') AND NVL(a.val_factor_max, '0')
AND a.fec_validez >= NVL(TO_DATE('&fec_tarifa', 'DDMMYYYY'), TO_DATE('01012014', 'DDMMYYYY'))
ORDER BY cod_ramo, cod_tarifa, cod_modalidad, cod_cob, cod_desglose, cod_factor;

/************************** 01 octubre 2021 **************************/

-- Background
select * from xbackground;
delete from xbackground where cod_marco = 734;

tron2000.ed_k_417_dv_vcr_le


select * from g2000020 where cod_cia = 1 and cod_ramo= 734 order by tip_nivel, num_secu;

-- DATOS FIJOS
tron2000.EV_K_901_DF_VCR
-- PAQUETE DATOS FIJOS PRODUCTO 734
tron2000.ed_k_734_df
tron2000.ed_k_871_vcr
TRON2000.ED_K_416_VCR
TRP_XX_DL.EV_K_803_DV_VCR
TRP_XX_DL.ED_K_736_DV_VCR
-- PAQUETE DATOS VARIABLES PRODUCTO 734
TRP_XX_DL.ED_K_734_DV_VCR;

-- DATOS DEL ASEGURADO
SELECT * FROM X2000060_VCR

TRON2000.ed_k_734_ df

tron2000.ed_k_734_utils_vcr;
tron2000.ed_k_417_utils_vcr;.
tron2000.em_k_ptd_ine

tron2000.em_k_ptd_ter_vcr
TRP_XX_DL.em_k_ptd_ter_vcr
TRON2000.em_k_ptd_ter_vcr .p_v_blacklist

TRP_XX_DL.ed_k_734_utils_vcr;

SELECT * FROM A1001390;
SELECT * FROM A1001399;

--BLACKLIST
SELECT * FROM TRON2000.A1009031_VCR;

/**************************/

ed_k_734_ct



tron2000.trn_xx_dl

tron2000.ed_k_734_DV
TRP_XX_DL.ED_K_734_DV_VCR

select * from G9999991 

select * from g0200001;
select * from g0200002;

EV_K_901_DV_VI.p_ws_v_fec_nacimiento

EV_K_803_DV_VCR.p_ws_calc_anios_duracion_n

EM_K_BATCH.p_emite

trn_k_trace.

tron2000.trn_k_ptd.p_gen_comienzo_traza
tron2000.trn_k_ptd.p_gen_final_traza
select * from tron2000.t_trn_trn_r_dbg

tron2000.ev_k_901_dv_vcr.p_pre_cod_modalidad

TRN_K_PTD.P_GEN_COMIENZO_TRAZA
TRN_K_PTD.P_GEN_FINAL_TRAZA

-- Tablas pantallas
select * from g1010100;
select * from g1010210;
select * from g1010110;


-- tabla cotizaciones
select * from c2000000;

lo que est� como dato obligatorio en la g2000020 debe estar en la g0009020

select * from g2000010 where nom_campo like '%SEGURO%';
select * from g2000010 where cod_campo in (
'NUM_CTA_CTE_DC',
'NUM_CTA_CTE',
'COD_OFICINA_DEBITO') and cod_cia = 1;

SELECT * FROM TRON2000.B2500035

tron2000.EM_K_ATUALIZA_FCA_VCR
EM_K_ATUALIZA_FCA_VCR

select * from g2000020 where cod_campo LIKE '%FCA%' AND cod_ramo = 734 and cod_cia = 1;

select * from g2000020 where cod_campo like '%BACEN%' AND cod_ramo = 734 and cod_cia = 1 for update;

delete from g2000020 where cod_campo = 'TIP_FINALIDADE_BACEN' AND cod_ramo = 734 and cod_cia = 1;

insert into g2000020 (COD_CIA, COD_RAMO, COD_MODALIDAD, COD_COB, COD_AGR, FEC_VALIDEZ, TIP_NIVEL, NUM_SECU, COD_CAMPO, MCA_INH, MCA_VISIBLE, MCA_OBLIGATORIO, MCA_VALIDA_SI_NULL, MCA_MODALIDAD, MCA_CALCULO, MCA_PRESUPUESTO, MCA_SINI, MCA_UNICO, MCA_INSPEC, MCA_BUSCA_INSP, MCA_BUSCA_POR_IGUAL_INSP, MCA_SOLICITA_EN_COPIA, MCA_GRABA_RECHAZO, MCA_SUMA_ASEG, MCA_VALIDACION, MCA_VALIDACION_CIA, COD_USR, FEC_ACTU, TIP_REGULARIZA, TIP_REGULARIZA_ESP, PCT_REGULARIZA_ESP, COD_INDICE, NOM_PRG_REGULARIZA_ESP, NOM_PRG_PRE_CAMPO, VAL_DEFECTO, NOM_TABLA_VAL_DEFECTO, NOM_CAMPO_TABLA_VAL_DEFECTO, NOM_PGM_HELP, NOM_TABLA_VALIDA, COD_VERSION, NOM_GLOBAL_PGM_HELP, NOM_PRG_CAMPO, COD_LISTA, COD_TRANSPORTES, NUM_SECU_INSP, MCA_CASE_SENSITIVE, COD_PANEL, TIP_SUBNIVEL, TIP_DATO_FONDO, MCA_VLD_ONLINE, MCA_EXPORTAR_REA_EXT)
values (1, 734, 99999, 9999, 999, to_date('21-05-2019', 'dd-mm-yyyy'), 1, 27, 'TIP_FINALIDADE_BACEN', 'N', 'S', 'N', 'S', 'N', 'N', 'S', 'S', 'N', 'N', 'N', 'S', 'N', 'S', 'N', 'S', 'N', 'T_JULIAN', to_date('12-02-2017', 'dd-mm-yyyy'), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'N', null, null, null, 'N', null);


select * from g2000020 where cod_campo in (
'NUM_CTA_CTE_DC',
'NUM_CTA_CTE',
'COD_OFICINA_DEBITO') and cod_ramo = 734 and cod_cia = 1;

select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 2 order by num_secu for update;
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 1 order by COD_CAMPO DESC for update;

SELECT * FROM A1002150 WHERE COD_CIA = 1 AND COD_RAMO IN (417,734) ORDER BY COD_RAMO, NUM_SECU;

SELECT COD_COB FROM A1002150 WHERE COD_CIA = 1 AND COD_RAMO IN (417,734) ORDER BY COD_RAMO, NUM_SECU;

SELECT COD_COB FROM A1002150 WHERE COD_CIA = 1 AND COD_RAMO =734;

SELECT * FROM A1002150 WHERE COD_CIA = 1 AND COD_COB = 112 ORDER BY COD_RAMO DESC FOR UPDATE;

SELECT * FROM A1002150 WHERE COD_CIA = 1 and cod_ramo = 734 and cod_cob in(
112,194,405,406,407,762,869,962,972) for update;

SELECT SUBSTR (SYS_CONNECT_BY_PATH (COD_COB , ','), 2) csv
      FROM (SELECT COD_COB, ROW_NUMBER () OVER (ORDER BY COD_COB ) rn,
                   COUNT (*) OVER () cnt
              FROM A1002150
              WHERE COD_CIA = 1 AND COD_RAMO =734)
     WHERE rn = cnt
START WITH rn = 1
CONNECT BY rn = PRIOR rn + 1;

delete from g2000020 where cod_campo in (
'NUM_CTA_CTE_DC',
'NUM_CTA_CTE',
'COD_OFICINA_DEBITO') and cod_ramo = 734 and cod_cia = 1 and tip_nivel = 1;

select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 1 order by num_secu for update;
insert into g2000020 (COD_CIA, COD_RAMO, COD_MODALIDAD, COD_COB, COD_AGR, FEC_VALIDEZ, TIP_NIVEL, NUM_SECU, COD_CAMPO, MCA_INH, MCA_VISIBLE, MCA_OBLIGATORIO, MCA_VALIDA_SI_NULL, MCA_MODALIDAD, MCA_CALCULO, MCA_PRESUPUESTO, MCA_SINI, MCA_UNICO, MCA_INSPEC, MCA_BUSCA_INSP, MCA_BUSCA_POR_IGUAL_INSP, MCA_SOLICITA_EN_COPIA, MCA_GRABA_RECHAZO, MCA_SUMA_ASEG, MCA_VALIDACION, MCA_VALIDACION_CIA, COD_USR, FEC_ACTU, TIP_REGULARIZA, TIP_REGULARIZA_ESP, PCT_REGULARIZA_ESP, COD_INDICE, NOM_PRG_REGULARIZA_ESP, NOM_PRG_PRE_CAMPO, VAL_DEFECTO, NOM_TABLA_VAL_DEFECTO, NOM_CAMPO_TABLA_VAL_DEFECTO, NOM_PGM_HELP, NOM_TABLA_VALIDA, COD_VERSION, NOM_GLOBAL_PGM_HELP, NOM_PRG_CAMPO, COD_LISTA, COD_TRANSPORTES, NUM_SECU_INSP, MCA_CASE_SENSITIVE, COD_PANEL, TIP_SUBNIVEL, TIP_DATO_FONDO, MCA_VLD_ONLINE, MCA_EXPORTAR_REA_EXT)
values (1, 734, 99999, 9999, 999, to_date('01-06-2002', 'dd-mm-yyyy'), 1, 34, 'COD_OFICINA_DEBITO', 'N', 'S', 'S', 'N', 'N', 'N', 'N', 'S', 'N', 'N', 'N', 'S', 'N', 'S', 'N', 'N', 'N', 'VERA53', to_date('05-03-2003', 'dd-mm-yyyy'), null, null, null, null, null, 'EM_K_RAMO.P_PRECAMPO_DVS_DEBITO', null, null, null, 'AL000010', 'A1009015_VCR', 1, 'VLISTA_AGENCIA_VCR', 'EM_K_RAMO.P_VALIDA_COD_OFICINA_DEBITO', null, null, null, 'N', null, null, null, 'N', null);

insert into g2000020 (COD_CIA, COD_RAMO, COD_MODALIDAD, COD_COB, COD_AGR, FEC_VALIDEZ, TIP_NIVEL, NUM_SECU, COD_CAMPO, MCA_INH, MCA_VISIBLE, MCA_OBLIGATORIO, MCA_VALIDA_SI_NULL, MCA_MODALIDAD, MCA_CALCULO, MCA_PRESUPUESTO, MCA_SINI, MCA_UNICO, MCA_INSPEC, MCA_BUSCA_INSP, MCA_BUSCA_POR_IGUAL_INSP, MCA_SOLICITA_EN_COPIA, MCA_GRABA_RECHAZO, MCA_SUMA_ASEG, MCA_VALIDACION, MCA_VALIDACION_CIA, COD_USR, FEC_ACTU, TIP_REGULARIZA, TIP_REGULARIZA_ESP, PCT_REGULARIZA_ESP, COD_INDICE, NOM_PRG_REGULARIZA_ESP, NOM_PRG_PRE_CAMPO, VAL_DEFECTO, NOM_TABLA_VAL_DEFECTO, NOM_CAMPO_TABLA_VAL_DEFECTO, NOM_PGM_HELP, NOM_TABLA_VALIDA, COD_VERSION, NOM_GLOBAL_PGM_HELP, NOM_PRG_CAMPO, COD_LISTA, COD_TRANSPORTES, NUM_SECU_INSP, MCA_CASE_SENSITIVE, COD_PANEL, TIP_SUBNIVEL, TIP_DATO_FONDO, MCA_VLD_ONLINE, MCA_EXPORTAR_REA_EXT)
values (1, 734, 99999, 9999, 999, to_date('01-06-2002', 'dd-mm-yyyy'), 1, 35, 'NUM_CTA_CTE', 'N', 'S', 'S', 'N', 'N', 'N', 'N', 'S', 'N', 'N', 'N', 'S', 'N', 'S', 'N', 'N', 'N', 'VERA53', to_date('05-03-2003', 'dd-mm-yyyy'), null, null, null, null, null, 'EM_K_RAMO.P_PRECAMPO_DVS_DEBITO', null, null, null, 'AL000010', 'A1009015_VCR', 2, 'VLISTA_CTA_VCR', 'EM_K_RAMO.P_VALIDA_NUM_CTA_CTE', null, null, null, 'N', null, null, null, 'N', null);

insert into g2000020 (COD_CIA, COD_RAMO, COD_MODALIDAD, COD_COB, COD_AGR, FEC_VALIDEZ, TIP_NIVEL, NUM_SECU, COD_CAMPO, MCA_INH, MCA_VISIBLE, MCA_OBLIGATORIO, MCA_VALIDA_SI_NULL, MCA_MODALIDAD, MCA_CALCULO, MCA_PRESUPUESTO, MCA_SINI, MCA_UNICO, MCA_INSPEC, MCA_BUSCA_INSP, MCA_BUSCA_POR_IGUAL_INSP, MCA_SOLICITA_EN_COPIA, MCA_GRABA_RECHAZO, MCA_SUMA_ASEG, MCA_VALIDACION, MCA_VALIDACION_CIA, COD_USR, FEC_ACTU, TIP_REGULARIZA, TIP_REGULARIZA_ESP, PCT_REGULARIZA_ESP, COD_INDICE, NOM_PRG_REGULARIZA_ESP, NOM_PRG_PRE_CAMPO, VAL_DEFECTO, NOM_TABLA_VAL_DEFECTO, NOM_CAMPO_TABLA_VAL_DEFECTO, NOM_PGM_HELP, NOM_TABLA_VALIDA, COD_VERSION, NOM_GLOBAL_PGM_HELP, NOM_PRG_CAMPO, COD_LISTA, COD_TRANSPORTES, NUM_SECU_INSP, MCA_CASE_SENSITIVE, COD_PANEL, TIP_SUBNIVEL, TIP_DATO_FONDO, MCA_VLD_ONLINE, MCA_EXPORTAR_REA_EXT)
values (1, 734, 99999, 9999, 999, to_date('01-06-2002', 'dd-mm-yyyy'), 1, 36, 'NUM_CTA_CTE_DC', 'N', 'S', 'S', 'N', 'N', 'N', 'N', 'S', 'N', 'N', 'N', 'S', 'N', 'S', 'N', 'N', 'N', 'VERA53', to_date('05-03-2003', 'dd-mm-yyyy'), null, null, null, null, null, 'EM_K_RAMO.P_PRECAMPO_DVS_DEBITO', null, null, null, 'AL000010', 'A1009015_VCR', 2, 'VLISTA_CTA_DG_VCR', 'EM_K_RAMO.P_VALIDA_NUM_CTA_CTE_DC', null, null, null, 'N', null, null, null, 'N', null);



-- Background
select * from xbackground;
delete from xbackground where cod_marco = 734;

select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 2 order by num_secu;

select cod_campo from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 2 order by num_secu;
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 1 order by num_secu FOR UPDATE;
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 2 order by num_secu FOR UPDATE;

SELECT * FROM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO NOT IN (SELECT COD_campo from g2000010);

select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and tip_nivel = 3 order by num_secu FOR UPDATE;
select * from g2000010 where cod_campo = 'BAIRRO'
select * from g2000010 where cod_campo LIKE '%ESTADO%'
COD_BAIRRO_VCR
NOM_BAIRRO
NOM_CIDADE_ESTADO

select * from A1001402 where cod_cia = 1;
select * from A1001403 where cod_cia = 1 and cod_ramo = 734;
select * from A1001410 where cod_cia = 1;
select * from A1001420 where cod_cia = 1;
select * from A1001430 where cod_cia = 1  and cod_ramo in (417, 734); 
select * from A1001342 where cod_cia = 1;

tron2000.TS_K_A7009118_VCR_CURSORES_VCR
tron2000.GC_K_RECIBOS_DOMI_TRN
        SELECT *
          FROM a7009118_vcr
         WHERE cod_cia = g_cod_cia
           AND mca_situacao_vcr = 'C'
           AND tip_gestor = 'BA';

select * from a5020200;
a5020200


select *
from all_source
where owner = 'TRON2000'
AND lower(TEXT) LIKE '%gestor = ''db%';

select * from a2000030 where cod_cia = 1 and cod_ramo =734;

select * from g2000020 where cod_cia = 1 and cod_ramo = 734;

select
       substr(a.spid,1,9) pid,
       substr(b.sid,1,5) sid,
       substr(b.serial#,1,5) ser#,
       substr(b.machine,1,6) box,
       substr(b.username,1,10) username,
--       b.server,
       substr(b.osuser,1,8) os_user,
       substr(b.program,1,30) program
from v$session b, v$process a
where
b.paddr = a.addr
and type='USER'
order by spid; 

tron2000.trn_x_global line 288

tron2000.trn_k_global
-- Tablas migracion
A1001800,A1001801,A1002090,A1002091,A1009039_VCR,A2009048_VCR,G2000010,G2000020,G2990006,A1002150,G2000180,G2000190,DF_CMN_NWT_XX_CNN,df_cmn_nwt_xx_vrb_cnc,
G2000030,G2990005,A1001403,A2100300,A1001750,G2000020,A2990560,A2990565,A2990570,A2109035_VCR

select * from A2109035_VCR where cod_cia = 1 and cod_ramo = 734;
select * from A2990570 where cod_cia = 1 and cod_ramo = 734;
delete from  A2990570 where cod_cia = 1 and cod_ramo = 734;
select * from A2990565 where cod_cia = 1 and cod_ramo = 734;
delete from A2990565 where cod_cia = 1 and cod_ramo = 734;
select * from A2990560 where cod_cia = 1 and cod_ramo = 734;
delete from A2990560 where cod_cia = 1 and cod_ramo = 734;
select * from G2000020 where cod_cia = 1 and cod_ramo = 734;
delete  from G2000020 where cod_cia = 1 and cod_ramo = 734;
select * from A1001750 where cod_cia = 1 and cod_ramo = 734;
delete from A1001750 where cod_cia = 1 and cod_ramo = 734;
select * from A2100300 where cod_cia = 1 and cod_ramo = 734;
delete from A2100300 where cod_cia = 1 and cod_ramo = 734;
select * from G2000200 where cod_cia = 1 and cod_ramo = 734;
delete from G2000200 where cod_cia = 1 and cod_ramo = 734;
select * from A1001403 where cod_cia = 1 and cod_ramo = 734;
delete from A1001403 where cod_cia = 1 and cod_ramo = 734;
select * from G2990005 where cod_cia = 1 and cod_ramo = 734;
delete from G2990005 where cod_cia = 1 and cod_ramo = 734;
select * from G2000030 where cod_cia = 1 and cod_ramo = 734;
delete from G2000030 where cod_cia = 1 and cod_ramo = 734;
select * from G2000190 where cod_cia = 1 and cod_ramo = 734;
delete from G2000190 where cod_cia = 1 and cod_ramo = 734;
select * from G2000180 where cod_cia = 1 and cod_ramo = 734;
delete from G2000180 where cod_cia = 1 and cod_ramo = 734;
select * from A1002150 where cod_cia = 1 and cod_ramo = 734;
delete from A1002150 where cod_cia = 1 and cod_ramo = 734;
select * from G2990006 where cod_cia = 1 and cod_ramo = 734;
delete from G2990006 where cod_cia = 1 and cod_ramo = 734;
select * from A2009048_VCR where cod_cia = 1 and cod_ramo = 734;
delete from A2009048_VCR where cod_cia = 1 and cod_ramo = 734;
select * from A1009039_VCR where cod_cia = 1 and cod_ramo = 734;
delete from A1009039_VCR where cod_cia = 1 and cod_ramo = 734;
select * from A1002091 where cod_cia = 1 and cod_ramo = 734;
delete from A1002091 where cod_cia = 1 and cod_ramo = 734;
select * from A1002090 where cod_cia = 1 and cod_ramo = 734;
delete from A1002090 where cod_cia = 1 and cod_ramo = 734;
select * from A1001801 where cod_cia = 1 and cod_ramo = 734;
delete from A1001801 where cod_cia = 1 and cod_ramo = 734;
select * from A1001800 where cod_cia = 1 and cod_ramo = 734;
delete from A1001800 where cod_cia = 1 and cod_ramo = 734;


select * from trazas_mpr;

-- Background
select * from xbackground;
delete from xbackground where cod_marco = 734;

INSERT INTO a1001800 (cod_cia,cod_sector,cod_subsector,cod_ramo,nom_ramo,abr_ramo,mca_clausula,mca_anexo,mca_prorrata,mca_cambia_prorrata,mca_riesgos,mca_periodos,mca_recibo_por_periodo,mca_emision,mca_cambio_nivel_3,mca_calcula_fracc_pago,mca_spto_en_plan_pago,mca_cambio_plan_pago,mca_certificados,mca_inh,mca_comis_coa_ext,mca_365_dias,mca_obliga_presupuesto,mca_autoriza_presupuesto,mca_cambio_num_poliza,mca_cambio_num_poliza_apli,mca_val_stro_en_spto,mca_remesa_recibo,mca_recibo_manual,mca_comis_manual,mca_busca_insp_emision,mca_emision_sin_recibo,mca_reutiliza_presupuesto,mca_reutiliza_declaracion,mca_aplica_at_en_riesgo,tip_coaseguro_permitido,mca_cuadro_coaseguro_obl,tip_primas_manuales,num_agt,num_riesgos_traspaso_directo,num_riesgos_impresion,nom_prg_riesgo,tip_formacion_modalidad,cod_usr,fec_actu,nom_prg_busca_insp_emision,cod_tratamiento,cod_tratamiento_sini,cod_tratamiento_ctable,nom_prg_emision_sin_recibo,cod_proceso,cod_proceso_p,cod_proceso_r,cod_est_dv_poliza,cod_est_riesgo,cod_est_modalidad,cod_est_accesorios,cod_est_plan_pago,cod_est_inspec,nom_prg_coef_cob,nom_prg_busca_insp,nom_prg_excluye_insp,tip_dst_comis,nom_prg_dst_comis,nom_prg_remesa_recibo,mca_mod_org_ase,mca_mod_com_cuota_interv,mca_rechazo_susp_a_todos,mca_recalcula_comis,mca_registra_hora,tip_rea_permitido,mca_tasa_manual,mca_des_por_riesgo_batch,mca_motivos_spto,tip_acceso_com,mca_rechaza_suspende_apli,nom_prg_spto_plan_pago,mca_ct_en_anulacion_sptos,mca_cuenta_2902_tmp,mca_respeta_dia_vcto,mca_anexo_ries,mca_regenera_sptos_ct,tip_formacion_imagen,mca_error_aviso_stro,mca_val_stro_term_en_spto,mca_error_aviso_stro_term,mca_comis_cartera,nom_prg_cobro_recibo,mca_modifica_cambio,nom_prg_valida_cambio,mca_val_fec_emision_estandar,nom_prg_val_fec_emi_estandar,mca_tip_anexo,mca_caucion,mca_gestion_fondo,mca_cal_imp_cob,mca_rea_externo,mca_crea_error_emi,mca_crea_error_sin,mca_copia_anexos_desde_ppto,mca_multi_idioma_anexo,mca_psypd,nom_prg_psypd)
VALUES (1,30,30,734,'MULTIRRISCO RURAL','MPRRS','N','S','S','S','S','N','N','S','S','S','S','S','N','N','N','S','N','N','S','N','N','N','N','N','N','N','S','S','N',0,'N','1',4,99999,99999,'EM_K_ASIGNA_NOM_RIESGO.P_ASIGNA_NOM_RIESGO_GENER','1','PVELASQU',TRUNC(SYSDATE),NULL,'D','D','D',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,'S','N','N','N','N',0,'N','N','S','1','N',NULL,'N',NULL,NULL,'N','N','1','N','N','N','N',NULL,'N',NULL,'S',NULL,'N','N',NULL,NULL,NULL,NULL,NULL,'N','N','N',NULL);

  INSERT INTO a2990560 (cod_cia,cod_sector,cod_ramo,cod_nivel1,cod_nivel2,cod_nivel3,num_secu_desde,num_secu_hasta,num_reserva_desde,num_reserva_hasta,cod_usr,fec_actu)
VALUES (1,30,734,0,0,0,1,99999999,1,1800,'JOSPINA',TRUNC(SYSDATE));


-- Tablas consulta backup
select * from A1001800 where cod_cia = 1 and cod_ramo = 734 for update;-- ok ya cambiado
select * from A1001800 where cod_cia = 1 and cod_ramo = 734;
select * from A1001801 where cod_cia = 1 and cod_ramo = 734 for update;--ok ya cambiado
select * from A1001801 where cod_cia = 1 and cod_ramo in ( 734,417);
select * from A1002090 where cod_cia = 1 and cod_ramo in ( 734,417); -- ok ya cambiado
select * from A1002091 where cod_cia = 1 and cod_ramo in ( 734,417); -- ok ya cambiado
select * from A1009038_VCR where cod_cia = 1 and cod_ramo in ( 734,417);
select * from A1009039_VCR where cod_cia = 1 and cod_ramo = 736 for update; -- ok ya cambiado
select * from A2009048_VCR where cod_cia = 1 and cod_ramo = 736 for update; -- ERROR
update A2009048_VCR set cod_ramo = 734 where cod_ramo = 736;
delete from A2009048_VCR where cod_ramo = 736;
-- Background
select * from xbackground;
delete from xbackground where cod_marco = 734;

select * from A2990560 where cod_ramo in (417, 734) for update;

select *
from all_tab_columns
where owner = 'TRON2000'
AND COLUMN_NAME = 'TIP_GESTOR';


insert into A2009048_VCR (COD_CIA, COD_SECTOR, COD_RAMO, COD_NIVEL3, COD_AGT, NUM_CONTRATO, MCA_VIGENTE, FEC_VIG_INI_VCR, FEC_FIN_VIG_VCR, COD_USR, FEC_ACTU, MCA_VIGENTE_TW_VCR, MCA_COMPLETO, MCA_SUB_RISCO_VCR, MCA_TW_TOTAL, MCA_CIRCULAR_326, MCA_CARTA_SINISTRO)
values (1, 30, 734, 9998, 99998, 99998, 'S', to_date('01-01-2018', 'dd-mm-yyyy'), to_date('31-12-1950', 'dd-mm-yyyy'), 'T_ROSANA', to_date('27-07-2021', 'dd-mm-yyyy'), 'S', 'S', 'S', 'S', null, 'S');

-- controles tecnicos
validacion que se dispara en diferentes momentos, (cotizacion p_calcular)
disparar con un control tecnico de rechazo con el bot�n terminar.
tron2000.DC_P_CT_190_VCR
G2000211	Definicion de los errores de Control Tecnico
select * from G2000210 where cod_cia = 1 and cod_error = 190;	--Definicion de Controles Tecnicos a Nivel de Compa��a
select * from G2000200 where cod_ramo = 417;
select * from G2000200 where cod_ramo = 901; -- este tiene codigo
select * from G2000200 where cod_ramo = 734 for update;
select * from G2000200 where nom_prg = 'DC_P_CT_190_VCR';
ED_K_734_CT;
EV_K_901_CT
TRP_XX_DL.ED_K_734_CT_VCR;
TRP_XX_DL.ED_K_417_CT_VCR;
EV_K_901_CT;
ED_K_417_CT.P_TERMINAR --CUANDO SE DA AL BOTON TERMINAR?
G2000200	Definicion de Controles Tecnicos a Nivel de Ramo
select * from tron2000.G2999017_vcr	--Definicion de Controles Tecnicos por Ramo y Cobertura

select * from G2000200 where cod_ramo in(417, 734) for update;
select * from G2000200 where cod_ramo = 417;
select * from G2000200 where cod_ramo =734;
DELETE FROM G2000200 WHERE COD_RAMO = 734;


select * from G2000010-- se renombro la descripcion de los dv ojo
select * from G2000020 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from G2990006 where cod_cia = 1 and cod_ramo = 736 for update; -- ok  YA CAMBIADO
select * from A1002150 where cod_cia = 1 and cod_ramo = 736 for update; -- ok ya cambiado
select * from G2000180 where cod_cia = 1 and cod_ramo = 736 for update; -- ok ya cambiado
select * from G2000190 where cod_cia = 1 and cod_ramo = 736 for update; -- ok ya cambiado
select * from DF_CMN_NWT_XX_CNN-- no
select * from df_cmn_nwt_xx_vrb_cnc--no
select * from G2000030 where cod_cia = 1 and cod_ramo = 736 for update; -- ok ya cambiado
select * from G2990005 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from A1001403 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from A2100300 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from A1001750 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from A2990560 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from A2990565 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from A2990570 where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO
select * from A2109035_VCR where cod_cia = 1 and cod_ramo = 736 for update; -- ok YA CAMBIADO

select * from G2000030 where cod_cia = 1 and cod_ramo = 734; -- ok ya cambiado
select * from G2990005 where cod_cia = 1 and cod_ramo = 734; -- ok YA CAMBIADO
select * from A1001403 where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO
select * from A2100300 where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO
select * from A1001750 where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO
select * from A2990560 where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO
select * from A2990565 where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO
select * from A2990570 where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO
select * from A2109035_VCR where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO


select * from A1001800-- no se modifica
select * from A1001801 where cod_cia = 1 and cod_ramo  IN(417, 734) for update;--ok
select * from A1002090 where cod_cia = 1 and cod_ramo IN(417, 734) for update;--ok
select * from A1002091 where cod_cia = 1 and cod_ramo IN(417, 734) for update;--ok
tron2000.DC_K_CT_900_VCR
tron2000.DC_K_AC999004_TRN
tron2000.GC_T_A9989010_VCR

select * from a1001403 where cod_cia = 1 and cod_ramo in (417, 734);

select * from A1001800 where cod_ramo in (734,736) for update;

SELECT 
       distinct(       ac.name)
       /*ac.owner "USUARIO DUENIO",
       ac.name  "NOMBRE PAQUETE",
       ac.type  "TIPO PAQUETE"  ,
       ac.line  "LINEA"         ,
       ac.text  "TEXTO COMPLETO"*/
  FROM all_source ac
 WHERE LOWER(ac.text) LIKE LOWER('% 15 %')
   AND UPPER(ac.owner) LIKE UPPER('%TRON2000%')
 ORDER BY ac.name,
          ac.type,
          ac.line;

AS999001

TRON2000.TRN_K_GLOBAL

select * from A1009039_VCR where cod_cia = 1 and cod_ramo = 734 for update; -- ok
select * from A2009048_VCR where cod_cia = 1 and cod_ramo IN(417, 734); -- ok YA CAMBIADO




-- Resetear contrasenia tronweb
SELECT a.*,ROWID FROM g1010108 a where cod_saptron = 'RURQUIJO' for update;

select * from G2000211;
select * from G2000210;
select * from G2000200;
select * from G2999017_vcr;

select * from g2000200 where cod_cia = 1 and cod_ramo = 734;

ED_K_417_CT.P_DATOS_FIJOS
ed_k_417

-- Background
select * from xbackground;
delete from xbackground where cod_marco = 734;


a1002150 y revise quiz�s la de desgloses g2000180 y g2000190

select * from a1002150 where cod_cia = 1 and cod_ramo = 734;
select * from g2000180 where cod_cia = 1 and cod_ramo in (417, 734);
select * from g2000190 where cod_cia = 1 and cod_ramo in (417, 734);

select * from g2000200 where cod_cia = 1 and cod_ramo = 734;

select * from g2000200 where cod_cia = 1 and cod_ramo in (417, 734);

  INSERT INTO g2990005 (cod_cia,cod_ramo,cod_mon,mca_mon_def,num_decimales_primas,num_decimales_recibos,num_decimales_comisiones,imp_prima_minima,fec_validez,cod_usr,fec_actu,imp_prima_maxima)
VALUES (1,734,1,'N',2,2,2,-999999,TO_DATE('01012019', 'DDMMYYYY'),'NTRIANA',TRUNC(SYSDATE),NULL);

TRON2000.EM_K_AP200000_VCR

select * from A2990565 where cod_cia = 1 and cod_ramo in (417, 734);

select * from g2990300 where cod_cia = 1 and cod_ramo = 734;

select * from A2990560 where cod_cia = 1 and cod_ramo in (417, 734);
select * from A2990570  where cod_cia = 1 and cod_ramo in (417, 734);

select * from a2999023_vcr where num_poliza = '7342100001802';
select * from a2999023_vcr where trunc(fec_actu) = to_date('09/01/2021','mm/dd/rrrr');
select * from a2999023_vcr order by fec_actu desc;

select * from g2990016 where cod_cia = 1;
select * from a5020058
select * from a2000032
select * from a1001800 where cod_cia = 1 and cod_ramo = 734;
a2000032


-- dv
select * from g2000020 where cod_cia =1 and cod_ramo = 736;
select * from g2000020 where cod_cia =1 and cod_ramo = 736 for update;

-- Tabla test
select * from tron2000.x1009999_vcr where txt_tarefa = 125;
select * from tron2000.x1009999_vcr where txt_tarefa = 125 for update;

-- Created on 5/12/2020 by SSGOMEZ 
declare 
  -- Local variables here
  i integer;
begin
  -- Test statements here
  tron2000.dc_k_exporta_dados_vcr.p_inicio(p_FEC_TRATAMIENTO => TO_DATE ('06182021' , 'MMDDYYYY') ,
                                           p_txt_tarefa => '125' ) ; 
end;

-- Background
select *                              from xbackground;
delete from xbackground where cod_marco = 734;


/************************************************** ayudas jorge mario echeverry ***************************** */
poner traza 
SELECT * FROM TRAZAS_MPR WHERE COD_TRAZA = 'MY' ORDER BY ID_TRAZA DESC;
DELETE FROM TRAZAS_MPR WHERE COD_TRAZA = 'MY' ;
|dc_p_trazas_mpr ('JGG', 'XXXXXX => ' || NULL);

PTD
SELECT * FROM tron2000.t_trn_trn_r_dbg
delete from tron2000.t_trn_trn_r_dbg where pgm_nam='ed_k_417_dv'
trn_k_ptd.p_gen_traza_variable('p_val_pacotes', 'l_tip_relac', l_tip_relac);
Trn_k_ptd.p_habilita_traza(p_idn_traza => 'PTD');

em_k_ptd_atr.p_asg_mca_salto(p_mca_salto => l_mca_salto);

trn_k_ptd.p_gen_error (p_cod_idioma  => l_cod_idioma              ,
                                                 p_cod_mensaje => 20095619                  ,
                                                 p_t_valores   => trn_k_ptd.t_t_valores_aux ,
                                                 p_pre_mensaje => NULL                      ,
                                                 p_pos_mensaje => NULL   





SE                                               ,
                                                ev_k_901_dvLECT *  FROM G1010310;   ---TABLAS DE AYUDA
SELECT  * FROM G1010300;   ---TABAL�AS DE AYUDA
G1010020=tabla de mensajes
G2000210=mensaje error control tecnico
SELECT * FROM G1010031 WHERE COD_CAMPO='TIP_NIVEL'--ver los datos variables a que nivel estan
--VER LOS DATOS AVRIABLES ASOCIADOS A LA COBERTURA
SELECT * FROM G2000010 WHERE COD_CAMPO='VAL_CAPITAL_INMOVILIDAD';   -- etiquetas
SELECT * FROM G2000020 WHERE COD_COB=8113;
SELECT  * FROM G2990006 WHERE COD_CAMPO='VAL_CAPITAL_INMOVILIDAD';
SELECT * FROM a1000510 WHERE cod_mon=14 ORDER BY  fec_cambio DESC; --tasas de cambio
RE2000030  -- TABLA DE POLIZAS RECHAZADAS POR CT

SELECT * FROM G1010031 WHERE COD_CAMPO = 'TIP_PRIMAS_MANUALES';---ayudas por campos

en  C/local/scripts... escritorio  remoto encuentro los scrips

tablas principales

a2000020 datos variables 
g2000020 par�metros datos variables
a2000030 datos fijos 
a2000031 datos de los riesgos 
a1001331 terceros 
A1000710
A1001332 agentes
A1001342
A1001399 = nombre tercero 
a1001332 
a1001390 nombres de los terceros
a2000040 datos coberturas por poliza 
a2000060 datos terceros por poliza 
a1002150 conf coberturas por ramo 
g2000200 controles t�cnicos por paquetes 
a1009012_mgt  Objetos de reportes
G2990004 = Modalidades Cia
A2100300 = Modalidades por Ramo
A2300101 = Tabla Principal de Modalidades Vida
A2300102 = Coberturas por Modalidad
TA299020_MUY = Planes por Modalidad
A2990700 Recibos
A5020301 Historico Recibos
G2000020 = Datos Variables a nivel poliza, Riesgo, Cobertura
G2999009_MUY = Salto de campos por Modalidad
A1002150 = Coberturas por Ramo y Modalidad
G2000170=Conceptos de desglose a Nivel compa��a
A2100170 = Conceptos de desglose asociados a polizas
G2000180 = Conceptos de desglose por ramo
G2000190 = Modificaci�n de desglose por ramo
g2999003_mgt definir campos
G0200001Tareas o programas
G1010020=tabla de mensajes
G2000210=mensaje error control tecnico
G1010020  = TABLA DE MENSAJES
G2990006 = TABLA DE AYUDA(POSIBLE VALORES QUE PUEDE TOMAR UN DV)
a1002090 =  mca obligatorio modalidad->cobertura
g1010300 = ayudas 
g1010310 = ayudas
clausulas = a9990010
g1010031 = tabal de ayuda de busqeuda de campos
G1010021 =TOLTIPS
g2000275  = dv que se dejan modificr en endosos 
a1009039_vcr = configuracion del impuesto
G2990019 =  dv a nivel de pol grupo}
a2000400 = Motivos suplementos 
G2990300 = suplementos 
a1009039_vcr= Veronica 
A1002091 = Modalidad /cobertura 
a1002200 = cada actividad tercero-> se define estructura y pantalla
G2000260 = Dar permisos para autorizar CT
g2000230 = Dar permisos para autorizar CT
g2990005 = Monedas y decimasles
a2000221 = controles tecnicos
G2000210 = ct (observacion,)
x2000025 = tipo lista 
Recordar las particiones al moemento de instalar ramos en brasil
G2000161 = conceptos economicos
a1001320 = terceros no deseados
a1001600 = cmabiar fechas proceso
g1002000 = ramo contable
SELECT owner,
       decode(partition_name,
              NULL,
              segment_name,
              segment_name || ':' || partition_name) NAME,
       segment_type,
       tablespace_name,
       bytes,
            initial_extent ,
       ne     ,
       ev_k_901_dvxt_extent,
       pct_increase,
       extents,
       max_extents
  FROM dba_segments
 WHERE 1 = 1
   --AND extents > 1
   AND owner = 'TRON2000'
   AND partition_name IS NOT NULL
   AND segment_type = 'TABLE PARTITION'
   AND partition_name LIKE '%417%'
 ORDER BY 2;
/opt/apache-tomcat-6.0.26/webapps/wtw_reports/WEB-INF/classes/com/mapfre/msv/jrp

Guatemala
/opt/apache-tomcat-6.0.26/webapps/wtw_reports/WEB-INF/classes/com/mapfre/mgt/jrp/gc

/opt/tomcat6/gt/apache-tomcat-6.0.53/webapps/wtw_reports/WEB-INF/classes/com/mapfre/mgt/jrp





-----------------------------------------------------------


(seenoevil)

SELECT owner,
       decode(partition_name,
              NULL,
              segment_name,
              segment_name || ':' || partition_name) NAME,
       segment_type,
       tablespace_name,
       bytes,
       initial_extent,
       next_extent,
       pct_increase,
       extents,
       max_extents
  FROM dba_segments
 WHERE 1 = 1
   --AND extents > 1
   AND owner = 'TRON2000'
   AND partition_name IS NOT NULL
   AND segment_type = 'TABLE PARTITION'
   AND partition_name LIKE '%417%'
 ORDER BY 2;

endososos--suplementos
C�sar, 10:00 a.m.
SELECT * FROM DF_CMN_NWT_XX_VRB_CNC WHERE cmp_val = 1 and vrb_nam = 'COD_SUB_COD_SPTO' and lob_val in(418) FOR UPDATE;--motivos 
SELECT * FROM G2990300 WHERE COD_CIA = 1 AND cod_Ramo= 417;--motivos 
SELECT * FROM G2000030 WHERE cod_cia= 1 AND cod_Ramo=417;--ok
SELECT * FROM g2000275 WHERE cod_cia= 1;--dvs para endosso


precondiciones endoso de restitucion

juan, 2:40 p.m.
Para poder hacer pruebas se debe de realizar cambios en recibos para dejarlos pagados y poder realizar la restitucion.

SELECT * FROM a2990700 WHERE num_poliza = '3354000019291' --> Cambiar algunos tip_situacion = CT;
SELECT * FROM a5029102_vcr WHERE num_poliza = '3354000019291' --> Cambiar algunos mca_proceso_vcr = N relacionarlos con la a2990700 por num_spto;

 a1009039_VCR-> impuesto brasil

coprcims3  CiM$tRon#0#0
