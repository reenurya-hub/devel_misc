-- Tabla general de Terceros 
select * from A1001399;

-- Definicion de ramo
select * from a1001800 where cod_cia = 1 and cod_ramo = 736;

-- Terceros comunes
select * from A1001801 where cod_cia = 1 and cod_ramo = 736;

-- TABLA DE CONTRATOS ASOCIADOS A POLIZA GRUPO.  Fecha Ven
select *from A2000010 where num_poliza IN ('736000006667'); 
