select * from corpp0.a1001800 where cod_cia = 1 and cod_ramo = 901;
select max(cod_mensaje) from corpp0.g1010020;
select * from corpp0.g2000020 where cod_cia = 1 and cod_ramo =734 order by tip_nivel, num_secu
