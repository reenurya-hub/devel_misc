select * from a2000020;


select * from all_tab_partititions;
