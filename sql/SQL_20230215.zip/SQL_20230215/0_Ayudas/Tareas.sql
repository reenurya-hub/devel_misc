-- Tablas de ejecuci�n de tareas.
select * from g0200001;
select * from g0200002;
