select * from all_source where owner = 'TRON2000'; -- para ver solo las columnas del all_source
--
SELECT /* * */
    --distinct(name)
    owner, NAME, LINE, TEXT, TYPE
    FROM ALL_SOURCE
   WHERE 1 = 1
     --AND OWNER = 'TRP_XX_DL'
     --AND OWNER IN ('TRP_XX_DL','TRON2000')
     --AND lower(NAME) LIKE '%dc_k_a1001331.p_lee%'
     --AND TYPE NOT IN ('FUNCTION', 'PROCEDURE', 'TRIGGER') 
     --AND TYPE IN ('PROCEDURE') 
     --AND TYPE = 'PACKAGE BODY'
     --AND TEXT LIKE '%TS_K_AP700043.p_query%'
     AND lower(TEXT) LIKE '%00/100%'
     --AND LOWER(NAME) LIKE '%jbcod_spto_as%'
     --AND upper(NAME) LIKE '%em_k_a2992131%'
   ORDER BY NAME, LINE;
--
--
SELECT * --distinct(NAME)
    FROM ALL_SOURCE
   WHERE 1 = 1
     --AND OWNER = 'TRP_XX_DL'
     --AND OWNER IN ('TRP_XX_DL','TRON2000')
     --AND LOWER(NAME) LIKE '%ed_k_734_utils_vcr%'
     --AND LOWER(TEXT) LIKE '%ed_k_734_utils_vcr%'
     --AND TYPE = 'PACKAGE BODY';
     AND TYPE = 'SYNONYM';

-- ALL_TAB_COLUMNS
select *
from all_tab_columns
where owner = 'TRON2000'
AND COLUMN_NAME = 'TIP_GESTOR';
