beginningDateTermInsurance: corresponde con la fecha de inicio de vigencia del Seguro de Vida >> 
P2000030 (fec_efec_spto, fec_efec_poliza)


endDateTermInsurance: corresponde con la fecha de vencimiento de la vigencia del Seguro de Vida >> 
P2000030 (fec_vcto_spto, fec_vcto_poliza)

 
insuranceContractingDate: corresponde con la fecha de contrataci�n del seguro >> puede usarse para cargar 
P2000030 (fec_emision, fec_emision_spto), sin embargo Tron no utiliza estos datos y finalmente tomar� fec_emision = fec_emision_spto = a1001600.fec_proc_emi.  Por consiguiente, este dato debe cargarse en el dato variable FEC_CONTRATACAO, es decir, en la tabla P2000020 (cod_campo = 'FEC_CONTRATACAO')


en principio no es procedente esa validaci�n porque Tron no va a tener en cuenta esa fecha que viene en 
starTermIns de la cobertura.  Tron generar� los recibos/parcelas a partir de la fec_efec_spto en adelante 
y nunca con una fecha retroactiva o anterior a la fec_efec_spto

 
De hecho, la starTermIns ni siguiera se debe estar cargando en alguna tabla (confirmar con Accenture 
en qu� tabla est�n poniendo esa fecha)


Lo anterior es lo que hace Tron por default, sin embargo, como saben, finalizando la emisi�n, 
el plan de pago puede llegar a alterar las fechas de efecto y vcto de los recibos/parcelas.  
Por otra parte, existe de forma personalizada la rutina EM_K_FEC_VCTO_PAGO_VCR.P_FEC_VCTO_PAGO en la tabla 
del post grabar g2990016 en donde tambi�n se est�n alterando las fechas 
