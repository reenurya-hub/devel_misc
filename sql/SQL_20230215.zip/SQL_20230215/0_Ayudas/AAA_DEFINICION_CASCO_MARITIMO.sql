DEFINICIONES DEL PRODUCTO DE CASCO MARITIMO


Nombre del producto:     CASCO MAR�TIMO
C�digo del producto:    260 
Tratamiento:            Generales
Sector:       2 Diversos 
Subsector:      26 Cascos 
Colectivo:                                  Si
P�liza grupo:                            Si
Duraci�n mayor a un a�o:     No
Hojas anexas:                           Si
Clausulas:                                  Si
Multiriesgo:                              Si
M�ximo de agentes:               4

COD_CIA =2
COD_RAMO = 260 -- CASCO MARITIMO
COD_RAMO = 210 -- DINERO Y VALORES
COD_RAMO = 228 -- FAMILIA HOGAR SEGURO
cod_cia = 2 
cod_ramo = 260
num_poliza = 2602000004347
COD_AGT = 3040
cod_moneda = 1 
