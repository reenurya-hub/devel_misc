-- TAREA A LANZAR
SELECT * FROM G0200001;

-- OPCIONES DE TAREA
select * from g1010131 where cod_pgm = 'AP020012';
