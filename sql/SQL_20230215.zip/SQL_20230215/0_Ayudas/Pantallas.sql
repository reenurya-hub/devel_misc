-- Tablas pantallas
select * from g1010100;
select * from g1010210;
select * from g1010110;
