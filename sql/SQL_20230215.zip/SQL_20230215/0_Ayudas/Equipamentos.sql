para las ayudas nuevas de tablas nuevas se usan las tablas
G1010300
G1010310
SELECT * FROM G1010300 WHERE NOM_TABLA = 'g2009072_VCR';
SELECT * FROM G1010310 WHERE NOM_TABLA = 'g2009071_VCR';


SELECT * FROM g2009070_vcr ;--(Agrupacion equipamento)
SELECT * FROM g2009071_vcr ;--(Clases )
SELECT * FROM g2009072_vcr ;--(Equipamentos)
SELECT * FROM g2009073_vcr ;

select * from g1010310 where nom_tabla = 'G2009071_VCR' ;
select * from g1010300 where nom_tabla = 'G2009071_VCR' ;
select * from g1010310 where nom_tabla = 'G2009072_VCR' ;
select * from g1010300 where nom_tabla = 'G2009072_VCR' ;
