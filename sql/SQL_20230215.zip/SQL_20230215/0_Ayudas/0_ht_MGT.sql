COD_CIA =2
COD_RAMO = 260 -- CASCO MARITIMO
COD_RAMO = 210 -- DINERO Y VALORES
COD_RAMO = 228 -- FAMILIA HOGAR SEGURO
cod_cia = 2 
cod_ramo = 260
num_poliza = 2602000004347
COD_AGT = 3040
cod_moneda = 1 

-- background
SELECT * FROM xbackground
delete from xbackground where COD_CIA = 2 AND cod_marco = '228'; -- x2000040 cod_marco del producto
COMMIT;

COD_CIA =2
COD_RAMO = 260 -- CASCO MARITIMO
COD_RAMO = 210 -- DINERO Y VALORES
COD_RAMO = 228 -- FAMILIA HOGAR SEGURO
cod_cia = 2 
cod_ramo = 260
num_poliza = 2602000004347
COD_AGT = 3040
cod_moneda = 1 

-- background
SELECT * FROM xbackground
delete from xbackground where COD_CIA = 2 AND cod_marco = '228'; -- x2000040 cod_marco del producto
COMMIT;

-- mnemotecnicos
select * from g2999003_mgt where cod_cia = 2 and cod_ramo = 228 
and nom_nemotecnico = 'VAL_MAXIMO_EDIF_CONT';

--- POLIZAS VIGENTES NO BLOQUEADAS O ANULADAS
select * from a2000030 where cod_cia = 2 and cod_ramo = 228
and mca_provisional = 'N' AND MCA_POLIZA_ANULADA = 'N' AND MCA_SPTO_ANULADO = 'N'
AND MCA_EXCLUSIVO = 'N'
AND TRUNC(FEC_EFEC_SPTO) >= TO_DATE('01/01/2022','DD/MM/YYYY') 
and num_poliza not in (select NUM_POLIZA from a2000030 where mca_poliza_anulada = 'S')
ORDER BY NUM_POLIZA ASC;

-- DESBLOQUEAR SINIESTROS
select mca_exclusivo from a7000900 where num_sini = 200121022000508
update a7000900 set mca_exclusivo = 'N' where num_sini = 200121022000508;
COMMIT;



select * from g2000020;

select * from a1001800 where cod_cia = 2 AND COD_RAMO = 260;

select distinct(cod_cia) from a1001800;

select * from a2000030 where cod_cia = 2 and cod_ramo = 260 
and trunc(fec_efec_spto) = to_date('11/08/2022', 'dd/mm/yyyy');
2602000004347;

tron2000.ed_k_260_ct_mgt;






create or replace procedure tron2000.tmp_p_ejecuta_traza(p_desc_traza varchar2, p_traza varchar2) is
pragma autonomous_transaction;
begin
  insert into tron2000.tmp_traz
  values (p_desc_traza, p_traza)
  commit;
end;

select * from g2000020;

select * from a1001800 where cod_cia = 2 AND COD_RAMO = 260;

select distinct(cod_cia) from a1001800;

select * from a2000030 where cod_cia = 2 and cod_ramo = 260 
and trunc(fec_efec_spto) >= to_date('01/08/2022', 'dd/mm/yyyy');
2602000004347;

tron2000.ed_k_260_ct_mgt;







create or replace procedure tron2000.tmp_p_ejecuta_traza(p_desc_traza varchar2, p_traza varchar2) is
pragma autonomous_transaction;
begin
  insert into tron2000.tmp_traz
  values (p_desc_traza, p_traza)
  commit;
end;
