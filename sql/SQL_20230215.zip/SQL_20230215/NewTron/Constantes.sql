l_tip_situacion_pago := em_k_ptd_atr.f_pre_constante('TIP_SITUACION_PAGO');
      l_cod_spto_canc      := em_k_ptd_atr.f_pre_constante('COD_SPTO_AT');
      l_cod_spto_rest      := em_k_ptd_atr.f_pre_constante('COD_SPTO_AP');
      --
      l_dias_cancelamento  := em_k_ptd_atr.f_pre_constante('DIAS_CANCELAMENTO');
      
      
      trp_xx_dl.em_k_ptd_atr;
      
      
      FUNCTION f_pre_constante (p_vrb_nam df_cmn_nwt_xx_cnn.vrb_nam%TYPE)
       RETURN df_cmn_nwt_xx_cnn.vrb_nam_val%TYPE IS
       ;
       
select * from tron2000.df_cmn_nwt_xx_cnn where cmp_val = 1 and vrb_nam in ('COD_SPTO_AT','COD_SPTO_AP' );


       
