-- TABLA DEFINICION MENSAJES PARA EVENTOS
-- EVN_IDN_VAL, CMP_VAL, VLD_DAT, VRS_IDN_VAL 
SELECT * 
  FROM TRON2000.DF_TRN_NWT_XX_EVN_MSG a
 WHERE a.cmp_val        = 1                                  -- (PK) COMPANIA
   --AND a.evn_idn_val    = 11                                 -- (PK) IDENTIFICADOR EVENTO
   AND a.evn_idn_nam    = 'ACEITA POLIZA'                  -- LIKE upper('ACEITA') --(PK) NOMBRE EVENTO
   AND a.vrs_idn_val    = 1                                -- (PK) IDENTIFICADOR VERSION
   --AND a.typ_dst_val    = 'MB'                               -- IDENTIFICADOR DESTINO
   --AND a.txt_que_val    = 'TRN_EVN_O'                        -- IDENTIFICADOR COLA
   --AND a.txt_top_val    = 'trnEvn'                           -- IDENTIFICADOR TOPIC
   --AND a.nam_prg_val    LIKE UPPER('%985%')                  -- PROCEDIMIENTO DINAMICO
   --AND a.stu_msg_val    IS NULL                              -- = '' ESTRUCTURA MENSAJE
   AND TRUNC(a.vld_dat) = TO_DATE('06/04/2022','DD/MM/YYYY') -- (PK) FECHA VALIDEZ
   --AND dsb_row          = 'N'                                -- FILA DESHABILITADA
   --AND a.usr_val        = 'ALMSOUZA'                         -- USUARIO QUE ACTUALIZO LA FILA
   --AND TRUNC(a.mdf_dat) = TO_DATE('06/04/2022','DD/MM/YYYY') -- FECHA MODIFICACION
;
