--DEFINICION FORMULA
/*CMP_VAL, LOB_VAL, MDT_VAL, CRN_VAL, CVR_VAL, FRS_LVL_VAL, SCN_LVL_VAL, 
THR_LVL_VAL, FRS_DST_HNL_VAL, SCN_DST_HNL_VAL, THR_DST_HNL_VAL, AGN_VAL, 
GPP_VAL, DEL_VAL, SBL_VAL, PLY_VAL, VRB_NAM, ROW_VAL, VLD_DAT  PK */

SELECT * 
  FROM TRON2000.DF_CMN_NWT_XX_VRB_CNC a
 WHERE a.cmp_val         = 1                                    -- (PK) COMPANIA 
   AND a.lob_val         = 417                                  -- (PK) RAMO
   AND a.mdt_val         = 99999                                -- (PK) MODALIDAD
   AND a.crn_val         = 99                                   -- (PK) MONEDA
   AND a.cvr_val         = 9999                                 -- (PK) COBERTURA
   AND a.frs_lvl_val     = 99                                   -- (PK) PRIMER NIVEL
   AND a.scn_lvl_val     = 999                                  -- (PK) SEGUNDO NIVEL
   AND a.thr_lvl_val     = 9999                                 -- (PK) TERCER NIVEL
   AND a.frs_dst_hnl_val = 'ZZZZ'                               -- (PK) PRIMER CANAL DISTRIBUCION
   AND a.scn_dst_hnl_val = 'ZZZZ'                               -- (PK) SEGUNDO CANAL DISTRIBUCION
   AND a.thr_dst_hnl_val = 'ZZZZ'                               -- (PK) TERCER CANAL DISTRIBUCION
   AND a.agn_val         = 99999                                -- (PK) AGENTE
   AND a.gpp_val         = 'ZZZZZZZZZZZZZ'                      -- (PK) POLIZA GRUPO
   AND a.del_val         = 99999                                -- (PK) ACUERDO (CONTRATO?)
   AND a.sbl_val         = 99999                                -- (PK) SUBACUERDO (SUBCONTRATO?)
   AND a.ply_val         = 'ZZZZZZZZZZZZZ'                      -- (PK) POLIZA
   AND a.vrb_nam         = 'MTV_X_RESTITUCAO'                   -- (PK) NOMBRE VARIABLE
   AND a.row_val         = 4                                    -- (PK) CODIGO FILA
   AND TRUNC(a.vld_dat)  = TO_DATE('01/01/2010','DD/MM/YYYY')   -- (PK) 
   --AND a.row_nam         = 'PROCESO RESTITUCAO'               -- NOMBRE FILA
   --AND a.row_val_val     = 'AP-558-4-2'                       -- VALOR FILA
   --AND a.dfl_chc         = 'N'                                -- DEFECTO
   --AND a.jmp_chc         = 'N'                                -- SALTO
   --AND a.dsb_row         = 'N'                                -- INHABILIADO
   --AND a.usr_val         = 'JVILLADA'                         -- USUARIO ACTUALIZA FILA
   --AND TRUNC(a.mdf_dat)  = TO_DATE('12/09/2022','DD/MM/YYYY') -- FECHA ACTUALIZACION DEL REGISTRO
;
