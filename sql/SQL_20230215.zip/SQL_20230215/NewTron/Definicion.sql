-- PAQUETE nwt_dl.dl_ply_gni
-- PARA INSERTAR EN TABLAS
PROCEDURE p_inr
-- PARA OBTENER DATOS
PROCEDURE p_get
-- PARA BORRAR
PROCEDURE p_dlt
-- PARA ACTUALIZAR
PROCEDURE p_upd
  


-- TIPO OBJETO
nwt_o.o_ply_gni_s

-- PARA LLAMAR A UN TIPO OBJETO SE DEFINE EN EL DECLARE EJEMPLO:
lv_o_ply_gni_s nwt_o.o_ply_gni_s;

-- PARA CREAR EL NUEVO OBJETO:
lv_o_ply_gni_s := NEW nwt_o.o_ply_gni_s ();

-- PARA RETORNARLO SE DEFINE EN LA FUNCION:
RETURN nwt_o.o_ply_gni_s

-- PARA RETORNAR EL OBJETO CREADO CON:
RETURN lv_o_ply_gni_s;

-- PARA OBTENER DATOS DE LA POLIZA (A2000030, ETC)
--p_get : ISU-37 - CONSULTAR informacion general poliza
nwt_dl.dl_ply_gni;
nwt_dl.dl_ply_gni.p_get
