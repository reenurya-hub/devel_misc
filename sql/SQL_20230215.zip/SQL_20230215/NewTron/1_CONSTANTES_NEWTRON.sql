       SELECT * FROM df_cmn_nwt_xx_cnn WHERE vrb_nam_val = '985';
       
       SELECT * FROM df_cmn_nwt_xx_cnn WHERE VRB_NAM = 'IDADE_MAX_PLENO';
