select * from all_tables where table_name LIKE UPPER('%NWT%');

select * from all_TAB_COMMENTS where table_name LIKE UPPER('%NWT%');

select * from all_TAB_COMMENTS WHERE TABLE_NAME IN 
(SELECT TABLE_NAME from all_tables where table_name LIKE UPPER('%NWT%')); 

select * from df_trn_nwt_xx_evn_def;
select * from tron2000.df_trn_nwt_xx_evn_msg where nam_prg_val LIKE UPPER('%985%');

select * from ml_trn_nwt_xx_evn_msg;
