-- TABLA BUZON MENSAJE PARA EVENTOS
-- EVN_IDN_VAL, CMP_VAL, SCN_IDN_VAL PK
SELECT * 
  FROM TRON2000.ML_TRN_NWT_XX_EVN_MSG a
 WHERE a.cmp_val            = 1                                   -- PK COMPANIA                             
   AND a.evn_idn_val        = 1                                   -- PK IDENTIFICADOR EVENTO
   AND a.scn_idn_val        = 17                                  -- PK SECUENCIA
   --AND a.rcr_pss_chc        = 'S'                                 -- REGISTRO TRATADO
   --AND LOWER(a.evn_msg_val) LIKE('%event%')                       -- MENSAJE JSON
   --AND a.usr_val            = 'TRON2000'                          -- USUARIO QUE ACTUALIZO LA FILA
   AND TRUNC(a.mdf_dat)     = TO_DATE('04/05/2022','DD/MM/YYYY')  -- FECHA MODIFICACION
ORDER BY a.mdf_dat DESC
;
