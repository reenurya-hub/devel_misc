-- TABELA DE DEFINICAO DOS PACOTES PARA TRATAMENTO DE EVENTOS
-- COD_CIA, COD_RAMO, EVN_IDN_VAL PK
SELECT * 
  FROM TRON2000.DF_TRN_NWT_XX_EVN_DEF_VCR a
 WHERE a.cod_cia         = 1                                  -- COMPANIA
   AND a.cod_ramo        = 985                                -- RAMO
   AND a.evn_idn_val     = 13                                 -- NUMERO EVENTO
   AND a.vrs_idn_val     = 1                                  -- VERSION
   AND a.usr_val         = 'JGIRALDO'                         -- USUARIO
   AND TRUNC(a.fec_actu) = TO_DATE('06/05/2022','DD/MM/YYYY') -- FECHA ACTUALIZACION
   AND a.mca_baja        = 'N'                                -- MARCA SI SE HA DADO DE BAJA
 ;
