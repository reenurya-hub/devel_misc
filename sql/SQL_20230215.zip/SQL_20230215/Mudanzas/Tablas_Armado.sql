SELECT * FROM A1001800;--  Definicion y Creacion de un Ramo 
SELECT * FROM A1001801;--  Definicion de Tipos de Terceros que Intervienen en la poliza
SELECT * FROM A1002050;--  Definicion de Coberturas a Nivel Compa��a
SELECT * FROM A1002150;--  Definicion de Coberturas a Nivel de Ramo
SELECT * FROM G1002000;--  Definicion de Ramos Contables a Nivel Compa��a
SELECT * FROM A1002150;--  Definicion de Ramos Contables a Nivel de Ramo
SELECT * FROM G2990007;--  Definicion de Agrupamientos de coberturas a Nivel Compa��a
SELECT * FROM G2990008;--  Definicion de Agrupamientos de coberturas a Nivel Compa��a
SELECT * FROM G2990009;--  Definicion de Agrupamientos de coberturas a Nivel Compa��a
SELECT * FROM G2990010;--  Definicion de Agrupamientos de coberturas a Nivel Compa��a
SELECT * FROM A1002150;--  Definicion de Agrupamientos de coberturas a Nivel de Cobertura
SELECT * FROM G2000400;--  Definicion de Limites a Nivel Cobertura
SELECT * FROM A2100700;--  Definicion de Deducibles a Nivel Compa��a
SELECT * FROM A2100701;--  Definicion de Deducibles a Nivel Cobertura 
SELECT * FROM A2300102;--  Definicion de Deducibles Por Ramo, Modalidad, Cobertura
SELECT * FROM G2000010;--  Definicion de Datos Variables a Nivel de Compa��a
SELECT * FROM G2000020;--  Definicion de Datos Variables a Nivel de Poliza  
SELECT * FROM G2000020;--  Definicion de Datos Variables a Nivel de Riesgo 
SELECT * FROM G2000020;--  Definicion de Datos Variables a Nivel de Cobertura  
SELECT * FROM G2000020;--  Definicion de Datos Variables Tipo Listas (Poliza, Riesgo, Cobertura)
SELECT * FROM A2990210;--  Definicion de Datos Asociados a una lista de Valores
SELECT * FROM G2990006;--  Definicion de Listas de Valores de un Dato variable
SELECT * FROM A2990200;--  Definicion de Listas
SELECT * FROM G1010300;--  Definicion de Campos para ayuda en Datos variables
SELECT * FROM G1010310;--  Definicion de Condiciones para ayuda en Datos variables
SELECT * FROM G1010020;--  Definicion de Mensajes de Error
SELECT * FROM G1010021;--  Defincion de Etiquetas para Nombres de Campos 
SELECT * FROM G2999009;--  Definicion de Datos variables para salto de campos
SELECT * FROM G2990004;--  Definicion de Modalidades a Nivel Compa��a
SELECT * FROM A2100300;--  Definicion de Modalidades a por Ramo
SELECT * FROM A2100310;--  Definicion de Modalidades para Ramos de Autos
SELECT * FROM A2100210;--  Definicion de Modalidades por Ramo y Tipo de Vehiculo
SELECT * FROM G2000190;--  Definicion de Modalidades por Ramo , Cobertura , Desglose
SELECT * FROM A1002090;--  Definicion de Modalidades por Ramo y Cobertura
SELECT * FROM A1002091;--  Definicion de Modalidades por Ramo y Dato Variable
SELECT * FROM G2990005;--  Definicion de Parametros del Ramo
SELECT * FROM A9990010;--  Definicion de Clausulas a Nivel Compa��a
SELECT * FROM A9990011;--  Definicion de Textos Fijos y variables de la Clausulas  
SELECT * FROM A9990015;--  Definicion de Clausulas a nivel Ramo, Cobertura
SELECT * FROM A9990016;--  Definicion de Clausulas procedimientos
SELECT * FROM G2000161;--  Definicion de Conceptos Economicos  
SELECT * FROM G2000170;--  Definicion de Conceptos de Desglose a Nivel de Compa��a 
SELECT * FROM G2000180;--  Definicion de Conceptos de Desglose a Nivel de Ramo y Cobertura
SELECT * FROM G2000190;--  Definicion de Modificaciones de Conceptos de Desglose a Nivel de Ramo y Cobertura
SELECT * FROM A1001402;--  Definicion de las Formas de Pago 
SELECT * FROM A1001403;--  Definicion de las Formas de Pago por Ramo
SELECT * FROM A1001410;--  Definicion de los Planes de Pago
SELECT * FROM A1001420;--  Definicion de los Planes de Pago por Cuotas
SELECT * FROM A1001430;--  Definicion de los Planes de Pago por Gestor
SELECT * FROM A1001342;--  Definicion de Comisiones por Agente
SELECT * FROM A1001752;--  Definicion de los Cuadros de Comision
SELECT * FROM A1001750;--  Definicion de la Tabla de porcentajes de cuadros de comision
SELECT * FROM A1001760;--  Definicion de la Distribucion de la Comision
SELECT * FROM A2991800;--  Definicion de Codigos y Subcodigos de Suplementos
SELECT * FROM G2000275;--  Definicion de los Campos a Modificar en Suplementos
SELECT * FROM A2000400;--  Definicion de suplementos
SELECT * FROM G2990300;--  Definicion de Suplementos a nivel Ramo
SELECT * FROM G2000211;--  Definicion de los errores de Control Tecnico
SELECT * FROM G2000210;--  Definicion de Controles Tecnicos a Nivel de Compa��a
SELECT * FROM G2000200;--  Definicion de Controles Tecnicos a Nivel de Ramo
SELECT * FROM G2999017;--  Definicion de Controles Tecnicos por Ramo y Cobertura
SELECT * FROM G2000220;--  Definicion de Niveles de Salto de Control Tecnico
SELECT * FROM G2000230;--  Definicion de Niveles de Autorizacion de Control Tecnico por Usuario 
SELECT * FROM A2990570;--  Definicion de Control de Solicitudes
SELECT * FROM A2990575;--  Definicion de Control de Polizas
SELECT * FROM A2990565;--  Definicion de Reserva Numeros de Solicitud
SELECT * FROM A2990560;--  Definicion de Reserva Numeros de Poliza
SELECT * FROM A1002080;--  Definicion de Reaseguro por Ramo y Cobertura
SELECT * FROM G2000101;--  Definicion de Cuadros de Coaseguro
SELECT * FROM G2000102;--  Definicion de Porcentajes de Participacion Coaseguro
SELECT * FROM G2990002;--  Definicion de Polizas Cliente
SELECT * FROM G2990017;--  Definicion de Polizas Grupo 
SELECT * FROM G2990000;--  Definicion de Parametros de Contratos de Polizas Grupo
SELECT * FROM G2990001;--  Definicion de Contratos a Nivel de Compa��a
SELECT * FROM A2000010;--  Definicion de Contratos asociados a una Poliza Grupo
SELECT * FROM G2990027;--  Definicion de Contratos asociados a una Poliza Grupo
SELECT * FROM G2990021;--  Definicion de Contratos asociados a un ramo
SELECT * FROM G2000030;--  Procedimientos de PRE y POS campo para datos fijos
