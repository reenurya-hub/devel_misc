SELECT * FROM corpp0.a1009039_vcr WHERE cod_ramo = 734; --22
-- OJO TOCA VOLVER A SACAR LAS AYUDAS DE G2990006 PARA TIP_FINANC
select * from corpp0.g2990006 where cod_cia = 1 and cod_ramo = 734 and COD_CAMPO IN ('MCA_COMP_AQUISICAO','MCA_NUM_SERIE_CHASSI');--4
SELECT * FROM corpp0.a1002050 WHERE cod_cob IN (1296,1297);--0
SELECT * FROM corpp0.DF_CMN_NWT_XX_CNN WHERE lob_val = 734;--5
SELECT * FROM corpp0.G2002152 WHERE COD_cIA = 1 AND cod_ramo = 734;--8
SELECT * FROM corpp0.G2002154 WHERE COD_cIA = 1 AND cod_ramo = 734;--272
SELECT * FROM corpp0.A1002090 WHERE cod_ramo = 734;--18
SELECT * FROM corpp0.G2002153 WHERE COD_cIA = 1 AND cod_ramo = 734;--1
SELECT * FROM corpp0.g2000180 WHERE cod_ramo = 734;--9
SELECT * FROM corpp0.G2002159 WHERE COD_cIA = 1 AND cod_ramo = 734;--1
SELECT * FROM corpp0.g2000190 WHERE cod_ramo = 734;--9
SELECT * FROM corpp0.g1002000 WHERE cod_ramo_ctable = '030030734';--0
SELECT * FROM corpp0.a2100700 WHERE cod_franquicia IN (997,996,995,994);--0
SELECT * FROM corpp0.g1010020 WHERE COD_IDIOMA = 'PT' AND COD_MENSAJE = 99990834;--0
SELECT * FROM corpp0.a1001800 WHERE COD_CIA = 1 AND COD_RAMO = 734;--1
SELECT * FROM g2000010 WHERE  COD_CIA = 1 and cod_campo in (select cod_campo from g2000020 where cod_cia = 1 and cod_ramo = 734) and cod_campo NOT in (select cod_campo from g2000020 where cod_cia = 1 and cod_ramo != 734);--14
SELECT * FROM corpp0.g2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734;--55
SELECT * FROM corpp0.a2100701 WHERE COD_RAMO = 734;--0
SELECT * FROM corpp0.a1002150 WHERE COD_RAMO = 734;--9
select * from corpp0.G2009074_vcr;
