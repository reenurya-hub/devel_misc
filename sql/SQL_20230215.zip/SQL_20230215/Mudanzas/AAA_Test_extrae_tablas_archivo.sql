-- TENER EN CUENTA LOS SUFIJOS: _MGT = GUATEMALA, _VCR = BRASIL

-- x1009999_vcr Tabla para sacar los archivos por ftp, recordar quitar el nombre del archivo para volverlo a sacar
select * from tron2000.x1009999_mgt where txt_tarefa = 125;
select * from tron2000.x1009999_vcr ORDER by txt_tarefa;
select nom_arquivo from tron2000.x1009999_mgt where txt_tarefa = 125 order by num_secu;

select * from tron2000.x1009999_vcr ORDER by txt_tarefa;
select * from tron2000.x1009999_vcr where txt_tarefa = 100 and nom_tabla = 'G2992152_VCR' for update;
select * from tron2000.x1009999_vcr where txt_tarefa = 999 order by num_secu for update;


-- Genera los archivos DML 
begin
   tron2000.dc_k_exporta_dados_vcr.p_inicio(p_FEC_TRATAMIENTO => TO_DATE ('06062022' , 'MMDDYYYY'), p_txt_tarefa => '999' ) ; 
end;


declare
i integer;
begin
tron2000.dc_k_exporta_dados_vcr.p_inicio(p_FEC_TRATAMIENTO => TO_DATE ('06062022' , 'MMDDYYYY') , p_txt_tarefa => '999' ) ;
end;

