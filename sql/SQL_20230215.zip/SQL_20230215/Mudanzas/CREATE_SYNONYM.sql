CREATE OR REPLACE SYNONYM ed_k_734_df
                         FOR trp_xx_dl.ed_k_734_df_vcr;
