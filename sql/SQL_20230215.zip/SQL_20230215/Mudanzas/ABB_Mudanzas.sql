select * from g2000010 where cod_cia = 1 and cod_campo in (select cod_campo from g2000020 where cod_cia = 1 and cod_ramo = 734);
select * from g2000020 where cod_cia = 1 and cod_ramo = 734;
select * from g2990006 where cod_cia = 1 and cod_ramo = 734;
select * from g1010020 where cod_mensaje in (99990812,99990813,99990815,99990816,99990817,99990818,99990824,99990825,99990827,99990828,99990830,99990831,99990832,20098186,20098185,20098244,20098245);
select * from df_cmn_nwt_xx_cnn where vrb_nam in ('VAL_MAXIMO_COB_869','COD_MODALIDAD_NEMO','TIP_DOC_PESSOA_JURIDICA','TIP_FINANC_DOS_734','COD_VAL_TIP_FIN_DOS_734','DV_TIP_FINANC','COD_VAL_TIP_FIN_DOS_734','TIP_FINANC_TRES_734','COD_VAL_TIP_FIN_TRES_734');




PENHOR RUR - CED GAR CRED RUR.
select * from G2990006 where cod_campo = 'TIP_FINANC' AND COD_CIA = 1  for update;

CREATE OR REPLACE SYNONYM TRON2000.ed_k_734_coti
FOR  trp_xx_dl.ed_k_734_coti_vcr;
GRANT EXECUTE ON trp_xx_dl.ed_k_734_coti_vcr TO TRON2000, ANALISTAS, USUARIOS;
GRANT EXECUTE ON  tron2000.dc_k_ptd_int_vcr TO TRP_XX_DL;

-- 12/11/2021
DVS NUEVOS
MCA_COMP_AQUISICAO  = Comprova aquisi��o do Equipamento atrav�s de documento fiscal (Nota Fiscal)? (OBLIGATORIO)
MCA_NUM_SERIE_CHASSI = NR SERIE/CHASSI CORR PLAQUETA? TRONWEB (OBLIGATORIO)
-- ESTA NO MCA_FURTO_SIMPLES = Contrata Cobertura de Furto Simples? TRONWEB      ====> 962 FURTO SIMPLES (1297)
SELECT * FRoM G2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO IN ('MCA_COMP_AQUISICAO','MCA_NUM_SERIE_CHASSI');
delete from g2000020 WHERE COD_CIA = 1 AND COD_RAMO = 734 AND COD_CAMPO IN ('MCA_COMP_AQUISICAO','MCA_NUM_SERIE_CHASSI');
select * from g2990006 where cod_cia = 1 and cod_ramo = 734 and COD_CAMPO IN ('MCA_COMP_AQUISICAO','MCA_NUM_SERIE_CHASSI');

select * from G2009070_VCR FOR UPDATE;
ALTER TABLE TRON2000.G2009070_VCR ADD cod_agt NUMBER(6);
alter table TRON2000.G2009070_VCR
drop constraint SYS_C004462859 cascade;

alter table TRON2000.G2009070_VCR
add constraint SYS_C004462859 primary key (TIP_CLASSIFICACAO_CORRETOR, COD_EQUIPAMENTO, COD_CIA,cod_agt);
ALTER TABLE TRON2000.G2009070_VCR ADD constraint primary key(SYS_C004462859);

select * from a1001332;
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734


Estoy compartindo con usted los dados reales que tenemos que actualizar en las tablas g1001332_vcr (Classifica��o corretor),
 g2009071_vcr (Classes) e g2009072_vcr (Equipamento por Classe).
Los datos reales de la tabla g2009070_vcr estan en levantamiento pela unidad.
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734 AND COD_AGT=29671;
insert into g1001332_vcr (COD_CIA, COD_SECTOR, COD_RAMO, TIP_PRODUTO, COD_NIVEL1, COD_NIVEL2, COD_NIVEL3, COD_CANAL1, COD_CANAL2, COD_CANAL3, COD_AGT, COD_SUSEP, NUM_POLIZA_GRUPO, NUM_CONTRATO, NUM_SUBCONTRATO, NUM_POLIZA_CLIENTE, NUM_POLIZA, COD_MODALIDAD, TIP_SEGMENTO, TIP_CLASSIFICACAO_CORRETOR, MCA_CORRETOR_MAIS, FEC_VALIDEZ, MCA_BAJA, FEC_ACTU, COD_USR)
values (1, 30, 734, 99, 99, 999, 9999, 'ZZZZ', 'ZZZZ', 'ZZZZ', 
29671, '99999', '9999999999999', 99999, 99999, '9999999999999', '9999999999999', '99999', '9999999999', 'SI', 'N', to_date('01-01-2019', 'dd-mm-yyyy'), 'N', to_date('23-05-2021', 'dd-mm-yyyy'), 'AUTOMAT');

select * from g2009071_vcr where cod_cia = 1 and cod_classe = 4015; -- classe equipamento

insert into g2009071_vcr (COD_CIA, COD_CLASSE, NOM_CLASE, MCA_INH, COD_USR, FEC_ACTU)
values (1, 4015, 'COLHEITA', 'N', 'AUTOMAT', to_date('12-10-2021', 'dd-mm-yyyy'));

select * from g2009072_vcr WHERE COD_CIA = 1 AND COD_CLASSE = 4015 AND COD_EQUIPAMENTO = 1542; -- Equipamento por Classe

insert into g2009072_vcr (COD_CIA, COD_CLASSE, COD_EQUIPAMENTO, NOM_EQUIPAMENTO, MCA_INH, COD_USR, FEC_ACTU)
 values (1, 4015, 1542, 'COLHEITADEIRA DE GR�OS  Sem Plataforma', 'N', 'SVIDAL', to_date('12-10-2021', 'dd-mm-yyyy'));


-- 27/10/2021
trp_xx_dl.ed_k_734_utils_vcr;--Constantes y otras funciones
trp_xx_dl.ed_k_734_dv_vcr; -- datos variables
tron2000.dc_k_ptd_thp_vcr;-- PTD de cod_postal
tron2000.dc_k_ptd_int_vcr;-- PTD de corretor, cobertura etc
select * from g2000010 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'NUM_CONTR_FINANC_734';
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'NUM_CONTR_FINANC_734';
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'NUM_POL_ANT_MAPFRE';-- se quita el obligatorio
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'TIP_FINANC';
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'TIP_CLASSIF_CORRETOR_734';
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'NUM_PAC';
select * from g2990006 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'TIP_FINANC';
SELECT * FROM df_cmn_nwt_xx_cnn WHERE vrb_nam IN ('TIP_FINANC_UNO_734', 'COD_VAL_TIP_FIN_UNO_734', 'TIP_FINANC_DOS_734', 'COD_VAL_TIP_FIN_DOS_734',
'TIP_FINANC_TRES_734', 'COD_VAL_TIP_FIN_TRES_734', 'DV_TIP_FINANC');
SELECT * FROM g1010020 WHERE COD_MENSAJE IN (99990817);
SELECT * FROM df_cmn_nwt_xx_cnn WHERE vrb_nam IN ('TIP_FINANC_UNO_734', 'COD_VAL_TIP_FIN_UNO_734', 'TIP_FINANC_DOS_734', 'COD_VAL_TIP_FIN_DOS_734',
'TIP_FINANC_TRES_734', 'COD_VAL_TIP_FIN_TRES_734', 'DV_TIP_FINANC', 'VAL_PTC_AGRAVO_734');
insert into df_cmn_nwt_xx_cnn (CMP_VAL, LOB_VAL, MDT_VAL, CRN_VAL, CVR_VAL, FRS_LVL_VAL, SCN_LVL_VAL, THR_LVL_VAL, FRS_DST_HNL_VAL, SCN_DST_HNL_VAL, THR_DST_HNL_VAL, AGN_VAL, GPP_VAL, DEL_VAL, SBL_VAL, PLY_VAL, VRB_NAM, VRB_NAM_VAL, JMP_CHC, VLD_DAT, DSB_ROW, USR_VAL, MDF_DAT)
values (1, 999, 99999, 99, 9999, 99, 999, 9999, 'ZZZZ', 'ZZZZ', 'ZZZZ', 99999, 'ZZZZZZZZZZZZZ', 99999, 99999, 'ZZZZZZZZZZZZZ', 'VAL_PTC_AGRAVO_734', '60', 'N', to_date('01-01-2010', 'dd-mm-yyyy'), 'N', 'TRON2000', to_date('07-03-2019', 'dd-mm-yyyy'));



/*****************************************/
-- 21/10/2021
dc_k_ptd_int_vcr.sps
dc_k_ptd_int_vcr.spb
ed_k_734_dv_vcr.sps
ed_k_734_dv_vcr.spb
dc_k_ptd_thp_vcr.sps
dc_k_ptd_thp_vcr.spb
select * from g2000010 where  cod_cia = 1 and cod_campo IN( 'MCA_IOF_194','MCA_IOF_869', 'MCA_IOF_972');
--delete from  g2000020 where  cod_cia = 1 and cod_ramo = 734 and cod_campo = 'MCA_IOF';
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 and cod_campo IN ( 'MCA_IOF_194','MCA_IOF_869', 'MCA_IOF_972');
--delete from  g2000020 where  cod_cia = 1 and cod_ramo = 734 and cod_campo = ( 'COD_POSTAL','NOM_DOMICILIO1','NUM_APARTADO','NOM_COMPLEMENTO','COD_BAIRRO','COD_PROV_734','COD_ESTADO','COD_MICROREGIAO','TXT_MICROREGIAO');
select * from g2000020 where  cod_cia = 1 and cod_ramo = 734 and cod_campo IN ( 'COD_POSTAL','NOM_DOMICILIO1','NUM_APARTADO','NOM_COMPLEMENTO','COD_BAIRRO','COD_PROV_734','COD_ESTADO','COD_MICROREGIAO','TXT_MICROREGIAO');
--delete from  G2990006 where  cod_cia = 1 and cod_ramo = 734 and cod_campo = 'MCA_IOF';
select * from G2990006 where cod_cia = 1 and cod_ramo = 734 and cod_campo IN ( 'MCA_IOF_194','MCA_IOF_869', 'MCA_IOF_972');
SELECT * FROM g1010020 WHERE COD_MENSAJE IN (99990827, 99990828,99990829);



/****************************************************** OK OK OK OK OK 
--tablas pacote 05/10/2021
-- Todos los resgistros (validar con Bruna si el tip_classificacao_corretor c�mo va a quedar)
select * from g1001332_vcr where cod_cia = 1 and cod_ramo = 734;
-- paquete dv;
trp_xx_dl.ed_k_734_dv_vcr;
-- mensaje de error
select * from g1010020 where cod_mensaje in (99990817);
-- Se colocaron constantes en el utils
ED_K_734_UTILS_VCR
-- nuevo package para trabajar el tip_classificacao_corretor 
dc_k_ptd_int_vcr
-- Los sinonimos del paquete
CREATE OR REPLACE SYNONYM dc_k_ptd_int_vcr   FOR TRON2000.dc_k_ptd_int_vcr;   
GRANT EXECUTE ON  tron2000.dc_k_ptd_int_vcr TO TRP_XX_DL;
-- datos variables
select * from g2000020 where cod_cia = 1 and cod_ramo = 734 and cod_campo in ('TIP_CLASSIFICACAO_CORRECTOR', 'PCT_AGRAVO','NUM_PER_IDENITARIO');
-- Ayudas
select * from g2990006 where cod_cia = 1 and cod_ramo = 734 and cod_campo = 'NUM_PER_IDENITARIO';
*/
