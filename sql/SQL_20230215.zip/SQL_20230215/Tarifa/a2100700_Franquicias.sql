--tip_importe = 1 --Porcentaje
--tip_importe = 2 --importe
select * 
 from a2100700;