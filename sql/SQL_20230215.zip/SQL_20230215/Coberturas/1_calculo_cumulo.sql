-- PRIMERO SE CONSULTA LAS POLIZAS DEL ASEGURADO
-- Consulta cuantas polizas por asegurado homologacion
SELECT * FROM CORPP0.A2000030 WHERE COD_CIA = 1 AND COD_RAMO = 985 AND COD_DOCUM = '26166746881';
select * from a1001331 where cod_docum ='26166746881' ;
-- desarrollo
SELECT * FROM A2000030 WHERE COD_CIA = 1 AND COD_RAMO = 985 AND COD_DOCUM = '26166746881';
SELECT * FROM A2000030 WHERE COD_CIA = 1 AND COD_RAMO = 985 ORDER BY COD_DOCUM;

-- LUEGO SE CONSULTA LA SUMA ASEGURADA DE LAS POLIZAS
-- Consulta suma asegurada polizas del asegurado homologacion.
SELECT * FROM corpp0.A2000040 WHERE COD_CIA = 1 AND NUM_POLIZA IN ('4135000021077','4135000021177');
SELECT * FROM A2000040 WHERE COD_CIA = 1 AND NUM_POLIZA IN ('4135000021077','4135000021177');

-- Consulta suma asegurada polizas del asegurado desarrollo.
SELECT * FROM A2000040 
WHERE COD_CIA = 1 
AND NUM_POLIZA IN (SELECT num_poliza FROM A2000030 WHERE COD_CIA = 1 AND COD_RAMO = 985 AND COD_DOCUM = '10120060779');
--
SELECT sum(suma_aseg) FROM A2000040 
WHERE COD_CIA = 1 
AND NUM_POLIZA IN (SELECT num_poliza FROM A2000030 WHERE COD_CIA = 1 AND COD_RAMO = 985 AND COD_DOCUM = '10120060779');



SELECT * FROM A1001331 WHERE TIP_DOCUM = 'CPF' AND COD_DOCUM = '10120060779';

--linea 816 ahi esta el cursor
tron2000.EV_K_983_COB_VCR;

--
trp_xx_dl.ev_k_985_cob_vcr;

-- donde trae 
ev_k_901_utils;
ev_k_901_utils.gc_a2000060_30;

/* *********************************************************

ev_k_901_utils.gc_a2000060_30
 */
     SELECT a.tip_docum    ,
            a.cod_docum    ,
            a.num_riesgo   ,
            a.tip_relac    ,
            a.num_spto     ,
            a.num_spto_apli,
            a.num_apli     ,
            a.num_poliza   ,
            b.cod_ramo     ,
            b.fec_efec_spto,
            b.fec_vcto_spto
       FROM a2000060 a, a2000030 b
      WHERE a.cod_cia       = 1--p_cod_cia
        AND a.cod_docum     = '26166746881'--p_cod_docum
        AND a.tip_benef     = '2'--g_k_tip_aseg
        AND a.tip_relac     IN ('3','1')--(g_k_tip_relac_t, g_k_tip_relac_c)
        AND a.cod_cia       =  b.cod_cia
        AND a.num_poliza    = b.num_poliza
        AND a.num_spto      = b.num_spto
        AND a.num_apli      = b.num_apli
        AND a.num_spto_apli = b.num_spto_apli
        AND  EXISTS (SELECT c.*
                       FROM a2000030 c
                      WHERE a.cod_cia          = c.cod_cia
                        AND c.num_poliza       = a.num_poliza
                        AND c.num_spto         = 0--tron2000.em_k_a2000030.f_max_spto(1,num_poliza,null,null,null)-- (p_cod_cia, num_poliza, NULL,NULL,NULL)
                        AND c.cod_ramo         = 985--p_cod_ramo
                        AND a.num_apli         = c.num_apli
                        AND a.num_spto_apli    = c.num_spto_apli
                        AND c.num_apli         = 0--p_num_apli
                        AND c.num_spto_apli    = 0--p_num_spto_apli
                        AND mca_provisional    = 'N'--trn.NO
                        AND mca_poliza_anulada = 'N'--trn.NO
                        AND mca_baja           = 'N'--trn.NO
                        AND mca_vigente        = 'S'--trn.SI
                        AND SYSDATE BETWEEN b.fec_efec_poliza
                                        AND b.fec_vcto_poliza);


SELECT * FROM A2000060 WHERE COD_DOCUM = '26166746881';
SELECT * FROM A2000030 WHERE NUM_POLIZA IN ('540090805231','540014718631','6057001898831','540091679731','540015179531','4135000021077','4135000021177');

      SELECT DISTINCT a.cod_docum,
                      a.tip_docum,
                      a.num_riesgo,
                      a.tip_relac,
                      a.num_spto,
                      a.num_spto_apli,
                      a.num_apli,
                      b.num_poliza,
                      b.cod_ramo
        FROM a2000060 a, a2000030 b
       WHERE a.cod_cia = 1--pc_cod_cia
         AND a.cod_cia = b.cod_cia
         AND a.cod_docum = '26166746881' --pc_cod_docum
         AND a.tip_docum = 'CPF'--pc_tip_docum
         AND b.cod_ramo = 985--pc_cod_ramo
         AND a.num_poliza = b.num_poliza
         AND a.num_spto = b.num_spto
         AND a.num_apli = b.num_apli
         AND a.num_spto_apli = b.num_spto_apli
         AND a.mca_baja = 'N'--trn.NO
         AND a.mca_vigente = 'S'--trn.SI
         AND a.num_spto =
             (SELECT MAX(c.num_spto)
                FROM a2000060 c
               WHERE a.cod_cia = c.cod_cia
                 AND a.num_poliza = c.num_poliza
                 AND a.num_apli = c.num_apli
                 AND a.num_spto_apli = c.num_spto_apli)
            --AND a.num_spto     <= NVL(pc_num_spto,c.num_spto))
         AND a.num_apli = 0--pc_num_apli
         AND a.num_spto_apli = 0--pc_num_spto_apli
         AND a.tip_benef = '2'--em.TIP_BENEF_ASEGURADO
         AND SYSDATE BETWEEN b.fec_efec_spto AND b.fec_vcto_spto;
