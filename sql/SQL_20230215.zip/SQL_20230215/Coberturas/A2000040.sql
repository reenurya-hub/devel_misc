-- COBERTURAS DE LA POLIZA
-- NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, COD_RAMO                                              -- INDICE1
-- COD_CIA, COD_RAMO, NUM_POLIZA, NUM_SPTO                                                              -- INDICE2
-- NUM_POLIZA, COD_RAMO, COD_CIA, NUM_SPTO, NUM_RIESGO, MCA_VIGENTE, MCA_BAJA_RIESGO                    -- INDICE3
-- COD_CIA, NUM_POLIZA, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, NUM_SPTO                                   -- INDICE4
-- COD_CIA, NUM_POLIZA, NUM_SPTO, NUM_APLI, NUM_SPTO_APLI, NUM_RIESGO, NUM_PERIODO, COD_COB, COD_RAMO   -- PK
SELECT *
  FROM a2000040 a
 WHERE a.cod_cia       = 1                     -- INDICE
   AND a.num_poliza    = '4135000090177'       -- INDICE
   AND a.num_spto      = 0                     -- INDICE
   --AND a.num_apli      = 0                     -- INDICE
   --AND a.num_spto_apli = 0                     -- INDICE
   --AND a.num_riesgo    = 1                     -- INDICE
   --AND a.num_periodo   = 1                     -- INDICE
   --AND a.cod_cob       = 9011                  -- INDICE
   AND a.cod_ramo      = 985                   -- INDICE
   --AND a.mca_vigente   = 'S'
;
