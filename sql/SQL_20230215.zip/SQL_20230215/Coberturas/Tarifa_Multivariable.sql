select * from g2002050 where cod_Cia = 1 and cod_tarifa =734 for update;-- tabla de tarifa
select * from g2002051 where cod_Cia = 1 and cod_factor in (169,170);-- tabla de factores
select * from g2002150 where cod_Cia = 1 and cod_ramo = 734;-- tabla Factor X Desglose
select * from g2002151 where cod_Cia = 1 and cod_ramo = 734 and cod_desglose = 1;-- tabla Factor X Desglose X Campo
select * from g2002152 where cod_Cia = 1 and cod_ramo = 734 and cod_cob = 112;-- tabla orden
select * from g2002153 where cod_Cia = 1 and cod_ramo = 734 and cod_Cob = 112;-- tabla de factor inicial
select * from g2002154 where cod_Cia = 1 and cod_ramo = 734 and cod_desglose = 1 and cod_factor = 168 and cod_cob
=112;-- tablas de tasas
select * from g2002159 where cod_Cia = 1 and cod_ramo = 734;-- tabla Cobertua X tarifa
--factores copmpuestos
select * from tron2000.G2002151_VCR where cod_cia = 1 and cod_factor_compuesto = 1069 and cod_ramo = 734;--169 franquia ,170 factor pos
select * from tron2000.G2002154_VCR where cod_cia = 1 and cod_factor_compuesto = 1069 and cod_ramo = 734;
--desgloses
select * from g2000170 where cod_Cia = 1 and cod_desglose = 103 ;--Definciiopn por compania
select * from g2000180 where cod_Cia = 1 and cod_desglose = 103 ;--Desglose orden de ejecucion
select * from g2000180 where cod_Cia = 1 and cod_desglose = 103 ;--Definciiopn por ramo
--
select * from a2009170_VCR where cod_Cia = 1 and cod_r
--
trp_xx_dl.ed_k_734_dv;
