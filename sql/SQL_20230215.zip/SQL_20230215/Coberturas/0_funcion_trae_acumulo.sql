
ev_k_985_cob.p_v_acumulo_cob;

TRON2000.em_k_ptd_cvr_vcr;

em_k_ptd_cvr_vcr.f_con_acumulo_capital_segurado;


   FUNCTION f_con_acumulo_capital_segurado(
     p_cod_cia             IN a2000030.cod_cia%TYPE,
     p_cod_ramo            IN a2000030.cod_ramo%TYPE,
     p_tip_docum_aseg      IN a2000060.tip_docum%TYPE,
     p_cod_docum_aseg      IN a2000060.cod_docum%TYPE,
     p_fec_efec_poliza     IN a2000030.fec_efec_poliza%TYPE DEFAULT NULL,
     p_fec_vcto_poliza     IN a2000030.fec_vcto_poliza%TYPE DEFAULT NULL,
     p_num_cotizacion      IN a2000030.num_poliza%TYPE DEFAULT NULL,
     p_cod_docum_resp_fin  IN a2000030.cod_docum%TYPE DEFAULT  NULL,
     p_cod_docum_contrato  IN g2990000.cod_docum%TYPE DEFAULT  NULL,
     p_cod_cob             IN a2000040.cod_cob%TYPE DEFAULT NULL,
     p_suma_aseg           IN a2000040.suma_aseg%TYPE DEFAULT NULL
   )
