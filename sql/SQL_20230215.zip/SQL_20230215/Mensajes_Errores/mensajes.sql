--MENSAJES
--COD_MENSAJE, COD_IDIOMA
SELECT * 
  FROM g1010020
 WHERE cod_mensaje = 20095641 --INDICE, NUMBER
   AND cod_idioma  = 'PT' --INDICE
   AND cod_cia     = 1
   -- AND cod_instalacion = 'VCR'
;

SELECT * 
  FROM g1010020 
 WHERE UPPER(TXT_MENSAJE) LIKE '%CPF%';

select * from g1010020 where cod_mensaje in ('20095641','20095642');
