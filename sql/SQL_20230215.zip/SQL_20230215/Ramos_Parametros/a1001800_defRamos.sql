-- DEFINICION DE RAMOS
SELECT a.*
  FROM a1001800 a
 WHERE 1=1
   AND a.cod_cia = 2
   -- AND a.cod_sector = 0 --= a.cod_sector
   -- AND a.cod_subsector = 0 --= a.cod_subsector
   AND a.cod_ramo = 228
   -- AND a.nom_ramo = a.nom_ramo
   -- AND a.abr_ramo = a.abr_ramo
   -- AND a.mca_clausula = a.mca_clausula
   -- AND a.mca_anexo = a.mca_anexo
   -- AND a.mca_prorrata = a.mca_prorrata
   -- AND a.mca_cambia_prorrata = a.mca_cambia_prorrata
   -- AND a.mca_riesgos = a.mca_riesgos
   -- AND a.mca_periodos = a.mca_periodos
   -- AND a.mca_recibo_por_periodo = a.mca_recibo_por_periodo
   -- AND a.mca_emision = a.mca_emision
   -- AND a.mca_cambio_nivel_3 = a.mca_cambio_nivel_3
   -- AND a.mca_calcula_fracc_pago = a.mca_calcula_fracc_pago
   -- AND a.mca_spto_en_plan_pago = a.mca_spto_en_plan_pago
   -- AND a.mca_cambio_plan_pago = a.mca_cambio_plan_pago
   -- AND a.mca_certificados = a.mca_certificados
   -- AND a.mca_inh = a.mca_inh
   -- AND a.mca_comis_coa_ext = a.mca_comis_coa_ext
   -- AND a.mca_365_dias = a.mca_365_dias
   -- AND a.mca_obliga_presupuesto = a.mca_obliga_presupuesto
   -- AND a.mca_autoriza_presupuesto = a.mca_autoriza_presupuesto
   -- AND a.mca_cambio_num_poliza = a.mca_cambio_num_poliza
   -- AND a.mca_cambio_num_poliza_apli = a.mca_cambio_num_poliza_apli
   -- AND a.mca_val_stro_en_spto = a.mca_val_stro_en_spto
   -- AND a.mca_remesa_recibo = a.mca_remesa_recibo
   -- AND a.mca_recibo_manual = a.mca_recibo_manual
   -- AND a.mca_comis_manual = a.mca_comis_manual
   -- AND a.mca_busca_insp_emision = a.mca_busca_insp_emision
   -- AND a.mca_emision_sin_recibo = a.mca_emision_sin_recibo
   -- AND a.mca_reutiliza_presupuesto = a.mca_reutiliza_presupuesto
   -- AND a.mca_reutiliza_declaracion = a.mca_reutiliza_declaracion
   -- AND a.mca_aplica_at_en_riesgo = a.mca_aplica_at_en_riesgo
   -- AND a.tip_coaseguro_permitido = 0 --= a.tip_coaseguro_permitido
   -- AND a.mca_cuadro_coaseguro_obl = a.mca_cuadro_coaseguro_obl
   -- AND a.tip_primas_manuales = a.tip_primas_manuales
   -- AND a.num_agt = 0 --= a.num_agt
   -- AND a.num_riesgos_traspaso_directo = 0 --= a.num_riesgos_traspaso_directo
   -- AND a.num_riesgos_impresion = 0 --= a.num_riesgos_impresion
   -- AND a.nom_prg_riesgo = a.nom_prg_riesgo
   -- AND a.tip_formacion_modalidad = a.tip_formacion_modalidad
   -- AND a.cod_usr = 'TRON2000'
   -- AND a.TRUNC(fec_actu) = TO_DATE('01/01/2023','DD/MM/YYYY')
   -- AND a.nom_prg_busca_insp_emision = a.nom_prg_busca_insp_emision
   -- AND a.cod_tratamiento = a.cod_tratamiento
   -- AND a.cod_tratamiento_sini = a.cod_tratamiento_sini
   -- AND a.cod_tratamiento_ctable = a.cod_tratamiento_ctable
   -- AND a.nom_prg_emision_sin_recibo = a.nom_prg_emision_sin_recibo
   -- AND a.cod_proceso = a.cod_proceso
   -- AND a.cod_proceso_p = a.cod_proceso_p
   -- AND a.cod_proceso_r = a.cod_proceso_r
   -- AND a.cod_est_dv_poliza = a.cod_est_dv_poliza
   -- AND a.cod_est_riesgo = a.cod_est_riesgo
   -- AND a.cod_est_modalidad = a.cod_est_modalidad
   -- AND a.cod_est_accesorios = a.cod_est_accesorios
   -- AND a.cod_est_plan_pago = a.cod_est_plan_pago
   -- AND a.cod_est_inspec = a.cod_est_inspec
   -- AND a.nom_prg_coef_cob = a.nom_prg_coef_cob
   -- AND a.nom_prg_busca_insp = a.nom_prg_busca_insp
   -- AND a.nom_prg_excluye_insp = a.nom_prg_excluye_insp
   -- AND a.tip_dst_comis = 0 --= a.tip_dst_comis
   -- AND a.nom_prg_dst_comis = a.nom_prg_dst_comis
   -- AND a.nom_prg_remesa_recibo = a.nom_prg_remesa_recibo
   -- AND a.mca_mod_org_ase = a.mca_mod_org_ase
   -- AND a.mca_mod_com_cuota_interv = a.mca_mod_com_cuota_interv
   -- AND a.mca_rechazo_susp_a_todos = a.mca_rechazo_susp_a_todos
   -- AND a.mca_recalcula_comis = a.mca_recalcula_comis
   -- AND a.mca_registra_hora = a.mca_registra_hora
   -- AND a.tip_rea_permitido = 0 --= a.tip_rea_permitido
   -- AND a.mca_tasa_manual = a.mca_tasa_manual
   -- AND a.mca_des_por_riesgo_batch = a.mca_des_por_riesgo_batch
   -- AND a.mca_motivos_spto = a.mca_motivos_spto
   -- AND a.tip_acceso_com = a.tip_acceso_com
   -- AND a.mca_rechaza_suspende_apli = a.mca_rechaza_suspende_apli
   -- AND a.nom_prg_spto_plan_pago = a.nom_prg_spto_plan_pago
   -- AND a.mca_ct_en_anulacion_sptos = a.mca_ct_en_anulacion_sptos
   -- AND a.mca_cuenta_2902_tmp = a.mca_cuenta_2902_tmp
   -- AND a.mca_respeta_dia_vcto = a.mca_respeta_dia_vcto
   -- AND a.tip_formacion_imagen = a.tip_formacion_imagen
   -- AND a.mca_error_aviso_stro = a.mca_error_aviso_stro
   -- AND a.mca_val_stro_term_en_spto = a.mca_val_stro_term_en_spto
   -- AND a.mca_error_aviso_stro_term = a.mca_error_aviso_stro_term
   -- AND a.mca_anexo_ries = a.mca_anexo_ries
   -- AND a.mca_regenera_sptos_ct = a.mca_regenera_sptos_ct
   -- AND a.mca_comis_cartera = a.mca_comis_cartera
   -- AND a.nom_prg_cobro_recibo = a.nom_prg_cobro_recibo
   -- AND a.mca_modifica_cambio = a.mca_modifica_cambio
   -- AND a.nom_prg_valida_cambio = a.nom_prg_valida_cambio
   -- AND a.mca_val_fec_emision_estandar = a.mca_val_fec_emision_estandar
   -- AND a.nom_prg_val_fec_emi_estandar = a.nom_prg_val_fec_emi_estandar
   -- AND a.mca_tip_anexo = a.mca_tip_anexo
   -- AND a.mca_caucion = a.mca_caucion
   -- AND a.mca_gestion_fondo = a.mca_gestion_fondo
   -- AND a.mca_cal_imp_cob = a.mca_cal_imp_cob
   -- AND a.mca_copia_anexos_desde_ppto = a.mca_copia_anexos_desde_ppto
   -- AND a.mca_rea_externo = a.mca_rea_externo
   -- AND a.mca_crea_error_emi = a.mca_crea_error_emi
   -- AND a.mca_crea_error_sin = a.mca_crea_error_sin
   -- AND a.mca_multi_idioma_anexo = a.mca_multi_idioma_anexo
;

select * from a1001800
where cod_cia = 2
and cod_sector = 2
and cod_subsector = 21
and cod_ramo = 228
